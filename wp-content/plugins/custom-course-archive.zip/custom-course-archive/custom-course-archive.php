<?php
/**
 * Plugin Name: Custom Course Archive
 * Plugin URI: https://succeedlearn.com
 * Description: Advanced course archive with category sidebar, filters, and pagination
 * Version: 1.1.0
 * Author: Succeedtech Platform team
 * Text Domain: custom-course-archive
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CCA_VERSION', '1.1.0');
define('CCA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CCA_PLUGIN_URL', plugin_dir_url(__FILE__));

class Custom_Course_Archive {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    private function load_dependencies() {
        require_once CCA_PLUGIN_DIR . 'includes/class-course-query.php';
        require_once CCA_PLUGIN_DIR . 'includes/class-shortcode.php';
        require_once CCA_PLUGIN_DIR . 'includes/class-cca-term-meta.php';
    }
    
    private function init_hooks() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('init', array($this, 'register_shortcode'));
        add_action('init', array($this, 'init_term_meta'));
        add_filter('cca_course_category_taxonomy', array($this, 'use_learnpress_taxonomy'));
        add_action('wp_ajax_cca_filter_courses', array($this, 'ajax_filter_courses'));
        add_action('wp_ajax_nopriv_cca_filter_courses', array($this, 'ajax_filter_courses'));
    }
    
    public function enqueue_assets() {
        wp_enqueue_style(
            'cca-style',
            CCA_PLUGIN_URL . 'assets/css/style.css',
            array(),
            CCA_VERSION
        );
        
        wp_enqueue_script(
            'cca-script',
            CCA_PLUGIN_URL . 'assets/js/script.js',
            array('jquery'),
            CCA_VERSION,
            true
        );
        
        wp_localize_script('cca-script', 'ccaAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cca_nonce')
        ));
    }

    public function enqueue_admin_assets($hook) {
        // Only load on taxonomy term add/edit screens
        if ($hook !== 'edit-tags.php' && $hook !== 'term.php') {
            return;
        }
        $tax = isset($_GET['taxonomy']) ? sanitize_text_field($_GET['taxonomy']) : '';
        if (!in_array($tax, array('lp_course_category', 'course_category'), true)) {
            return;
        }
        wp_enqueue_style(
            'cca-admin-term-meta',
            CCA_PLUGIN_URL . 'assets/css/admin-term-meta.css',
            array(),
            CCA_VERSION
        );
    }
    
    public function register_shortcode() {
        add_shortcode('custom_course_archive', array('CCA_Shortcode', 'render'));
    }
    
    public function init_term_meta() {
        if (class_exists('CCA_Term_Meta')) {
            CCA_Term_Meta::init();
        }
    }
    
    /**
     * Use LearnPress course category taxonomy when present (Eduma theme).
     * So category sidebar and bulk section use the same categories you edit in admin.
     */
    public function use_learnpress_taxonomy($taxonomy) {
        if (taxonomy_exists('lp_course_category')) {
            return 'lp_course_category';
        }
        return $taxonomy;
    }
    
    public function ajax_filter_courses() {
        check_ajax_referer('cca_nonce', 'nonce');
        
        $category = isset($_POST['category']) ? intval($_POST['category']) : 0;
        $sort = isset($_POST['sort']) ? sanitize_text_field($_POST['sort']) : 'newest';
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        
        $query = new CCA_Course_Query();
        $results = $query->get_courses($category, $sort, $page);
        
        wp_send_json_success($results);
    }
}

Custom_Course_Archive::get_instance();


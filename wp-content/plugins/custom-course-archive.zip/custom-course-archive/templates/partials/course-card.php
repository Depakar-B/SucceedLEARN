<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="cca-course-card"
     data-course-title="<?php echo esc_attr(strtolower($course['title'])); ?>"
     data-sort-title="<?php echo esc_attr(strtolower($course['title'])); ?>"
     data-sort-date="<?php echo esc_attr(get_post_time('U', true, $course['id'])); ?>">
    <div class="cca-course-thumbnail">
        <a href="<?php echo esc_url($course['url']); ?>">
            <img src="<?php echo esc_url($course['thumbnail']); ?>"
                 alt="<?php echo esc_attr($course['title']); ?>"
                 onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'400\' height=\'200\'%3E%3Crect fill=\'%23f0f0f0\' width=\'400\' height=\'200\'/%3E%3Ctext fill=\'%23999\' font-family=\'Arial\' font-size=\'18\' x=\'50%25\' y=\'50%25\' text-anchor=\'middle\' dominant-baseline=\'middle\'%3ENo Image%3C/text%3E%3C/svg%3E';">
        </a>
    </div>

    <div class="cca-course-content">
        <h3 class="cca-course-title">
            <a href="<?php echo esc_url($course['url']); ?>">
                <?php echo esc_html($course['title']); ?>
            </a>
        </h3>

        <div class="cca-course-excerpt">
            <p class="cca-excerpt-text">
                <?php echo esc_html($course['excerpt']); ?>
            </p>
            <a href="<?php echo esc_url($course['url']); ?>" class="cca-read-more">
                <?php esc_html_e('Read More', 'custom-course-archive'); ?>
            </a>
        </div>

        <div class="cca-course-meta">
            <span class="cca-course-duration">
                <?php
                $duration_label = !empty($course['duration_label']) ? $course['duration_label'] : 'Total Duration';
                $duration_value = !empty($course['duration']) && $course['duration'] != 'N/A' ? $course['duration'] : '';

                if (!empty($duration_value)) {
                    echo '<strong>' . esc_html($duration_label) . ':</strong> <span class="cca-duration-value">' . esc_html($duration_value) . '</span>';
                }
                ?>
            </span>
            <span class="cca-course-price">
                <?php
                $price_display = !empty($course['price']) ? $course['price'] : 'Free';
                echo wp_kses_post($price_display);
                ?>
            </span>
        </div>

        <a href="<?php echo esc_url($course['url']); ?>" class="cca-course-link">
            <?php esc_html_e('View Course', 'custom-course-archive'); ?>
        </a>
    </div>
</div>

<!doctype html>
<html amp lang="en">
<head>
  <meta charset="utf-8">
  <title>Courses | SucceedLEARN</title>
  <link rel="canonical" href="<?php echo esc_url(get_permalink()); ?>">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">

  <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">

  <!-- AMP Boilerplate -->
  <style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>

  <!-- AMP Scripts -->
  <script async src="https://cdn.ampproject.org/v0.js"></script>
  <script async custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js"></script>
  <script async custom-element="amp-bind" src="https://cdn.ampproject.org/v0/amp-bind-0.1.js"></script>
  <script async custom-element="amp-selector" src="https://cdn.ampproject.org/v0/amp-selector-0.1.js"></script>
  <script async custom-element="amp-accordion" src="https://cdn.ampproject.org/v0/amp-accordion-0.1.js"></script>
  <script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
  <script async custom-element="amp-mustache" src="https://cdn.ampproject.org/v0/amp-mustache-0.2.js"></script>

  <?php do_action('amp_post_template_head', $this); ?>
  
  <style amp-custom>
    /* ========================================
       AMP Course Archive Styles
       ======================================== */
    
    * {
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Open Sans', sans-serif;
      margin: 0;
      padding: 0;
      background: #f5f7fa;
      color: #333;
    }

.empty-banner {
  margin: 10px;
  max-height: 40px !important;
  height: 40px !important;
}
/************************* Header *************************/
.site-header {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 60px;
  background-color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  z-index: 1000;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.site-header amp-img {
  height: 40px;
}

.menu-icon {
  font-size: 28px;
  cursor: pointer;
  color: #333;
}
	

/************************* Sidebar *************************/
amp-sidebar.sidebar-main {
  width: 260px;
  background: #ffffff;
  padding: 15px;
}

.sidebar-header {
  display: flex;
  justify-content: flex-end;
  font-size: 26px;
  cursor: pointer;
  margin-bottom: 10px;
}

/************************* Menu Sections *************************/
.menu-section {
  margin-bottom: 12px;
}

.menu-link {
  display: block;
  padding: 8px 0;
  text-decoration: none;
  color: #333;
  font-size: 16px;
font-weight:500;
  transition: color 0.2s ease;
}
.menu-link:hover {
  color: #1472ba;
}
	.menu-item-section,.section-solutions{
		padding: 0px !important;
	}
/************************* Accordion *************************/
amp-accordion section {
  border: none;
  margin: 0;
}

.submenu a {
  display: block;
  font-size: 16px;
  padding: 12px 0 12px 14px;
  margin: 2px 0;
  border-bottom: 2px solid #eee;
  color: #444444;
  text-decoration: none;
	font-weight: 500 !important;
}
.submenu a:active {
  color: #1472ba;
}
.menu-title, .title-about{
	background-color: #ffffff !important;
    padding: 12px 20px 12px 0px !important;;
    border: none !important;
	color: #444444 !important;
    font-size: 16px !important;
    font-weight: 500 !important;
	}
	
/* Add arrow to dropdown menu titles */
.menu-title {
    position: relative;
    cursor: pointer;
    padding-right: 20px; 
}

/* Arrow on the right */
.menu-title::after {
    content: '▼'; 
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    font-size: 12px;
    transition: transform 0.3s ease;
}

/* Arrow on the right (unchanged) */
.menu-title::after {
    content: '▼'; 
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    font-size: 12px;
    transition: transform 0.3s ease;
}

/* Rotate arrow when section is expanded */
amp-accordion section[expanded] .menu-title::after {
    transform: translateY(-50%) rotate(-180deg);
}


/************************* CTA Button *************************/
.cta-btn {
  display: block;
  background: #003f88;
  color: #fff;
  text-align: center;
  padding: 10px;
  border-radius: 4px;
  text-decoration: none;
  font-weight: bold;
  margin-top: 24px!important;
}
.cta-btn:hover {
  background: #002f66;
}

/************************* Contact Info *************************/
.menu-contact {
  font-size: 13px;
  margin-top: 10px;
  line-height: 1.4;
}
.menu-contact a {
     color: #1472ba !important;
    text-decoration: none;
    font-size: 16px !important;
    font-weight: 500 !important;
	margin-top: 18px !important
}
.hidden-phone {
  display: none;
}
	.contact-email{
		text-align: center !important;
	}
/************************* Utility *************************/
.text-small {
  font-size: 13px;
}
.text-muted {
  color: #777;
}
	
	/*********************Scroll to top ****************************/
.scroll-top-btn {
    position: fixed;
    bottom: 25px;
    right: 25px;
    width: 32px;
    height: 32px;
    background-color: #ffffff;
    border: 2px solid #003f88; /* button border */
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    z-index: 9999;
    box-shadow: 0 3px 6px rgba(0,0,0,0.15);
    opacity: 0.85;
    transition: transform 0.2s ease, opacity 0.3s ease;
}

.scroll-top-btn:hover {
    opacity: 1;
    transform: translateY(-2px);
}

/* Hollow V arrow using rotated borders */
.arrow-up {
    display: block;
    width: 8px;
    height: 8px;
    border-left: 2px solid #003f88;
    border-bottom: 2px solid #003f88;
    transform: rotate(135deg); /* rotate to make V point up */
}
	
	
/************************Cookiee ************************/
	


	
  /************************Footer************************/
  .site-footer {
  background-color: #f5f7fa;
  padding: 40px 0 0 0;
  color: #333;
  text-align: center;
}

.footer-section {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0px 20px 20px 20px;
}

.footer-subtopic {
  font-size: 1.3em;
  color: #222;
  margin-bottom: 12px;
}

.footer-links,
.contact-info {
  list-style: none;
  padding: 0;
  margin: 0;
}

.footer-inner {
  max-width: 1200px;
  margin: 0 auto 30px auto;
  padding: 0 20px;
  text-align: left;
}

.footer-inner .footer-logo {
  display: block;
  margin-bottom: 12px;
}

.footer-description {
  max-width: 500px;
  font-size: 14px;
  color: #555;
  line-height: 1.6;
}
.footer-highlight-link {
  color: #1472ba;
  text-decoration: none;
  font-weight: 600; 
}

  .footer-subtopic {
    font-size: 1.3em;
    color: #222;
    margin-bottom: 12px;
  }

  .footer-links {
    list-style: none;
    padding: 0;
    margin: 0;
  }
.footer-link {
  text-decoration: none;
  color: inherit;
}

  .footer-links li {
    margin: 6px 0;
  }

  .footer-links a {
    text-decoration: none;
    color: #333;
    transition: color 0.3s ease;
  }

  .contact-info {
    list-style: none;
    padding: 0;
    margin: 0;
    color: #555;
  }

  .contact-info li {
    margin: 8px 0;
  }

  .no-style-link {
    color: inherit;
    text-decoration: none;
    cursor: pointer;
  }

  .social-icons {
    display: flex;
    gap: 14px;
    margin-top: 15px;
	  justify-content:center;
  }

  .social-icons a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #e9ecef;
    padding: 6px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
  }

  .footer-bottom {
    text-align: center;
	   position: static !important;
    font-size: 0.9em;
    color: #ffffff;
    padding: 10px 0px;
    border-top: 1px solid #ccc;
    margin-top: 20px;
	 background-color:#1472ba;
  }
    
    /* Main Container */
    .cca-amp-container {
      max-width: 1400px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .cca-amp-wrapper {
      display: flex;
      gap: 20px;
      align-items: flex-start;
    }
    
    /* ========================================
       Sidebar Styles
       ======================================== */
    .cca-amp-sidebar-wrapper {
      width: 280px;
      flex-shrink: 0;
      position: sticky;
      top: 85px;
      z-index: 10;
    }
    
    .cca-amp-sidebar {
      background: #fff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    }
    
    .cca-amp-sidebar-title {
      font-size: 1.3em;
      margin: 0px 16px;
      padding: 20px 15px;
		border-radius:8px;
      color: #fff;
      text-align: center;
      background: linear-gradient(to right, #576094, #915ebd);
    }
    
    .cca-amp-category-list {
      list-style: none;
      padding: 16px;
      margin: 0;
    }
    
    .cca-amp-category-item {
      margin: 0;
      padding: 0;
		margin-top:12px;
    }
    
    .cca-amp-category-link {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 15px;
      text-decoration: none;
      color: #555;
      transition: all 0.3s ease;
      font-size: 0.95em;
      cursor: pointer;
      border: none;
      background: transparent;
      width: 100%;
      text-align: left;
      font-family: inherit;
      -webkit-appearance: none;
      appearance: none;
    }
    
    .cca-amp-category-link:hover,
    .cca-amp-category-link[selected],
    .cca-amp-category-link.active {
      background: #0073aa;
      color: #fff;
		border-radius:4px;
    }
    
    .cca-amp-category-count {
      font-size: 0.85em;
      opacity: 0.7;
    }
    
    /* ========================================
       Content Area Styles
       ======================================== */
    .cca-amp-content {
      flex: 1;
      min-width: 0;
    }
    
    /* Filter Bar */
    .cca-amp-filter-bar {
      background: linear-gradient(to right, #576094, #915ebd);
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 25px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 20px;
      flex-wrap: wrap;
    }
    
    .cca-amp-search-wrapper {
      position: relative;
      flex: 1;
      min-width: 200px;
      max-width: 400px;
    }
    
    .cca-amp-search-input {
      width: 100%;
      padding: 12px 15px 12px 45px;
      border: 2px solid #e0e0e0;
      border-radius: 6px;
      font-size: 0.95em;
      background: #fff;
      outline: none;
      text-transform: lowercase;
    }
    
    .cca-amp-search-input:focus {
      border-color: #0073aa;
    }
    
    .cca-amp-search-input::placeholder {
      text-transform: none;
    }
    
    .cca-amp-search-icon {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      width: 20px;
      height: 20px;
      color: #999;
    }
    
    .cca-amp-sort-wrapper {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    .cca-amp-sort-label {
      color: #fff;
      font-size: 0.95em;
      white-space: nowrap;
    }
    
    .cca-amp-sort-links {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      align-items: center;
    }
    
    .cca-amp-sort-link {
      padding: 8px 14px;
      border-radius: 6px;
      font-size: 0.9em;
      background: rgba(255,255,255,0.2);
      color: #fff;
      text-decoration: none;
      border: 1px solid rgba(255,255,255,0.4);
      transition: background 0.2s ease;
    }
    
    .cca-amp-sort-link:hover,
    .cca-amp-sort-link.active {
      background: #fff;
      color: #576094;
      border-color: #fff;
    }
    
    /* Desktop: sort + reset group on its own row; reset on next line, wider */
    .cca-amp-sort-reset-group {
      display: flex;
      flex-direction: column;
      align-items: stretch;
      gap: 12px;
      width: 100%;
      margin-left: 0;
    }
    
    .cca-amp-reset-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 24px;
      min-width: 220px;
      width: 100%;
      max-width: 320px;
      background: rgba(255,255,255,0.25);
      color: #fff;
      font-size: 0.95em;
      font-weight: 600;
      text-decoration: none;
      border-radius: 6px;
      border: 1px solid rgba(255,255,255,0.5);
      transition: background 0.2s ease;
    }
    
    .cca-amp-reset-btn:hover {
      background: #fff;
      color: #576094;
      border-color: #fff;
    }

    /* Bulk / full category purchase section (AMP) */
    .cca-amp-bulk-purchase {
      width: 100%;
      margin: 0 0 25px;
      background: linear-gradient(135deg, #576094 0%, #915ebd 100%);
      border-radius: 10px;
      padding: 20px 22px;
      box-shadow: 0 3px 15px rgba(0,0,0,0.1);
      box-sizing: border-box;
      color: #fff;
    }

    .cca-amp-bulk-title {
      margin: 0 0 10px;
      font-size: 1.2em;
      font-weight: 700;
      color: #fff;
    }

    .cca-amp-bulk-desc,
    .cca-amp-bulk-intro {
      margin: 0 0 10px;
      font-size: 0.95em;
      line-height: 1.5;
      color: rgba(255,255,255,0.95);
    }

    .cca-amp-bulk-price {
      margin: 0 0 14px;
      font-size: 1.2em;
      font-weight: 700;
      color: #fff;
    }

    .cca-amp-bulk-btn {
      display: inline-block;
      padding: 12px 20px;
      background: #fff;
      color: #576094;
      font-weight: 600;
      text-decoration: none;
      border-radius: 6px;
    }
    
    /* ========================================
       Category Sections (single-page layout)
       ======================================== */
    .cca-amp-courses-sections {
      width: 100%;
      margin-bottom: 40px;
    }

    .cca-amp-category-section {
      margin-bottom: 48px;
      scroll-margin-top: 120px;
    }

    .cca-amp-category-section[id]::before,
    #cca-courses-sections::before {
      display: block;
      content: "";
      height: 120px;
      margin-top: -120px;
      visibility: hidden;
      pointer-events: none;
    }

    .cca-amp-category-section:last-child {
      margin-bottom: 0;
    }

    .cca-amp-category-section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      padding: 18px 24px;
      border-radius: 10px;
      margin-bottom: 24px;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.08);
      background: linear-gradient(to right, #576094, #915ebd);
    }

    .cca-amp-category-section-title {
      margin: 0;
      font-size: 1.35em;
      font-weight: 700;
      color: #fff;
      line-height: 1.3;
    }

    .cca-amp-category-section-count {
      flex-shrink: 0;
      font-size: 0.9em;
      font-weight: 600;
      color: rgba(255, 255, 255, 0.92);
      background: rgba(255, 255, 255, 0.18);
      padding: 6px 14px;
      border-radius: 999px;
      white-space: nowrap;
    }

    .cca-amp-category-section .cca-amp-bulk-purchase {
      margin-top: -8px;
    }

    /* ========================================
       Course Grid Styles
       ======================================== */
    .cca-amp-courses-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 25px;
    }
    
    .cca-amp-course-card {
      background: #fff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 10px rgba(0,0,0,0.08);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      padding-top: 12px;
    }
    
    .cca-amp-course-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }
    
    .cca-amp-course-card[hidden],
    .cca-amp-course-card.amp-hidden {
      display: none !important;
    }
    
    .cca-amp-course-thumbnail {
      position: relative;
      overflow: hidden;
      background: #f0f0f0;
      height: 220px;
      width: 100%;
    }
    
    .cca-amp-course-thumbnail a {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
    }
    
    .cca-amp-course-thumbnail amp-img {
      object-fit: cover;
      object-position: center;
    }
    
    .cca-amp-course-thumbnail amp-img img {
      object-fit: cover;
      object-position: center;
    }
    
    .cca-amp-course-content {
      padding: 20px;
    }
    
    .cca-amp-course-title {
      font-size: 1.1em;
      margin: 0 0 10px;
      line-height: 1.4;
    }
    
    .cca-amp-course-title a {
      color: #333;
      text-decoration: none;
    }
    
    .cca-amp-course-title a:hover {
      color: #0073aa;
    }
    
    .cca-amp-course-excerpt {
      font-size: 0.9em;
      color: #666;
      line-height: 1.6;
      margin-bottom: 8px;
    }
    
    .cca-amp-read-more {
      display: inline-block;
      font-size: 0.9em;
      color: #0073aa;
      text-decoration: none;
      margin-bottom: 12px;
      font-weight: 500;
    }
    
    .cca-amp-read-more:hover {
      text-decoration: underline;
    }
    
    .cca-amp-course-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 8px;
      padding: 10px 0;
      border-top: 1px solid #eee;
      margin-bottom: 15px;
      font-size: 1em;
    }
    
    .cca-amp-course-duration {
      color: #666;
      font-size: 1em;
    }
    
    .cca-amp-course-duration .cca-amp-duration-label {
      font-weight: 600;
      font-size: 1em;
    }
    
    .cca-amp-course-duration .cca-amp-duration-value {
      font-size: 1em;
    }
    
    .cca-amp-course-price {
      font-weight: 600;
      color: #0073aa;
      font-size: 1.1em;
    }
    
    .cca-amp-course-price.free {
      color: #28a745;
      font-size: 1.1em;
    }
    
    .cca-amp-course-link {
      display: block;
      width: 100%;
      padding: 12px 20px;
      background: #0073aa;
      color: #fff;
      text-align: center;
      text-decoration: none;
      border-radius: 6px;
      font-weight: 600;
      transition: background 0.3s ease;
    }
    
    .cca-amp-course-link:hover {
      background: #005a87;
    }
    
    /* No Courses Message */
    .cca-amp-no-courses {
      text-align: center;
      padding: 60px 20px;
      background: #fff;
      border-radius: 8px;
      grid-column: 1 / -1;
    }
    
    .cca-amp-no-courses p {
      color: #666;
      font-size: 1.1em;
    }
    
    /* ========================================
       Pagination Styles
       ======================================== */
    .cca-amp-pagination {
      margin-top: 40px;
      display: flex;
      justify-content: center;
    }
    
    .cca-amp-page-numbers {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      justify-content: center;
    }
    
    .cca-amp-page-numbers li {
      margin: 0;
    }
    
    .cca-amp-page-number,
    .cca-amp-page-prev,
    .cca-amp-page-next {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 40px;
      height: 40px;
      padding: 0 12px;
      background: #fff;
      color: #333;
      text-decoration: none;
      border-radius: 6px;
      font-size: 0.95em;
      transition: all 0.3s ease;
    }
    
    .cca-amp-page-number:hover,
    .cca-amp-page-prev:hover,
    .cca-amp-page-next:hover {
      background: #0073aa;
      color: #fff;
    }
    
    .cca-amp-page-number.active {
      background: #0073aa;
      color: #fff;
    }
    
    /* ========================================
       Mobile Sidebar (AMP Sidebar) & Category Menu
       ======================================== */
    .cca-amp-mobile-menu-btn {
      display: none;
      padding: 14px 18px;
      background: linear-gradient(to right, #576094, #915ebd);
      color: #fff;
      border: none;
      border-radius: 8px;
      font-size: 1.05em;
      font-weight: 600;
      cursor: pointer;
      margin-bottom: 18px;
      width: 100%;
      text-align: center;
      box-shadow: 0 2px 8px rgba(87, 96, 148, 0.3);
    }
    
    .cca-amp-mobile-menu-btn::before {
      content: "☰ ";
      font-size: 1.2em;
      margin-right: 6px;
    }
    
    .cca-amp-mobile-category-bar {
      display: none;
      margin-bottom: 15px;
    }
    
    amp-sidebar {
      width: 300px;
      max-width: 85vw;
      background: #fff;
    }
    
    amp-sidebar .cca-amp-sidebar {
      box-shadow: none;
      border-radius: 0;
    }
    
    .cca-amp-sidebar-close {
      display: block;
      width: 100%;
      padding: 15px 20px;
      text-align: right;
      background: #f5f5f5;
      border: none;
      font-size: 1.5em;
      cursor: pointer;
      font-weight: 300;
    }
    
    /* ========================================
       AMP Selector Styles
       ======================================== */
    amp-selector[role="listbox"] {
      display: block;
    }
    
    amp-selector [option] {
      outline: none;
    }
    
    amp-selector [option][selected] {
      background: #0073aa;
      color: #fff;
    }
    
    /* ========================================
       Responsive Styles
       ======================================== */
    @media (max-width: 1024px) {
      .cca-amp-wrapper {
        flex-direction: column;
      }
      
      .cca-amp-sidebar-wrapper {
        display: none;
      }
      
      .cca-amp-mobile-menu-btn,
      .cca-amp-mobile-category-bar {
        display: block;
      }
      
      .cca-amp-content {
        width: 100%;
      }
      
      /* Tablet: sort left, reset right (inline), reset small width */
      .cca-amp-sort-reset-group {
        flex-direction: row;
        width: auto;
        margin-left: auto;
        align-items: center;
      }
      
      .cca-amp-reset-btn {
        min-width: 0;
        max-width: none;
        width: auto;
        padding: 8px 16px;
        font-size: 0.9em;
      }
    }
    
    @media (max-width: 768px) {
      .cca-amp-filter-bar {
        flex-direction: column;
        align-items: stretch;
      }
      
      .cca-amp-search-wrapper {
        max-width: 100%;
      }
      
      /* Mobile: sort and reset on different lines (stacked) */
      .cca-amp-sort-reset-group {
        flex-direction: column;
        width: 100%;
        margin-left: 0;
        align-items: stretch;
      }
      
      .cca-amp-reset-btn {
        width: 100%;
        max-width: none;
        padding: 12px 20px;
      }
      
      .cca-amp-sort-wrapper {
        width: 100%;
      }
      
      .cca-amp-sort-links {
        flex: 1;
      }
      
      .cca-amp-category-section-header {
        flex-direction: column;
        align-items: flex-start;
        padding: 16px 18px;
      }

      .cca-amp-category-section-title {
        font-size: 1.15em;
      }

      .cca-amp-courses-grid {
        grid-template-columns: 1fr;
      }
      
      .cca-amp-course-thumbnail {
        height: 200px;
      }
      
      .cca-amp-course-excerpt,
      .cca-amp-read-more,
      .cca-amp-course-meta {
        display: block !important;
      }
      
      .cca-amp-course-meta {
        display: flex !important;
      }
    }
    
    @media (max-width: 480px) {
      .cca-amp-container {
        padding: 15px 10px;
      }
    }
  </style>

  <!-- Schema Markup -->
  <script type="application/ld+json">
  {
    "@context": "http://schema.org",
    "@type": "CollectionPage",
    "name": "Courses - SucceedLEARN",
    "url": "<?php echo esc_url(get_permalink()); ?>",
    "description": "Browse our collection of professional courses"
  }
  </script>
</head>
<body>
<section class="empty-banner" aria-label="Security Awareness Banner">
  </section>
<?php
$query = new CCA_Course_Query();
$categories = $query->get_all_categories();
$current_sort = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'newest';
$category_sections = $query->get_courses_grouped_by_category($current_sort);
$has_courses = !empty($category_sections);
$reset_url = get_permalink();
$sort_base_url = get_permalink();
?>

<!-- AMP State for client-side search -->
<amp-state id="courseFilter">
  <script type="application/json">
  { "search": "" }
  </script>
</amp-state>

<!-- ✅ AMP Sidebar/Menu (your existing menu) -->
<?php 
if (file_exists(plugin_dir_path(__FILE__) . 'menu.php')) {
    include(plugin_dir_path(__FILE__) . 'menu.php'); 
}
?>

<!-- Mobile Category Sidebar -->
<amp-sidebar id="category-sidebar" layout="nodisplay" side="left">
  <button class="cca-amp-sidebar-close" on="tap:category-sidebar.close">×</button>
  <div class="cca-amp-sidebar">
    <h3 class="cca-amp-sidebar-title">Categories</h3>
    <ul class="cca-amp-category-list">
      <li class="cca-amp-category-item">
        <button
          type="button"
          class="cca-amp-category-link active"
          on="tap:category-sidebar.close, AMP.scrollTo(id='cca-courses-sections', duration=400, position='top')"
        >
          All Courses
        </button>
      </li>
      <?php foreach ($categories as $cat) :
        if ((int) $cat->count < 1) {
            continue;
        }
        $section_id = 'cca-category-' . $cat->slug;
      ?>
        <li class="cca-amp-category-item">
          <button
            type="button"
            class="cca-amp-category-link"
            on="tap:category-sidebar.close, AMP.scrollTo(id='<?php echo esc_attr( $section_id ); ?>', duration=400, position='top')"
          >
            <?php echo esc_html($cat->name); ?>
            <span class="cca-amp-category-count">(<?php echo (int) $cat->count; ?>)</span>
          </button>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</amp-sidebar>

<!-- Main Content -->
<div class="cca-amp-container">
  <div class="cca-amp-wrapper">
    
    <!-- Desktop Sidebar -->
    <aside class="cca-amp-sidebar-wrapper">
      <div class="cca-amp-sidebar">
        <h3 class="cca-amp-sidebar-title">Categories</h3>
        <ul class="cca-amp-category-list">
          <li class="cca-amp-category-item">
            <button
              type="button"
              class="cca-amp-category-link active"
              on="tap:AMP.scrollTo(id='cca-courses-sections', duration=400, position='top')"
            >
              All Courses
            </button>
          </li>
          <?php foreach ($categories as $cat) :
            if ((int) $cat->count < 1) {
                continue;
            }
            $section_id = 'cca-category-' . $cat->slug;
          ?>
            <li class="cca-amp-category-item">
              <button
                type="button"
                class="cca-amp-category-link"
                on="tap:AMP.scrollTo(id='<?php echo esc_attr( $section_id ); ?>', duration=400, position='top')"
              >
                <?php echo esc_html($cat->name); ?>
                <span class="cca-amp-category-count">(<?php echo (int) $cat->count; ?>)</span>
              </button>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </aside>

    <!-- Content Area -->
    <main class="cca-amp-content">
      
      <!-- Mobile Category Menu (visible only on mobile) -->
      <div class="cca-amp-mobile-category-bar">
        <button class="cca-amp-mobile-menu-btn" on="tap:category-sidebar.open" aria-label="Open category menu">
          Categories
        </button>
      </div>
      
      <!-- Filter Bar -->
      <div class="cca-amp-filter-bar">
        <div class="cca-amp-search-wrapper">
          <svg class="cca-amp-search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          <input type="text" 
                 id="course-search"
                 class="cca-amp-search-input" 
                 placeholder="Search courses..."
                 on="input-debounced:AMP.setState({courseFilter: {search: event.value}})"
                 [value]="courseFilter.search">
        </div>
        
        <div class="cca-amp-sort-reset-group">
          <div class="cca-amp-sort-wrapper">
            <span class="cca-amp-sort-label">Sort by:</span>
            <div class="cca-amp-sort-links">
              <a href="<?php echo esc_url(add_query_arg('sort', 'newest', $sort_base_url)); ?>"
                 class="cca-amp-sort-link<?php echo $current_sort === 'newest' ? ' active' : ''; ?>" target="_top">Newest</a>
              <a href="<?php echo esc_url(add_query_arg('sort', 'oldest', $sort_base_url)); ?>"
                 class="cca-amp-sort-link<?php echo $current_sort === 'oldest' ? ' active' : ''; ?>" target="_top">Oldest</a>
              <a href="<?php echo esc_url(add_query_arg('sort', 'a-z', $sort_base_url)); ?>"
                 class="cca-amp-sort-link<?php echo $current_sort === 'a-z' ? ' active' : ''; ?>" target="_top">A–Z</a>
              <a href="<?php echo esc_url(add_query_arg('sort', 'z-a', $sort_base_url)); ?>"
                 class="cca-amp-sort-link<?php echo $current_sort === 'z-a' ? ' active' : ''; ?>" target="_top">Z–A</a>
            </div>
          </div>
          <a href="<?php echo esc_url($reset_url); ?>"
             class="cca-amp-reset-btn"
             on="tap:AMP.setState({courseFilter: {search: ''}})"
             target="_top">Reset</a>
        </div>
      </div>

      <div class="cca-amp-courses-sections" id="cca-courses-sections">
        <?php if ($has_courses) : ?>
          <?php foreach ($category_sections as $section) :
            $category = $section['category'];
            $courses = $section['courses'];
            $section_id = 'cca-category-' . $category->slug;
            $bulk_data = class_exists('CCA_Term_Meta') ? CCA_Term_Meta::get_bulk_data($category->term_id) : null;
            $show_bulk_section = $bulk_data && (
              $bulk_data['bulk_price'] !== '' ||
              $bulk_data['bulk_description'] !== '' ||
              $bulk_data['bulk_cta_url'] !== '' ||
              $bulk_data['section_title'] !== '' ||
              $bulk_data['section_intro'] !== ''
            );
          ?>
            <section class="cca-amp-category-section"
                     id="<?php echo esc_attr($section_id); ?>"
                     data-category-id="<?php echo esc_attr($category->term_id); ?>">
              <div class="cca-amp-category-section-header">
                <h2 class="cca-amp-category-section-title"><?php echo esc_html($category->name); ?></h2>
                <span class="cca-amp-category-section-count">
                  <?php
                  printf(
                      esc_html(_n('%d course', '%d courses', count($courses), 'custom-course-archive')),
                      count($courses)
                  );
                  ?>
                </span>
              </div>

              <?php if ($show_bulk_section) : ?>
                <?php
                $bulk_title = !empty($bulk_data['section_title'])
                    ? $bulk_data['section_title']
                    : ($bulk_data['name'] . ' — ' . __('Full category package', 'custom-course-archive'));
                $bulk_intro = !empty($bulk_data['section_intro'])
                    ? $bulk_data['section_intro']
                    : __('Companies can purchase all courses in this category as a single bulk package for multiple users.', 'custom-course-archive');
                ?>
                <div class="cca-amp-bulk-purchase">
                  <h3 class="cca-amp-bulk-title"><?php echo esc_html($bulk_title); ?></h3>
                  <?php if ($bulk_data['bulk_description'] !== '') : ?>
                    <p class="cca-amp-bulk-desc"><?php echo esc_html($bulk_data['bulk_description']); ?></p>
                  <?php endif; ?>
                  <p class="cca-amp-bulk-intro"><?php echo esc_html($bulk_intro); ?></p>
                  <?php if ($bulk_data['bulk_price'] !== '') : ?>
                    <div class="cca-amp-bulk-price"><?php echo wp_kses_post($bulk_data['bulk_price']); ?></div>
                  <?php endif; ?>
                  <?php if ($bulk_data['bulk_cta_url'] !== '') : ?>
                    <a class="cca-amp-bulk-btn" href="<?php echo esc_url($bulk_data['bulk_cta_url']); ?>" target="_top"><?php echo esc_html($bulk_data['bulk_cta_text']); ?></a>
                  <?php endif; ?>
                </div>
              <?php endif; ?>

              <div class="cca-amp-courses-grid">
                <?php foreach ($courses as $course) :
                  $excerpt = isset($course['excerpt']) ? $course['excerpt'] : '';
                  $short_excerpt = mb_strlen($excerpt) > 80 ? mb_substr($excerpt, 0, 80) . '...' : $excerpt;
                  $search_title = strtolower(trim($course['title']));
                  $search_title_clean = strtolower(preg_replace('/[^a-z0-9\s]/i', '', $course['title']));
                ?>
                  <article class="cca-amp-course-card"
                           data-title="<?php echo esc_attr($search_title_clean); ?>"
                           [hidden]="courseFilter.search.length > 0 && '<?php echo esc_js($search_title); ?>'.indexOf(courseFilter.search) < 0">
                    <div class="cca-amp-course-thumbnail">
                      <a href="<?php echo esc_url($course['url']); ?>">
                        <amp-img src="<?php echo esc_url($course['thumbnail']); ?>"
                                 alt="<?php echo esc_attr($course['title']); ?>"
                                 width="600"
                                 height="280"
                                 layout="fill">
                        </amp-img>
                      </a>
                    </div>

                    <div class="cca-amp-course-content">
                      <h3 class="cca-amp-course-title">
                        <a href="<?php echo esc_url($course['url']); ?>">
                          <?php echo esc_html($course['title']); ?>
                        </a>
                      </h3>

                      <p class="cca-amp-course-excerpt">
                        <?php echo esc_html($short_excerpt); ?>
                      </p>
                      <a href="<?php echo esc_url($course['url']); ?>" class="cca-amp-read-more">Read More</a>

                      <div class="cca-amp-course-meta">
                        <span class="cca-amp-course-duration">
                          <?php
                          $duration_label = !empty($course['duration_label']) ? $course['duration_label'] : 'Total Duration';
                          $duration_value = !empty($course['duration']) && $course['duration'] != 'N/A' ? $course['duration'] : '';
                          if (!empty($duration_value)) {
                              echo '<span class="cca-amp-duration-label">' . esc_html($duration_label) . ': </span><span class="cca-amp-duration-value">' . esc_html($duration_value) . '</span>';
                          } else {
                              echo '<span class="cca-amp-duration-label">' . esc_html($duration_label) . ': </span><span class="cca-amp-duration-value">—</span>';
                          }
                          ?>
                        </span>
                        <span class="cca-amp-course-price <?php echo empty($course['price']) || $course['price'] == 'Free' ? 'free' : ''; ?>">
                          <?php echo !empty($course['price']) ? esc_html($course['price']) : 'Free'; ?>
                        </span>
                      </div>

                      <a href="<?php echo esc_url($course['url']); ?>" class="cca-amp-course-link">
                        View Course
                      </a>
                    </div>
                  </article>
                <?php endforeach; ?>
              </div>
            </section>
          <?php endforeach; ?>
        <?php else : ?>
          <div class="cca-amp-no-courses">
            <p>No courses found.</p>
          </div>
        <?php endif; ?>
      </div>

    </main>
  </div>
</div>

<!-- ✅ Footer (your existing footer) -->
<?php 
if (file_exists(plugin_dir_path(__FILE__) . 'footer.php')) {
    include(plugin_dir_path(__FILE__) . 'footer.php'); 
}
?>

</body>
</html>

<?php
if (!defined('ABSPATH')) {
    exit;
}

$query = new CCA_Course_Query();
$categories = $query->get_all_categories();
$current_sort = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'newest';
$category_sections = $query->get_courses_grouped_by_category($current_sort);
$has_courses = !empty($category_sections);
?>

<!-- SEO H1: visually hidden, readable by search engines -->
<h1 class="cca-seo-h1"><?php echo esc_html(get_the_title()); ?></h1>

<div class="cca-wrapper">
    <!-- Left Sidebar - Categories -->
    <div class="cca-sidebar-wrapper">
        <aside class="cca-sidebar">
            <div class="cca-sidebar-inner">
                <h3 class="cca-sidebar-title"><?php esc_html_e('Categories', 'custom-course-archive'); ?></h3>
                <ul class="cca-category-list">
                    <li class="cca-category-item active">
                        <a href="#cca-courses-sections" data-scroll-target="cca-courses-sections" class="cca-category-link">
                            <?php esc_html_e('All Courses', 'custom-course-archive'); ?>
                        </a>
                    </li>
                    <?php foreach ($categories as $category) : ?>
                        <?php if ((int) $category->count < 1) {
                            continue;
                        } ?>
                        <li class="cca-category-item">
                            <a href="#cca-category-<?php echo esc_attr($category->slug); ?>"
                               data-scroll-target="cca-category-<?php echo esc_attr($category->slug); ?>"
                               data-category="<?php echo esc_attr($category->term_id); ?>"
                               data-slug="<?php echo esc_attr($category->slug); ?>"
                               class="cca-category-link">
                                <?php echo esc_html($category->name); ?>
                                <span class="cca-category-count">(<?php echo (int) $category->count; ?>)</span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </aside>
    </div>
    <!-- Spacer when sidebar is fixed (maintains 20% width in layout) -->
    <div class="cca-sidebar-spacer" aria-hidden="true"></div>

    <!-- Right Content Area -->
    <main class="cca-content">
        <!-- Search and Filter Bar -->
        <div class="cca-filter-bar-wrapper">
            <div class="cca-filter-bar">
                <div class="cca-search-wrapper">
                    <svg class="cca-search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                    <input type="text" id="cca-search-input" class="cca-search-input" placeholder="<?php esc_attr_e('Search courses...', 'custom-course-archive'); ?>" autocomplete="off">
                    <button type="button" class="cca-search-clear" id="cca-search-clear" style="display: none;">×</button>
                </div>
                <div class="cca-sort-reset-group">
                    <div class="cca-filter-group">
                        <label for="cca-sort-filter"><?php esc_html_e('Sort by:', 'custom-course-archive'); ?></label>
                        <select id="cca-sort-filter" class="cca-sort-select">
                            <option value="newest" <?php selected($current_sort, 'newest'); ?>>
                                <?php esc_html_e('Newest First', 'custom-course-archive'); ?>
                            </option>
                            <option value="oldest" <?php selected($current_sort, 'oldest'); ?>>
                                <?php esc_html_e('Oldest First', 'custom-course-archive'); ?>
                            </option>
                            <option value="a-z" <?php selected($current_sort, 'a-z'); ?>>
                                <?php esc_html_e('A to Z', 'custom-course-archive'); ?>
                            </option>
                            <option value="z-a" <?php selected($current_sort, 'z-a'); ?>>
                                <?php esc_html_e('Z to A', 'custom-course-archive'); ?>
                            </option>
                        </select>
                    </div>
                    <button type="button" class="cca-reset-btn" id="cca-reset-btn">
                        <?php esc_html_e('Reset', 'custom-course-archive'); ?>
                    </button>
                </div>
            </div>
        </div>

        <div class="cca-courses-sections cca-no-bulk-top" id="cca-courses-sections">
            <?php if ($has_courses) : ?>
                <?php foreach ($category_sections as $section) : ?>
                    <?php
                    $category = $section['category'];
                    $courses = $section['courses'];
                    $section_id = 'cca-category-' . $category->slug;
                    $bulk_data = class_exists('CCA_Term_Meta') ? CCA_Term_Meta::get_bulk_data($category->term_id) : null;
                    $show_bulk_section = $bulk_data && ($bulk_data['bulk_description'] !== '' || $bulk_data['bulk_cta_url'] !== '');
                    ?>
                    <section class="cca-category-section"
                             id="<?php echo esc_attr($section_id); ?>"
                             data-category-id="<?php echo esc_attr($category->term_id); ?>"
                             data-category-slug="<?php echo esc_attr($category->slug); ?>">
                        <div class="cca-category-section-header">
                            <h2 class="cca-category-section-title"><?php echo esc_html($category->name); ?></h2>
                            <span class="cca-category-section-count">
                                <?php
                                printf(
                                    esc_html(_n('%d course', '%d courses', count($courses), 'custom-course-archive')),
                                    count($courses)
                                );
                                ?>
                            </span>
                        </div>

                        <?php if ($show_bulk_section) : ?>
                            <div class="cca-bulk-purchase-section">
                                <div class="cca-bulk-purchase-inner">
                                    <?php
                                    $bulk_title = !empty($bulk_data['section_title'])
                                        ? $bulk_data['section_title']
                                        : ($bulk_data['name'] . ' — ' . __('Full category package', 'custom-course-archive'));
                                    $bulk_intro = !empty($bulk_data['section_intro'])
                                        ? $bulk_data['section_intro']
                                        : __('Companies can purchase all courses in this category as a single bulk package for multiple users.', 'custom-course-archive');
                                    ?>
                                    <h3 class="cca-bulk-purchase-title"><?php echo esc_html($bulk_title); ?></h3>
                                    <?php if ($bulk_data['bulk_description'] !== '') : ?>
                                        <p class="cca-bulk-purchase-desc"><?php echo esc_html($bulk_data['bulk_description']); ?></p>
                                    <?php endif; ?>
                                    <p class="cca-bulk-purchase-intro"><?php echo esc_html($bulk_intro); ?></p>
                                    <?php if ($bulk_data['bulk_cta_url'] !== '') : ?>
                                        <a href="<?php echo esc_url($bulk_data['bulk_cta_url']); ?>" class="cca-bulk-purchase-btn"><?php echo esc_html($bulk_data['bulk_cta_text']); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="cca-courses-grid">
                            <?php foreach ($courses as $course) : ?>
                                <?php include CCA_PLUGIN_DIR . 'templates/partials/course-card.php'; ?>
                            <?php endforeach; ?>
                        </div>
                    </section>
                <?php endforeach; ?>

                <div class="cca-no-courses cca-search-no-results" id="cca-search-no-results" style="display: none;">
                    <p><?php esc_html_e('No courses match your search.', 'custom-course-archive'); ?></p>
                </div>
            <?php else : ?>
                <div class="cca-no-courses">
                    <p><?php esc_html_e('No courses found.', 'custom-course-archive'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<input type="hidden" id="cca-current-sort" value="<?php echo esc_attr($current_sort); ?>">

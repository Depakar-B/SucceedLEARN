jQuery(document).ready(function($) {

    var DEFAULT_SORT = 'newest';

    function getScrollOffset() {
        var filterHeight = $('.cca-filter-bar-wrapper').outerHeight() || 0;
        var headerOffset = 80;
        return filterHeight + headerOffset + 16;
    }

    function scrollToTarget(targetId) {
        var $target = $('#' + targetId);
        if (!$target.length) {
            return;
        }

        $('html, body').animate({
            scrollTop: $target.offset().top - getScrollOffset()
        }, 500);
    }

    function setActiveCategory(targetId) {
        $('.cca-category-item').removeClass('active');
        $('.cca-category-link[data-scroll-target="' + targetId + '"]').closest('.cca-category-item').addClass('active');
    }

    // Search filter (client-side: filter visible cards by title)
    function runSearch() {
        var $input = $('#cca-search-input');
        var searchVal = $.trim($input.val()).toLowerCase();
        var $cards = $('.cca-course-card');
        var $clear = $('#cca-search-clear');
        var $noResults = $('#cca-search-no-results');

        $clear.toggle(searchVal.length > 0);
        if ($noResults.length) {
            $noResults.hide();
        }
        $cards.removeClass('cca-search-hidden');

        if (searchVal.length === 0) {
            $cards.show();
            $('.cca-category-section').show();
            return;
        }

        var visibleCount = 0;
        $cards.each(function() {
            var title = $(this).attr('data-course-title');
            if (typeof title !== 'string') {
                title = '';
            }
            title = title.toLowerCase();
            var show = title.indexOf(searchVal) !== -1;
            if (show) {
                $(this).show().removeClass('cca-search-hidden');
                visibleCount++;
            } else {
                $(this).addClass('cca-search-hidden');
            }
        });

        setTimeout(function() {
            $cards.filter('.cca-search-hidden').hide();
        }, 200);

        $('.cca-category-section').each(function() {
            var sectionVisible = $(this).find('.cca-course-card:visible').length > 0;
            $(this).toggle(sectionVisible);
        });

        if ($noResults.length && visibleCount === 0) {
            $noResults.show();
        }
    }

    function sortCourses(sortValue) {
        $('.cca-category-section').each(function() {
            var $grid = $(this).find('.cca-courses-grid').first();
            var $cards = $grid.children('.cca-course-card').get();

            $cards.sort(function(a, b) {
                var $a = $(a);
                var $b = $(b);

                if (sortValue === 'a-z' || sortValue === 'z-a') {
                    var titleA = ($a.attr('data-sort-title') || '').toString();
                    var titleB = ($b.attr('data-sort-title') || '').toString();
                    var cmp = titleA.localeCompare(titleB);
                    return sortValue === 'z-a' ? -cmp : cmp;
                }

                var dateA = parseInt($a.attr('data-sort-date'), 10) || 0;
                var dateB = parseInt($b.attr('data-sort-date'), 10) || 0;
                return sortValue === 'oldest' ? dateA - dateB : dateB - dateA;
            });

            $.each($cards, function(_, card) {
                $grid.append(card);
            });
        });
    }

    $(document).on('input keyup', '#cca-search-input', function() {
        runSearch();
    });

    $(document).on('keydown', '#cca-search-input', function(e) {
        if (e.key === 'Enter' || e.which === 13) {
            e.preventDefault();
            runSearch();
            $(this).blur();
        }
    });

    $(document).on('click', '#cca-search-clear', function() {
        $('#cca-search-input').val('').focus();
        runSearch();
    });

    runSearch();

    // Category navigation — smooth scroll instead of page reload
    $(document).on('click', '.cca-category-link', function(e) {
        e.preventDefault();
        var targetId = $(this).data('scroll-target');
        if (!targetId) {
            return;
        }

        setActiveCategory(targetId);
        scrollToTarget(targetId);

        if (history.replaceState) {
            history.replaceState(null, '', '#' + targetId);
        }
    });

    // Sort courses within each section (no page reload)
    $('#cca-sort-filter').on('change', function() {
        var sortValue = $(this).val() || DEFAULT_SORT;
        sortCourses(sortValue);
        $('#cca-current-sort').val(sortValue);
    });

    // Reset search, sort, and scroll to top
    $('#cca-reset-btn').on('click', function() {
        $('#cca-search-input').val('');
        $('#cca-sort-filter').val(DEFAULT_SORT);
        $('#cca-current-sort').val(DEFAULT_SORT);
        sortCourses(DEFAULT_SORT);
        runSearch();
        setActiveCategory('cca-courses-sections');
        scrollToTarget('cca-courses-sections');

        if (history.replaceState) {
            history.replaceState(null, '', window.location.pathname + window.location.search);
        }
    });

    // Deep-link support: scroll to hash on load
    function handleInitialHash() {
        var hash = window.location.hash.replace('#', '');
        if (!hash) {
            return;
        }

        if ($('#' + hash).length) {
            setTimeout(function() {
                setActiveCategory(hash);
                scrollToTarget(hash);
            }, 150);
        }
    }

    handleInitialHash();

    // Read More/Less functionality
    $('.cca-read-more').on('click', function(e) {
        e.preventDefault();
        var $card = $(this).closest('.cca-course-card');
        var $excerpt = $card.find('.cca-excerpt-text');
        var $readMore = $card.find('.cca-read-more');
        var $readLess = $card.find('.cca-read-less');

        var fullContent = $excerpt.data('full');
        if (fullContent) {
            var shortExcerpt = $excerpt.text();
            $excerpt.data('short', shortExcerpt);
            $excerpt.text(fullContent).addClass('full');
            $readMore.hide();
            $readLess.show();
        }
    });

    $('.cca-read-less').on('click', function(e) {
        e.preventDefault();
        var $card = $(this).closest('.cca-course-card');
        var $excerpt = $card.find('.cca-excerpt-text');
        var $readMore = $card.find('.cca-read-more');
        var $readLess = $card.find('.cca-read-less');

        var shortExcerpt = $excerpt.data('short');
        if (shortExcerpt) {
            $excerpt.text(shortExcerpt).removeClass('full');
            $readLess.hide();
            $readMore.show();
        }
    });
});

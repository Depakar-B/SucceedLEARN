# Custom Course Archive Plugin

A WordPress plugin that creates a beautiful, filterable course archive page with category sidebar, sorting options, and pagination.

## Features

✅ **Sticky Category Sidebar** - Left sidebar with all course categories that stays fixed while scrolling  
✅ **Course Grid Layout** - Beautiful card-based grid displaying courses  
✅ **Course Information** - Featured image, title, description, duration, and price  
✅ **Read More/Less** - Expandable descriptions for each course  
✅ **Pagination** - 10 courses per page with Prev/Next and page numbers  
✅ **Sorting Filters** - Sort by Newest/Oldest, A-Z/Z-A  
✅ **Category Filtering** - Filter courses by category  
✅ **Auto-Update** - Automatically includes new courses when added  
✅ **Responsive Design** - Works perfectly on all devices  

## Installation

1. **Upload the Plugin**
   - Copy the `custom-course-archive` folder to your WordPress `wp-content/plugins/` directory
   - Or zip the folder and upload via WordPress Admin → Plugins → Add New → Upload Plugin

2. **Activate the Plugin**
   - Go to WordPress Admin → Plugins
   - Find "Custom Course Archive" and click "Activate"

## Usage

### Display on a Page

1. **Create a New Page**
   - Go to WordPress Admin → Pages → Add New
   - Title it "Courses" (or any name you prefer)

2. **Add the Shortcode**
   - In the page editor, add this shortcode:
   ```
   [custom_course_archive]
   ```

3. **Publish the Page**
   - Click "Publish"
   - Your course archive will be available at: `yoursite.com/courses/`

### Shortcode Options

The shortcode accepts optional parameters:

```
[custom_course_archive category="5"]
```

- `category` - Filter by specific category ID (default: 0 = all categories)

## How It Works

- **Category Sidebar**: Click any category to filter courses
- **Sort Dropdown**: Choose how to sort courses (Newest, Oldest, A-Z, Z-A)
- **Course Cards**: Click on any course card or "View Course" button to go to the course page
- **Read More/Less**: Click to expand/collapse course descriptions
- **Pagination**: Navigate through pages of courses

## Requirements

- WordPress 5.0 or higher
- LearnPress plugin (or Eduma theme with LearnPress)
- PHP 7.4 or higher

## Customization

### Change Courses Per Page

Edit `includes/class-course-query.php` and modify:
```php
private $posts_per_page = 10; // Change this number
```

### Change Colors/Styling

Edit `assets/css/style.css` to match your theme's colors.

### Change Post Type or Taxonomy

If your theme uses different post types or taxonomies, edit `includes/class-course-query.php`:
- Change `'post_type' => 'lp_course'` to your course post type
- Change `'taxonomy' => 'course_category'` to your category taxonomy

## Support

For issues or questions, please check:
- WordPress LearnPress documentation
- Your theme's documentation (Eduma)

## Version

1.0.0 - Initial release


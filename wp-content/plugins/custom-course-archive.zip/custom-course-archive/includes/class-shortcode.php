<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCA_Shortcode {
    
    public static function render($atts) {
        $atts = shortcode_atts(array(
            'category' => 0,
        ), $atts);
        
        ob_start();
        include CCA_PLUGIN_DIR . 'templates/course-archive-template.php';
        return ob_get_clean();
    }
}


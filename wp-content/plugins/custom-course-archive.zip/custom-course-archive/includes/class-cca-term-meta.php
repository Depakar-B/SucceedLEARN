<?php
/**
 * Term meta for course categories: bulk package price and description.
 * Supports both course_category and LearnPress lp_course_category (Eduma theme).
 */
if (!defined('ABSPATH')) {
    exit;
}

class CCA_Term_Meta {

    // Bulk section content
    const META_BULK_SECTION_TITLE = 'cca_bulk_section_title';
    const META_BULK_SECTION_INTRO = 'cca_bulk_section_intro';

    const META_BULK_PRICE = 'cca_bulk_price';
    const META_BULK_DESCRIPTION = 'cca_bulk_description';
    const META_BULK_CTA_TEXT = 'cca_bulk_cta_text';
    const META_BULK_CTA_URL = 'cca_bulk_cta_url';

    /** Taxonomies that get the bulk fields (LearnPress uses lp_course_category) */
    public static function get_supported_taxonomies() {
        return apply_filters('cca_bulk_term_meta_taxonomies', array('course_category', 'lp_course_category'));
    }

    public static function init() {
        // Run in admin after LearnPress has registered its Categories taxonomy (LearnPress → Categories)
        add_action('admin_init', array(__CLASS__, 'register_hooks'));
    }

    public static function register_hooks() {
        foreach (self::get_supported_taxonomies() as $tax) {
            if (!taxonomy_exists($tax)) {
                continue;
            }
            add_action($tax . '_add_form_fields', array(__CLASS__, 'add_form_fields'));
            add_action($tax . '_edit_form_fields', array(__CLASS__, 'edit_form_fields'));
            add_action('created_' . $tax, array(__CLASS__, 'save_meta'));
            add_action('edited_' . $tax, array(__CLASS__, 'save_meta'));
        }
    }

    public static function add_form_fields() {
        ?>
        <div class="cca-bulk-section">
            <h4><?php esc_html_e('Bulk package (course archive)', 'custom-course-archive'); ?></h4>
        <div class="form-field cca-bulk-field">
            <label for="<?php echo esc_attr(self::META_BULK_SECTION_TITLE); ?>"><?php esc_html_e('Bulk section title (override)', 'custom-course-archive'); ?></label>
            <input type="text" name="<?php echo esc_attr(self::META_BULK_SECTION_TITLE); ?>" id="<?php echo esc_attr(self::META_BULK_SECTION_TITLE); ?>" placeholder="<?php esc_attr_e('e.g. Financial Crime Prevention Suite — Full category package', 'custom-course-archive'); ?>">
            <p class="description"><?php esc_html_e('Optional. If empty, the title will be “{Category Name} — Full category package”.', 'custom-course-archive'); ?></p>
        </div>
        <div class="form-field cca-bulk-field">
            <label for="<?php echo esc_attr(self::META_BULK_DESCRIPTION); ?>"><?php esc_html_e('Subtitle / offer line', 'custom-course-archive'); ?></label>
            <textarea name="<?php echo esc_attr(self::META_BULK_DESCRIPTION); ?>" id="<?php echo esc_attr(self::META_BULK_DESCRIPTION); ?>" rows="2" placeholder="<?php esc_attr_e('e.g. Purchase all the courses under this category for this limited price', 'custom-course-archive'); ?>"></textarea>
        </div>
        <div class="form-field cca-bulk-field">
            <label for="<?php echo esc_attr(self::META_BULK_SECTION_INTRO); ?>"><?php esc_html_e('Intro text (editable)', 'custom-course-archive'); ?></label>
            <textarea name="<?php echo esc_attr(self::META_BULK_SECTION_INTRO); ?>" id="<?php echo esc_attr(self::META_BULK_SECTION_INTRO); ?>" rows="2" placeholder="<?php esc_attr_e('e.g. Companies can purchase all courses in this category as a single bulk package for multiple users.', 'custom-course-archive'); ?>"></textarea>
        </div>
        <div class="form-field cca-bulk-field">
            <label for="<?php echo esc_attr(self::META_BULK_PRICE); ?>"><?php esc_html_e('Bulk package price', 'custom-course-archive'); ?></label>
            <input type="text" name="<?php echo esc_attr(self::META_BULK_PRICE); ?>" id="<?php echo esc_attr(self::META_BULK_PRICE); ?>" placeholder="<?php esc_attr_e('e.g. $500 or Contact for pricing', 'custom-course-archive'); ?>">
            <p class="description"><?php esc_html_e('Shown in the archive when this category is selected (full category purchase for companies).', 'custom-course-archive'); ?></p>
        </div>
        <div class="form-field cca-bulk-field">
            <label for="<?php echo esc_attr(self::META_BULK_CTA_TEXT); ?>"><?php esc_html_e('Button text', 'custom-course-archive'); ?></label>
            <input type="text" name="<?php echo esc_attr(self::META_BULK_CTA_TEXT); ?>" id="<?php echo esc_attr(self::META_BULK_CTA_TEXT); ?>" placeholder="<?php esc_attr_e('e.g. Request bulk purchase', 'custom-course-archive'); ?>">
        </div>
        <div class="form-field cca-bulk-field">
            <label for="<?php echo esc_attr(self::META_BULK_CTA_URL); ?>"><?php esc_html_e('Button URL', 'custom-course-archive'); ?></label>
            <input type="url" name="<?php echo esc_attr(self::META_BULK_CTA_URL); ?>" id="<?php echo esc_attr(self::META_BULK_CTA_URL); ?>" placeholder="<?php esc_attr_e('https://...', 'custom-course-archive'); ?>">
        </div>
        </div>
        <?php
    }

    public static function edit_form_fields($term) {
        $section_title = get_term_meta($term->term_id, self::META_BULK_SECTION_TITLE, true);
        $section_intro = get_term_meta($term->term_id, self::META_BULK_SECTION_INTRO, true);
        $price = get_term_meta($term->term_id, self::META_BULK_PRICE, true);
        $desc = get_term_meta($term->term_id, self::META_BULK_DESCRIPTION, true);
        $cta_text = get_term_meta($term->term_id, self::META_BULK_CTA_TEXT, true);
        $cta_url = get_term_meta($term->term_id, self::META_BULK_CTA_URL, true);
        ?>
        <tr>
            <td colspan="2">
                <div class="cca-bulk-section">
                    <h4><?php esc_html_e('Bulk package (course archive)', 'custom-course-archive'); ?></h4>
                    <div class="cca-bulk-field">
                        <label for="<?php echo esc_attr(self::META_BULK_SECTION_TITLE); ?>"><?php esc_html_e('Bulk section title (override)', 'custom-course-archive'); ?></label>
                        <input type="text" name="<?php echo esc_attr(self::META_BULK_SECTION_TITLE); ?>" id="<?php echo esc_attr(self::META_BULK_SECTION_TITLE); ?>" value="<?php echo esc_attr($section_title); ?>" placeholder="<?php esc_attr_e('e.g. Financial Crime Prevention Suite — Full category package', 'custom-course-archive'); ?>">
                        <p class="description"><?php esc_html_e('Optional. If empty, the title will be “{Category Name} — Full category package”.', 'custom-course-archive'); ?></p>
                    </div>
                    <div class="cca-bulk-field">
                        <label for="<?php echo esc_attr(self::META_BULK_DESCRIPTION); ?>"><?php esc_html_e('Subtitle / offer line', 'custom-course-archive'); ?></label>
                        <textarea name="<?php echo esc_attr(self::META_BULK_DESCRIPTION); ?>" id="<?php echo esc_attr(self::META_BULK_DESCRIPTION); ?>" rows="2" placeholder="<?php esc_attr_e('e.g. Purchase all the courses under this category for this limited price', 'custom-course-archive'); ?>"><?php echo esc_textarea($desc); ?></textarea>
                    </div>
                    <div class="cca-bulk-field">
                        <label for="<?php echo esc_attr(self::META_BULK_SECTION_INTRO); ?>"><?php esc_html_e('Intro text (editable)', 'custom-course-archive'); ?></label>
                        <textarea name="<?php echo esc_attr(self::META_BULK_SECTION_INTRO); ?>" id="<?php echo esc_attr(self::META_BULK_SECTION_INTRO); ?>" rows="2" placeholder="<?php esc_attr_e('e.g. Companies can purchase all courses in this category as a single bulk package for multiple users.', 'custom-course-archive'); ?>"><?php echo esc_textarea($section_intro); ?></textarea>
                    </div>
                    <div class="cca-bulk-field">
                        <label for="<?php echo esc_attr(self::META_BULK_PRICE); ?>"><?php esc_html_e('Bulk package price', 'custom-course-archive'); ?></label>
                        <input type="text" name="<?php echo esc_attr(self::META_BULK_PRICE); ?>" id="<?php echo esc_attr(self::META_BULK_PRICE); ?>" value="<?php echo esc_attr($price); ?>" placeholder="<?php esc_attr_e('e.g. $500 or Contact for pricing', 'custom-course-archive'); ?>">
                        <p class="description"><?php esc_html_e('Shown when this category is selected (full category purchase for companies).', 'custom-course-archive'); ?></p>
                    </div>
                    <div class="cca-bulk-field">
                        <label for="<?php echo esc_attr(self::META_BULK_CTA_TEXT); ?>"><?php esc_html_e('Button text', 'custom-course-archive'); ?></label>
                        <input type="text" name="<?php echo esc_attr(self::META_BULK_CTA_TEXT); ?>" id="<?php echo esc_attr(self::META_BULK_CTA_TEXT); ?>" value="<?php echo esc_attr($cta_text); ?>" placeholder="<?php esc_attr_e('e.g. Request bulk purchase', 'custom-course-archive'); ?>">
                    </div>
                    <div class="cca-bulk-field">
                        <label for="<?php echo esc_attr(self::META_BULK_CTA_URL); ?>"><?php esc_html_e('Button URL', 'custom-course-archive'); ?></label>
                        <input type="url" name="<?php echo esc_attr(self::META_BULK_CTA_URL); ?>" id="<?php echo esc_attr(self::META_BULK_CTA_URL); ?>" value="<?php echo esc_attr($cta_url); ?>" placeholder="<?php esc_attr_e('https://...', 'custom-course-archive'); ?>">
                    </div>
                </div>
            </td>
        </tr>
        <?php
    }

    public static function save_meta($term_id) {
        if (!current_user_can('edit_term', $term_id)) {
            return;
        }
        $keys = array(
            self::META_BULK_SECTION_TITLE,
            self::META_BULK_SECTION_INTRO,
            self::META_BULK_PRICE,
            self::META_BULK_DESCRIPTION,
            self::META_BULK_CTA_TEXT,
            self::META_BULK_CTA_URL,
        );
        foreach ($keys as $key) {
            if (isset($_POST[$key])) {
                if ($key === self::META_BULK_DESCRIPTION || $key === self::META_BULK_SECTION_INTRO) {
                    update_term_meta($term_id, $key, sanitize_textarea_field($_POST[$key]));
                } elseif ($key === self::META_BULK_CTA_URL) {
                    update_term_meta($term_id, $key, esc_url_raw($_POST[$key]));
                } else {
                    update_term_meta($term_id, $key, sanitize_text_field($_POST[$key]));
                }
            }
        }
    }

    /**
     * Get bulk package data for a category (for use in template).
     * Works for any taxonomy (course_category or lp_course_category).
     */
    public static function get_bulk_data($term_id) {
        if (!$term_id) {
            return null;
        }
        $term = get_term($term_id);
        if (!$term || is_wp_error($term)) {
            return null;
        }
        $section_title = get_term_meta($term_id, self::META_BULK_SECTION_TITLE, true);
        $section_intro = get_term_meta($term_id, self::META_BULK_SECTION_INTRO, true);
        $price = get_term_meta($term_id, self::META_BULK_PRICE, true);
        $desc = get_term_meta($term_id, self::META_BULK_DESCRIPTION, true);
        $cta_text = get_term_meta($term_id, self::META_BULK_CTA_TEXT, true);
        $cta_url = get_term_meta($term_id, self::META_BULK_CTA_URL, true);
        return array(
            'name' => $term->name,
            'section_title' => $section_title,
            'section_intro' => $section_intro,
            'bulk_price' => $price,
            'bulk_description' => $desc,
            'bulk_cta_text' => $cta_text ?: __('Request bulk purchase', 'custom-course-archive'),
            'bulk_cta_url' => $cta_url,
        );
    }
}

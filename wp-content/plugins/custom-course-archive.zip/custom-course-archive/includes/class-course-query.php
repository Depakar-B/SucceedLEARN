<?php
if (!defined('ABSPATH')) {
    exit;
}

class CCA_Course_Query {

    /** Course CPT (SucceedLEARN Courses plugin; was LearnPress lp_course). */
    private function get_post_type() {
        return apply_filters('cca_course_post_type', 'course');
    }

    /** Taxonomy for course categories */
    private function get_taxonomy() {
        return apply_filters('cca_course_category_taxonomy', 'course_category');
    }
    
    /** -1 = show all courses on one page (no pagination) */
    private $posts_per_page = -1;
    
    public function get_courses($category_id = 0, $sort = 'newest', $page = 1) {
        $tax = $this->get_taxonomy();
        $args = array(
            'post_type' => $this->get_post_type(),
            'posts_per_page' => $this->posts_per_page,
            'post_status' => 'publish',
        );
        
        // Category filter
        if ($category_id > 0) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => $tax,
                    'field' => 'term_id',
                    'terms' => $category_id,
                ),
            );
        }
        
        // Sorting
        switch ($sort) {
            case 'newest':
                $args['orderby'] = 'date';
                $args['order'] = 'DESC';
                break;
            case 'oldest':
                $args['orderby'] = 'date';
                $args['order'] = 'ASC';
                break;
            case 'a-z':
                $args['orderby'] = 'title';
                $args['order'] = 'ASC';
                break;
            case 'z-a':
                $args['orderby'] = 'title';
                $args['order'] = 'DESC';
                break;
            default:
                $args['orderby'] = 'date';
                $args['order'] = 'DESC';
        }
        
        $query = new WP_Query($args);
        
        $courses = array();
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $courses[] = $this->format_course_data(get_the_ID());
            }
            wp_reset_postdata();
        }
        
        return array(
            'courses' => $courses,
            'total' => $query->found_posts,
            'pages' => 1,
            'current_page' => 1,
        );
    }
    
    public function get_all_categories() {
        $categories = get_terms(array(
            'taxonomy' => $this->get_taxonomy(),
            'hide_empty' => true,
            'orderby' => 'name',
            'order' => 'ASC',
        ));
        
        return is_array($categories) ? $categories : array();
    }

    /**
     * Return all courses grouped by category for single-page scroll layout.
     */
    public function get_courses_grouped_by_category($sort = 'newest') {
        $categories = $this->get_all_categories();
        $all = $this->get_courses(0, $sort, 1);
        $courses_by_id = array();

        foreach ($all['courses'] as $course) {
            $courses_by_id[$course['id']] = $course;
        }

        $grouped = array();
        $tax = $this->get_taxonomy();
        $orderby_args = $this->get_orderby_args($sort);

        foreach ($categories as $category) {
            $post_ids = get_posts(array_merge(array(
                'post_type' => $this->get_post_type(),
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'fields' => 'ids',
                'tax_query' => array(
                    array(
                        'taxonomy' => $tax,
                        'field' => 'term_id',
                        'terms' => $category->term_id,
                    ),
                ),
            ), $orderby_args));

            $term_courses = array();
            foreach ($post_ids as $post_id) {
                if (isset($courses_by_id[$post_id])) {
                    $term_courses[] = $courses_by_id[$post_id];
                }
            }

            if (!empty($term_courses)) {
                $grouped[] = array(
                    'category' => $category,
                    'courses' => $term_courses,
                );
            }
        }

        return $grouped;
    }

    private function get_orderby_args($sort) {
        switch ($sort) {
            case 'oldest':
                return array('orderby' => 'date', 'order' => 'ASC');
            case 'a-z':
                return array('orderby' => 'title', 'order' => 'ASC');
            case 'z-a':
                return array('orderby' => 'title', 'order' => 'DESC');
            case 'newest':
            default:
                return array('orderby' => 'date', 'order' => 'DESC');
        }
    }
    
    private function format_course_data($course_id) {
        $course = get_post($course_id);
        
        // Get featured image
        $thumbnail = get_the_post_thumbnail_url($course_id, 'medium');
        if (!$thumbnail) {
            $thumbnail = CCA_PLUGIN_URL . 'assets/images/placeholder.jpg';
        }
        
        // Use custom meta fields directly
        $course_title = get_post_meta($course_id, 'course_title', true);
        $title = !empty($course_title) ? $course_title : $course->post_title;
        
        $course_desc = get_post_meta($course_id, 'course_description', true);
        if (empty($course_desc)) {
            $course_desc = $course->post_excerpt;
        }
        if (empty($course_desc)) {
            $course_desc = $course->post_content;
        }
        // Use full description or trim to reasonable length for display
        $description = wp_strip_all_tags($course_desc);
        $excerpt = wp_trim_words($description, 30, '...');
        
        $duration_title = get_post_meta($course_id, 'duration_title', true);
        $duration_value = get_post_meta($course_id, 'duration_value', true);
        if (empty($duration_value)) {
            $duration_value = get_post_meta($course_id, '_lp_duration', true);
        }
        
        $individual_title = get_post_meta($course_id, 'individual_title', true);
        $individual_price = get_post_meta($course_id, 'individual_price', true);
        $individual_btn_text = get_post_meta($course_id, 'individual_btn_text', true);
        
        // Format price - prioritize individual_price with $ symbol
        $price = '';
        if (!empty($individual_price)) {
            // If it's a numeric value, add $ symbol
            if (is_numeric($individual_price)) {
                $price = '$' . $individual_price;
            } else {
                // If it already contains currency symbol or text, use as is
                $price = $individual_price;
            }
        }
        
        // Fallback to other price methods
        if (empty($price)) {
            $price = $this->get_custom_price($course_id, $individual_title, $individual_price);
        }
        
        if (empty($price)) {
            if (function_exists('learn_press_get_course_price_html')) {
                $price_html = learn_press_get_course_price_html($course_id);
                if (!empty($price_html)) {
                    $price = $price_html;
                }
            } else {
                $course_price = get_post_meta($course_id, '_lp_price', true);
                if (!empty($course_price) && $course_price > 0) {
                    $price = function_exists('wc_price') ? wc_price($course_price) : '$' . $course_price;
                }
            }
        }
        
        if (empty($price)) {
            $price = __('Free', 'custom-course-archive');
        }
        
        // Default button text
        if (empty($individual_btn_text)) {
            $individual_btn_text = __('View Course', 'custom-course-archive');
        }
        
        return array(
            'id' => $course_id,
            'title' => $title,
            'excerpt' => $excerpt,
            'description' => $description,
            'thumbnail' => $thumbnail,
            'url' => get_permalink($course_id),
            'duration' => $duration_value,
            'duration_label' => $duration_title,
            'price' => $price,
            'button_text' => $individual_btn_text,
            'date' => get_the_date('', $course_id),
        );
    }
    
    private function get_custom_price($course_id, $individual_title = '', $individual_price = '') {
        // If individual_title and individual_price are provided, use them
        if (!empty($individual_title) && !empty($individual_price)) {
            return trim($individual_title . ' ' . $individual_price);
        }
        
        // Fallback to meta fields
        if (empty($individual_price)) {
            $individual_price = get_post_meta($course_id, 'individual_price', true);
        }
        
        $individual_currency_symbol = get_post_meta($course_id, 'individual_currency_symbol', true);
        $individual_has_price = get_post_meta($course_id, 'individual_has_price', true);
        
        if (!empty($individual_has_price) && !empty($individual_price)) {
            return trim($individual_currency_symbol . ' ' . $individual_price);
        }
        
        if (!empty($individual_price)) {
            return trim($individual_currency_symbol . ' ' . $individual_price);
        }
        
        return '';
    }
}


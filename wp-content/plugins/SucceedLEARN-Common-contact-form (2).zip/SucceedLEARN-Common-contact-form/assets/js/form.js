(() => {
	const initScfForm = (form) => {
		if (!form || form.getAttribute('data-scf-initialized') === '1') {
			return;
		}
		form.setAttribute('data-scf-initialized', '1');

		const responseNode = form.querySelector('.scf-response');
		const submitBtn = form.querySelector('.scf-submit');
		const courseInterestCheckboxes = form.querySelectorAll('input[name="course_interest[]"]');
		const otherCourseHintNodes = form.querySelectorAll('.scf-other-course-hint');
		const hiddenFields = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'page_url'];

		const formLoadTime = Math.floor(Date.now() / 1000);
		let lastSubmissionTime = 0;
		const minTimeBetweenSubmissions = 5;

		const requiresRecaptcha = Boolean(SCF_FORM && SCF_FORM.recaptchaSiteKey);

		const waitForRecaptcha = (timeoutMs = 8000) => {
			const siteKey = SCF_FORM && SCF_FORM.recaptchaSiteKey;
			if (!siteKey) {
				return Promise.reject(new Error('Missing reCAPTCHA site key'));
			}

			const whenReady = () =>
				new Promise((resolve, reject) => {
					if (typeof window.grecaptcha === 'undefined' || typeof window.grecaptcha.ready !== 'function') {
						reject(new Error('grecaptcha unavailable'));
						return;
					}
					window.grecaptcha.ready(() => resolve(window.grecaptcha));
				});

			if (typeof window.grecaptcha !== 'undefined') {
				return whenReady();
			}

			return new Promise((resolve, reject) => {
				const existing = document.querySelector('script[src*="recaptcha/api.js"]');
				let settled = false;
				const timer = window.setTimeout(() => {
					if (!settled) {
						settled = true;
						reject(new Error('reCAPTCHA load timeout'));
					}
				}, timeoutMs);

				const finish = () => {
					whenReady()
						.then((api) => {
							if (!settled) {
								settled = true;
								window.clearTimeout(timer);
								resolve(api);
							}
						})
						.catch((err) => {
							if (!settled) {
								settled = true;
								window.clearTimeout(timer);
								reject(err);
							}
						});
				};

				const poll = window.setInterval(() => {
					if (typeof window.grecaptcha !== 'undefined') {
						window.clearInterval(poll);
						finish();
					}
				}, 100);

				if (!existing) {
					const script = document.createElement('script');
					script.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(siteKey);
					script.async = true;
					script.onerror = () => {
						window.clearInterval(poll);
						if (!settled) {
							settled = true;
							window.clearTimeout(timer);
							reject(new Error('reCAPTCHA script failed'));
						}
					};
					document.head.appendChild(script);
				}
			});
		};

		const params = new URLSearchParams(window.location.search);
		hiddenFields.forEach((field) => {
			const input = form.querySelector(`[name="${field}"]`);
			if (!input) {
				return;
			}
			if (field === 'page_url') {
				input.value = window.location.href;
			} else {
				input.value = params.get(field) || '';
			}
		});

		const setResponse = (message, isError = false) => {
			if (!responseNode) {
				return;
			}
			responseNode.textContent = message || '';
			responseNode.className = 'scf-response';
			if (message) {
				responseNode.classList.add(isError ? 'scf-error' : 'scf-success');
				responseNode.hidden = false;
			} else {
				responseNode.hidden = true;
			}
		};

		// Keep the status area collapsed until there is a real message.
		setResponse('');

		const validateCourseInterestGroup = () => {
			if (!courseInterestCheckboxes.length) {
				return;
			}
			const hasSelection = Array.from(courseInterestCheckboxes).some((input) => input.checked);
			const firstCheckbox = courseInterestCheckboxes[0];
			if (firstCheckbox && typeof firstCheckbox.setCustomValidity === 'function') {
				firstCheckbox.setCustomValidity(hasSelection ? '' : 'Please select at least one option.');
			}
		};

		const toggleOtherCourseHint = () => {
			if (!otherCourseHintNodes.length) {
				return;
			}
			const showHint = Array.from(courseInterestCheckboxes).some((input) => {
				return input.checked && String(input.value || '').trim().toLowerCase() === 'others';
			});
			otherCourseHintNodes.forEach((node) => {
				node.classList.toggle('is-hidden', !showHint);
			});
		};

		validateCourseInterestGroup();
		toggleOtherCourseHint();
		courseInterestCheckboxes.forEach((input) => {
			input.addEventListener('change', () => {
				validateCourseInterestGroup();
				toggleOtherCourseHint();
			});
		});

		const validateEmailDomain = (email) => {
			if (!email || !email.includes('@')) {
				return { valid: false, message: 'Please enter a valid organizational email id.' };
			}

			const emailParts = email.split('@');
			if (emailParts.length !== 2) {
				return { valid: false, message: 'Please enter a valid organizational email id.' };
			}

			const domain = emailParts[1].toLowerCase().trim();

			const commonProviders = [
				'gmail.com', 'googlemail.com',
				'yahoo.com', 'yahoo.co.uk', 'yahoo.co.in', 'yahoo.fr', 'yahoo.de', 'yahoo.es', 'yahoo.it', 'yahoo.ca', 'yahoo.com.au', 'yahoo.com.br', 'yahoo.com.mx', 'yahoo.co.jp', 'yahoo.co.kr',
				'outlook.com', 'hotmail.com', 'hotmail.co.uk', 'hotmail.fr', 'hotmail.de', 'hotmail.es', 'hotmail.it', 'hotmail.ca', 'hotmail.com.au', 'hotmail.co.jp',
				'live.com', 'msn.com',
				'aol.com', 'aol.co.uk', 'aol.fr', 'aol.de',
				'icloud.com', 'me.com', 'mac.com',
				'protonmail.com', 'proton.me',
				'zoho.com', 'zoho.eu',
				'yandex.com', 'yandex.ru', 'yandex.ua',
				'mail.com', 'email.com', 'gmx.com', 'gmx.de', 'gmx.net',
				'rediffmail.com', 'rediffmailpro.com',
				'inbox.com', 'fastmail.com',
				'aim.com', 'rocketmail.com',
			];

			if (commonProviders.includes(domain)) {
				return { valid: false, message: 'Please enter an organizational email id.' };
			}

			const fakeDomains = [
				'abc.com', 'test.com', 'test.net', 'test.org',
				'example.com', 'example.net', 'example.org',
				'fake.com', 'fake.net', 'fake.org',
				'invalid.com', 'invalid.net', 'invalid.org',
				'dummy.com', 'dummy.net', 'dummy.org',
				'sample.com', 'sample.net', 'sample.org',
				'demo.com', 'demo.net', 'demo.org',
				'localhost.com', 'localhost.net',
				'nonexistent.com', 'nonexistent.net', 'nonexistent.org',
			];

			if (fakeDomains.includes(domain)) {
				return { valid: false, message: 'Please enter a valid organizational email id.' };
			}

			const localPart = emailParts[0].toLowerCase().trim();
			const testPatterns = ['test', 'testing', 'tester', 'demo', 'sample', 'fake', 'dummy', 'invalid', 'example', 'temp', 'temporary'];

			if (testPatterns.includes(localPart) || /^(test|demo|sample|fake|dummy|invalid|example|temp|temporary)[0-9]+$/.test(localPart)) {
				return { valid: false, message: 'Please enter a valid organizational email id.' };
			}

			if (/^[0-9]+$/.test(localPart) || localPart.length < 3) {
				return { valid: false, message: 'Please enter a valid organizational email id.' };
			}

			return { valid: true, message: '' };
		};

		const applyEmailCustomValidity = (input) => {
			if (!input || input.type !== 'email') {
				if (input && typeof input.setCustomValidity === 'function') {
					// Keep native required / minlength messages for non-email fields.
					if (input.id !== 'scf-email') {
						input.setCustomValidity('');
					}
				}
				return;
			}

			const value = String(input.value || '').trim();
			if (!value) {
				// Empty required email → native browser message.
				input.setCustomValidity('');
				return;
			}

			const emailValidation = validateEmailDomain(value);
			input.setCustomValidity(emailValidation.valid ? '' : emailValidation.message);
		};

		const clearFieldErrorUi = (input) => {
			const field = input.closest('.scf-field');
			if (!field) return;
			const errorSpan = field.querySelector('.scf-error-message');
			if (errorSpan) {
				errorSpan.textContent = '';
			}
			input.style.borderColor = '';
		};

		// Popups often close on bubbled clicks; stop submit button from bubbling.
		if (submitBtn) {
			submitBtn.addEventListener(
				'click',
				(e) => {
					e.stopPropagation();
				},
				true
			);
		}

		form.addEventListener('submit', async (event) => {
			event.preventDefault();
			event.stopPropagation();

			const inputs = form.querySelectorAll('input, textarea, select');
			inputs.forEach((input) => {
				clearFieldErrorUi(input);
				applyEmailCustomValidity(input);
			});

			// Use the browser's default required / minlength messages under the field.
			if (!form.checkValidity()) {
				form.reportValidity();
				return;
			}

			const currentTime = Math.floor(Date.now() / 1000);
			const timeSinceLastSubmission = currentTime - lastSubmissionTime;
			const timeSinceFormLoad = currentTime - formLoadTime;

			if (timeSinceFormLoad < 5) {
				setResponse('Please take your time to fill out the form properly.', true);
				return;
			}

			if (lastSubmissionTime > 0 && timeSinceLastSubmission < minTimeBetweenSubmissions) {
				setResponse('Please wait at least ' + minTimeBetweenSubmissions + ' seconds before submitting again.', true);
				return;
			}

			setResponse('');
			if (submitBtn) {
				submitBtn.disabled = true;
				submitBtn.classList.add('is-loading');
			}

			const submitText = submitBtn ? submitBtn.querySelector('.scf-submit-text') : null;
			const submitLoading = submitBtn ? submitBtn.querySelector('.scf-submit-loading') : null;
			if (submitText) submitText.style.display = 'none';
			if (submitLoading) submitLoading.style.display = 'inline-flex';

			const resetSubmitState = () => {
				if (submitBtn) {
					submitBtn.disabled = false;
					submitBtn.classList.remove('is-loading');
				}
				if (submitText) submitText.style.display = '';
				if (submitLoading) submitLoading.style.display = 'none';
			};

			let recaptchaToken = '';
			if (requiresRecaptcha) {
				try {
					const recaptcha = await waitForRecaptcha();
					recaptchaToken = await recaptcha.execute(SCF_FORM.recaptchaSiteKey, { action: SCF_FORM.recaptchaAction || 'submit' });
				} catch (error) {
					console.error('reCAPTCHA error:', error);
				}
			}

			const formData = new FormData(form);

			const formTimeInput = form.querySelector('[name="scf_form_time"]');
			if (formTimeInput) {
				formTimeInput.value = formLoadTime;
			}

			formData.append('action', 'scf_submit_form');
			formData.append('nonce', (SCF_FORM && SCF_FORM.nonce) || '');
			if (recaptchaToken) {
				formData.append('recaptcha_token', recaptchaToken);
			}

			try {
				const ajaxUrl = (SCF_FORM && SCF_FORM.ajaxUrl) || '';
				if (!ajaxUrl) {
					throw new Error('AJAX URL not configured');
				}
				const response = await fetch(ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					body: formData,
					// Prefer a quick first byte; heavy email/ERP work continues server-side after response.
					keepalive: true,
				});

				let result;
				try {
					const text = await response.text();
					const normalizedText = text ? text.trim() : '';
					try {
						result = normalizedText ? JSON.parse(normalizedText) : {};
					} catch (parseError) {
						// Recover when warnings/BOM are prepended before JSON.
						const startIndex = normalizedText.indexOf('{');
						const endIndex = normalizedText.lastIndexOf('}');
						if (startIndex !== -1 && endIndex !== -1 && endIndex > startIndex) {
							result = JSON.parse(normalizedText.slice(startIndex, endIndex + 1));
						} else {
							throw parseError;
						}
					}
				} catch (parseErr) {
					throw new Error(
						(SCF_FORM && SCF_FORM.messages && SCF_FORM.messages.error) ||
							'Something went wrong. Please try again.'
					);
				}
				if (!response.ok || !result.success) {
					const errorMsg =
						(result && result.data && result.data.message) ||
						(SCF_FORM && SCF_FORM.messages && SCF_FORM.messages.error) ||
						'Something went wrong. Please try again.';
					throw new Error(errorMsg);
				}

				lastSubmissionTime = Math.floor(Date.now() / 1000);

				const successMsg =
					(result && result.data && result.data.message) ||
					(SCF_FORM && SCF_FORM.messages && SCF_FORM.messages.success) ||
					'Thank you! Our team will contact you soon.';

				// Show success immediately, then reset the form.
				setResponse(successMsg, false);
				resetSubmitState();

				const savedFormTime = formTimeInput ? formTimeInput.value : formLoadTime;

				form.reset();
				validateCourseInterestGroup();
				toggleOtherCourseHint();

				if (formTimeInput) {
					formTimeInput.value = savedFormTime;
				}

				const errorMessages = form.querySelectorAll('.scf-error-message');
				errorMessages.forEach((el) => {
					el.textContent = '';
				});

			} catch (error) {
				const errorMsg =
					error.message ||
					(SCF_FORM && SCF_FORM.messages && SCF_FORM.messages.error) ||
					'Something went wrong. Please try again.';

				const emailInput = form.querySelector('#scf-email');
				if (emailInput && (errorMsg.includes('organizational email') || errorMsg.includes('organizational mailid'))) {
					const emailField = emailInput.closest('.scf-field');
					const errorSpan = emailField ? emailField.querySelector('.scf-error-message') : null;
					if (errorSpan) {
						errorSpan.textContent = errorMsg;
						emailInput.style.borderColor = '#dc2626';
						emailInput.setCustomValidity(errorMsg);
						emailInput.reportValidity();
					}
				} else {
					setResponse(errorMsg, true);
				}

			} finally {
				if (submitBtn) {
					submitBtn.disabled = false;
					submitBtn.classList.remove('is-loading');
				}
				if (submitText) submitText.style.display = '';
				if (submitLoading) submitLoading.style.display = 'none';
			}
		});

		const inputs = form.querySelectorAll('input, textarea, select');
		inputs.forEach((input) => {
			const refreshValidity = () => {
				clearFieldErrorUi(input);
				applyEmailCustomValidity(input);
			};

			input.addEventListener('input', refreshValidity);
			input.addEventListener('change', refreshValidity);
		});
	};

	const scanAndInit = () => {
		document.querySelectorAll('form.scf-form').forEach(initScfForm);
	};

	let domScanTimer = null;
	const scheduleScanAndInit = () => {
		if (domScanTimer) {
			clearTimeout(domScanTimer);
		}
		domScanTimer = setTimeout(() => {
			domScanTimer = null;
			scanAndInit();
		}, 120);
	};

	const maybeScheduleInitForAddedNodes = (mutations) => {
		for (const m of mutations) {
			for (const n of m.addedNodes) {
				if (n.nodeType !== 1) {
					continue;
				}
				if (n.matches && n.matches('form.scf-form')) {
					scheduleScanAndInit();
					return;
				}
				if (n.querySelector && n.querySelector('form.scf-form')) {
					scheduleScanAndInit();
					return;
				}
			}
		}
	};

	const startMutationObserver = () => {
		if (typeof MutationObserver === 'undefined' || !document.body) {
			return;
		}
		const observer = new MutationObserver(maybeScheduleInitForAddedNodes);
		observer.observe(document.body, { childList: true, subtree: true });
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			scanAndInit();
			startMutationObserver();
		});
	} else {
		scanAndInit();
		startMutationObserver();
	}

	// Popups / modals: also callable when the popup opens (in case MutationObserver is blocked).
	window.scfInitContactForms = scanAndInit;
})();

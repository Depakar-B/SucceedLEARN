<?php
/**
 * Configuration Management Class
 *
 * @package SucceedLEARN\AMP
 */

namespace SucceedLEARN\AMP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Config Class — Phase 1: front page + form/ERP settings.
 */
class Config {

	/**
	 * Plugin settings.
	 *
	 * @var array
	 */
	private $settings;

	public function __construct() {
		$this->load_settings();
	}

	private function load_settings() {
		$defaults = array(
			'version'                         => SUCCEEDLEARN_AMP_VERSION,
			'home_page_id'                    => 0,
			'clients_page_id'                 => 0,
			'contact_page_id'                 => 0,
			'thankyou_page_id'                => 0,
			'enable_custom_css'               => true,
			'custom_css'                      => '',
			'erpnext_api_url'                 => 'https://intranet.succeedtech.com/api/resource/Lead',
			'erpnext_api_key'                 => '',
			'contact_emails'                  => array( 'sales@succeedtech.com' ),
			'phone_numbers'                   => array(
				array( 'url' => 'tel:+919740576761', 'text' => '+91-97405 76761' ),
				array( 'url' => 'tel:+918660448654', 'text' => '+91-86604 48654' ),
			),
			'contact_email_recipients'        => class_exists( __NAMESPACE__ . '\\Email' )
				? Email::get_default_admin_recipients()
				: array( 'sales@succeedtech.com' ),
			'contact_user_email_brochure_url' => '',
		);

		$this->settings = wp_parse_args( get_option( 'succeedlearn_amp_settings', array() ), $defaults );
	}

	/**
	 * @param string $key Setting key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public function get( $key, $default = null ) {
		if ( 'erpnext_api_url' === $key ) {
			if ( function_exists( 'scf_is_admin_email_test_mode' ) && scf_is_admin_email_test_mode() ) {
				if ( defined( 'SUCCEEDLEARN_ERP_UAT_API_URL' ) && SUCCEEDLEARN_ERP_UAT_API_URL ) {
					return (string) SUCCEEDLEARN_ERP_UAT_API_URL;
				}
				if ( class_exists( 'SCF_Contact_Form_Plugin' ) ) {
					return \SCF_Contact_Form_Plugin::ERP_UAT_API_URL;
				}
				return 'https://uaterp.succeedtech.com/api/resource/Lead';
			}
		}

		if ( 'erpnext_api_url' === $key && defined( 'SUCCEEDLEARN_ERP_API_URL' ) && SUCCEEDLEARN_ERP_API_URL ) {
			return (string) SUCCEEDLEARN_ERP_API_URL;
		}
		if ( 'erpnext_api_key' === $key && function_exists( 'scf_is_admin_email_test_mode' ) && scf_is_admin_email_test_mode() ) {
			if ( defined( 'SUCCEEDLEARN_ERP_UAT_API_KEY' ) && SUCCEEDLEARN_ERP_UAT_API_KEY ) {
				return (string) SUCCEEDLEARN_ERP_UAT_API_KEY;
			}
		}
		if ( 'erpnext_api_key' === $key && defined( 'SUCCEEDLEARN_ERP_API_KEY' ) && SUCCEEDLEARN_ERP_API_KEY ) {
			return (string) SUCCEEDLEARN_ERP_API_KEY;
		}

		return isset( $this->settings[ $key ] ) ? $this->settings[ $key ] : $default;
	}

	/**
	 * @param string $key Setting key.
	 * @param mixed  $value Value.
	 */
	public function set( $key, $value ) {
		$this->settings[ $key ] = $value;
	}

	/**
	 * @return bool
	 */
	public function save() {
		return update_option( 'succeedlearn_amp_settings', $this->settings );
	}

	/**
	 * @return array
	 */
	public function get_all() {
		return $this->settings;
	}

	/**
	 * AMP page map — templates served by this plugin.
	 *
	 * @return array<string, array{settings_key?:string,default_id:int,slugs:array,template:string}>
	 */
	public static function get_amp_page_map() {
		return array(
			'home'     => array(
				'settings_key' => 'home_page_id',
				'default_id'   => 0,
				'slugs'        => array(),
				'template'     => 'pages/home',
			),
			'clients'  => array(
				'settings_key' => 'clients_page_id',
				'default_id'   => 0,
				'slugs'        => array( 'clients', 'our-clients' ),
				'template'     => 'pages/clients',
			),
			'contact'  => array(
				'settings_key' => 'contact_page_id',
				'default_id'   => 0,
				'slugs'        => array( 'contact-us', 'contact' ),
				'template'     => 'pages/contact',
			),
			'thankyou' => array(
				'settings_key' => 'thankyou_page_id',
				'default_id'   => 0,
				'slugs'        => array( 'thankyou', 'thank-you' ),
				'template'     => 'pages/thankyou',
			),
		);
	}

	/**
	 * Resolve AMP page type for a post ID / slug.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $slug    Post slug.
	 * @return string Page type key or empty string.
	 */
	public function resolve_amp_page_type( $post_id = 0, $slug = '' ) {
		$post_id = absint( $post_id );
		$slug    = sanitize_title( (string) $slug );

		if ( $this->is_front_page_request( $post_id, $slug ) ) {
			return 'home';
		}

		foreach ( self::get_amp_page_map() as $type => $map ) {
			if ( 'home' === $type ) {
				continue;
			}

			$settings_key = isset( $map['settings_key'] ) ? (string) $map['settings_key'] : '';
			if ( $settings_key && $post_id && absint( $this->get( $settings_key, 0 ) ) === $post_id ) {
				return $type;
			}

			$slugs = isset( $map['slugs'] ) ? (array) $map['slugs'] : array();
			if ( $slug && in_array( $slug, $slugs, true ) ) {
				return $type;
			}

			if ( $post_id ) {
				foreach ( $slugs as $page_slug ) {
					$page = get_page_by_path( $page_slug );
					if ( $page && absint( $page->ID ) === $post_id ) {
						return $type;
					}
				}
			}
		}

		return '';
	}

	/**
	 * Clients page permalink (canonical, non-AMP).
	 *
	 * @return string
	 */
	public function get_clients_url() {
		$page = $this->get_clients_page();
		if ( $page ) {
			$url = get_permalink( $page );
			if ( $url ) {
				return $url;
			}
		}

		return home_url( '/clients/' );
	}

	/**
	 * Published clients page, if one exists.
	 *
	 * @return \WP_Post|null
	 */
	public function get_clients_page() {
		$id = absint( $this->get( 'clients_page_id', 0 ) );
		if ( $id ) {
			$page = get_post( $id );
			if ( $page && 'page' === $page->post_type && 'publish' === $page->post_status ) {
				return $page;
			}
		}

		foreach ( array( 'clients', 'our-clients' ) as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page && 'publish' === $page->post_status ) {
				return $page;
			}
		}

		return null;
	}

	/**
	 * Whether a published clients page is available.
	 *
	 * @return bool
	 */
	public function has_clients_page() {
		return (bool) $this->get_clients_page();
	}

	/**
	 * Whether the current request is the site front page.
	 *
	 * @param int    $post_id Optional post ID.
	 * @param string $slug    Optional slug.
	 * @return bool
	 */
	public function is_front_page_request( $post_id = 0, $slug = '' ) {
		if ( function_exists( 'is_front_page' ) && is_front_page() ) {
			return true;
		}

		$front_id = absint( get_option( 'page_on_front' ) );
		if ( $front_id && $post_id && absint( $post_id ) === $front_id ) {
			return true;
		}

		$configured = absint( $this->get( 'home_page_id', 0 ) );
		if ( $configured && $post_id && absint( $post_id ) === $configured ) {
			return true;
		}

		return false;
	}

	/**
	 * Resolve thank-you URL for AMP form redirects.
	 *
	 * @return string
	 */
	public function get_thankyou_url() {
		$id = absint( $this->get( 'thankyou_page_id', 0 ) );
		if ( $id ) {
			$url = get_permalink( $id );
			if ( $url ) {
				return $url;
			}
		}

		$page = get_page_by_path( 'thankyou' );
		if ( ! $page ) {
			$page = get_page_by_path( 'thank-you' );
		}
		if ( $page ) {
			return get_permalink( $page );
		}

		return home_url( '/' );
	}

	/**
	 * Build AMP URL for a path or permalink.
	 *
	 * @param string $path Path or full URL.
	 * @return string
	 */
	public function amp_url( $path = '/' ) {
		if ( function_exists( 'succeedlearn_amp_url' ) ) {
			return succeedlearn_amp_url( $path );
		}

		$url = ( 0 === strpos( $path, 'http' ) ) ? $path : home_url( $path );
		return add_query_arg( 'amp', '1', $url );
	}
}

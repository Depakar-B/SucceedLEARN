<?php
/**
 * AMP Router — mobile/tablet redirect to AMP for plugin pages.
 *
 * @package SucceedLEARN\AMP
 */

namespace SucceedLEARN\AMP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Amp_Router — mobile/tablet AMP redirect for plugin pages.
 */
class Amp_Router {

	/**
	 * @var Config
	 */
	private $config;

	/**
	 * @param Config $config Config instance.
	 */
	public function __construct( Config $config ) {
		$this->config = $config;
	}

	public function init() {
		add_action( 'plugins_loaded', array( $this, 'enable_amp_post_meta_for_plugin_pages' ), 30 );
		add_filter( 'ampforwp_disable_mobile_amp_redirect', array( $this, 'allow_mobile_amp_redirect' ), 99999 );
		add_filter( 'ampforwp_cpt_support', array( $this, 'ensure_page_cpt_support' ) );
		add_filter( 'amp_is_enabled', array( $this, 'force_amp_is_enabled' ), 100 );
		add_filter( 'ampforwp_is_non_amp', array( $this, 'force_amp_capable' ), 99999 );

		add_action( 'wp', array( $this, 'ensure_amp_post_meta_on_request' ), 1 );
		add_action( 'wp', array( $this, 'maybe_redirect' ), 1 );
		add_action( 'wp', array( $this, 'maybe_redirect' ), 99 );
		add_action( 'template_redirect', array( $this, 'maybe_redirect' ), 1 );

		add_action( 'wp_head', array( $this, 'print_amp_redirect_script' ), 1 );
		add_action( 'wp_footer', array( $this, 'print_amp_redirect_script' ), 1 );
	}

	/**
	 * Enable AMP meta on plugin-managed pages that have a custom template.
	 */
	public function enable_amp_post_meta_for_plugin_pages() {
		$ids = array();

		$front_id = absint( get_option( 'page_on_front' ) );
		if ( $front_id ) {
			$ids[] = $front_id;
		}

		foreach ( Config::get_amp_page_map() as $type => $map ) {
			$template = isset( $map['template'] ) ? SUCCEEDLEARN_AMP_TEMPLATES_DIR . $map['template'] . '.php' : '';
			if ( ! $template || ! is_readable( $template ) ) {
				continue;
			}

			if ( 'home' === $type ) {
				continue;
			}

			$settings_key = isset( $map['settings_key'] ) ? (string) $map['settings_key'] : '';
			if ( $settings_key ) {
				$configured = absint( $this->config->get( $settings_key, 0 ) );
				if ( $configured ) {
					$ids[] = $configured;
				}
			}

			$slugs = isset( $map['slugs'] ) ? (array) $map['slugs'] : array();
			foreach ( $slugs as $slug ) {
				$page = get_page_by_path( $slug );
				if ( $page ) {
					$ids[] = absint( $page->ID );
				}
			}
		}

		foreach ( array_unique( array_filter( $ids ) ) as $post_id ) {
			update_post_meta( $post_id, 'ampforwp-amp-on-off', 'enabled' );
		}
	}

	/**
	 * Re-enable mobile AMP redirect when theme/AMPforWP disabled it globally.
	 *
	 * @param bool $disabled Whether redirect is disabled.
	 * @return bool
	 */
	public function allow_mobile_amp_redirect( $disabled ) {
		if ( $this->is_plugin_amp_page_request() && $this->is_mobile_or_tablet_request() ) {
			return false;
		}
		return $disabled;
	}

	/**
	 * @param array $cpts Supported CPTs.
	 * @return array
	 */
	public function ensure_page_cpt_support( $cpts ) {
		if ( ! is_array( $cpts ) ) {
			$cpts = array();
		}
		if ( ! in_array( 'page', $cpts, true ) ) {
			$cpts[] = 'page';
		}
		return $cpts;
	}

	/**
	 * @param bool $enabled Whether AMP is enabled.
	 * @return bool
	 */
	public function force_amp_is_enabled( $enabled ) {
		if ( $this->is_plugin_amp_page_request() ) {
			return true;
		}
		return $enabled;
	}

	/**
	 * @param bool $is_non_amp Whether treated as non-AMP.
	 * @return bool
	 */
	public function force_amp_capable( $is_non_amp ) {
		if ( $this->is_plugin_amp_page_request() ) {
			return false;
		}
		return $is_non_amp;
	}

	public function ensure_amp_post_meta_on_request() {
		if ( ! $this->is_plugin_amp_page_request() ) {
			return;
		}
		$post_id = $this->resolve_request_page_id();
		if ( $post_id ) {
			update_post_meta( $post_id, 'ampforwp-amp-on-off', 'enabled' );
		}
	}

	public function maybe_redirect() {
		if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}

		if ( $this->is_serving_amp() ) {
			return;
		}

		if ( isset( $_GET['noamp'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		if ( ! $this->is_plugin_amp_page_request() ) {
			return;
		}

		if ( ! $this->is_mobile_or_tablet_request() ) {
			return;
		}

		$this->perform_amp_redirect();
	}

	/**
	 * @return bool
	 */
	public function is_plugin_amp_page_request() {
		$page_type = $this->resolve_request_page_type();
		if ( ! $page_type ) {
			return false;
		}

		$map = Config::get_amp_page_map();
		if ( empty( $map[ $page_type ]['template'] ) ) {
			return false;
		}

		$template = SUCCEEDLEARN_AMP_TEMPLATES_DIR . $map[ $page_type ]['template'] . '.php';
		return is_readable( $template );
	}

	/**
	 * @return string
	 */
	private function resolve_request_page_type() {
		$req_id = $this->resolve_request_page_id();
		$slug   = '';

		if ( $req_id ) {
			$post = get_post( $req_id );
			if ( $post ) {
				$slug = (string) $post->post_name;
			}
		}

		return $this->config->resolve_amp_page_type( $req_id, $slug );
	}

	/**
	 * @return int
	 */
	private function resolve_request_page_id() {
		if ( is_singular() ) {
			return absint( get_queried_object_id() );
		}

		$front_id = absint( get_option( 'page_on_front' ) );
		if ( $front_id && function_exists( 'is_front_page' ) && is_front_page() ) {
			return $front_id;
		}

		return 0;
	}

	/**
	 * @return bool
	 */
	public function is_mobile_or_tablet_request() {
		if ( function_exists( 'wp_is_mobile' ) && wp_is_mobile() ) {
			return true;
		}

		$ch = isset( $_SERVER['HTTP_SEC_CH_UA_MOBILE'] ) ? (string) wp_unslash( $_SERVER['HTTP_SEC_CH_UA_MOBILE'] ) : '';
		if ( '?1' === $ch ) {
			return true;
		}

		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		if ( '' === $ua ) {
			return false;
		}

		$tablet_needles = array( 'ipad', 'tablet', 'kindle', 'silk', 'playbook', 'nexus 7', 'nexus 10', 'sm-t' );
		foreach ( $tablet_needles as $needle ) {
			if ( false !== strpos( $ua, $needle ) ) {
				return true;
			}
		}

		// iPadOS often reports as Macintosh + touch.
		if ( false !== strpos( $ua, 'macintosh' ) && false !== strpos( $ua, 'mobile' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * @return bool
	 */
	public function is_serving_amp() {
		if ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() ) {
			return true;
		}
		if ( function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint() ) {
			return true;
		}
		if ( function_exists( 'amp_is_request' ) && amp_is_request() ) {
			return true;
		}
		if ( isset( $_GET['amp'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return true;
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( $uri && preg_match( '#/amp/?(\?|$)#', $uri ) ) {
			return true;
		}

		return false;
	}

	private function perform_amp_redirect() {
		$amp_url = $this->get_amp_permalink();
		if ( ! $amp_url ) {
			return;
		}

		$current = ( is_ssl() ? 'https://' : 'http://' ) . ( isset( $_SERVER['HTTP_HOST'] ) ? wp_unslash( $_SERVER['HTTP_HOST'] ) : '' ) . ( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '' );
		if ( untrailingslashit( $current ) === untrailingslashit( $amp_url ) ) {
			return;
		}

		nocache_headers();
		header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
		wp_safe_redirect( $amp_url, 302 );
		exit;
	}

	/**
	 * @return string
	 */
	public function get_amp_permalink() {
		$permalink = get_permalink();
		if ( ! $permalink && function_exists( 'is_front_page' ) && is_front_page() ) {
			$permalink = home_url( '/' );
		}
		if ( ! $permalink ) {
			return '';
		}

		if ( function_exists( 'ampforwp_url_controller' ) ) {
			$converted = ampforwp_url_controller( $permalink );
			if ( is_string( $converted ) && $converted ) {
				return $converted;
			}
		}

		if ( function_exists( 'amp_add_paired_endpoint' ) ) {
			return amp_add_paired_endpoint( $permalink );
		}

		return add_query_arg( 'amp', '1', $permalink );
	}

	/**
	 * JS fallback redirect for viewports ≤1024px when server UA miss.
	 */
	public function print_amp_redirect_script() {
		if ( is_admin() || $this->is_serving_amp() ) {
			return;
		}
		if ( ! $this->is_plugin_amp_page_request() ) {
			return;
		}
		if ( isset( $_GET['noamp'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$amp_url = $this->get_amp_permalink();
		if ( ! $amp_url ) {
			return;
		}

		static $printed = false;
		if ( $printed ) {
			return;
		}
		$printed = true;
		?>
		<script>
		(function(){
			try {
				if (window.location.search.indexOf('noamp') !== -1) return;
				var w = window.innerWidth || document.documentElement.clientWidth || 0;
				var touch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
				if (w > 0 && w <= 1024 && (touch || /Mobi|Android|iPad|Tablet/i.test(navigator.userAgent||''))) {
					window.location.replace(<?php echo wp_json_encode( $amp_url ); ?>);
				}
			} catch(e) {}
		})();
		</script>
		<?php
	}
}

<?php
/**
 * Performance / AMP HTML helpers.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @return bool
 */
function succeedlearn_amp_is_serving_amp() {
	if ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() ) {
		return true;
	}
	if ( function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint() ) {
		return true;
	}
	if ( function_exists( 'amp_is_request' ) && amp_is_request() ) {
		return true;
	}
	if ( isset( $_GET['amp'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return true;
	}
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	return (bool) ( $uri && preg_match( '#/amp/?(\?|$)#', $uri ) );
}

/**
 * @param string $path Path or URL.
 * @return string
 */
function succeedlearn_amp_url( $path = '/' ) {
	$url = ( 0 === strpos( (string) $path, 'http' ) ) ? $path : home_url( $path );
	if ( function_exists( 'ampforwp_url_controller' ) ) {
		$converted = ampforwp_url_controller( $url );
		if ( is_string( $converted ) && $converted ) {
			return $converted;
		}
	}
	if ( function_exists( 'amp_add_paired_endpoint' ) ) {
		return amp_add_paired_endpoint( $url );
	}
	return add_query_arg( 'amp', '1', $url );
}

/**
 * @param string $name Style partial basename.
 */
function succeedlearn_amp_include_style_partial( $name ) {
	$path = SUCCEEDLEARN_AMP_TEMPLATES_DIR . 'styles/' . sanitize_file_name( $name ) . '.php';
	if ( is_readable( $path ) ) {
		include $path;
	}
}

/**
 * @param string   $page_type Page type.
 * @param string[] $style_files Cached style files.
 * @param string[] $always_inline Always-inline partials.
 */
function succeedlearn_amp_output_page_styles( $page_type, $style_files = array(), $always_inline = array() ) {
	$shared      = array( 'menu', 'footer', 'scroll-to-top' );
	$extra       = array_values( array_unique( array_merge( (array) $style_files, (array) $always_inline ) ) );
	$cache_extra = array_values( array_diff( $extra, $shared, (array) $always_inline ) );
	$cache_files = array_values( array_unique( array_merge( $shared, $cache_extra ) ) );

	if ( class_exists( '\\SucceedLEARN\\AMP\\Performance_Optimizer' ) ) {
		$optimizer = \SucceedLEARN\AMP\Performance_Optimizer::get_instance();
		$css       = $optimizer->get_optimized_css( $page_type, $cache_files );
		if ( $css ) {
			echo $css; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			foreach ( $cache_files as $file ) {
				succeedlearn_amp_include_style_partial( $file );
			}
		}
	} else {
		foreach ( $cache_files as $file ) {
			succeedlearn_amp_include_style_partial( $file );
		}
	}

	foreach ( (array) $always_inline as $file ) {
		succeedlearn_amp_include_style_partial( $file );
	}
}

/**
 * @param string   $page_type Page type.
 * @param string[] $additional Extra components.
 */
function succeedlearn_amp_output_components( $page_type, $additional = array() ) {
	if ( class_exists( '\\SucceedLEARN\\AMP\\Performance_Optimizer' ) ) {
		\SucceedLEARN\AMP\Performance_Optimizer::get_instance()->output_amp_components( $page_type, $additional );
	}
}

/**
 * Collect compiled CSS for a page (used by template + post-tree-shake restore).
 *
 * @param string   $page_type Page type.
 * @param string[] $style_files Cached style files.
 * @param string[] $always_inline Always-inline partials.
 * @return string
 */
function succeedlearn_amp_get_page_styles_css( $page_type, $style_files = array(), $always_inline = array() ) {
	ob_start();
	succeedlearn_amp_output_page_styles( $page_type, $style_files, $always_inline );
	return trim( (string) ob_get_clean() );
}

/**
 * After AMPforWP tree shaking, restore SucceedLEARN amp-custom CSS when stripped.
 *
 * @param string $html HTML.
 * @return string
 */
function succeedlearn_amp_restore_custom_amp_css( $html ) {
	if ( ! is_string( $html ) || '' === $html ) {
		return $html;
	}
	if ( ! succeedlearn_amp_is_serving_amp() ) {
		return $html;
	}
	// Only restore when our markup is present but our selectors are missing from CSS.
	if ( false === strpos( $html, 'sl-hero' ) && false === strpos( $html, 'amp-site-header' ) ) {
		return $html;
	}
	if ( false !== strpos( $html, '.sl-hero' ) && false !== strpos( $html, '.amp-site-header' ) ) {
		return $html;
	}

	$hero_bg = get_template_directory_uri() . '/assets/images/hero-bg.jpg';
	$css     = succeedlearn_amp_get_page_styles_css( 'home', array( 'home-page' ), array( 'home-sections', 'contact-form' ) );
	$css    .= '.sl-hero{background-image:url(' . esc_url_raw( $hero_bg ) . ')}';

	if ( '' === trim( $css ) ) {
		return $html;
	}

	if ( preg_match( '/<style\b[^>]*\bamp-custom\b[^>]*>.*?<\/style>/is', $html ) ) {
		$html = preg_replace(
			'/(<style\b[^>]*\bamp-custom\b[^>]*>)(.*?)(<\/style>)/is',
			'$1' . $css . '$3',
			$html,
			1
		);
	} else {
		$html = preg_replace(
			'/<\/head>/i',
			'<style amp-custom>' . $css . '</style></head>',
			$html,
			1
		);
	}

	return $html;
}

/**
 * @return string
 */
function succeedlearn_amp_get_favicon_url() {
	$icon = get_site_icon_url( 32 );
	if ( $icon ) {
		return $icon;
	}
	$theme = get_template_directory_uri() . '/assets/images/logo-mark.svg';
	return $theme;
}

/**
 * Fixed widgets (scroll-to-top).
 */
function succeedlearn_amp_render_fixed_widgets() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	$path = SUCCEEDLEARN_AMP_TEMPLATES_DIR . 'components/scroll-to-top.php';
	if ( is_readable( $path ) ) {
		include $path;
	}
}

/**
 * Lightweight AMP HTML finalize for output buffer.
 *
 * @param string $html HTML.
 * @return string
 */
function succeedlearn_amp_finalize_amp_html( $html ) {
	$html = succeedlearn_amp_sanitize_amp_html( $html, false );
	return succeedlearn_amp_restore_custom_amp_css( $html );
}

/**
 * @param string $html HTML fragment.
 * @return string
 */
function succeedlearn_amp_sanitize_amp_fragment( $html ) {
	return succeedlearn_amp_sanitize_amp_html( $html, true );
}

/**
 * @param string $html HTML.
 * @param bool   $fragment_only Fragment mode.
 * @return string
 */
function succeedlearn_amp_sanitize_amp_html( $html, $fragment_only = false ) {
	if ( ! is_string( $html ) || '' === $html ) {
		return $html;
	}

	// Convert plain <img> to amp-img when possible.
	$html = preg_replace_callback(
		'/<img\b([^>]*)>/i',
		static function ( $m ) {
			$attrs = $m[1];
			if ( false !== stripos( $attrs, 'amp-img' ) ) {
				return $m[0];
			}
			$src = '';
			if ( preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $attrs, $sm ) ) {
				$src = $sm[1];
			}
			if ( ! $src ) {
				return '';
			}
			$width  = 600;
			$height = 400;
			if ( preg_match( '/\bwidth=["\']?(\d+)/i', $attrs, $wm ) ) {
				$width = (int) $wm[1];
			}
			if ( preg_match( '/\bheight=["\']?(\d+)/i', $attrs, $hm ) ) {
				$height = (int) $hm[1];
			}
			$alt = '';
			if ( preg_match( '/\balt=["\']([^"\']*)["\']/i', $attrs, $am ) ) {
				$alt = $am[1];
			}
			$class = '';
			if ( preg_match( '/\bclass=["\']([^"\']*)["\']/i', $attrs, $cm ) ) {
				$class = $cm[1];
			}
			return sprintf(
				'<amp-img src="%s" width="%d" height="%d" layout="responsive" alt="%s"%s></amp-img>',
				esc_url( $src ),
				$width,
				$height,
				esc_attr( $alt ),
				$class ? ' class="' . esc_attr( $class ) . '"' : ''
			);
		},
		$html
	);

	// Strip inline event handlers.
	$html = preg_replace( '/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html );

	if ( ! $fragment_only ) {
		// Ensure amp attribute on html.
		if ( preg_match( '/<html\b/i', $html ) && ! preg_match( '/<html\b[^>]*\bamp\b/i', $html ) ) {
			$html = preg_replace( '/<html\b/i', '<html amp', $html, 1 );
		}
	}

	return $html;
}

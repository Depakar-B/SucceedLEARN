<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SL_ERP_Logger {
	const STATUS_SYNCED    = 'synced';
	const STATUS_DUPLICATE = 'duplicate';
	const STATUS_ERROR     = 'error';
	const STATUS_SKIPPED   = 'skipped';
	const STATUS_DISABLED  = 'disabled';

	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'sl_erp_responses';
	}

	public static function create_table() {
		global $wpdb;
		$table   = self::table_name();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			form_key varchar(100) NOT NULL DEFAULT '',
			email varchar(255) NOT NULL DEFAULT '',
			utm_source varchar(255) NOT NULL DEFAULT '',
			status varchar(32) NOT NULL DEFAULT '',
			summary varchar(255) NOT NULL DEFAULT '',
			erp_response longtext NOT NULL,
			payload_json longtext NOT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY form_key (form_key),
			KEY email (email),
			KEY status (status)
		) {$charset};";
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
		self::maybe_upgrade_columns();
	}

	/**
	 * Ensure status/summary columns exist on older installs.
	 */
	public static function maybe_upgrade_columns() {
		global $wpdb;
		$table = self::table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$status_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW COLUMNS FROM `' . $table . '` LIKE %s', 'status' ) );
		if ( ! $status_exists ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query( "ALTER TABLE `{$table}` ADD status varchar(32) NOT NULL DEFAULT '' AFTER utm_source" );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$summary_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW COLUMNS FROM `' . $table . '` LIKE %s', 'summary' ) );
		if ( ! $summary_exists ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query( "ALTER TABLE `{$table}` ADD summary varchar(255) NOT NULL DEFAULT '' AFTER status" );
		}
	}

	/**
	 * Classify ERP response body into a readable status + summary.
	 *
	 * @param string $erp_response Raw ERP response JSON/text.
	 * @return array{status:string,summary:string}
	 */
	public static function classify_response( $erp_response ) {
		$body = (string) $erp_response;
		if ( '' === trim( $body ) ) {
			return array(
				'status'  => self::STATUS_ERROR,
				'summary' => 'Empty ERP response',
			);
		}

		$decoded = json_decode( $body, true );
		$error   = '';
		if ( is_array( $decoded ) ) {
			if ( ! empty( $decoded['error'] ) && is_string( $decoded['error'] ) ) {
				$error = $decoded['error'];
			} elseif ( ! empty( $decoded['exc_type'] ) && is_string( $decoded['exc_type'] ) ) {
				$error = $decoded['exc_type'];
			}
		}

		if ( 'erp_disabled' === $error ) {
			return array(
				'status'  => self::STATUS_DISABLED,
				'summary' => 'ERP sync disabled in settings',
			);
		}

		if ( 'skipped_not_homepage' === $error ) {
			return array(
				'status'  => self::STATUS_SKIPPED,
				'summary' => 'Skipped (not homepage form)',
			);
		}

		if ( false !== stripos( $body, 'DuplicateEntryError' )
			|| false !== stripos( $body, 'DuplicateEntry' )
			|| false !== stripos( $body, 'already exists' )
		) {
			$lead = '';
			if ( preg_match( '/ST-[A-Z0-9-]+/i', $body, $m ) ) {
				$lead = $m[0];
			}
			return array(
				'status'  => self::STATUS_DUPLICATE,
				'summary' => $lead ? sprintf( 'Duplicate lead (%s)', $lead ) : 'Duplicate email in ERP',
			);
		}

		if ( is_array( $decoded ) && ! empty( $decoded['data']['name'] ) ) {
			return array(
				'status'  => self::STATUS_SYNCED,
				'summary' => 'Synced: ' . sanitize_text_field( (string) $decoded['data']['name'] ),
			);
		}

		if ( false !== stripos( $body, '"exc_type"' )
			|| false !== stripos( $body, 'missing_api_credentials' )
			|| false !== stripos( $body, 'erp_http_error' )
			|| false !== stripos( $body, 'erp_curl_error' )
			|| false !== stripos( $body, 'wp_remote_request_failed' )
			|| ( is_array( $decoded ) && isset( $decoded['success'] ) && false === $decoded['success'] )
		) {
			$summary = $error ? sanitize_text_field( $error ) : 'ERP sync failed';
			if ( is_array( $decoded ) && ! empty( $decoded['message'] ) && is_string( $decoded['message'] ) ) {
				$summary = sanitize_text_field( wp_trim_words( $decoded['message'], 12 ) );
			}
			return array(
				'status'  => self::STATUS_ERROR,
				'summary' => $summary,
			);
		}

		return array(
			'status'  => self::STATUS_ERROR,
			'summary' => 'Unrecognized ERP response',
		);
	}

	/**
	 * Human label for status codes.
	 *
	 * @param string $status Status code.
	 * @return string
	 */
	public static function status_label( $status ) {
		$map = array(
			self::STATUS_SYNCED    => __( 'Synced', 'succeedlearn-form-erp' ),
			self::STATUS_DUPLICATE => __( 'Duplicate', 'succeedlearn-form-erp' ),
			self::STATUS_ERROR     => __( 'Error', 'succeedlearn-form-erp' ),
			self::STATUS_SKIPPED   => __( 'Skipped', 'succeedlearn-form-erp' ),
			self::STATUS_DISABLED  => __( 'Disabled', 'succeedlearn-form-erp' ),
		);
		$status = (string) $status;
		return isset( $map[ $status ] ) ? $map[ $status ] : $status;
	}

	public static function log( $form_key, $email, $utm_source, $erp_response, array $lead_data ) {
		global $wpdb;
		self::create_table();

		$classified = self::classify_response( (string) $erp_response );

		$wpdb->insert(
			self::table_name(),
			array(
				'form_key'     => sanitize_text_field( (string) $form_key ),
				'email'        => sanitize_email( (string) $email ),
				'utm_source'   => sanitize_text_field( (string) $utm_source ),
				'status'       => sanitize_text_field( $classified['status'] ),
				'summary'      => sanitize_text_field( $classified['summary'] ),
				'erp_response' => (string) $erp_response,
				'payload_json' => wp_json_encode( $lead_data ),
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Latest ERP log row for an email.
	 *
	 * @param string $email Email address.
	 * @return array<string, mixed>|null
	 */
	public static function get_latest_for_email( $email ) {
		global $wpdb;
		$email = sanitize_email( (string) $email );
		if ( '' === $email ) {
			return null;
		}

		self::maybe_upgrade_columns();
		$table = self::table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, status, summary, erp_response, created_at FROM {$table} WHERE email = %s ORDER BY id DESC LIMIT 1",
				$email
			),
			ARRAY_A
		);

		return is_array( $row ) ? $row : null;
	}

	/**
	 * Recent log rows for admin UI.
	 *
	 * @param int $limit Max rows.
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_recent( $limit = 50 ) {
		global $wpdb;
		self::maybe_upgrade_columns();
		$table = self::table_name();
		$limit = max( 1, min( 200, (int) $limit ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, form_key, email, utm_source, status, summary, LEFT(erp_response, 400) AS erp_response, created_at
				FROM {$table}
				ORDER BY id DESC
				LIMIT %d",
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}
}

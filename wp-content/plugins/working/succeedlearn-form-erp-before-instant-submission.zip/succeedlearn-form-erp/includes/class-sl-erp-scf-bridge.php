<?php
/**
 * Bridge Succeed Common Contact Form submissions to ERPNext.
 *
 * Only homepage form submissions are forwarded to ERP.
 *
 * @package SucceedLEARN_Form_ERP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hooks scf_after_submission into succeedlearn_form_send_to_erp().
 */
class SL_ERP_SCF_Bridge {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'scf_after_submission', array( __CLASS__, 'handle_submission' ), 10, 2 );
	}

	/**
	 * Forward homepage contact form data to ERP.
	 *
	 * @param array       $data     Submission data.
	 * @param array|false $response ERP HTTP response (unused).
	 */
	public static function handle_submission( $data, $response ) {
		if ( ! function_exists( 'succeedlearn_form_send_to_erp' ) ) {
			return;
		}

		if ( ! self::is_homepage_submission( $data ) ) {
			self::log_skip( $data, 'skipped_not_homepage' );
			return;
		}

		$form_variant = 'default';
		if ( ! empty( $data['form_variant'] ) ) {
			$form_variant = sanitize_text_field( (string) $data['form_variant'] );
		} elseif ( isset( $_POST['scf_form_variant'] ) ) {
			$form_variant = sanitize_text_field( wp_unslash( (string) $_POST['scf_form_variant'] ) );
		}

		$submission                 = $data;
		$submission['form_variant'] = $form_variant;
		$submission['source_tag']   = 'SucceedLEARN HomePage';

		succeedlearn_form_send_to_erp(
			$submission,
			array(
				'form_key'     => 'scf_homepage',
				'form_variant' => $form_variant,
			)
		);
	}

	/**
	 * Log a skipped ERP attempt for diagnostics.
	 *
	 * @param array  $data   Submission data.
	 * @param string $reason Skip reason code.
	 */
	private static function log_skip( $data, $reason ) {
		if ( ! class_exists( 'SL_ERP_Logger' ) ) {
			return;
		}

		$email   = isset( $data['email'] ) ? (string) $data['email'] : '';
		$utm     = isset( $data['utm_source'] ) ? (string) $data['utm_source'] : '';
		$payload = array(
			'source_tag' => isset( $data['source_tag'] ) ? (string) $data['source_tag'] : '',
			'page_url'   => isset( $data['page_url'] ) ? (string) $data['page_url'] : '',
		);
		$response = wp_json_encode(
			array(
				'success' => false,
				'error'   => $reason,
				'message' => 'SCF submission was not forwarded to ERP (homepage gate).',
				'meta'    => $payload,
			)
		);

		SL_ERP_Logger::log( 'scf_skipped', $email, $utm, $response, $payload );
	}

	/**
	 * Determine whether a submission came from the homepage form.
	 *
	 * @param array $data Submission data.
	 * @return bool
	 */
	private static function is_homepage_submission( $data ) {
		if ( ! empty( $data['source_tag'] ) && 'SucceedLEARN HomePage' === $data['source_tag'] ) {
			return true;
		}

		$page_url = ! empty( $data['page_url'] ) ? (string) $data['page_url'] : '';
		if ( '' !== $page_url && self::urls_match_front_page( $page_url ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Compare a submitted page URL to the site front page.
	 * Host may differ on staging; path match (or root/home) is enough.
	 *
	 * @param string $page_url Submitted page URL.
	 * @return bool
	 */
	private static function urls_match_front_page( $page_url ) {
		$home_url = trailingslashit( home_url( '/' ) );
		$home     = wp_parse_url( $home_url );
		$page     = wp_parse_url( $page_url );

		if ( empty( $page['host'] ) ) {
			return false;
		}

		$home_path = isset( $home['path'] ) ? untrailingslashit( (string) $home['path'] ) : '';
		$page_path = isset( $page['path'] ) ? untrailingslashit( (string) $page['path'] ) : '';

		if ( ! empty( $home['host'] )
			&& strtolower( (string) $home['host'] ) === strtolower( (string) $page['host'] )
			&& $home_path === $page_path
		) {
			return true;
		}

		$page_path_norm = strtolower( trim( $page_path, '/' ) );
		return ( '' === $page_path_norm || 'home' === $page_path_norm );
	}
}

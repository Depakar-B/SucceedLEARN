<?php
/**
 * Security Awareness AMP — Contact / demo section.
 *
 * Expected vars: $page_title, $canonical
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-section" id="contact">
	<div class="sl-wrap sl-contact-layout">
		<div class="sl-contact-intro">
			<p class="sl-eyebrow"><?php esc_html_e( 'Talk to our team', 'succeedlearn-amp' ); ?></p>
			<h2 class="sl-h2"><?php esc_html_e( 'See the Security Behaviour & Culture Suite in action', 'succeedlearn-amp' ); ?></h2>
			<p class="sl-lead"><?php esc_html_e( 'Book a short, no-obligation demo and we will walk you through awareness training, phishing simulations, microlearning, analytics, and how the suite can fit your organisation.', 'succeedlearn-amp' ); ?></p>
			<div class="sl-sa-contact-direct">
				<p class="sl-sa-contact-direct__label"><?php esc_html_e( 'Prefer to reach us directly?', 'succeedlearn-amp' ); ?></p>
				<a href="mailto:sales@succeedtech.com">
					<span class="sl-sa-contact-direct__title"><?php esc_html_e( 'Email us', 'succeedlearn-amp' ); ?></span>
					<span class="sl-sa-contact-direct__value">sales@succeedtech.com</span>
				</a>
				<a href="tel:+916362021778">
					<span class="sl-sa-contact-direct__title"><?php esc_html_e( 'Call us', 'succeedlearn-amp' ); ?></span>
					<span class="sl-sa-contact-direct__value">+91 63620 21778</span>
				</a>
			</div>
		</div>
		<div class="sl-contact-form-card">
			<?php
			if ( function_exists( 'succeedlearn_amp_render_contact_form' ) ) {
				succeedlearn_amp_render_contact_form(
					array(
						'form_page'     => $page_title,
						'form_page_url' => $canonical,
						'form_variant'  => 'course',
						'title'         => __( 'Request a Demo', 'succeedlearn-amp' ),
						'echo'          => true,
					)
				);
			} else {
				echo do_shortcode( '[contact_form form_variant="course" title="Request a Demo"]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
		</div>
	</div>
</section>

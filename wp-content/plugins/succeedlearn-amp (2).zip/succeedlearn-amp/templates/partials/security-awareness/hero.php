<?php
/**
 * Security Awareness AMP — Hero section.
 *
 * Expected vars: $page_title
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$hero_title = ! empty( $page_title )
	? $page_title
	: __( 'SucceedLEARN Security Behaviour & Culture Suite', 'succeedlearn-amp' );
?>
<section class="sl-sa-hero" aria-labelledby="sl-sa-hero-title">
	<div class="sl-wrap">
		<div class="sl-sa-hero__grid">
			<div class="sl-sa-hero__content">
				<span class="sl-home-sub-heading sl-sa-hero__eyebrow"><?php esc_html_e( 'Security Awareness & Human Risk', 'succeedlearn-amp' ); ?></span>
				<h1 id="sl-sa-hero-title"><?php echo esc_html( $hero_title ); ?></h1>
				<h2 class="sl-sa-hero__subheading"><?php esc_html_e( 'Build a Security-Aware Workforce. Strengthen Human Risk Resilience.', 'succeedlearn-amp' ); ?></h2>
				<p class="sl-sa-hero__description"><?php esc_html_e( 'The SucceedLEARN Security Behaviour & Culture Suite combines awareness training, phishing simulations, microlearning, gamification, visual nudges, analytics, and seamless integrations into one unified platform that helps organisations reduce human cyber risk while meeting global compliance requirements.', 'succeedlearn-amp' ); ?></p>
				<ul class="sl-sa-hero__points" aria-label="<?php esc_attr_e( 'Security awareness benefits', 'succeedlearn-amp' ); ?>">
					<li>
						<span class="sl-sa-hero__point-icon" aria-hidden="true">✓</span>
						<span><?php esc_html_e( 'Build stronger security behaviours', 'succeedlearn-amp' ); ?></span>
					</li>
					<li>
						<span class="sl-sa-hero__point-icon" aria-hidden="true">✓</span>
						<span><?php esc_html_e( 'Identify and reduce human cyber risk', 'succeedlearn-amp' ); ?></span>
					</li>
					<li>
						<span class="sl-sa-hero__point-icon" aria-hidden="true">✓</span>
						<span><?php esc_html_e( 'Measure awareness with actionable insights', 'succeedlearn-amp' ); ?></span>
					</li>
				</ul>
				<div class="sl-sa-hero__actions">
					<button type="button" class="sl-btn sl-btn--primary" <?php echo succeedlearn_amp_scroll_tap_attr( 'contact' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php esc_html_e( 'Request a Demo', 'succeedlearn-amp' ); ?></button>
					<button type="button" class="sl-btn sl-btn--secondary" <?php echo succeedlearn_amp_scroll_tap_attr( 'security-awareness-suite' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php esc_html_e( 'Explore the Suite', 'succeedlearn-amp' ); ?></button>
				</div>
			</div>

			<div class="sl-sa-hero__visual" aria-label="<?php esc_attr_e( 'Security awareness analytics dashboard preview', 'succeedlearn-amp' ); ?>">
				<div class="sl-sa-dashboard">
					<div class="sl-sa-dashboard__topbar">
						<div class="sl-sa-dashboard__brand">
							<span class="sl-sa-dashboard__brand-mark">S</span>
							<span><?php esc_html_e( 'Security Behaviour', 'succeedlearn-amp' ); ?></span>
						</div>
						<span class="sl-sa-dashboard__status">
							<span></span>
							<?php esc_html_e( 'Protected', 'succeedlearn-amp' ); ?>
						</span>
					</div>

					<div class="sl-sa-dashboard__heading">
						<div>
							<span class="sl-sa-dashboard__label"><?php esc_html_e( 'Human Risk Overview', 'succeedlearn-amp' ); ?></span>
							<h3><?php esc_html_e( 'Security Awareness', 'succeedlearn-amp' ); ?></h3>
						</div>
						<span class="sl-sa-dashboard__period"><?php esc_html_e( 'Last 30 days', 'succeedlearn-amp' ); ?></span>
					</div>

					<div class="sl-sa-dashboard__metrics">
						<div class="sl-sa-dashboard__metric">
							<span class="sl-sa-dashboard__metric-label"><?php esc_html_e( 'Risk Score', 'succeedlearn-amp' ); ?></span>
							<strong>18%</strong>
							<span class="sl-sa-dashboard__metric-change">↓ 12.4%</span>
						</div>
						<div class="sl-sa-dashboard__metric">
							<span class="sl-sa-dashboard__metric-label"><?php esc_html_e( 'Training Completion', 'succeedlearn-amp' ); ?></span>
							<strong>94%</strong>
							<span class="sl-sa-dashboard__metric-change">↑ 8.2%</span>
						</div>
						<div class="sl-sa-dashboard__metric">
							<span class="sl-sa-dashboard__metric-label"><?php esc_html_e( 'Phishing Resilience', 'succeedlearn-amp' ); ?></span>
							<strong>87%</strong>
							<span class="sl-sa-dashboard__metric-change">↑ 14.6%</span>
						</div>
					</div>

					<div class="sl-sa-dashboard__body">
						<div class="sl-sa-dashboard__chart">
							<div class="sl-sa-dashboard__chart-header">
								<strong><?php esc_html_e( 'Human Risk Trend', 'succeedlearn-amp' ); ?></strong>
								<span><?php esc_html_e( 'Risk ↓', 'succeedlearn-amp' ); ?></span>
							</div>
							<div class="sl-sa-dashboard__chart-area">
								<div class="sl-sa-dashboard__chart-grid"></div>
								<svg class="sl-sa-dashboard__line" viewBox="0 0 500 150" preserveAspectRatio="none" aria-hidden="true">
									<polyline
										points="0,35 70,48 135,42 200,78 265,70 330,96 400,105 500,125"
										fill="none"
										stroke="currentColor"
										stroke-width="5"
										stroke-linecap="round"
										stroke-linejoin="round"
									/>
								</svg>
							</div>
						</div>

						<div class="sl-sa-dashboard__risk">
							<div class="sl-sa-dashboard__chart-header">
								<strong><?php esc_html_e( 'Risk Areas', 'succeedlearn-amp' ); ?></strong>
							</div>
							<div class="sl-sa-dashboard__risk-item">
								<span><?php esc_html_e( 'Phishing', 'succeedlearn-amp' ); ?></span>
								<div class="sl-sa-dashboard__progress"><span style="width:82%"></span></div>
								<strong>82%</strong>
							</div>
							<div class="sl-sa-dashboard__risk-item">
								<span><?php esc_html_e( 'Password Security', 'succeedlearn-amp' ); ?></span>
								<div class="sl-sa-dashboard__progress"><span style="width:91%"></span></div>
								<strong>91%</strong>
							</div>
							<div class="sl-sa-dashboard__risk-item">
								<span><?php esc_html_e( 'Data Protection', 'succeedlearn-amp' ); ?></span>
								<div class="sl-sa-dashboard__progress"><span style="width:76%"></span></div>
								<strong>76%</strong>
							</div>
						</div>
					</div>

					<div class="sl-sa-dashboard__footer">
						<span><?php esc_html_e( '1,248 employees monitored', 'succeedlearn-amp' ); ?></span>
						<span><?php esc_html_e( '12 active learning campaigns', 'succeedlearn-amp' ); ?></span>
					</div>
				</div>

				<div class="sl-sa-hero__visual-note"><?php esc_html_e( 'Illustrative dashboard preview', 'succeedlearn-amp' ); ?></div>
			</div>
		</div>
	</div>
</section>

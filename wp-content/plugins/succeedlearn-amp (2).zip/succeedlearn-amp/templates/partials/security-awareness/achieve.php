<?php
/**
 * Security Awareness AMP — What Can Your Organization Achieve?
 *
 * Expected vars: $achieve_items
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $achieve_items ) || ! is_array( $achieve_items ) ) {
	return;
}
?>
<section
	class="sl-sa-achieve"
	id="what-can-your-organization-achieve"
	aria-labelledby="sl-sa-achieve-title"
>
	<div class="sl-wrap">
		<div class="sl-sa-achieve__intro">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Measurable Security Behaviour Change', 'succeedlearn-amp' ); ?>
			</span>

			<h2 id="sl-sa-achieve-title">
				<?php esc_html_e( 'What Can Your Organization', 'succeedlearn-amp' ); ?>
				<span><?php esc_html_e( 'Achieve?', 'succeedlearn-amp' ); ?></span>
			</h2>

			<p>
				<?php esc_html_e( 'The objective of security awareness should extend beyond training completion, with an integrated behaviour and culture programme, organisations can work towards:', 'succeedlearn-amp' ); ?>
			</p>
		</div>

		<div class="sl-sa-achieve__grid">
			<?php foreach ( $achieve_items as $item ) : ?>
				<article class="sl-sa-achieve__card">
					<div class="sl-sa-annual-training__title-row">
						<span class="sl-sa-annual-training__number">
							<?php echo esc_html( $item['number'] ); ?>
						</span>
						<p class="sl-sa-achieve__text">
							<?php echo esc_html( $item['text'] ); ?>
						</p>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

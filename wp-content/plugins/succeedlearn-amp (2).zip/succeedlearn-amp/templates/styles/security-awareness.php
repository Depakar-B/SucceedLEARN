<?php
/**
 * Security Awareness — AMP page styles.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
.sl-sap-page{--sl-page-navy:#16234e;--sl-page-primary:#1472ba;--sl-page-primary-dark:#283384;--sl-page-primary-soft:rgba(109,195,235,.16);--sl-page-cta:#ea3e24;--sl-page-text:#4A4A4A;--sl-page-muted:#6B7C93;--sl-page-bg:#F5F3EF;--sl-page-white:#fff}
.sl-sap-page .sl-eyebrow,.sl-sap-page .sl-home-sub-heading{display:inline-block;margin:0 0 10px;font-size:13px;font-weight:600;letter-spacing:.02em;color:var(--sl-page-primary)}
.sl-sap-page .sl-btn--primary{background:var(--sl-page-primary,#1472ba)}
.sl-sap-page .sl-btn--secondary{background:var(--sl-page-navy)}
.sl-sap-page .sl-section--alt{background:var(--sl-page-bg,#F5F3EF)}
.sl-sap-page .sl-stat__value{color:var(--sl-page-primary,#1472ba)!important}
.sl-sap-page .sl-clients__title span{color:var(--sl-page-primary,#1472ba)!important}
.sl-sap-page .sl-clients__cta{margin-top:24px}
.sl-sap-page .sl-clients__cta .sl-btn,
.sl-sap-page .sl-clients__cta a{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 22px;border-radius:8px;background:var(--sl-page-primary,#1472ba);border:1px solid var(--sl-page-primary,#1472ba);color:#fff;font-weight:700;text-decoration:none}
.sl-sap-page .sl-clients__grid{max-width:960px}
.sl-sap-page .sl-clients__cell amp-img{max-width:130px}
.sl-sap-page h2 span{color:var(--sl-page-primary,#1472ba)}
.sl-sa-dashboard__activity-value{display:none}
.sl-sa-hero{padding:16px;background:radial-gradient(circle at 90% 20%,rgba(20,114,186,.12),transparent 34%),var(--sl-page-white)}
.sl-sa-hero__grid{display:grid;gap:28px;align-items:center}
.sl-sa-hero__eyebrow{display:inline-block;margin:0 0 12px}
.sl-sa-hero h1{margin:0 0 10px;font-size:28px;line-height:1.2;color:var(--sl-page-navy)}
.sl-sa-hero__subheading{margin:0 0 14px;font-size:18px;line-height:1.35;color:var(--sl-page-primary);font-weight:600}
.sl-sa-hero__description{margin:0 0 16px;font-size:15px;line-height:1.65;color:var(--sl-page-text)}
.sl-sa-hero__points{margin:0 0 20px;padding:0;list-style:none;display:grid;gap:10px}
.sl-sa-hero__points li{display:flex;gap:10px;align-items:center;font-size:14px;line-height:1.5;color:var(--sl-page-navy);font-weight:600}
.sl-sa-hero__point-icon{width:23px;height:23px;display:inline-flex;align-items:center;justify-content:center;flex:0 0 23px;border-radius:50%;background:rgba(20,114,186,.12);color:var(--sl-page-primary);font-size:13px;font-weight:800}
.sl-sa-hero__actions{display:flex;flex-wrap:wrap;gap:12px}
.sl-sa-hero .sl-btn--secondary{background:var(--sl-page-white);color:var(--sl-page-navy);border:1px solid rgba(22,35,78,.18)}
.sl-sa-dashboard{position:relative;overflow:hidden;padding:18px;border:1px solid rgba(255,255,255,.16);border-radius:24px;background:linear-gradient(145deg,#0b1f44 0%,#102f68 52%,#1558a5 100%);color:#fff;box-shadow:0 30px 70px rgba(11,31,68,.22),0 10px 25px rgba(20,114,186,.12)}
.sl-sa-dashboard__topbar,.sl-sa-dashboard__heading,.sl-sa-dashboard__chart-header,.sl-sa-dashboard__footer{display:flex;justify-content:space-between;gap:12px;align-items:center}
.sl-sa-dashboard__topbar{padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.12)}
.sl-sa-dashboard__brand{display:flex;gap:10px;align-items:center;font-size:13px;font-weight:700;color:#fff}
.sl-sa-dashboard__brand-mark{width:30px;height:30px;border-radius:8px;background:#fff;color:#1558a5;display:inline-flex;align-items:center;justify-content:center;font-weight:800}
.sl-sa-dashboard__status{display:inline-flex;gap:7px;align-items:center;padding:7px 10px;border-radius:20px;background:rgba(255,255,255,.1);color:#fff;font-size:11px;font-weight:700}
.sl-sa-dashboard__status span{width:7px;height:7px;border-radius:50%;background:#22c55e}
.sl-sa-dashboard__label{display:block;margin-bottom:5px;color:rgba(255,255,255,.62);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.08em}
.sl-sa-dashboard__heading{gap:16px;padding:18px 0 14px}
.sl-sa-dashboard__heading h3{margin:0;font-size:16px;color:#fff}
.sl-sa-dashboard__period{padding:8px 10px;border:1px solid rgba(255,255,255,.12);border-radius:7px;color:rgba(255,255,255,.75);font-size:11px}
.sl-sa-dashboard__metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.sl-sa-dashboard__metric{padding:12px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(255,255,255,.07)}
.sl-sa-dashboard__metric-label{display:block;margin-bottom:6px;color:rgba(255,255,255,.65);font-size:10px}
.sl-sa-dashboard__metric strong{display:block;margin-bottom:4px;font-size:22px;color:#fff}
.sl-sa-dashboard__metric-change{font-size:10px;color:#67e8f9;font-weight:700}
.sl-sa-dashboard__body{display:grid;gap:12px;margin-top:12px}
.sl-sa-dashboard__chart,.sl-sa-dashboard__risk{min-width:0;padding:14px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(255,255,255,.06)}
.sl-sa-dashboard__chart-header{margin-bottom:12px;font-size:12px}
.sl-sa-dashboard__chart-header strong{color:#fff}
.sl-sa-dashboard__chart-header span{color:#67e8f9;font-size:10px}
.sl-sa-dashboard__chart-area{position:relative;height:110px;overflow:hidden}
.sl-sa-dashboard__chart-grid{position:absolute;inset:0;background-image:linear-gradient(to bottom,rgba(255,255,255,.1) 1px,transparent 1px);background-size:100% 28px}
.sl-sa-dashboard__line{position:absolute;inset:8px 0;width:100%;height:calc(100% - 16px);color:#67e8f9}
.sl-sa-dashboard__risk{display:flex;flex-direction:column}
.sl-sa-dashboard__risk-item{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px;margin-bottom:14px}
.sl-sa-dashboard__risk-item>span{width:100%;color:rgba(255,255,255,.72);font-size:10px}
.sl-sa-dashboard__progress{flex:1;height:6px;overflow:hidden;border-radius:10px;background:rgba(255,255,255,.12)}
.sl-sa-dashboard__progress span{display:block;height:100%;border-radius:inherit;background:#67e8f9}
.sl-sa-dashboard__risk-item strong{color:#fff;font-size:10px}
.sl-sa-dashboard__footer{gap:12px;margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.12);font-size:10px;color:rgba(255,255,255,.58)}
.sl-sa-hero__visual-note{margin-top:10px;font-size:11px;color:rgba(11,31,68,.5);font-style:italic;text-align:center}
@media(min-width:900px){.sl-sa-hero__grid{grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr)}.sl-sa-hero h1{font-size:36px}.sl-sa-dashboard__body{grid-template-columns:1.25fr .75fr}}
@media(max-width:767px){.sl-sa-dashboard__metrics{grid-template-columns:1fr}}
.sl-sa-platform,.sl-sa-definition,.sl-sa-lifecycle,.sl-sa-traditional,.sl-sa-compliance,.sl-suite-section,.sl-sa-behaviour,.sl-sa-achieve,.sl-sa-leadership,.sl-sa-annual-training,.sl-sa-process,.sl-sa-comparison{padding:48px 16px}
.sl-sa-platform,.sl-sa-lifecycle,.sl-sa-achieve,.sl-sa-process,.sl-sa-comparison,.sl-sa-compliance{background:var(--sl-page-bg)}
.sl-sa-definition,.sl-suite-section,.sl-sa-behaviour,.sl-sa-leadership,.sl-sa-annual-training,.sl-sa-traditional{background:var(--sl-page-white)}
.sl-sa-platform__grid,.sl-sa-definition__layout,.sl-sa-lifecycle__layout,.sl-sa-traditional__content,.sl-sa-compliance__content{display:grid;gap:24px;align-items:center}
@media(min-width:900px){.sl-sa-platform__grid,.sl-sa-definition__layout,.sl-sa-lifecycle__layout,.sl-sa-traditional__content,.sl-sa-compliance__content{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}}
.sl-sa-platform amp-img,.sl-sa-definition amp-img{border-radius:18px;overflow:hidden;border:1px solid rgba(107,124,147,.18)}
.sl-sa-platform h2,.sl-sa-definition h2,.sl-sa-lifecycle h2,.sl-sa-achieve h2,.sl-sa-leadership h2,.sl-sa-annual-training h2,.sl-sa-process h2,.sl-sa-traditional h2,.sl-sa-comparison h2,.sl-sa-compliance h2,.sl-suite-intro h2,.sl-sa-behaviour h2{margin:8px 0 14px;font-size:26px;line-height:1.25;color:var(--sl-page-navy)}
.sl-sa-platform p,.sl-sa-definition p,.sl-sa-lifecycle p,.sl-sa-traditional p,.sl-sa-compliance__text p,.sl-suite-intro p,.sl-sa-behaviour__header p,.sl-sa-achieve__intro p,.sl-sa-annual-training__heading p,.sl-sa-leadership .sl-sa-annual-training__heading p,.sl-sa-process .sl-sa-annual-training__heading p{margin:0 0 12px;font-size:15px;line-height:1.65;color:var(--sl-page-text)}
.sl-sa-platform__lead,.sl-sa-definition__lead{font-size:16px}
.sl-sa-definition__callout{margin:16px 0;padding:18px 20px;border-left:5px solid var(--sl-page-primary);border-radius:0 14px 14px 0;background:var(--sl-page-primary-soft)}
.sl-sa-definition__callout h3{margin:0 0 8px;font-size:16px;color:var(--sl-page-navy)}
.sl-sa-lifecycle__image-placeholder,.sl-sa-traditional__image-placeholder{min-height:220px;border:1px dashed rgba(107,124,147,.35);border-radius:16px;background:rgba(109,195,235,.08);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:24px;text-align:center;color:var(--sl-page-muted);font-size:13px}
.sl-suite-intro{margin-bottom:22px}
.sl-suite-accordion section{border:1px solid rgba(107,124,147,.18);border-radius:12px;margin-bottom:10px;background:var(--sl-page-white);overflow:hidden}
.sl-suite-accordion__header{display:flex;gap:12px;align-items:center;margin:0;padding:14px 16px;font-size:15px;color:var(--sl-page-navy);background:var(--sl-page-white);border:0}
.sl-suite-accordion__header strong{display:block;font-size:15px}
.sl-suite-accordion__header small{display:block;font-size:12px;color:var(--sl-page-muted);font-weight:500}
.sl-suite-nav-number{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;border-radius:10px;background:var(--sl-page-primary-soft);color:var(--sl-page-primary);font-size:12px;font-weight:700}
.sl-suite-panel-copy{padding:0 16px 16px}
.sl-suite-product-label{display:inline-block;margin-bottom:8px;font-size:12px;font-weight:700;color:var(--sl-page-primary);text-transform:uppercase;letter-spacing:.04em}
.sl-suite-panel-copy h4{margin:0 0 6px;font-size:18px;color:var(--sl-page-navy)}
.sl-suite-panel__subtitle{margin:0 0 10px;font-size:14px;font-weight:600;color:var(--sl-page-muted)}
.sl-suite-highlight{display:block;margin-top:12px;padding:12px 14px;border-radius:10px;background:var(--sl-page-primary-soft);color:var(--sl-page-navy);font-size:14px;line-height:1.5}
.sl-sa-behaviour__header{margin-bottom:22px}
.sl-sa-behaviour__header h3{margin:0 0 12px;font-size:18px;color:var(--sl-page-navy)}
.sl-sa-behaviour__steps,.sl-sa-achieve__grid,.sl-sa-annual-training__grid,.sl-sa-process__grid{display:grid;gap:12px}
@media(min-width:700px){.sl-sa-behaviour__steps,.sl-sa-achieve__grid,.sl-sa-annual-training__grid,.sl-sa-process__grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(min-width:1000px){.sl-sa-behaviour__steps{grid-template-columns:repeat(5,minmax(0,1fr))}.sl-sa-achieve__grid{grid-template-columns:repeat(2,minmax(0,1fr))}.sl-sa-annual-training__grid,.sl-sa-process__grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
.sl-sa-behaviour__card,.sl-sa-achieve__card,.sl-sa-annual-training__card{background:var(--sl-page-white);border:1px solid rgba(107,124,147,.18);border-top:3px solid var(--sl-page-primary);border-radius:14px;padding:16px;height:100%}
.sl-sa-behaviour__number,.sl-sa-annual-training__number{display:inline-block;margin-bottom:8px;font-size:13px;font-weight:700;color:var(--sl-page-primary)}
.sl-sa-behaviour__card h3,.sl-sa-annual-training__card h3{margin:0 0 8px;font-size:16px;color:var(--sl-page-navy)}
.sl-sa-behaviour__card p,.sl-sa-achieve__text,.sl-sa-annual-training__card p{margin:0;font-size:14px;line-height:1.55;color:var(--sl-page-text)}
.sl-sa-behaviour__closing{margin-top:20px;padding:18px 20px;border-left:5px solid var(--sl-page-primary);border-radius:0 14px 14px 0;background:var(--sl-page-primary-soft)}
.sl-sa-behaviour__closing-label{display:block;margin-bottom:6px;font-size:12px;font-weight:700;color:var(--sl-page-primary);letter-spacing:.04em}
.sl-sa-annual-training__heading{margin-bottom:22px}
.sl-sa-annual-training__heading h3{margin:0 0 12px;font-size:17px;line-height:1.4;color:var(--sl-page-navy)}
.sl-sa-annual-training__title-row{display:flex;gap:10px;align-items:flex-start}
.sl-sa-comparison__table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
.sl-sa-comparison__table{width:100%;min-width:520px;border-collapse:collapse;background:var(--sl-page-white);border:1px solid rgba(107,124,147,.18);border-radius:14px;overflow:hidden}
.sl-sa-comparison__table th,.sl-sa-comparison__table td{padding:14px 16px;border-bottom:1px solid rgba(107,124,147,.14);text-align:left;font-size:14px;line-height:1.5;vertical-align:top}
.sl-sa-comparison__table th{background:var(--sl-page-navy);color:#fff;font-size:13px}
.sl-sa-comparison__table th:last-child{background:var(--sl-page-primary)}
.sl-sa-comparison__cell--highlight{color:var(--sl-page-primary);font-weight:600}
.sl-sa-compliance__dashboard{background:var(--sl-page-white);border:1px solid rgba(107,124,147,.18);border-radius:18px;padding:18px;box-shadow:0 16px 40px rgba(22,35,78,.1)}
.sl-sa-compliance__dashboard-header{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding-bottom:14px;border-bottom:1px solid rgba(107,124,147,.14)}
.sl-sa-compliance__dashboard-label{display:block;font-size:11px;font-weight:700;color:var(--sl-page-primary);text-transform:uppercase;letter-spacing:.04em}
.sl-sa-compliance__dashboard-header strong{display:block;margin-top:4px;font-size:15px;color:var(--sl-page-navy)}
.sl-sa-compliance__status{padding:5px 10px;border-radius:999px;background:var(--sl-page-primary-soft);color:var(--sl-page-primary-dark);font-size:12px;font-weight:700}
.sl-sa-compliance__metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:14px}
.sl-sa-compliance__metric{padding:12px;border:1px solid rgba(107,124,147,.14);border-radius:12px;background:var(--sl-page-white)}
.sl-sa-compliance__metric span,.sl-sa-compliance__metric small{display:block;font-size:11px;color:var(--sl-page-muted)}
.sl-sa-compliance__metric strong{display:block;margin:4px 0;font-size:20px;color:var(--sl-page-navy)}
.sl-sa-compliance__panel{margin-top:14px;padding:14px;border-radius:12px;background:rgba(109,195,235,.1);border:1px solid rgba(107,124,147,.12)}
.sl-sa-compliance__panel-heading{display:flex;justify-content:space-between;gap:10px;margin-bottom:12px;font-size:12px}
.sl-sa-compliance__panel-heading strong{color:var(--sl-page-navy)}
.sl-sa-compliance__panel-heading span{color:var(--sl-page-muted)}
.sl-sa-dashboard__activity-bars{display:flex;align-items:flex-end;gap:4px;height:120px}
.sl-sa-dashboard__activity-column{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;height:100%}
.sl-sa-dashboard__activity-bar-track{flex:1;width:100%;display:flex;align-items:flex-end;justify-content:center}
.sl-sa-dashboard__activity-bar{display:block;width:100%;max-width:14px;border-radius:4px 4px 2px 2px;background:var(--sl-page-primary)}
.sl-sa-dashboard__activity-label{margin-top:4px;font-size:8px;color:var(--sl-page-muted);font-weight:600}
.sl-sa-compliance__coverage{margin-top:14px;padding:14px;border:1px solid rgba(107,124,147,.14);border-radius:12px;background:var(--sl-page-white)}
.sl-sa-compliance__coverage-heading{display:flex;justify-content:space-between;gap:10px;margin-bottom:8px}
.sl-sa-compliance__coverage-heading strong{font-size:13px;color:var(--sl-page-navy)}
.sl-sa-compliance__coverage-heading span{font-size:14px;font-weight:700;color:var(--sl-page-primary)}
.sl-sa-compliance__progress{height:8px;border-radius:999px;background:rgba(109,195,235,.22);overflow:hidden}
.sl-sa-compliance__progress span{display:block;width:92%;height:100%;background:var(--sl-page-primary);border-radius:inherit}
.sl-sa-compliance__footer{display:flex;flex-wrap:wrap;gap:10px 16px;margin-top:14px;padding-top:12px;border-top:1px solid rgba(107,124,147,.14);font-size:11px;font-weight:600;color:var(--sl-page-muted)}
.sl-sa-contact-direct{display:grid;gap:10px;margin-top:16px}
.sl-sa-contact-direct__label{margin:0;font-size:13px;color:var(--sl-page-muted)}
.sl-sa-contact-direct a{display:block;padding:14px 16px;border:1px solid rgba(107,124,147,.18);border-radius:12px;text-decoration:none;background:var(--sl-page-white)}
.sl-sa-contact-direct__title{display:block;font-size:12px;color:var(--sl-page-muted)}
.sl-sa-contact-direct__value{display:block;font-size:15px;font-weight:600;color:var(--sl-page-navy)}
.sl-sap-page .sl-contact-layout{display:grid;gap:28px;align-items:start}
@media(min-width:900px){.sl-sap-page .sl-contact-layout{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}}
.sl-sap-page .sl-contact-form-card{max-width:none;margin:0}
@media(max-width:767px){.sl-sa-dashboard__metrics,.sl-sa-compliance__metrics{grid-template-columns:1fr}.sl-sa-hero h1,.sl-sa-platform h2,.sl-sa-definition h2,.sl-suite-intro h2,.sl-sa-behaviour h2,.sl-sa-lifecycle h2,.sl-sa-achieve h2,.sl-sa-leadership h2,.sl-sa-annual-training h2,.sl-sa-process h2,.sl-sa-traditional h2,.sl-sa-comparison h2,.sl-sa-compliance h2{font-size:24px}.sl-sa-dashboard__activity-label{display:none}}

# SucceedLearn Landing Bridge (safe for live Eduma)

Keeps **Eduma** as the live site theme. Only these URLs load `akaza-adventure`:

- `/us-cyber-aware-october/` (Cyber US)
- `/uk-cyber-aware-october/` (Cyber UK)
- `/cybersecurity-awareness/` (Infosec live SEO URL)
- Infosec aliases: `/infosec-cybersecurity-awareness-month-2026/` and related

If anything goes wrong: **deactivate this plugin**. The rest of the site is unchanged.

## Safe live rollout (do in this order)

### 1. Backup
- Full backup (files + DB), or at least a restore point.

### 2. Upload akaza-adventure (do NOT activate)
- Copy the whole `akaza-adventure` folder to live:
  - `wp-content/themes/akaza-adventure/`
- In **Appearance → Themes**, leave **Eduma** active.
- Confirm `akaza-adventure` is listed but not activated.

### 3. Upload this plugin (do NOT activate yet)
- Copy:
  - `wp-content/plugins/succeedlearn-landing-bridge/`

### 4. Optional AMP
- If you need AMP for these pages, upload/activate `succeedlearn-amp` + AMPforWP as you do on staging.
- If AMP is not ready, skip this. Desktop pages still work.

### 5. Activate the bridge plugin
- Plugins → activate **SucceedLearn Landing Bridge (Cyber + Infosec)**
- Home page and all Eduma pages should still look normal.

### 6. Create the landing pages
Create pages (or edit existing):

1. **Cybersecurity Awareness (US)**
   - Slug: `us-cyber-aware-october`
   - Template: **SucceedLearn: Cybersecurity Awareness**

2. **Cybersecurity Awareness (UK)**
   - Slug: `uk-cyber-aware-october`
   - Template: **SucceedLearn: Cybersecurity Awareness (UK)**

3. **Infosec 2026 Cyber**
   - Slug: `cybersecurity-awareness` (live: `http://succeedlearn.com/cybersecurity-awareness`)
   - Template: **SucceedLearn: Infosec 2026 Cyber**

Publish as **Draft** first if you want a private check with preview.

### 7. Test before announcing
- Open homepage (must still be Eduma).
- Open one normal Eduma page (must still be Eduma).
- Open the two new landings (must show SucceedLearn design).
- Test mobile + form submit on those three pages only.

### 8. Emergency rollback (instant)
1. Deactivate **SucceedLearn Landing Bridge**
2. Site immediately returns to Eduma-only behavior
3. Optional: leave pages as drafts

## Why this is safe
- Does **not** replace Eduma globally
- Does **not** edit Eduma theme files
- Only allowlisted slugs switch theme for that request
- Missing `akaza-adventure` → falls back, no fatal from this plugin
- One-click deactivate = full rollback

## Do NOT
- Activate `akaza-adventure` as the site theme
- Copy random template PHP into Eduma
- Deploy CoC or other akaza pages until you extend the slug allowlist on purpose

<?php
/**
 * WordPress admin dashboard and CSV export.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SSF_Admin {

	/** @var SSF_Database */
	private $database;

	public function __construct( SSF_Database $database ) {
		$this->database = $database;
	}

	public function register_menu() {
		add_menu_page(
			__( 'Cybersecurity Form Submissions', 'seo-form' ),
			__( 'Cybersecurity Form', 'seo-form' ),
			'manage_options',
			'ssf-submissions',
			array( $this, 'render_page' ),
			'dashicons-feedback',
			59
		);
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$filters = $this->get_filters();
		$items   = $this->database->get_submissions( $filters );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Cybersecurity Form Submissions', 'seo-form' ); ?></h1>
			<p><?php esc_html_e( 'Submissions from the [cybersecurity_form] shortcode. Notifications are sent to depakar@succeedtech.com.', 'seo-form' ); ?></p>

			<form method="get" style="margin-bottom:20px;">
				<input type="hidden" name="page" value="ssf-submissions" />
				<label>
					<?php esc_html_e( 'Start Date', 'seo-form' ); ?>
					<input type="date" name="start_date" value="<?php echo esc_attr( $filters['start_date'] ); ?>" />
				</label>
				&nbsp;
				<label>
					<?php esc_html_e( 'End Date', 'seo-form' ); ?>
					<input type="date" name="end_date" value="<?php echo esc_attr( $filters['end_date'] ); ?>" />
				</label>
				&nbsp;
				<label>
					<?php esc_html_e( 'Email', 'seo-form' ); ?>
					<input type="search" name="email" value="<?php echo esc_attr( $filters['email'] ); ?>" />
				</label>
				&nbsp;
				<button class="button button-primary" type="submit"><?php esc_html_e( 'Filter', 'seo-form' ); ?></button>
				<?php wp_nonce_field( 'ssf_export', 'ssf_export_nonce' ); ?>
				<button class="button" name="ssf_export" value="1"><?php esc_html_e( 'Export CSV', 'seo-form' ); ?></button>
			</form>

			<table class="widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Date', 'seo-form' ); ?></th>
						<th><?php esc_html_e( 'Name', 'seo-form' ); ?></th>
						<th><?php esc_html_e( 'Email', 'seo-form' ); ?></th>
						<th><?php esc_html_e( 'No. of Users', 'seo-form' ); ?></th>
						<th><?php esc_html_e( 'Message', 'seo-form' ); ?></th>
						<th><?php esc_html_e( 'UTM Source', 'seo-form' ); ?></th>
						<th><?php esc_html_e( 'Page URL', 'seo-form' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $items ) ) : ?>
						<tr><td colspan="7"><?php esc_html_e( 'No submissions found.', 'seo-form' ); ?></td></tr>
					<?php else : ?>
						<?php
						$date_format = get_option( 'date_format', 'Y-m-d' ) . ' ' . get_option( 'time_format', 'H:i' );
						foreach ( $items as $item ) :
							?>
							<tr>
								<td><?php echo esc_html( wp_date( $date_format, strtotime( $item->created_at ) ) ); ?></td>
								<td><?php echo esc_html( $item->name ); ?></td>
								<td><?php echo esc_html( $item->email ); ?></td>
								<td><?php echo esc_html( $item->employees ?? '' ); ?></td>
								<td><?php echo esc_html( wp_trim_words( $item->message, 12 ) ); ?></td>
								<td><?php echo esc_html( $item->utm_source ); ?></td>
								<td><a href="<?php echo esc_url( $item->page_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View', 'seo-form' ); ?></a></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public function maybe_export_csv() {
		$export_flag = isset( $_GET['ssf_export'] ) ? sanitize_text_field( wp_unslash( $_GET['ssf_export'] ) ) : '';
		if ( '1' !== $export_flag ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'seo-form' ) );
		}
		if ( ! isset( $_GET['ssf_export_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['ssf_export_nonce'] ) ), 'ssf_export' ) ) {
			wp_die( esc_html__( 'Invalid export request.', 'seo-form' ) );
		}

		$data     = $this->database->get_submissions( $this->get_filters() );
		$filename = 'cybersecurity-form-submissions-' . gmdate( 'Ymd-His' ) . '.csv';

		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename=' . $filename );

		$fh = fopen( 'php://output', 'w' );
		fputcsv(
			$fh,
			array( 'ID', 'Date', 'Name', 'Email', 'Users', 'Message', 'UTM Source', 'UTM Medium', 'UTM Campaign', 'Page URL', 'IP' )
		);
		foreach ( $data as $row ) {
			fputcsv(
				$fh,
				array(
					$row->id,
					$row->created_at,
					$row->name,
					$row->email,
					$row->employees ?? '',
					$row->message,
					$row->utm_source,
					$row->utm_medium,
					$row->utm_campaign,
					$row->page_url,
					$row->user_ip,
				)
			);
		}
		fclose( $fh );
		exit;
	}

	/**
	 * @return array
	 */
	private function get_filters() {
		return array(
			'start_date' => sanitize_text_field( wp_unslash( $_GET['start_date'] ?? '' ) ),
			'end_date'   => sanitize_text_field( wp_unslash( $_GET['end_date'] ?? '' ) ),
			'email'      => sanitize_email( wp_unslash( $_GET['email'] ?? '' ) ),
		);
	}
}

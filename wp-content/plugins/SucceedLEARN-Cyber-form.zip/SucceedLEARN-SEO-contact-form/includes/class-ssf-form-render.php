<?php
/**
 * Shortcode rendering and form HTML output.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SSF_Form_Render {

	/** @var SSF_Security */
	private $security;

	public function __construct( SSF_Security $security ) {
		$this->security = $security;
	}

	public function register_shortcode() {
		add_shortcode( 'cybersecurity_form', array( $this, 'render' ) );
		add_shortcode( 'seo_form', array( $this, 'render' ) ); // Alias for backwards compatibility.
	}

	/**
	 * Render the cybersecurity form.
	 *
	 * Usage: [cybersecurity_form title="Get the special offer"]
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public function render( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title'    => __( 'Get the special offer', 'seo-form' ),
				'subtitle' => __( 'Fill in your details and we will reach out shortly.', 'seo-form' ),
			),
			$atts,
			'cybersecurity_form'
		);

		if ( $this->is_amp() ) {
			return $this->render_amp_form( $atts );
		}

		return $this->render_standard_form( $atts );
	}

	/**
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	private function render_standard_form( $atts ) {
		ob_start();
		$privacy_url    = get_privacy_policy_url();
		$source_tag     = $this->determine_source_tag();
		$form_token     = $this->security->generate_form_token();
		$honeypot_names = $this->security->create_honeypots( $form_token );
		?>
		<div class="ssf-form-wrap">
			<div class="ssf-form-card">
				<div class="ssf-form-header">
					<h3 class="ssf-form-title"><?php echo esc_html( $atts['title'] ); ?></h3>
					<?php if ( ! empty( $atts['subtitle'] ) ) : ?>
						<p class="ssf-form-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
					<?php endif; ?>
				</div>
				<form id="ssf-form" class="ssf-form" method="post" novalidate>
					<input type="hidden" name="ssf_form_token" value="<?php echo esc_attr( $form_token ); ?>" />
					<input type="hidden" name="ssf_form_time" value="<?php echo esc_attr( time() ); ?>" />
					<input type="hidden" name="source_tag" value="<?php echo esc_attr( $source_tag ); ?>" />

					<div class="ssf-honeypot">
						<label for="ssf-website"><?php esc_html_e( 'Website', 'seo-form' ); ?></label>
						<input type="text" id="ssf-website" name="<?php echo esc_attr( $honeypot_names['website'] ); ?>" tabindex="-1" autocomplete="off" aria-hidden="true" />
					</div>
					<div class="ssf-honeypot">
						<label for="ssf-company"><?php esc_html_e( 'Company', 'seo-form' ); ?></label>
						<input type="text" id="ssf-company" name="<?php echo esc_attr( $honeypot_names['company'] ); ?>" tabindex="-1" autocomplete="off" aria-hidden="true" />
					</div>

					<div class="ssf-field">
						<label for="ssf-name"><?php esc_html_e( 'Name', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="text" id="ssf-name" name="name" required placeholder="<?php esc_attr_e( 'John Smith', 'seo-form' ); ?>" autocomplete="name" />
					</div>

					<div class="ssf-field">
						<label for="ssf-email"><?php esc_html_e( 'Email', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="email" id="ssf-email" name="email" required placeholder="<?php esc_attr_e( 'you@company.com', 'seo-form' ); ?>" autocomplete="email" />
					</div>

					<div class="ssf-field">
						<label for="ssf-employees"><?php esc_html_e( 'No. of Users', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="number" id="ssf-employees" name="employees" required min="1" step="1" inputmode="numeric" placeholder="<?php esc_attr_e( 'e.g. 250', 'seo-form' ); ?>" />
					</div>

					<div class="ssf-field">
						<label for="ssf-message"><?php esc_html_e( 'Message', 'seo-form' ); ?></label>
						<textarea id="ssf-message" name="message" rows="4" placeholder="<?php esc_attr_e( 'How can we help you?', 'seo-form' ); ?>"></textarea>
					</div>

					<div class="ssf-field ssf-checkbox">
						<input type="checkbox" id="ssf-privacy" name="privacy" value="1" required />
						<label for="ssf-privacy">
							<?php
							printf(
								wp_kses(
									__( 'I agree to the <a href="%s" target="_blank" rel="noopener">privacy policy</a>', 'seo-form' ),
									array(
										'a' => array(
											'href'   => array(),
											'target' => array(),
											'rel'    => array(),
										),
									)
								),
								esc_url( $privacy_url ? $privacy_url : '#' )
							);
							?>
							<span class="ssf-required"> *</span>
						</label>
					</div>

					<input type="hidden" name="utm_source" />
					<input type="hidden" name="utm_medium" />
					<input type="hidden" name="utm_campaign" />
					<input type="hidden" name="utm_term" />
					<input type="hidden" name="utm_content" />
					<input type="hidden" name="page_url" />

					<button type="submit" class="ssf-submit">
						<span class="ssf-submit-text"><?php esc_html_e( 'Book a Demo', 'seo-form' ); ?></span>
						<span class="ssf-submit-loading" style="display:none;">
							<span class="ssf-spinner"></span>
							<?php esc_html_e( 'Submitting...', 'seo-form' ); ?>
						</span>
					</button>
					<p class="ssf-response" role="status" aria-live="polite"></p>
				</form>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * AMP-compatible form (amp-form + action-xhr). No custom JS.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	private function render_amp_form( $atts ) {
		ob_start();
		$privacy_url    = get_privacy_policy_url();
		$ajax_url       = admin_url( 'admin-ajax.php' );
		$nonce          = wp_create_nonce( 'ssf_submit' );
		$form_token     = $this->security->generate_form_token();
		$honeypot_names = $this->security->create_honeypots( $form_token );
		$current_url    = ( isset( $_SERVER['HTTPS'] ) && 'on' === $_SERVER['HTTPS'] ? 'https' : 'http' )
			. '://' . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '' );
		$source_tag     = $this->determine_source_tag( $current_url );
		$form_time      = time();
		?>
		<amp-state id="ssfButtonState">
			<script type="application/json">{"text":"<?php echo esc_js( __( 'Book a Demo', 'seo-form' ) ); ?>","loading":false}</script>
		</amp-state>
		<amp-state id="ssfFormTime">
			<script type="application/json"><?php echo (int) $form_time; ?></script>
		</amp-state>
		<amp-state id="ssfErrorState">
			<script type="application/json">{"message":"<?php echo esc_js( __( 'Please check your information and try again.', 'seo-form' ) ); ?>"}</script>
		</amp-state>

		<div class="ssf-form-wrap ssf-form-wrap--amp">
			<div class="ssf-form-card">
				<div class="ssf-form-header">
					<h3 class="ssf-form-title"><?php echo esc_html( $atts['title'] ); ?></h3>
					<?php if ( ! empty( $atts['subtitle'] ) ) : ?>
						<p class="ssf-form-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
					<?php endif; ?>
				</div>

				<form
					id="ssfAmpForm"
					class="ssf-form"
					method="post"
					action-xhr="<?php echo esc_url( $ajax_url ); ?>"
					target="_top"
					on="submit:AMP.setState({ssfButtonState:{text:'<?php echo esc_js( __( 'Submitting...', 'seo-form' ) ); ?>',loading:true}});
						submit-success:AMP.setState({ssfButtonState:{text:'<?php echo esc_js( __( 'Book a Demo', 'seo-form' ) ); ?>',loading:false},ssfFormTime:<?php echo (int) time(); ?>}),ssfAmpForm.clear,ssf-success-popup.open;
						submit-error:AMP.setState({ssfButtonState:{text:'<?php echo esc_js( __( 'Book a Demo', 'seo-form' ) ); ?>',loading:false},ssfErrorState:{message:(event.response && event.response.message)?event.response.message:'<?php echo esc_js( __( 'Please check your information and try again.', 'seo-form' ) ); ?>'}}),ssf-error-popup.open;"
				>
					<input type="hidden" name="action" value="ssf_submit_form" />
					<input type="hidden" name="nonce" value="<?php echo esc_attr( $nonce ); ?>" />
					<input type="hidden" name="ssf_form_token" value="<?php echo esc_attr( $form_token ); ?>" />
					<input type="hidden" name="ssf_form_time" [value]="ssfFormTime || <?php echo (int) $form_time; ?>" value="<?php echo esc_attr( (string) $form_time ); ?>" />
					<input type="hidden" name="source_tag" value="<?php echo esc_attr( $source_tag ); ?>" />
					<input type="hidden" name="amp_submission" value="1" />

					<div class="ssf-honeypot" aria-hidden="true">
						<label for="ssf-website-amp"><?php esc_html_e( 'Website', 'seo-form' ); ?></label>
						<input type="text" id="ssf-website-amp" name="<?php echo esc_attr( $honeypot_names['website'] ); ?>" tabindex="-1" autocomplete="off" />
					</div>
					<div class="ssf-honeypot" aria-hidden="true">
						<label for="ssf-company-amp"><?php esc_html_e( 'Company', 'seo-form' ); ?></label>
						<input type="text" id="ssf-company-amp" name="<?php echo esc_attr( $honeypot_names['company'] ); ?>" tabindex="-1" autocomplete="off" />
					</div>

					<div class="ssf-field">
						<label for="ssf-name-amp"><?php esc_html_e( 'Name', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="text" id="ssf-name-amp" name="name" required autocomplete="name" />
						<span visible-when-invalid="valueMissing" validation-for="ssf-name-amp" class="ssf-error-message"><?php esc_html_e( 'Please fill out this field.', 'seo-form' ); ?></span>
					</div>

					<div class="ssf-field">
						<label for="ssf-email-amp"><?php esc_html_e( 'Email', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="email" id="ssf-email-amp" name="email" required autocomplete="email" />
						<span visible-when-invalid="valueMissing" validation-for="ssf-email-amp" class="ssf-error-message"><?php esc_html_e( 'Please fill out this field.', 'seo-form' ); ?></span>
						<span visible-when-invalid="typeMismatch" validation-for="ssf-email-amp" class="ssf-error-message"><?php esc_html_e( 'Please enter a valid email address.', 'seo-form' ); ?></span>
					</div>

					<div class="ssf-field">
						<label for="ssf-employees-amp"><?php esc_html_e( 'No. of Users', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="number" id="ssf-employees-amp" name="employees" required min="1" step="1" inputmode="numeric" />
						<span visible-when-invalid="valueMissing" validation-for="ssf-employees-amp" class="ssf-error-message"><?php esc_html_e( 'Please fill out this field.', 'seo-form' ); ?></span>
						<span visible-when-invalid="rangeUnderflow" validation-for="ssf-employees-amp" class="ssf-error-message"><?php esc_html_e( 'Please enter a valid number of users.', 'seo-form' ); ?></span>
					</div>

					<div class="ssf-field">
						<label for="ssf-message-amp"><?php esc_html_e( 'Message', 'seo-form' ); ?></label>
						<textarea id="ssf-message-amp" name="message" rows="4"></textarea>
					</div>

					<div class="ssf-field ssf-checkbox">
						<input type="checkbox" id="ssf-privacy-amp" name="privacy" value="1" required />
						<label for="ssf-privacy-amp">
							<?php
							printf(
								wp_kses(
									__( 'I agree to the <a href="%s" target="_blank" rel="noopener">privacy policy</a>', 'seo-form' ),
									array(
										'a' => array(
											'href'   => array(),
											'target' => array(),
											'rel'    => array(),
										),
									)
								),
								esc_url( $privacy_url ? $privacy_url : '#' )
							);
							?>
							<span class="ssf-required"> *</span>
						</label>
						<span visible-when-invalid="valueMissing" validation-for="ssf-privacy-amp" class="ssf-error-message"><?php esc_html_e( 'Please accept the privacy policy.', 'seo-form' ); ?></span>
					</div>

					<input type="hidden" name="utm_source" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $_GET['utm_source'] ?? '' ) ) ); ?>" />
					<input type="hidden" name="utm_medium" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $_GET['utm_medium'] ?? '' ) ) ); ?>" />
					<input type="hidden" name="utm_campaign" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $_GET['utm_campaign'] ?? '' ) ) ); ?>" />
					<input type="hidden" name="utm_term" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $_GET['utm_term'] ?? '' ) ) ); ?>" />
					<input type="hidden" name="utm_content" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $_GET['utm_content'] ?? '' ) ) ); ?>" />
					<input type="hidden" name="page_url" value="<?php echo esc_url( $current_url ); ?>" />

					<button type="submit" class="ssf-submit" [disabled]="ssfButtonState.loading">
						<span [text]="ssfButtonState.text"><?php esc_html_e( 'Book a Demo', 'seo-form' ); ?></span>
					</button>
				</form>
			</div>
		</div>

		<amp-lightbox id="ssf-success-popup" layout="nodisplay" on="close:ssfAmpForm.clear">
			<div class="ssf-lightbox-overlay">
				<div class="ssf-lightbox-content ssf-lightbox-success">
					<div class="ssf-lightbox-title"><?php esc_html_e( 'Submitted Successfully', 'seo-form' ); ?></div>
					<div class="ssf-lightbox-message"><?php esc_html_e( 'Thank you! We will get back to you soon.', 'seo-form' ); ?></div>
					<button type="button" on="tap:ssf-success-popup.close" class="ssf-lightbox-button"><?php esc_html_e( 'Close', 'seo-form' ); ?></button>
				</div>
			</div>
		</amp-lightbox>

		<amp-lightbox id="ssf-error-popup" layout="nodisplay">
			<div class="ssf-lightbox-overlay">
				<div class="ssf-lightbox-content ssf-lightbox-error">
					<div class="ssf-lightbox-title"><?php esc_html_e( 'Submission Failed', 'seo-form' ); ?></div>
					<div class="ssf-lightbox-message" [text]="ssfErrorState.message"><?php esc_html_e( 'Please check your information and try again.', 'seo-form' ); ?></div>
					<button type="button" on="tap:ssf-error-popup.close" class="ssf-lightbox-button"><?php esc_html_e( 'Close', 'seo-form' ); ?></button>
				</div>
			</div>
		</amp-lightbox>
		<?php
		return ob_get_clean();
	}

	/**
	 * @return bool
	 */
	private function is_amp() {
		if ( function_exists( 'succeedlearn_amp_is_serving_amp' ) && succeedlearn_amp_is_serving_amp() ) {
			return true;
		}
		if ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() ) {
			return true;
		}
		if ( function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint() ) {
			return true;
		}
		return false;
	}

	public function determine_source_tag( $page_url = '' ) {
		$path = $this->extract_path_from_url( $page_url );
		$tag  = 'cybersecurity';
		if ( preg_match( '#/(blog|resources|articles)/#i', $path ) ) {
			$tag = 'content';
		} elseif ( preg_match( '#cybersecurity#i', $path ) ) {
			$tag = 'cybersecurity';
		}
		return apply_filters( 'ssf_source_tag', $tag, $path, $page_url );
	}

	private function extract_path_from_url( $page_url = '' ) {
		if ( empty( $page_url ) ) {
			$page_url = ( isset( $_SERVER['HTTPS'] ) && 'on' === $_SERVER['HTTPS'] ? 'https' : 'http' )
				. '://' . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '' );
		}
		$parsed = wp_parse_url( $page_url );
		return ! empty( $parsed['path'] ) ? strtolower( $parsed['path'] ) : '/';
	}
}

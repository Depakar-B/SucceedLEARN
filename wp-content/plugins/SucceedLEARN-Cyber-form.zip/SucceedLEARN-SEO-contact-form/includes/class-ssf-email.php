<?php
/**
 * Admin and user email notifications (mirrors SCF contact form behaviour).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SSF_Email {

	/**
	 * Send both admin and user emails.
	 *
	 * @param array $data Submission data.
	 */
	public function send_all( $data ) {
		$this->send_admin_email( $data );
		$this->send_user_email( $data );
	}

	/**
	 * Send admin notification (depakar@succeedtech.com for now).
	 *
	 * @param array $data Submission data.
	 */
	public function send_admin_email( $data ) {
		$admin_emails = function_exists( 'ssf_get_admin_email_recipients' )
			? ssf_get_admin_email_recipients()
			: array( apply_filters( 'ssf_admin_email', SSF_ADMIN_EMAIL ) );

		$subject = sprintf(
			/* translators: %s: submitter name */
			__( 'New Cybersecurity Form Submission from %s', 'seo-form' ),
			$data['name']
		);

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: noreply@succeedlearn.com',
			'Reply-To: ' . $data['name'] . ' <' . $data['email'] . '>',
		);

		$utm_source_display = ! empty( $data['utm_source'] ) ? $data['utm_source'] : 'Direct';
		$employees_display  = ! empty( $data['employees'] ) ? $data['employees'] : 'N/A';

		$body = sprintf(
			'<h2>New Cybersecurity Form Submission</h2>
			<p><strong>Name:</strong> %1$s</p>
			<p><strong>Email:</strong> %2$s</p>
			<p><strong>No. of Users:</strong> %3$s</p>
			<p><strong>Message:</strong><br/>%4$s</p>
			<p><strong>UTM Source:</strong> %5$s</p>
			<p><strong>Source Tag:</strong> %6$s</p>
			<p><strong>Page URL:</strong> <a href="%7$s">%7$s</a></p>
			<p><strong>IP:</strong> %8$s</p>',
			esc_html( $data['name'] ),
			esc_html( $data['email'] ),
			esc_html( $employees_display ),
			nl2br( esc_html( $data['message'] ?? '' ) ),
			esc_html( $utm_source_display ),
			esc_html( $data['source_tag'] ?? '' ),
			esc_url( $data['page_url'] ?? '' ),
			esc_html( $data['user_ip'] ?? '' )
		);

		$this->dispatch_mail( $admin_emails, $subject, $body, $headers, 'admin' );
	}

	/**
	 * Send confirmation email to the user who submitted the form.
	 *
	 * @param array $data Submission data.
	 */
	public function send_user_email( $data ) {
		if ( ! is_email( $data['email'] ) ) {
			$this->log( 'Invalid user email address: ' . ( $data['email'] ?? '' ) );
			return;
		}
		if ( ! $this->can_send_user_reply_email( $data['email'] ) ) {
			$this->log( 'User confirmation suppressed because reply limit reached for: ' . $data['email'] );
			return;
		}

		$subject = __( 'We received your message', 'seo-form' );
		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: noreply@succeedlearn.com',
		);

		$message_snippet = trim( wp_strip_all_tags( $data['message'] ?? '' ) );
		if ( '' !== $message_snippet ) {
			$message_snippet = wp_trim_words( $message_snippet, 30, '…' );
		}

		$body = sprintf(
			'<p>Hi %1$s,</p>
			<p>Thanks for reaching out to SucceedLEARN. Our team will contact you soon.</p>
			%2$s
			<p>Regards,<br/>SucceedLEARN Team</p>',
			esc_html( $data['name'] ),
			'' !== $message_snippet
				? '<p><strong>Your message:</strong> ' . esc_html( $message_snippet ) . '</p>'
				: ''
		);

		$sent = $this->dispatch_mail( array( $data['email'] ), $subject, $body, $headers, 'user' );
		if ( $sent ) {
			$this->increment_user_reply_email_count( $data['email'] );
		}
	}

	/**
	 * Async fallback — load submission from DB and send emails.
	 *
	 * @param int $submission_id Submission ID.
	 */
	public function send_emails_async( $submission_id ) {
		$database   = SSF_Plugin::instance()->database;
		$submission = $database->get_submission_by_id( (int) $submission_id );

		if ( ! $submission ) {
			$this->log( 'Async email: submission not found for ID ' . $submission_id );
			return;
		}

		$data = array(
			'name'             => $submission->name,
			'email'            => $submission->email,
			'employees'        => $submission->employees ?? '',
			'message'          => $submission->message ?? '',
			'privacy_accepted' => $submission->privacy_accepted ?? 0,
			'utm_source'       => $submission->utm_source ?? '',
			'utm_medium'       => $submission->utm_medium ?? '',
			'utm_campaign'     => $submission->utm_campaign ?? '',
			'utm_term'         => $submission->utm_term ?? '',
			'utm_content'      => $submission->utm_content ?? '',
			'source_tag'       => $submission->source_tag ?? '',
			'page_url'         => $submission->page_url ?? '',
			'user_ip'          => $submission->user_ip ?? '',
			'user_agent'       => $submission->user_agent ?? '',
		);

		$this->log( 'Sending async emails for submission ID: ' . $submission_id );

		try {
			$this->send_admin_email( $data );
			$this->log( 'Admin email sent (async)' );
			$this->send_user_email( $data );
			$this->log( 'User email sent (async)' );
		} catch ( Exception $e ) {
			$this->log( 'Async email error: ' . $e->getMessage() );
		}
	}

	/**
	 * Log wp_mail failures when WP_DEBUG is on.
	 *
	 * @param WP_Error $error Mail error.
	 */
	public function log_wp_mail_error( $error ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && is_wp_error( $error ) ) {
			error_log( 'SSF wp_mail Error: ' . $error->get_error_message() );
		}
	}

	/**
	 * @param string|array $recipients Recipient email(s).
	 * @param string       $subject    Email subject.
	 * @param string       $body       HTML body.
	 * @param array        $headers    Mail headers.
	 * @param string       $type       admin|user — for logging.
	 */
	private function dispatch_mail( $recipients, $subject, $body, $headers, $type ) {
		if ( ! function_exists( 'wp_mail' ) ) {
			$this->log( 'wp_mail function does not exist!' );
			return false;
		}

		$valid = array();
		foreach ( (array) $recipients as $email ) {
			if ( is_email( $email ) ) {
				$valid[] = $email;
			} else {
				$this->log( 'Invalid ' . $type . ' email address: ' . $email );
			}
		}

		if ( empty( $valid ) ) {
			$this->log( 'No valid ' . $type . ' email addresses to send to' );
			return false;
		}

		$this->log( 'Sending ' . $type . ' email to: ' . implode( ', ', $valid ) );
		$this->log( 'Subject: ' . $subject );

		$result = wp_mail( $valid, $subject, $body, $headers );

		if ( $result ) {
			$this->log( ucfirst( $type ) . ' email sent successfully' );
		} else {
			$this->log( ucfirst( $type ) . ' email failed to send' );
			global $phpmailer;
			if ( isset( $phpmailer ) && is_object( $phpmailer ) && ! empty( $phpmailer->ErrorInfo ) ) {
				$this->log( 'PHPMailer error: ' . $phpmailer->ErrorInfo );
			}
		}

		return $result;
	}

	/**
	 * @param string $email User email.
	 * @return bool
	 */
	private function can_send_user_reply_email( $email ) {
		$normalized_email = strtolower( sanitize_email( $email ) );
		if ( '' === $normalized_email ) {
			return false;
		}
		if ( $this->is_user_reply_email_exempt( $normalized_email ) ) {
			return true;
		}
		$max_replies = (int) apply_filters( 'succeedlearn_user_reply_limit', 2, $normalized_email );
		if ( $max_replies < 1 ) {
			$max_replies = 1;
		}
		$current_count = (int) get_option( $this->get_user_reply_email_count_option_key( $normalized_email ), 0 );
		return $current_count < $max_replies;
	}

	/**
	 * @param string $email User email.
	 * @return void
	 */
	private function increment_user_reply_email_count( $email ) {
		$normalized_email = strtolower( sanitize_email( $email ) );
		if ( '' === $normalized_email ) {
			return;
		}
		$option_key   = $this->get_user_reply_email_count_option_key( $normalized_email );
		$current      = (int) get_option( $option_key, 0 );
		$next_counter = $current + 1;
		if ( false === get_option( $option_key, false ) ) {
			add_option( $option_key, $next_counter, '', false );
			return;
		}
		update_option( $option_key, $next_counter, false );
	}

	/**
	 * @param string $normalized_email Normalized email.
	 * @return string
	 */
	private function get_user_reply_email_count_option_key( $normalized_email ) {
		return 'succeedlearn_user_reply_count_' . md5( $normalized_email );
	}

	/**
	 * @param string $normalized_email Normalized email.
	 * @return bool
	 */
	private function is_user_reply_email_exempt( $normalized_email ) {
		$default_exempt = array(
			'depakar@succeedtech.com',
		);
		$exempt_emails = apply_filters( 'succeedlearn_user_reply_exempt_emails', $default_exempt );
		$exempt_emails = is_array( $exempt_emails ) ? $exempt_emails : array();
		$exempt_emails = array_filter(
			array_map(
				static function ( $email ) {
					return strtolower( sanitize_email( (string) $email ) );
				},
				$exempt_emails
			)
		);
		return in_array( $normalized_email, $exempt_emails, true );
	}

	/**
	 * @param string $message Debug message.
	 */
	private function log( $message ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( 'SSF: ' . $message );
		}
	}
}

<?php
/**
 * Plugin Name: Succeed Cybersecurity Form
 * Description: Lightweight contact form for the Cybersecurity Awareness page: name, email, number of employees, message, and privacy checkbox. Submissions go to depakar@succeedtech.com. No ERP integration.
 * Version: 1.2.1
 * Author: SucceedTech
 * Text Domain: seo-form
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SSF_VERSION', '1.2.1' );
define( 'SSF_PLUGIN_FILE', __FILE__ );
define( 'SSF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SSF_ADMIN_EMAIL', 'depakar@succeedtech.com' );

/**
 * Admin notification recipients.
 * Later: uncomment santhosh.kt@succeedtech.com and sanmathi@succeedtech.com.
 *
 * @return string[]
 */
function ssf_get_admin_email_recipients() {
	$recipients = array(
		SSF_ADMIN_EMAIL,
		// 'santhosh.kt@succeedtech.com',
		// 'sanmathi@succeedtech.com',
	);

	return apply_filters( 'ssf_admin_email_recipients', $recipients );
}

require_once SSF_PLUGIN_DIR . 'includes/class-ssf-security.php';
require_once SSF_PLUGIN_DIR . 'includes/class-ssf-database.php';
require_once SSF_PLUGIN_DIR . 'includes/class-ssf-email.php';
require_once SSF_PLUGIN_DIR . 'includes/class-ssf-form-render.php';
require_once SSF_PLUGIN_DIR . 'includes/class-ssf-form-handler.php';
require_once SSF_PLUGIN_DIR . 'includes/class-ssf-admin.php';
require_once SSF_PLUGIN_DIR . 'includes/class-ssf-assets.php';
require_once SSF_PLUGIN_DIR . 'includes/class-ssf-plugin.php';

SSF_Plugin::instance();

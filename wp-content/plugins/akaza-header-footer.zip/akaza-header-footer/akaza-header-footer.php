<?php
/**
 * Plugin Name:       Akaza Header Footer
 * Plugin URI:        https://succeedlearn.com
 * Description:       Custom desktop mega menu, mobile header, site footer, and notification bar for SucceedLEARN (classic + Genesis themes).
 * Version:           1.14.12
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            SucceedTech
 * Text Domain:       akaza-header-footer
 * Domain Path:       /languages
 *
 * @package Akaza_Header_Footer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AHF_VERSION', '1.14.12' );
define( 'AHF_PLUGIN_FILE', __FILE__ );
define( 'AHF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AHF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AHF_OPTION_SETTINGS', 'ahf_settings' );

require_once AHF_PLUGIN_DIR . 'includes/class-ahf-config.php';
require_once AHF_PLUGIN_DIR . 'includes/class-ahf-amp.php';
require_once AHF_PLUGIN_DIR . 'includes/class-ahf-menu-items.php';
require_once AHF_PLUGIN_DIR . 'includes/class-ahf-plugin.php';

/**
 * Backward-compatible class aliases (old eLearnPOSH plugin names).
 */
class_alias( 'AHF_Plugin', 'EPSH_Plugin' );
class_alias( 'AHF_Config', 'EPSH_Config' );
class_alias( 'AHF_Amp', 'EPSH_Amp' );
class_alias( 'AHF_Menu_Items', 'EPSH_Menu_Items' );
class_alias( 'AHF_Footer', 'EPSH_Footer' );
class_alias( 'AHF_Footer_Items', 'EPSH_Footer_Items' );
class_alias( 'AHF_Classic_Layout', 'EPSH_Classic_Layout' );
class_alias( 'AHF_Genesis_Layout', 'EPSH_Genesis_Layout' );
class_alias( 'AHF_Custom_Nav', 'EPSH_Custom_Nav' );
class_alias( 'AHF_Mobile_Header', 'EPSH_Mobile_Header' );
class_alias( 'AHF_Top_Bar', 'EPSH_Top_Bar' );
class_alias( 'AHF_Site_Search', 'EPSH_Site_Search' );

/**
 * Copy legacy option once if the new key is missing.
 */
function ahf_maybe_migrate_settings() {
	$current = get_option( AHF_OPTION_SETTINGS, false );
	if ( false !== $current ) {
		return;
	}

	$legacy = get_option( 'epsh_settings', false );
	if ( false !== $legacy && is_array( $legacy ) ) {
		update_option( AHF_OPTION_SETTINGS, $legacy );
		return;
	}

	update_option( AHF_OPTION_SETTINGS, AHF_Config::default_settings() );
}

/**
 * @return AHF_Plugin
 */
function ahf_plugin() {
	ahf_maybe_migrate_settings();
	return AHF_Plugin::instance();
}

/** @deprecated Use ahf_plugin() */
function epsh_plugin() {
	return ahf_plugin();
}

add_action( 'plugins_loaded', 'ahf_plugin' );

register_activation_hook(
	__FILE__,
	static function () {
		ahf_maybe_migrate_settings();
	}
);

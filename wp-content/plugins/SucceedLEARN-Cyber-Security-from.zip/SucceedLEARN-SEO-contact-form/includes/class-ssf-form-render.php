<?php
/**
 * Shortcode rendering and form HTML output.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SSF_Form_Render {

	/** @var SSF_Security */
	private $security;

	public function __construct( SSF_Security $security ) {
		$this->security = $security;
	}

	public function register_shortcode() {
		add_shortcode( 'cybersecurity_form', array( $this, 'render' ) );
		add_shortcode( 'seo_form', array( $this, 'render' ) ); // Alias for backwards compatibility.
	}

	/**
	 * Render the cybersecurity form.
	 *
	 * Usage: [cybersecurity_form title="Get the special offer"]
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public function render( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title'    => __( 'Get the special offer', 'seo-form' ),
				'subtitle' => __( 'Fill in your details and we will reach out shortly.', 'seo-form' ),
			),
			$atts,
			'cybersecurity_form'
		);

		ob_start();
		$privacy_url    = get_privacy_policy_url();
		$source_tag     = $this->determine_source_tag();
		$form_token     = $this->security->generate_form_token();
		$honeypot_names = $this->security->create_honeypots( $form_token );
		?>
		<div class="ssf-form-wrap">
			<div class="ssf-form-card">
				<div class="ssf-form-header">
					<h3 class="ssf-form-title"><?php echo esc_html( $atts['title'] ); ?></h3>
					<?php if ( ! empty( $atts['subtitle'] ) ) : ?>
						<p class="ssf-form-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
					<?php endif; ?>
				</div>
				<form id="ssf-form" class="ssf-form" method="post" novalidate>
					<input type="hidden" name="ssf_form_token" value="<?php echo esc_attr( $form_token ); ?>" />
					<input type="hidden" name="ssf_form_time" value="<?php echo esc_attr( time() ); ?>" />
					<input type="hidden" name="source_tag" value="<?php echo esc_attr( $source_tag ); ?>" />

					<div class="ssf-honeypot">
						<label for="ssf-website"><?php esc_html_e( 'Website', 'seo-form' ); ?></label>
						<input type="text" id="ssf-website" name="<?php echo esc_attr( $honeypot_names['website'] ); ?>" tabindex="-1" autocomplete="off" aria-hidden="true" />
					</div>
					<div class="ssf-honeypot">
						<label for="ssf-company"><?php esc_html_e( 'Company', 'seo-form' ); ?></label>
						<input type="text" id="ssf-company" name="<?php echo esc_attr( $honeypot_names['company'] ); ?>" tabindex="-1" autocomplete="off" aria-hidden="true" />
					</div>

					<div class="ssf-field">
						<label for="ssf-name"><?php esc_html_e( 'Name', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="text" id="ssf-name" name="name" required placeholder="<?php esc_attr_e( 'John Smith', 'seo-form' ); ?>" autocomplete="name" />
					</div>

					<div class="ssf-field">
						<label for="ssf-email"><?php esc_html_e( 'Email', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="email" id="ssf-email" name="email" required placeholder="<?php esc_attr_e( 'you@company.com', 'seo-form' ); ?>" autocomplete="email" />
					</div>

					<div class="ssf-field">
						<label for="ssf-employees"><?php esc_html_e( 'No. of employees', 'seo-form' ); ?> <span class="ssf-required">*</span></label>
						<input type="number" id="ssf-employees" name="employees" required min="1" step="1" inputmode="numeric" placeholder="<?php esc_attr_e( 'e.g. 250', 'seo-form' ); ?>" />
					</div>

					<div class="ssf-field">
						<label for="ssf-message"><?php esc_html_e( 'Message', 'seo-form' ); ?></label>
						<textarea id="ssf-message" name="message" rows="4" placeholder="<?php esc_attr_e( 'How can we help you?', 'seo-form' ); ?>"></textarea>
					</div>

					<div class="ssf-field ssf-checkbox">
						<input type="checkbox" id="ssf-privacy" name="privacy" value="1" required />
						<label for="ssf-privacy">
							<?php
							printf(
								wp_kses(
									__( 'I agree to the <a href="%s" target="_blank" rel="noopener">privacy policy</a>', 'seo-form' ),
									array(
										'a' => array(
											'href'   => array(),
											'target' => array(),
											'rel'    => array(),
										),
									)
								),
								esc_url( $privacy_url ? $privacy_url : '#' )
							);
							?>
							<span class="ssf-required"> *</span>
						</label>
					</div>

					<input type="hidden" name="utm_source" />
					<input type="hidden" name="utm_medium" />
					<input type="hidden" name="utm_campaign" />
					<input type="hidden" name="utm_term" />
					<input type="hidden" name="utm_content" />
					<input type="hidden" name="page_url" />

					<button type="submit" class="ssf-submit">
						<span class="ssf-submit-text"><?php esc_html_e( 'Send Message', 'seo-form' ); ?></span>
						<span class="ssf-submit-loading" style="display:none;">
							<span class="ssf-spinner"></span>
							<?php esc_html_e( 'Sending...', 'seo-form' ); ?>
						</span>
					</button>
					<p class="ssf-response" role="status" aria-live="polite"></p>
				</form>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	public function determine_source_tag( $page_url = '' ) {
		$path = $this->extract_path_from_url( $page_url );
		$tag  = 'cybersecurity';
		if ( preg_match( '#/(blog|resources|articles)/#i', $path ) ) {
			$tag = 'content';
		} elseif ( preg_match( '#cybersecurity#i', $path ) ) {
			$tag = 'cybersecurity';
		}
		return apply_filters( 'ssf_source_tag', $tag, $path, $page_url );
	}

	private function extract_path_from_url( $page_url = '' ) {
		if ( empty( $page_url ) ) {
			$page_url = ( isset( $_SERVER['HTTPS'] ) && 'on' === $_SERVER['HTTPS'] ? 'https' : 'http' )
				. '://' . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '' );
		}
		$parsed = wp_parse_url( $page_url );
		return ! empty( $parsed['path'] ) ? strtolower( $parsed['path'] ) : '/';
	}
}

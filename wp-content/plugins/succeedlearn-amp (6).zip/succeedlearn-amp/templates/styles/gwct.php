<?php
/**
 * Global Workplace Compliance Training — AMP page styles.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
.sl-gwct-page{--sl-page-navy:#16234e;--sl-page-primary:#1472ba;--sl-page-primary-dark:#283384;--sl-page-primary-soft:rgba(109,195,235,.16);--sl-page-cta:#ea3e24;--sl-page-text:#4A4A4A;--sl-page-muted:#6B7C93;--sl-page-bg:#f5f5f5;--sl-page-white:#fff}
.sl-gwct-page .sl-eyebrow,.sl-gwct-page .sl-home-sub-heading{display:inline-flex;align-items:center;gap:10px;margin:0 0 12px;font-size:15px;font-weight:500;line-height:1.3;color:var(--sl-page-primary)}
.sl-gwct-page .sl-eyebrow::before,.sl-gwct-page .sl-home-sub-heading::before{content:"";width:24px;height:1px;background:var(--sl-page-primary);flex-shrink:0}
.sl-gwct-page .sl-stat__value{color:var(--sl-page-primary)}
.sl-gwct-page .sl-clients__title span{color:var(--sl-page-primary)}
.sl-gwct-page h1,.sl-gwct-page h2{color:var(--sl-page-navy)}
/* Hero — layout only; button look from global-ui.php */
.sl-gwct-page .sl-gwct-hero.sl-section{padding:24px 16px 32px;background:var(--sl-page-white)}
.sl-gwct-hero__grid{display:grid;grid-template-columns:minmax(0,1fr);gap:24px;align-items:center}
.sl-gwct-hero__content{min-width:0}
.sl-gwct-hero h1{margin:0 0 10px;font-size:28px;line-height:1.2;color:var(--sl-page-navy)}
.sl-gwct-hero__tagline{margin:0 0 14px;font-size:18px;line-height:1.35;color:var(--sl-page-primary);font-weight:700}
.sl-gwct-hero__description{margin:0;font-size:15px;line-height:1.65;color:var(--sl-page-text)}
.sl-gwct-hero__actions{display:flex;flex-direction:column;flex-wrap:nowrap;align-items:stretch;gap:12px;margin-top:24px}
.sl-gwct-hero__cta,.sl-gwct-page .sl-gwct-hero__actions .sl-btn.sl-gwct-hero__cta{display:inline-flex;align-items:center;justify-content:center;gap:10px;width:100%;max-width:100%;margin:0;flex:0 0 auto;padding:13px 20px;text-align:center;box-sizing:border-box;white-space:normal}
.sl-gwct-hero__visual{display:block;min-width:0;width:100%;max-width:560px;margin:8px auto 0}
.sl-gwct-hero__image{display:block;overflow:hidden;width:100%;border-radius:12px;border:1px solid rgba(107,124,147,.18);line-height:0;background:var(--sl-page-bg)}
.sl-gwct-hero__image amp-img{display:block;width:100%;max-width:100%}
.sl-gwct-hero__image amp-img img{object-fit:cover;object-position:center}
@media(max-width:767px){.sl-gwct-page .sl-gwct-hero__actions{flex-direction:column;align-items:stretch}.sl-gwct-page .sl-gwct-hero__actions .sl-gwct-hero__cta,.sl-gwct-page .sl-gwct-hero__actions .sl-btn.sl-gwct-hero__cta{width:100%;max-width:100%;white-space:normal}}
@media(min-width:768px){.sl-gwct-page .sl-gwct-hero.sl-section{padding:24px 16px 40px}.sl-gwct-page .sl-gwct-hero__actions{flex-direction:row;flex-wrap:wrap;align-items:center;justify-content:flex-start;gap:12px}.sl-gwct-page .sl-gwct-hero__actions .sl-gwct-hero__cta,.sl-gwct-page .sl-gwct-hero__actions .sl-btn.sl-gwct-hero__cta{width:auto;max-width:none;flex:0 0 auto;align-self:center;white-space:nowrap}.sl-gwct-hero__visual{margin-top:16px}.sl-gwct-hero h1{font-size:32px}.sl-gwct-hero__tagline{font-size:20px}}
@media(min-width:1000px){.sl-gwct-hero__grid{grid-template-columns:minmax(0,1.1fr) minmax(280px,.9fr);gap:48px;align-items:center}.sl-gwct-hero__visual{max-width:none;margin:0}.sl-gwct-hero h1{font-size:36px}.sl-gwct-hero__tagline{font-size:22px}}
/* Lock secondary CTA to shared outline style (beats home-page .sl-btn--secondary) */
.sl-gwct-page .sl-btn--secondary,
.sl-gwct-page button.sl-btn--secondary,
.sl-gwct-page a.sl-btn--secondary{
	margin-left:0;
	background:linear-gradient(var(--sl-page-white,#fff),var(--sl-page-white,#fff)) padding-box,var(--sl-btn-primary-fill,linear-gradient(180deg,#4d7ed6 0%,#1a3b87 100%)) border-box!important;
	background-color:transparent!important;
	border:2px solid transparent!important;
	color:var(--sl-page-primary,#1472ba)!important;
	box-shadow:none;
}
.sl-gwct-dashboard{background:var(--sl-page-white);border:1px solid rgba(107,124,147,.18);border-radius:16px;padding:18px;box-shadow:0 12px 32px rgba(22,35,78,.08)}
.sl-gwct-dashboard__head{display:flex;gap:12px;align-items:flex-start;margin-bottom:14px}
.sl-gwct-dashboard__icon{width:42px;height:42px;border-radius:12px;background:var(--sl-page-primary-soft);color:var(--sl-page-primary);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px}
.sl-gwct-dashboard__label{margin:0 0 4px;font-size:12px;color:var(--sl-page-muted);text-transform:uppercase;letter-spacing:.04em}
.sl-gwct-dashboard__title{margin:0;font-size:18px;color:var(--sl-page-navy)}
.sl-gwct-dashboard__bar{height:8px;border-radius:999px;background:rgba(107,124,147,.16);overflow:hidden;margin:10px 0}
.sl-gwct-dashboard__bar span{display:block;height:100%;background:var(--sl-page-primary);border-radius:999px}
.sl-gwct-dashboard__meta{display:flex;justify-content:space-between;gap:12px;font-size:13px;color:var(--sl-page-muted)}
.sl-gwct-dashboard__meta strong{color:var(--sl-page-navy);font-size:16px}
.sl-gwct-dashboard__items{display:grid;gap:10px;margin-top:14px}
.sl-gwct-dashboard__item{display:grid;grid-template-columns:auto 1fr auto;gap:10px;align-items:center;padding:10px 12px;border-radius:12px;background:var(--sl-page-bg)}
.sl-gwct-dashboard__item strong{display:block;font-size:14px;color:var(--sl-page-navy)}
.sl-gwct-dashboard__item small{display:block;font-size:12px;color:var(--sl-page-muted)}
.sl-gwct-dashboard__item.is-pending{opacity:.85}
.sl-gwct-points{margin:16px 0 0;padding:0;list-style:none;display:grid;gap:10px}
.sl-gwct-points li{position:relative;padding-left:18px;font-size:15px;line-height:1.55;color:var(--sl-page-text)}
.sl-gwct-points li::before{content:"";position:absolute;left:0;top:9px;width:8px;height:8px;border-radius:50%;background:var(--sl-page-primary)}
.sl-gwct-points--steps{gap:0}
.sl-gwct-points--steps li{display:grid;grid-template-columns:40px minmax(0,1fr);gap:12px;align-items:start;padding:0 0 16px}
.sl-gwct-points--steps li:last-child{padding-bottom:0}
.sl-gwct-points--steps li::before{left:19px;top:40px;bottom:0;width:2px;height:auto;border-radius:0;background:rgba(20,114,186,.22)}
.sl-gwct-points--steps li:last-child::before{display:none}
.sl-gwct-points__index{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;background:var(--sl-page-primary);color:#fff;font-size:12px;font-weight:700}
.sl-gwct-points__copy{display:block;padding:10px 14px;border:1px solid rgba(107,124,147,.16);border-radius:12px;background:var(--sl-page-white)}
.sl-gwct-points__copy strong{color:var(--sl-page-navy);font-weight:700}
.sl-gwct-split{display:grid;gap:24px;align-items:center}
@media(min-width:900px){.sl-gwct-split{grid-template-columns:minmax(0,.95fr) minmax(0,1.05fr)}.sl-gwct-split--reverse .sl-gwct-split__visual{order:2}}
.sl-gwct-media{border-radius:18px;overflow:hidden;border:1px solid rgba(107,124,147,.18);background:var(--sl-page-white)}
.sl-gwct-media amp-img{display:block}
.sl-gwct-cta-panel{text-align:center;padding:36px 24px;border-radius:18px;background:linear-gradient(180deg,var(--sl-page-bg) 0%,var(--sl-page-white) 100%);border:1px solid rgba(107,124,147,.18)}
.sl-gwct-cta-panel .sl-h2{color:var(--sl-page-navy)}
.sl-gwct-cta-panel .sl-btn--whatsapp{background:#25d366;color:#fff;border:0;text-decoration:none}
.sl-gwct-cta-panel .sl-btn--whatsapp:hover,.sl-gwct-cta-panel .sl-btn--whatsapp:focus{background:#1ebe57;color:#fff}
.sl-gwct-trust{text-align:center;padding:32px 24px;border-radius:18px;background:var(--sl-page-white);border:1px solid rgba(107,124,147,.18)}
.sl-gwct-trust .sl-h2{margin-bottom:12px}
.sl-gwct-trust .sl-lead{margin:0 auto 20px;max-width:720px}
.sl-gwct-trust__badges{display:flex;flex-wrap:wrap;justify-content:center;gap:18px 28px;margin:0 0 18px;padding:0;list-style:none}
.sl-gwct-trust__badges li{margin:0}
.sl-gwct-trust__note{margin:0 auto 18px;max-width:640px;font-size:15px;line-height:1.6;color:var(--sl-page-text)}
.sl-gwct-trust .sl-btn{margin:0 auto}
.sl-gwct-solutions{display:grid;gap:18px}
.sl-gwct-solution{background:var(--sl-page-white);border:1px solid rgba(107,124,147,.18);border-top:3px solid var(--sl-page-primary);border-radius:16px;padding:22px}
.sl-gwct-solution h3{margin:0 0 8px;font-size:20px;color:var(--sl-page-primary)}
.sl-gwct-solution__subtitle{margin:0 0 12px;font-size:15px;line-height:1.55;color:var(--sl-page-navy);font-weight:600}
.sl-gwct-solution p{margin:0 0 12px;font-size:15px;line-height:1.65;color:var(--sl-page-text)}
.sl-gwct-solution ul{margin:0;padding:0;list-style:none;display:grid;gap:8px}
.sl-gwct-solution li{position:relative;padding-left:18px;font-size:14px;line-height:1.55;color:var(--sl-page-text)}
.sl-gwct-solution li::before{content:"";position:absolute;left:0;top:9px;width:8px;height:8px;border-radius:50%;background:var(--sl-page-primary)}
.sl-gwct-solution li.sl-gwct-course--flag{display:flex;align-items:center;gap:10px;padding-left:0}
.sl-gwct-solution li.sl-gwct-course--flag::before{display:none}
.sl-gwct-course-flag{display:inline-flex;flex:0 0 auto;overflow:hidden;border-radius:3px;border:1px solid rgba(107,124,147,.25)}
.sl-gwct-course-flag amp-img{display:block}
.sl-gwct-solution__meta{display:grid;gap:16px;margin-top:16px}
@media(min-width:768px){.sl-gwct-solution__meta{grid-template-columns:1fr 1fr}}
.sl-gwct-solution__block h4{margin:0 0 10px;font-size:14px;color:var(--sl-page-navy)}
.sl-gwct-why-grid{display:grid;gap:14px}
@media(min-width:700px){.sl-gwct-why-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(min-width:1000px){.sl-gwct-why-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
.sl-gwct-why-card{background:var(--sl-page-white);border:1px solid rgba(107,124,147,.18);border-radius:14px;padding:18px;height:100%}
.sl-gwct-why-card h3{margin:0 0 8px;font-size:18px;color:var(--sl-page-primary)}
.sl-gwct-why-card p{margin:0;font-size:14px;line-height:1.6;color:var(--sl-page-text)}
.sl-gwct-callout{margin-top:16px;padding:18px 20px;border-left:5px solid var(--sl-page-primary);border-radius:0 14px 14px 0;background:var(--sl-page-primary-soft)}
.sl-gwct-callout strong{color:var(--sl-page-navy)}
.sl-gwct-contact-note{margin:16px 0;padding:16px 18px;border-radius:12px;background:var(--sl-page-primary-soft);font-size:14px;line-height:1.6;color:var(--sl-page-text)}
.sl-gwct-contact-note strong{display:block;margin-bottom:4px;color:var(--sl-page-navy)}
.sl-gwct-contact-direct{display:grid;gap:10px;margin-top:16px}
.sl-gwct-contact-direct a{display:flex;gap:12px;align-items:center;padding:14px 16px;border:1px solid rgba(107,124,147,.18);border-radius:12px;text-decoration:none;color:var(--sl-page-navy);background:var(--sl-page-white)}
.sl-gwct-contact-direct a.sl-gwct-contact__whatsapp{background:#25d366;border-color:#25d366;color:#fff;box-shadow:0 12px 28px rgba(37,211,102,.28)}
.sl-gwct-contact-direct a.sl-gwct-contact__whatsapp .sl-gwct-contact-direct__title,.sl-gwct-contact-direct a.sl-gwct-contact__whatsapp .sl-gwct-contact-direct__value{color:#fff}
.sl-gwct-contact-direct__title{display:block;font-size:13px;color:var(--sl-page-muted)}
.sl-gwct-contact-direct__value{display:block;font-size:15px;font-weight:600;color:var(--sl-page-navy)}
.sl-gwct-testimonials-note{margin:0 0 12px;font-size:13px;line-height:1.55;color:var(--sl-page-muted);font-style:italic}

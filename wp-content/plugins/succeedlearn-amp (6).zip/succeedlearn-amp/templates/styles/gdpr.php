<?php
/**
 * GDPR Employee Awareness Training — AMP page styles (single file for all sections).
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

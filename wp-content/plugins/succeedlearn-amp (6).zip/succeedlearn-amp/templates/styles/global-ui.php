<?php
/**
 * Shared AMP UI tokens — gradient primary CTAs, accent color, chrome.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
:root{
	--sl-heading-accent:#135db7;
	--sl-btn-primary-fill:linear-gradient(180deg,#4d7ed6 0%,#1a3b87 100%);
	--sl-btn-primary-shadow:rgba(26,59,135,.22);
	--sl-chrome-fill:var(--sl-btn-primary-fill);
}
.sl-btn--primary,
a.sl-btn--primary,
button.sl-btn--primary,
.sl-amp-btn,
.sl-courses-card__cta,
a.sl-courses-card__cta,
.sl-courses-page .sl-courses-card__cta,
.sl-courses-page a.sl-courses-card__cta.sl-btn--primary,
.sl-about-page .sl-btn--primary,
.sl-contact-page .sl-btn--primary,
.sl-dd-page .sl-btn--primary,
.sl-sap-page .sl-btn--primary,
.sl-sap-page .sl-clients__cta .sl-btn,
.sl-sap-page .sl-clients__cta a,
.sl-gwct-page .sl-btn--primary,
.sl-csa-page .sl-btn--primary,
.sl-whp-page .sl-btn--primary{
	background:var(--sl-btn-primary-fill)!important;
	background-color:transparent!important;
	border:1px solid transparent!important;
	color:#fff!important;
	box-shadow:0 6px 16px var(--sl-btn-primary-shadow);
}
/* Outline secondary CTAs (CSA / WHP / GWCT pattern) */
.sl-csa-page .sl-btn--secondary,
.sl-whp-page .sl-btn--secondary,
.sl-gwct-page .sl-btn--secondary,
.sl-csa-page button.sl-btn--secondary,
.sl-whp-page button.sl-btn--secondary,
.sl-gwct-page button.sl-btn--secondary{
	margin-left:0;
	background:linear-gradient(var(--sl-page-white,#fff),var(--sl-page-white,#fff)) padding-box,var(--sl-btn-primary-fill) border-box!important;
	background-color:transparent!important;
	border:2px solid transparent!important;
	color:var(--sl-page-primary,#1472ba)!important;
	box-shadow:none;
}
.scf-submit,
button.scf-submit{
	background:var(--sl-btn-primary-fill)!important;
	background-color:transparent!important;
	border:1px solid transparent!important;
	color:#fff!important;
	box-shadow:0 6px 16px var(--sl-btn-primary-shadow);
}
.scf-lightbox-button{
	background:var(--sl-btn-primary-fill)!important;
	background-color:transparent!important;
	border:1px solid transparent!important;
	color:#fff!important;
}

/* Shared numbered FAQ accordion (all AMP pages). Class-only selectors so tree shaking keeps them. */
.sl-amp-faq{margin:12px 0 0}
.sl-amp-faq__accordion{display:block}
.sl-amp-faq__item{border:1px solid rgba(107,124,147,.18);border-radius:12px;margin:0 0 10px;background:#fff;overflow:hidden}
.sl-amp-faq__item:last-child{margin-bottom:0}
.sl-amp-faq__summary{display:flex;align-items:flex-start;gap:12px;margin:0;padding:16px 16px 16px 16px;font-size:15px;line-height:1.45;font-weight:700;color:#16234e;background:#fff;border:0}
.sl-amp-faq__num{flex:0 0 auto;min-width:1.75rem;color:#000000;font-size:14px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1.45}
.sl-amp-faq__q{flex:1 1 auto;min-width:0;color:#16234e}
.sl-amp-faq__panel{padding:0px 16px 16px 16px;font-size:14px;line-height:1.65;color:#4A4A4A;background:#fff}
.sl-amp-faq__panel p{margin:0}
@media(max-width:480px){.sl-amp-faq__panel{padding:0px 16px 16px 16px}}

/* Global bordered list item (checklists, included features, integration rows) */
.sl-list,
.sl-csa-checklist,
.sl-csa-included__features,
.sl-cybersecurity-campaign-measure__metrics,
.sl-csa-integration__list{
	display:grid;
	grid-template-columns:minmax(0,1fr);
	gap:10px;
	margin:0;
	padding:0;
	list-style:none
}
.sl-list-item,
.sl-csa-checklist li,
.sl-csa-included__feature,
.sl-csa-integration__list>div,
.sl-cybersecurity-campaign-measure__metric{
	display:flex;
	align-items:center;
	gap:9px;
	min-height:58px;
	padding:13px 14px;
	border:1px solid rgba(22,35,78,.09);
	border-radius:8px;
	background:var(--sl-page-white,#fff);
	color:var(--sl-page-text,#4a4a4a);
	font-size:16px;
	line-height:1.45;
	box-sizing:border-box
}
.sl-list-item__label,
.sl-csa-integration__list dt{
	flex:0 0 auto;
	min-width:110px;
	margin:0;
	color:var(--sl-page-primary,#1472ba);
	font-weight:700
}
.sl-list-item__text,
.sl-csa-integration__list dd{
	flex:1 1 auto;
	min-width:0;
	margin:0;
	color:var(--sl-page-text,#4a4a4a);
	line-height:1.45
}
.sl-csa-checklist li>span{
	display:inline-flex;
	flex:0 0 auto;
	align-items:center;
	justify-content:center;
	width:19px;
	height:19px;
	border-radius:50%;
	background:var(--sl-page-primary,#1472ba);
	color:#fff;
	font-size:12px;
	font-weight:700
}
.sl-csa-included__features{counter-reset:csa-included-feature}
.sl-csa-included__feature::before{
	content:counter(csa-included-feature) ".";
	counter-increment:csa-included-feature;
	flex:0 0 auto;
	min-width:1.5ch;
	color:var(--sl-page-primary,#1472ba);
	font-weight:800
}
.sl-csa-included__feature--highlight{
	border-color:#1472ba;
	background:rgba(20,114,186,.09);
	color:#16234e;
	font-weight:700
}
.sl-csa-included__feature--highlight::before{color:#1472ba}
@media(min-width:700px){
	.sl-list--2up,
	.sl-csa-included__features{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
}
@media(min-width:768px){
	.sl-csa-checklist{grid-template-columns:repeat(2,minmax(0,1fr));column-gap:20px;row-gap:12px}
}

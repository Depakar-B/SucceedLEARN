<?php
/**
 * HIPAA Annual Workforce Training AMP — Why Us section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

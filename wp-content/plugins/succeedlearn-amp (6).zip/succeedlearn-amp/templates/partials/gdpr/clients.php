<?php
/**
 * GDPR Employee Awareness Training AMP — Clients section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

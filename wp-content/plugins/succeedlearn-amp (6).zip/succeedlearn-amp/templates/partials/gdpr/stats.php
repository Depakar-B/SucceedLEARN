<?php
/**
 * GDPR Employee Awareness Training AMP — Stats section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

<?php
/**
 * DPDPA Compliance Training AMP — Curriculum section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

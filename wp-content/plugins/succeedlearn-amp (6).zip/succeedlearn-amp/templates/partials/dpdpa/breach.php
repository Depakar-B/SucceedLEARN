<?php
/**
 * DPDPA Compliance Training AMP — Breach section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

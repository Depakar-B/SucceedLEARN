<?php
/**
 * DPDPA Compliance Training AMP — Training Records section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

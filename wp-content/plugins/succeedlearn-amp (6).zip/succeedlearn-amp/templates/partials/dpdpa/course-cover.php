<?php
/**
 * DPDPA Compliance Training AMP — Course Cover section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

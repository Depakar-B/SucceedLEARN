<?php
/**
 * DPDPA Compliance Training AMP — Signoff section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

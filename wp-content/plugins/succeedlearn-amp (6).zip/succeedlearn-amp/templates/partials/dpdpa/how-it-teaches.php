<?php
/**
 * DPDPA Compliance Training AMP — How It Teaches section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

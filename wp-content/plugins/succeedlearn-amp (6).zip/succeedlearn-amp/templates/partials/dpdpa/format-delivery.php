<?php
/**
 * DPDPA Compliance Training AMP — Format Delivery section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

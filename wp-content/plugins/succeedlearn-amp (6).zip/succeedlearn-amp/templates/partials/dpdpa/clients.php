<?php
/**
 * DPDPA Compliance Training AMP — Clients section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

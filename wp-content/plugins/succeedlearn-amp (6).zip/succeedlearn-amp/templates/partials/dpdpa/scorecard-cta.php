<?php
/**
 * DPDPA Compliance Training AMP — Scorecard Cta section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

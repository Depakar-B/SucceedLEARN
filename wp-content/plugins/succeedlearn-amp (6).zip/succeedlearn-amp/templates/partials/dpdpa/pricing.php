<?php
/**
 * DPDPA Compliance Training AMP — Pricing section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

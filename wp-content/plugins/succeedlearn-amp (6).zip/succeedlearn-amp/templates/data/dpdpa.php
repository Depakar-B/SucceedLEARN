<?php
/**
 * DPDPA Compliance Training — AMP data helpers.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include a DPDPA Compliance Training section partial.
 *
 * @param string $name Partial basename without .php.
 */
function succeedlearn_amp_dpdpa_partial( $name ) {
	$path = SUCCEEDLEARN_AMP_TEMPLATES_DIR . 'partials/dpdpa/' . sanitize_file_name( (string) $name ) . '.php';
	if ( is_readable( $path ) ) {
		include $path;
	}
}

/**
 * @return string
 */
function succeedlearn_amp_get_dpdpa_canonical_url() {
	$canonical = home_url( '/dpdpa-compliance-training/' );
	foreach ( array( 'dpdpa-compliance-training' ) as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			$link = get_permalink( $page );
			if ( $link ) {
				return $link;
			}
		}
	}
	return $canonical;
}

/**
 * @return string
 */
function succeedlearn_amp_get_dpdpa_page_title() {
	return __( 'DPDPA Compliance Training', 'succeedlearn-amp' );
}

/**
 * @return string
 */
function succeedlearn_amp_get_dpdpa_meta_description() {
	return '';
}

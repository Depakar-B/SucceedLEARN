<?php
/**
 * GDPR Employee Awareness Training — AMP data helpers.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include a GDPR Employee Awareness Training section partial.
 *
 * @param string $name Partial basename without .php.
 */
function succeedlearn_amp_gdpr_partial( $name ) {
	$path = SUCCEEDLEARN_AMP_TEMPLATES_DIR . 'partials/gdpr/' . sanitize_file_name( (string) $name ) . '.php';
	if ( is_readable( $path ) ) {
		include $path;
	}
}

/**
 * @return string
 */
function succeedlearn_amp_get_gdpr_canonical_url() {
	$canonical = home_url( '/gdpr-employee-awareness-training/' );
	foreach ( array( 'gdpr-employee-awareness-training' ) as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			$link = get_permalink( $page );
			if ( $link ) {
				return $link;
			}
		}
	}
	return $canonical;
}

/**
 * @return string
 */
function succeedlearn_amp_get_gdpr_page_title() {
	return __( 'GDPR Employee Awareness Training', 'succeedlearn-amp' );
}

/**
 * @return string
 */
function succeedlearn_amp_get_gdpr_meta_description() {
	return '';
}

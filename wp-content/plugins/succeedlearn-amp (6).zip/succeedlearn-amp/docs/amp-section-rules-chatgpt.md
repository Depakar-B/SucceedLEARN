# SucceedLearn AMP Section Rules — ChatGPT Prompt

**How to use:** Copy everything from `--- START PROMPT ---` through `--- END PROMPT ---` and paste it at the **start** of your ChatGPT conversation (or into a Custom GPT / project instructions). Then paste your desktop section code or describe the section you want ported.

---

--- START PROMPT ---

You are building SucceedLearn AMP page sections for WordPress. All code goes in the plugin:

`wp-content/plugins/succeedlearn-amp/`

**Do not** use legacy `_incoming/live-amp/` templates. **Do not** use Bootstrap. **Do not** invent a parallel class system.

Match the desktop theme (`wp-content/themes/akaza-adventure/template-parts/…`) in section order, copy, BEM class names, and visual intent.

**Canonical examples to follow:**
- `templates/pages/home.php`
- `templates/pages/security-awareness.php`
- `templates/styles/home-page.php` (shared primitives)
- `templates/styles/home-sections.php` (section CSS style)
- `templates/partials/security-awareness/suite.php` (static card grid instead of accordion)

---

## 1. Golden rule — mirror desktop first

Every AMP section must match its desktop counterpart in:

- **Section order** (same as theme wrapper)
- **Copy** (headings, bullets, CTAs)
- **BEM class names** (`sl-sa-hero`, `sl-suite-card`, `sl-reality__grid`, `sl-testimonials__card`, etc.)
- **Dual-colour h2** — navy base text + accent words in `<span>` inside `.sl-h2`

When desktop uses JS AMP cannot run (accordion, carousel, sticky scroll), use the **closest static AMP equivalent** (e.g. suite accordion → expanded card grid, all cards visible).

---

## 2. File layout

| Purpose | Path |
|---|---|
| Full AMP page | `templates/pages/{page}.php` |
| Section partial | `templates/partials/{page}/{section}.php` |
| Data + loader | `templates/data/{page}.php` → `succeedlearn_amp_*_partial( 'hero' )` |
| Inlined CSS | `templates/styles/{name}.php` or `.css` |

New pages must register in `includes/class-config.php` → `get_amp_page_map()`.

---

## 3. Page shell pattern

```php
<!doctype html>
<html amp lang="...">
<head>
  <script async src="https://cdn.ampproject.org/v0.js"></script>
  <link rel="canonical" href="..." />
  <style amp-custom>
  <?php succeedlearn_amp_output_page_styles( 'page_type', array( 'home-page' ), array( 'home-sections', 'page-specific' ) ); ?>
  </style>
  <?php succeedlearn_amp_output_components( 'page_type', array( 'amp-form', 'amp-sidebar', ... ) ); ?>
</head>
<body class="sl-home sl-*-page">
  <?php include SUCCEEDLEARN_AMP_TEMPLATES_DIR . 'components/menu.php'; ?>
  <main id="main-content">
    <?php succeedlearn_amp_*_partial( 'hero' ); ?>
  </main>
  <?php include SUCCEEDLEARN_AMP_TEMPLATES_DIR . 'components/footer.php'; ?>
</body>
</html>
```

---

## 4. Shared markup (reuse — do not reinvent)

Use these existing AMP primitives from `home-page.php`:

- Section wrapper: `<section class="sl-section sl-section--alt">` + `<div class="sl-wrap">`
- Eyebrow: `.sl-eyebrow` or `.sl-home-sub-heading`
- Title: `.sl-h2` with accent `<span>`
- Lead: `.sl-lead`
- Cards: `.sl-card` inside `.sl-grid-2` / `.sl-grid-3` / `.sl-grid-4`
- Buttons: `.sl-btn .sl-btn--primary | --secondary | --ghost`

Do **not** create parallel systems (`banner`, `hero-static-section`, Bootstrap rows, etc.).

---

## 5. Layout — CSS Grid only

- **Never Bootstrap** (`row`, `col-md-*`, etc.)
- CSS Grid / Flexbox only
- `minmax(0, 1fr)` on grid columns
- **AMP breakpoints:** 700px, 768px, 900px, 1000px (not desktop 991/1199)
- Write **mobile-first**. Default to 1 column, then add `min-width` queries. Do not start at 3 columns and only collapse with `max-width`.
- Section padding: `48px 16px` (mobile-first). If the section also has `.sl-section`, do not stack a second large padding (90px). Override: `.sl-*-page .sl-*-section.sl-section { padding: 48px 16px; }`
- Content width: `.sl-wrap { max-width: 1100px }`
- Common grids: 4-up → 2-col @ tablet → 1-col mobile; hero content+image: 1-col mobile, **2-col from 768px**
- **Card / item gap (required):** always set `gap` on the grid (`16px` mobile, `20px` tablet, `22–24px` desktop). Do not rely on borders alone. 3-up cards stay **1-col until 1000px** so tablet is not a squeezed 3-col or a giant single card with 90px padding.
- **Mobile buttons (≤767px):** column, `width: 100%`, `justify-content: center`, `text-align: center`, `margin-left: 0` (override `.sl-btn--secondary { margin-left: 8px }`). From 768px, buttons sit in a row at `width: auto`.
- **Hero / section images:** `amp-img` with explicit width/height + `layout="responsive"`. Wrapper: `overflow: hidden; border-radius: 12px`. `amp-img img { object-fit: cover; object-position: center; }`. On stacked (mobile) layouts, cap the visual `max-width: 360px; margin: 0 auto` so a 4:3 image is not full-bleed tall. From 768px, `max-width: none`.

### Card equal-height alignment (critical)

Body copy and CTAs must start on the **same vertical baseline** across cards in a row:

1. Wrap icon/number + title in `__head`
2. Set shared `min-height` on `__head` for tallest title (2–3 lines)
3. Identical card padding; no uneven top margins on `<p>`
4. CTA: `margin-top: auto` on flex column cards

```html
<article class="example__card">
  <div class="example__head">
    <!-- icon / number -->
    <h3>…</h3>
  </div>
  <p>…</p>
  <a class="example__link">…</a>
</article>
```

```css
.example__card { display: flex; flex-direction: column; height: 100%; }
.example__head { min-height: /* tallest title */; margin-bottom: 12px; }
.example__link { margin-top: auto; }
```

---

## 6. Brand colours (required — use only these)

Working set per page: navy + primary blue + optional CTA orange + neutrals.

```css
.sl-*-page {
  --sl-page-navy: #16234e;
  --sl-page-primary: #1472ba;
  --sl-page-primary-dark: #283384;
  --sl-page-primary-soft: rgba(109, 195, 235, 0.16);
  --sl-page-cta: #ea3e24;
  --sl-page-text: #4A4A4A;
  --sl-page-muted: #6B7C93;
  --sl-page-bg: #f5f5f5;
  --sl-page-white: #fff;
}
```

- Prefer `var(--sl-page-primary)` over raw hex
- Normalize near-misses: `#18233b` → `#16234e`, `#135db7` → `#1472ba`
- Do **not** use pinks, purples, lavenders unless design explicitly requires them
- Do **not** use broken `--sl-sa-*` aliases — use `--sl-page-*`

Full palette if needed: blue `#1472ba` / `#20bced` / `#6dc3eb`; navy `#16234e` / `#283384`; CTA orange `#ea3e24`; green `#0e9f4a` only on green-accent pages.

---

## 7. Typography

- Eyebrow: `<span class="sl-home-sub-heading">` or `.sl-eyebrow`
- Section title: `h2` navy; accent in `<span>`
- Card titles: `h3`; accent `#1472ba` when designed that way
- Card `h3` often **18px** — override with page-scoped selector
- Dual-colour h2: `<?php echo wp_kses_post( __( 'Main words <span>accent words</span>', 'succeedlearn-amp' ) ); ?>` inside `.sl-h2`
- `.sl-h2 span { color: var(--sl-page-primary) }`

---

## 8. AMP-only constraints (critical)

| Desktop | AMP |
|---|---|
| `<img>` | `<amp-img width="" height="" layout="responsive" or layout="fixed">` |
| `<a href="#contact">` scroll | `<button type="button" class="sl-btn" <?php echo succeedlearn_amp_scroll_tap_attr('contact'); ?>>` |
| Custom JS / onclick | **Forbidden** — AMP actions (`on="tap:..."`) or allowed components only |
| CSS enqueue | Inlined in `<style amp-custom>` via `succeedlearn_amp_output_page_styles()` |
| `akaza_upload_url()` | `succeedlearn_amp_upload_url( '2026/08/file.webp' )` |
| Text domain `akaza-adventure` | **`succeedlearn-amp`** |
| Hardcoded content | Prefer theme helpers: `akaza_get_client_testimonials()`, `akaza_get_breadcrumbs()` |

- No inline `onclick`, custom `<script>`, or `<video>` on sections
- CTA tracking: add `data-cta="hero-trial"` on buttons/links
- Images: always explicit `width` + `height`; decorative icons `alt=""`

---

## 9. CSS authoring

- Put CSS in `templates/styles/*.php` — minified single-line blocks (see `home-sections.php`)
- Shared auto-loaded: `menu`, `global-ui`, `footer`, `scroll-to-top`, `breadcrumbs`
- Page-specific styles: pass in `$always_inline` array to `succeedlearn_amp_output_page_styles()`
- **New class selectors** must be added to `includes/class-plugin.php` → `whitelist_home_css_for_tree_shaking()` or production CSS may be stripped
- Keep CSS lean — `amp-custom` has ~75KB limit
- Hero background URLs: append after `succeedlearn_amp_output_page_styles()` in page template

---

## 10. Card chrome, callouts, icons

- Card border: `1px solid rgba(107, 124, 147, 0.18)`; radius ~14–18px
- Optional top accent: `border-top: 3px solid var(--sl-page-primary)`
- Callout block:

```css
.example__callout {
  padding: 22px 26px;
  border-left: 5px solid var(--sl-page-primary, #1472ba);
  border-radius: 0 14px 14px 0;
  background: rgba(109, 195, 235, 0.16);
}
```

- Icons: plain, no circle/bg by default; consistent size (e.g. 32×32 `layout="fixed"`)
- Two-column + image: stack on mobile; side-by-side @ ≥700–900px (see `.sl-reality__grid`)

---

## 11. Forms & contact

- `do_shortcode( '[contact_form]' )` or `succeedlearn_amp_render_contact_form()`
- Layout: `.sl-contact-layout` + `.sl-contact-intro` + `.sl-contact-form-card`
- Contact section: `id="contact"`; scroll CTAs use `succeedlearn_amp_scroll_tap_attr( 'contact' )`
- Declare `amp-form`, `amp-mustache`, `amp-lightbox` in `succeedlearn_amp_output_components()` when form is present

---

## 12. PHP partial template

```php
<?php
/**
 * Page AMP — Section name.
 * Expected vars: $foo
 * @package SucceedLEARN\AMP
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-*-section" aria-labelledby="section-title-id">
  <div class="sl-wrap">
    <span class="sl-eyebrow"><?php esc_html_e( 'Eyebrow', 'succeedlearn-amp' ); ?></span>
    <h2 id="section-title-id" class="sl-h2">
      <?php esc_html_e( 'Main words', 'succeedlearn-amp' ); ?>
      <span><?php esc_html_e( 'accent words', 'succeedlearn-amp' ); ?></span>
    </h2>
  </div>
</section>
```

- Escape: `esc_html`, `esc_url`, `esc_attr`, `esc_html_e`, `wp_kses_post`
- Reuse data from `templates/data/{page}.php` — don't duplicate content
- Decorative icons: `alt=""` + `aria-hidden="true"`

---

## 13. What NOT to do

- No Bootstrap grid
- No `<img>`, custom JS, inline event handlers
- No off-brand colours
- No accordion/carousel unless AMP component is explicitly loaded
- No copying from `_incoming/live-amp/` legacy templates
- No separate CSS file enqueues
- No dashboard clutter in heroes unless desktop has it (Security Awareness dashboard mock is the exception)

---

## 14. Output format

When I ask you to build or port a section, return:

1. **PHP partial** — full file for `templates/partials/{page}/{section}.php`
2. **CSS block** — minified rules to add to the correct `templates/styles/` file
3. **Data changes** — if arrays/helpers needed in `templates/data/{page}.php`
4. **Whitelist additions** — any new CSS selectors for `class-plugin.php`
5. **Page wiring** — if the partial must be included in `templates/pages/{page}.php`

---

## 15. Checklist (verify before finishing)

- [ ] Section order + copy matches desktop theme partial
- [ ] Uses `sl-section` / `sl-wrap` / shared grid classes
- [ ] Dual-colour h2 with `<span>` where desktop has accent words
- [ ] All images are `amp-img` with width/height
- [ ] Scroll CTAs use `succeedlearn_amp_scroll_tap_attr()`
- [ ] CSS in correct `templates/styles/` partial
- [ ] New selectors listed for tree-shaking whitelist
- [ ] Brand tokens only; card `__head` min-heights for equal alignment

--- END PROMPT ---

---

## Example follow-up message (paste after the prompt)

```
Port this desktop section to AMP. Return the PHP partial, CSS, and any wiring changes.

[Paste desktop template-parts code here]

Target page: security-awareness
Section name: achieve
```

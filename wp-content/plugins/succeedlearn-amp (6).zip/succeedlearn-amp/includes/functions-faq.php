<?php
/**
 * Shared AMP FAQ accordion helpers.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render the shared numbered AMP FAQ accordion.
 *
 * Use this UI on all AMP pages regardless of desktop FAQ styling.
 *
 * @param array  $items FAQ items with question/answer keys.
 * @param string $extra_class Optional extra wrapper class.
 */
function succeedlearn_amp_render_faq_accordion( $items, $extra_class = '' ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return;
	}

	$classes = trim( 'sl-amp-faq ' . (string) $extra_class );
	?>
	<div class="<?php echo esc_attr( $classes ); ?>">
		<amp-accordion class="sl-amp-faq__accordion" animate expand-single-section>
			<?php
			$opened = false;
			foreach ( $items as $index => $item ) :
				$question = isset( $item['question'] ) ? (string) $item['question'] : '';
				$answer   = isset( $item['answer'] ) ? (string) $item['answer'] : '';
				if ( '' === $question || '' === $answer ) {
					continue;
				}
				$num = str_pad( (string) ( (int) $index + 1 ), 2, '0', STR_PAD_LEFT ) . '.';
				?>
				<section class="sl-amp-faq__item"<?php echo ! $opened ? ' expanded' : ''; ?>>
					<h3 class="sl-amp-faq__summary">
						<span class="sl-amp-faq__num" aria-hidden="true"><?php echo esc_html( $num ); ?></span>
						<span class="sl-amp-faq__q"><?php echo esc_html( $question ); ?></span>
					</h3>
					<div class="sl-amp-faq__panel">
						<p><?php echo esc_html( $answer ); ?></p>
					</div>
				</section>
				<?php
				$opened = true;
			endforeach;
			?>
		</amp-accordion>
	</div>
	<?php
}

<?php
/**
 * Desktop search panel markup (Solutions-sized dropdown).
 *
 * @package Akaza_Header_Footer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div
	id="epsh-search-panel"
	class="epsh-search-panel"
	role="dialog"
	aria-modal="false"
	aria-label="<?php esc_attr_e( 'Site search', 'akaza-header-footer' ); ?>"
	hidden
	style="display:none"
>
	<div class="epsh-search-panel__inner">
		<form class="epsh-search-panel__form" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" role="search">
			<label class="screen-reader-text" for="epsh-search-input"><?php esc_html_e( 'Search SucceedLEARN', 'akaza-header-footer' ); ?></label>
			<input
				type="search"
				id="epsh-search-input"
				class="epsh-search-panel__input"
				name="s"
				placeholder="<?php esc_attr_e( 'Search SucceedLEARN...', 'akaza-header-footer' ); ?>"
				autocomplete="off"
				autocapitalize="off"
				spellcheck="false"
			>
			<button type="submit" class="epsh-search-panel__submit"><?php esc_html_e( 'Search', 'akaza-header-footer' ); ?></button>
			<button type="button" class="epsh-search-panel__close" aria-label="<?php esc_attr_e( 'Close search', 'akaza-header-footer' ); ?>">&times;</button>
		</form>

		<div class="epsh-search-panel__status" id="epsh-search-status" aria-live="polite"></div>
		<div class="epsh-search-panel__results" id="epsh-search-results" role="listbox" aria-label="<?php esc_attr_e( 'Search suggestions', 'akaza-header-footer' ); ?>"></div>
		<div class="epsh-search-panel__footer" id="epsh-search-footer" hidden>
			<a class="epsh-search-panel__view-all" id="epsh-search-view-all" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php esc_html_e( 'View all results', 'akaza-header-footer' ); ?>
			</a>
		</div>
	</div>
</div>
<div id="epsh-search-backdrop" class="epsh-search-backdrop" hidden style="display:none"></div>
<?php
/**
 * Security Awareness — AMP page styles.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
.sl-sap-page{--sl-page-navy:#16234e;--sl-page-primary:#1472ba;--sl-page-primary-dark:#283384;--sl-page-primary-soft:rgba(109,195,235,.16);--sl-page-cta:#ea3e24;--sl-page-text:#4A4A4A;--sl-page-muted:#6B7C93;--sl-page-bg:#F5F3EF;--sl-page-white:#fff}
.slf-breadcrumbs,.slf-breadcrumbs--inline{position:relative;z-index:2;margin:0 0 14px;padding:0;background:transparent;border:0}
.slf-breadcrumbs__list{display:flex;flex-wrap:wrap;align-items:center;gap:0;margin:0;padding:0;list-style:none;font-size:12px;line-height:1.4;color:#6B7C93}
.slf-breadcrumbs__item{display:inline-flex;align-items:center;max-width:100%;margin:0;padding:0;list-style:none}
.slf-breadcrumbs__sep{display:inline-block;margin:0 .4rem;color:rgba(22,35,78,.32);font-weight:400}
.slf-breadcrumbs__link{color:#16234e;text-decoration:none;font-weight:600;white-space:nowrap}
.slf-breadcrumbs__link:hover,.slf-breadcrumbs__link:focus{color:#1472ba;text-decoration:none}
.slf-breadcrumbs__current{display:inline-block;max-width:min(100%,18rem);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#6B7C93;font-weight:500}
@media(max-width:767px){.slf-breadcrumbs--inline{margin-bottom:10px}.slf-breadcrumbs__list{font-size:11px}.slf-breadcrumbs__current{max-width:min(100%,14rem)}}
.sl-sap-page .sl-eyebrow,.sl-sap-page .sl-home-sub-heading{display:inline-block;margin:0 0 10px;font-size:13px;font-weight:600;letter-spacing:.02em;color:var(--sl-page-primary)}
.sl-sap-page .sl-btn--primary{background:var(--sl-page-primary,#1472ba)}
.sl-sap-page .sl-btn--secondary{background:var(--sl-page-navy)}
.sl-sap-page .sl-section--alt{background:var(--sl-page-bg,#F5F3EF)}
.sl-sap-page .sl-stat__value{color:var(--sl-page-primary,#1472ba)!important}
.sl-sap-page .sl-clients__title span{color:var(--sl-page-primary,#1472ba)!important}
.sl-sap-page .sl-clients__cta{margin-top:24px}
.sl-sap-page .sl-clients__cta .sl-btn,
.sl-sap-page .sl-clients__cta a{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 22px;border-radius:8px;background:var(--sl-page-primary,#1472ba);border:1px solid var(--sl-page-primary,#1472ba);color:#fff;font-weight:700;text-decoration:none}
.sl-sap-page .sl-clients__grid{max-width:960px}
.sl-sap-page .sl-clients__cell amp-img{max-width:130px}
.sl-sap-page h2 span{color:var(--sl-page-primary,#1472ba)}
.sl-sa-dashboard__activity-value{display:none}
.sl-sa-hero{padding:16px 16px 40px 16px;background:radial-gradient(circle at 90% 20%,rgba(20,114,186,.12),transparent 34%),var(--sl-page-white)}
.sl-sa-hero__grid{display:grid;gap:28px;align-items:center}
.sl-sa-hero__eyebrow{display:inline-block;margin:0 0 12px}
.sl-sa-hero h1{margin:0 0 10px;font-size:28px;line-height:1.2;color:var(--sl-page-navy)}
.sl-sa-hero__subheading{margin:0 0 14px;font-size:18px;line-height:1.35;color:var(--sl-page-primary);font-weight:600}
.sl-sa-hero__description{margin:0 0 16px;font-size:15px;line-height:1.65;color:var(--sl-page-text)}
.sl-sa-hero__actions{display:flex;flex-wrap:wrap;gap:12px}
.sl-sa-hero .sl-btn--secondary{background:var(--sl-page-white);color:var(--sl-page-navy);border:1px solid rgba(22,35,78,.18)}
.sl-sa-dashboard{position:relative;overflow:hidden;padding:18px;border:1px solid rgba(255,255,255,.16);border-radius:24px;background:linear-gradient(145deg,#0b1f44 0%,#102f68 52%,#1558a5 100%);color:#fff;box-shadow:0 30px 70px rgba(11,31,68,.22),0 10px 25px rgba(20,114,186,.12)}
.sl-sa-dashboard__topbar,.sl-sa-dashboard__heading,.sl-sa-dashboard__chart-header,.sl-sa-dashboard__footer{display:flex;justify-content:space-between;gap:12px;align-items:center}
.sl-sa-dashboard__topbar{padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.12)}
.sl-sa-dashboard__brand{display:flex;gap:10px;align-items:center;font-size:13px;font-weight:700;color:#fff}
.sl-sa-dashboard__brand-mark{width:30px;height:30px;border-radius:8px;background:#fff;color:#1558a5;display:inline-flex;align-items:center;justify-content:center;font-weight:800}
.sl-sa-dashboard__status{display:inline-flex;gap:7px;align-items:center;padding:7px 10px;border-radius:20px;background:rgba(255,255,255,.1);color:#fff;font-size:11px;font-weight:700}
.sl-sa-dashboard__status span{width:7px;height:7px;border-radius:50%;background:#22c55e}
.sl-sa-dashboard__label{display:block;margin-bottom:5px;color:rgba(255,255,255,.62);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.08em}
.sl-sa-dashboard__heading{gap:16px;padding:18px 0 14px}
.sl-sa-dashboard__heading h3{margin:0;font-size:16px;color:#fff}
.sl-sa-dashboard__period{padding:8px 10px;border:1px solid rgba(255,255,255,.12);border-radius:7px;color:rgba(255,255,255,.75);font-size:11px}
.sl-sa-dashboard__metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.sl-sa-dashboard__metric{padding:12px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(255,255,255,.07)}
.sl-sa-dashboard__metric-label{display:block;margin-bottom:6px;color:rgba(255,255,255,.65);font-size:10px}
.sl-sa-dashboard__metric strong{display:block;margin-bottom:4px;font-size:22px;color:#fff}
.sl-sa-dashboard__metric-change{font-size:10px;color:#67e8f9;font-weight:700}
.sl-sa-dashboard__body{display:grid;gap:12px;margin-top:12px}
.sl-sa-dashboard__chart,.sl-sa-dashboard__risk{min-width:0;padding:14px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(255,255,255,.06)}
.sl-sa-dashboard__chart-header{margin-bottom:12px;font-size:12px}
.sl-sa-dashboard__chart-header strong{color:#fff}
.sl-sa-dashboard__chart-header span{color:#67e8f9;font-size:10px}
.sl-sa-dashboard__chart-area{position:relative;height:110px;overflow:hidden}
.sl-sa-dashboard__chart-grid{position:absolute;inset:0;background-image:linear-gradient(to bottom,rgba(255,255,255,.1) 1px,transparent 1px);background-size:100% 28px}
.sl-sa-dashboard__line{position:absolute;inset:8px 0;width:100%;height:calc(100% - 16px);color:#67e8f9}
.sl-sa-dashboard__risk{display:flex;flex-direction:column}
.sl-sa-dashboard__risk-item{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px;margin-bottom:14px}
.sl-sa-dashboard__risk-item>span{width:100%;color:rgba(255,255,255,.72);font-size:10px}
.sl-sa-dashboard__progress{flex:1;height:6px;overflow:hidden;border-radius:10px;background:rgba(255,255,255,.12)}
.sl-sa-dashboard__progress span{display:block;height:100%;border-radius:inherit;background:#67e8f9}
.sl-sa-dashboard__risk-item strong{color:#fff;font-size:10px}
.sl-sa-dashboard__footer{gap:12px;margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.12);font-size:10px;color:rgba(255,255,255,.58)}
@media(min-width:900px){.sl-sa-hero__grid{grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr)}.sl-sa-hero h1{font-size:36px}.sl-sa-dashboard__body{grid-template-columns:1.25fr .75fr}}
@media(max-width:767px){.sl-sa-dashboard__metrics{grid-template-columns:1fr}}
.sl-sa-platform,.sl-sa-definition,.sl-sa-lifecycle,.sl-sa-traditional,.sl-sa-compliance,.sl-suite-section,.sl-sa-behaviour,.sl-sa-achieve,.sl-sa-leadership,.sl-sa-annual-training,.sl-sa-process,.sl-sa-comparison{padding:48px 16px}
.sl-sa-definition,.sl-sa-traditional{background:var(--sl-page-white)}
.sl-suite-section,.sl-sa-platform,.sl-sa-lifecycle,.sl-sa-achieve,.sl-sa-leadership,.sl-sa-annual-training,.sl-sa-process,.sl-sa-comparison,.sl-sa-compliance,.sl-sa-behaviour{background:var(--sl-page-bg)}
.sl-sa-platform__grid,.sl-sa-definition__layout,.sl-sa-lifecycle__layout,.sl-sa-traditional__content,.sl-sa-compliance__content{display:grid;gap:24px;align-items:center}
@media(min-width:900px){.sl-sa-platform__grid,.sl-sa-definition__layout,.sl-sa-lifecycle__layout,.sl-sa-traditional__content,.sl-sa-compliance__content{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}}
.sl-sa-platform amp-img,.sl-sa-definition amp-img{border-radius:18px;overflow:hidden;border:1px solid rgba(107,124,147,.18)}
.sl-sa-platform h2,.sl-sa-definition h2,.sl-sa-lifecycle h2,.sl-sa-achieve h2,.sl-sa-leadership h2,.sl-sa-annual-training h2,.sl-sa-process h2,.sl-sa-traditional h2,.sl-sa-comparison h2,.sl-sa-compliance h2,.sl-suite-intro h2,.sl-sa-behaviour h2{margin:8px 0 14px;font-size:26px;line-height:1.25;color:var(--sl-page-navy)}
.sl-sa-platform p,.sl-sa-definition p,.sl-sa-lifecycle p,.sl-sa-traditional p,.sl-sa-compliance__text p,.sl-suite-intro p,.sl-sa-behaviour__header p,.sl-sa-achieve__intro p,.sl-sa-annual-training__heading p{margin:0 0 12px;font-size:15px;line-height:1.65;color:var(--sl-page-text)}
.sl-sa-platform__lead,.sl-sa-definition__lead{font-size:16px}
.sl-sa-definition__callout{margin:16px 0;padding:18px 20px;border-left:5px solid var(--sl-page-primary);border-radius:0 14px 14px 0;background:var(--sl-page-primary-soft)}
.sl-sa-definition__callout h3{margin:0 0 8px;font-size:16px;color:var(--sl-page-navy)}
.sl-sa-lifecycle__image-placeholder,.sl-sa-traditional__image-placeholder,.sl-sa-platform__image-placeholder,.sl-sa-definition__image-placeholder{min-height:220px;border:1px dashed rgba(20,114,186,.45);border-radius:16px;background:rgba(20,114,186,.05);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:24px;text-align:center}
.sl-sa-platform__image-placeholder{aspect-ratio:720/760}
.sl-sa-definition__image-placeholder{aspect-ratio:640/720}
.sl-sa-lifecycle__image-placeholder{aspect-ratio:640/520}
.sl-sa-traditional__image-placeholder{aspect-ratio:700/520}
.sl-sa-platform__image-size,.sl-sa-definition__image-size,.sl-sa-lifecycle__image-size,.sl-sa-traditional__image-size{color:var(--sl-page-primary);font-size:13px;font-weight:700}
.sl-sa-platform__image-note,.sl-sa-definition__image-note,.sl-sa-lifecycle__image-note,.sl-sa-traditional__image-note{color:var(--sl-page-navy);font-size:14px;font-weight:600;line-height:1.45}
.sl-suite-intro{margin-bottom:22px}
.sl-suite-accordion{display:block;overflow:hidden;border:1px solid rgba(107,124,147,.18);border-radius:18px;background:var(--sl-page-white);box-shadow:0 10px 30px rgba(22,35,78,.06)}
.sl-suite-accordion>section{border-bottom:1px solid rgba(107,124,147,.14)}
.sl-suite-accordion>section:last-child{border-bottom:0}
.sl-suite-accordion__header{display:flex;align-items:center;gap:12px;margin:0;padding:16px;background:rgba(245,243,239,.65);color:var(--sl-page-navy);font-size:15px;font-weight:600;cursor:pointer;outline:none}
.sl-suite-accordion>section[expanded]>.sl-suite-accordion__header{background:var(--sl-page-white);border-bottom:1px solid rgba(107,124,147,.12)}
.sl-suite-nav-number{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;flex:0 0 34px;border-radius:10px;background:var(--sl-page-primary-soft);color:var(--sl-page-primary);font-size:12px;font-weight:700}
.sl-suite-accordion>section[expanded] .sl-suite-nav-number{background:var(--sl-page-primary);color:#fff}
.sl-suite-accordion__titles{display:flex;flex-direction:column;min-width:0;gap:2px}
.sl-suite-card__name{display:block;font-size:15px;line-height:1.3;color:var(--sl-page-navy);font-weight:700}
.sl-suite-card__tagline{display:block;font-size:12px;line-height:1.4;color:var(--sl-page-muted);font-weight:500}
.sl-suite-accordion__panel{padding:8px 16px 20px;background:var(--sl-page-white)}
.sl-suite-card__title{margin:0 0 6px;font-size:18px;line-height:1.35;color:var(--sl-page-primary);font-weight:700}
.sl-suite-card__subtitle{margin:0 0 12px;font-size:13px;line-height:1.45;color:var(--sl-page-muted);font-weight:600}
.sl-suite-card__text{margin:0 0 12px;font-size:14px;line-height:1.65;color:var(--sl-page-text)}
.sl-suite-highlight{display:block;margin-top:8px;padding:12px 14px;border-left:4px solid var(--sl-page-primary);border-radius:0 12px 12px 0;background:var(--sl-page-primary-soft);color:var(--sl-page-navy);font-size:13px;line-height:1.5;font-weight:700}
.sl-sa-behaviour__header{margin-bottom:22px}
.sl-sa-behaviour__header h3{margin:0 0 12px;font-size:18px;color:var(--sl-page-navy)}
.sl-sa-behaviour__steps{display:grid;grid-template-columns:1fr;gap:12px}
@media(min-width:600px){.sl-sa-behaviour__steps{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(min-width:900px){.sl-sa-behaviour__steps{grid-template-columns:repeat(5,minmax(0,1fr));gap:14px}.sl-sa-behaviour__line{display:block}}
.sl-sa-behaviour__card{position:relative;min-width:0;padding:20px 16px 22px;border:1px solid rgba(107,124,147,.2);border-radius:16px;background:var(--sl-page-white);box-shadow:0 12px 35px rgba(22,35,78,.06);box-sizing:border-box}
.sl-sa-behaviour__card-top{display:flex;align-items:center;margin-bottom:16px}
.sl-sa-behaviour__number{position:relative;z-index:2;display:inline-flex;align-items:center;justify-content:center;width:42px;height:42px;flex:0 0 42px;border-radius:12px;background:var(--sl-page-primary);color:#fff;font-size:13px;font-weight:700;line-height:1}
.sl-sa-behaviour__line{display:none;width:100%;height:1px;margin-left:10px;background:rgba(20,114,186,.28)}
.sl-sa-behaviour__card-body h3{margin:0 0 8px;font-size:16px;line-height:1.3;color:var(--sl-page-navy)}
.sl-sa-behaviour__card-body p{margin:0;font-size:14px;line-height:1.55;color:var(--sl-page-text)}
.sl-sa-behaviour__closing{display:grid;gap:8px;margin-top:20px;padding:18px 20px;border:1px solid rgba(107,124,147,.18);border-radius:14px;background:var(--sl-page-white)}
.sl-sa-behaviour__closing-label{display:block;font-size:12px;font-weight:700;color:var(--sl-page-primary);letter-spacing:.04em}
.sl-sa-behaviour__closing p{margin:0;font-size:14px;line-height:1.6;color:var(--sl-page-text)}
.sl-sa-achieve__grid,.sl-sa-annual-training__grid{display:grid;grid-template-columns:1fr;gap:14px}
@media(min-width:600px){.sl-sa-achieve__grid,.sl-sa-annual-training__grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(min-width:900px){.sl-sa-achieve__grid{grid-template-columns:repeat(3,minmax(0,1fr))}.sl-sa-annual-training__grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
.sl-sa-annual-training__heading{margin-bottom:22px}
.sl-sa-annual-training__heading h3{margin:0 0 12px;font-size:17px;line-height:1.4;color:var(--sl-page-primary);font-weight:600}
.sl-sa-annual-training__card,.sl-sa-achieve__card{display:flex;flex-direction:column;height:100%;padding:20px;border:1px solid rgba(107,124,147,.18);border-radius:16px;background:var(--sl-page-white);box-sizing:border-box;box-shadow:0 8px 24px rgba(22,35,78,.04)}
.sl-sa-annual-training__title-row{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.sl-sa-annual-training__number{display:inline-flex;align-items:center;justify-content:center;width:38px;height:38px;flex:0 0 38px;border-radius:9px;background:rgba(109,195,235,.22);color:var(--sl-page-primary);font-size:13px;font-weight:700;line-height:1}
.sl-sa-annual-training__card h3,.sl-sa-annual-training__title-row h3{margin:0;color:var(--sl-page-primary);font-size:16px;font-weight:600;line-height:1.3}
.sl-sa-annual-training__card>h3{margin:0 0 12px}
.sl-sa-annual-training__card p{margin:0;font-size:14px;line-height:1.55;color:var(--sl-page-text)}
.sl-sa-achieve__card .sl-sa-annual-training__title-row{flex-direction:column;align-items:flex-start;gap:12px;margin-bottom:0}
.sl-sa-achieve__text{margin:0;color:var(--sl-page-navy);font-size:15px;font-weight:500;line-height:1.55}
.sl-sa-comparison__heading{margin-bottom:22px}
.sl-sa-comparison__table-wrap{display:block;width:100%;max-width:100%;overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain;border:1px solid rgba(107,124,147,.18);border-radius:14px;background:var(--sl-page-white);box-shadow:0 10px 28px rgba(22,35,78,.06)}
.sl-sa-comparison__table{width:100%;min-width:560px;border-collapse:separate;border-spacing:0;background:var(--sl-page-white)}
.sl-sa-comparison__table th,.sl-sa-comparison__table td{width:50%;padding:14px 16px;border-bottom:1px solid rgba(107,124,147,.14);text-align:center;font-size:14px;line-height:1.5;vertical-align:top;box-sizing:border-box}
.sl-sa-comparison__table th{background:var(--sl-page-navy);color:#fff;font-size:13px;font-weight:700}
.sl-sa-comparison__table th:last-child{background:var(--sl-page-primary)}
.sl-sa-comparison__table tbody tr:last-child td{border-bottom:0}
.sl-sa-comparison__table tbody td:first-child{border-right:1px solid rgba(107,124,147,.14);background:rgba(245,243,239,.55)}
.sl-sa-comparison__cell{display:block}
.sl-sa-comparison__cell--highlight{color:var(--sl-page-navy);font-weight:700}
@media(max-width:767px){.sl-sa-comparison__table{min-width:520px}.sl-sa-comparison__table th,.sl-sa-comparison__table td{padding:12px 14px;font-size:13px;text-align:left}}
.sl-sa-compliance__dashboard{background:var(--sl-page-white);border:1px solid rgba(107,124,147,.18);border-radius:18px;padding:18px;box-shadow:0 16px 40px rgba(22,35,78,.1)}
.sl-sa-compliance__dashboard-header{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding-bottom:14px;border-bottom:1px solid rgba(107,124,147,.14)}
.sl-sa-compliance__dashboard-label{display:block;font-size:11px;font-weight:700;color:var(--sl-page-primary);text-transform:uppercase;letter-spacing:.04em}
.sl-sa-compliance__dashboard-header strong{display:block;margin-top:4px;font-size:15px;color:var(--sl-page-navy)}
.sl-sa-compliance__status{padding:5px 10px;border-radius:999px;background:var(--sl-page-primary-soft);color:var(--sl-page-primary-dark);font-size:12px;font-weight:700}
.sl-sa-compliance__metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:14px}
.sl-sa-compliance__metric{padding:12px;border:1px solid rgba(107,124,147,.14);border-radius:12px;background:var(--sl-page-white)}
.sl-sa-compliance__metric span,.sl-sa-compliance__metric small{display:block;font-size:11px;color:var(--sl-page-muted)}
.sl-sa-compliance__metric strong{display:block;margin:4px 0;font-size:20px;color:var(--sl-page-navy)}
.sl-sa-compliance__panel{margin-top:14px;padding:14px;border-radius:12px;background:rgba(109,195,235,.1);border:1px solid rgba(107,124,147,.12)}
.sl-sa-compliance__panel-heading{display:flex;justify-content:space-between;gap:10px;margin-bottom:12px;font-size:12px}
.sl-sa-compliance__panel-heading strong{color:var(--sl-page-navy)}
.sl-sa-compliance__panel-heading span{color:var(--sl-page-muted)}
.sl-sa-dashboard__activity-bars{display:flex;align-items:flex-end;gap:4px;height:120px}
.sl-sa-dashboard__activity-column{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;height:100%}
.sl-sa-dashboard__activity-bar-track{flex:1;width:100%;display:flex;align-items:flex-end;justify-content:center}
.sl-sa-dashboard__activity-bar{display:block;width:100%;max-width:14px;border-radius:4px 4px 2px 2px;background:var(--sl-page-primary)}
.sl-sa-dashboard__activity-label{margin-top:4px;font-size:8px;color:var(--sl-page-muted);font-weight:600}
.sl-sa-compliance__coverage{margin-top:14px;padding:14px;border:1px solid rgba(107,124,147,.14);border-radius:12px;background:var(--sl-page-white)}
.sl-sa-compliance__coverage-heading{display:flex;justify-content:space-between;gap:10px;margin-bottom:8px}
.sl-sa-compliance__coverage-heading strong{font-size:13px;color:var(--sl-page-navy)}
.sl-sa-compliance__coverage-heading span{font-size:14px;font-weight:700;color:var(--sl-page-primary)}
.sl-sa-compliance__progress{height:8px;border-radius:999px;background:rgba(109,195,235,.22);overflow:hidden}
.sl-sa-compliance__progress span{display:block;width:92%;height:100%;background:var(--sl-page-primary);border-radius:inherit}
.sl-sa-compliance__footer{display:flex;flex-wrap:wrap;gap:10px 16px;margin-top:14px;padding-top:12px;border-top:1px solid rgba(107,124,147,.14);font-size:11px;font-weight:600;color:var(--sl-page-muted)}
.sl-sa-contact-direct{display:flex;flex-wrap:wrap;align-items:stretch;gap:10px;margin-top:16px}
.sl-sa-contact-direct__label{flex:0 0 100%;margin:0;font-size:13px;color:var(--sl-page-muted)}
.sl-sa-contact-direct a{display:inline-flex;flex-direction:column;justify-content:center;gap:2px;width:auto;max-width:100%;min-height:52px;padding:10px 14px;border:1px solid rgba(107,124,147,.18);border-radius:10px;text-decoration:none;background:var(--sl-page-white);box-sizing:border-box}
.sl-sa-contact-direct__title{display:block;font-size:11px;color:var(--sl-page-muted);line-height:1.2}
.sl-sa-contact-direct__value{display:block;font-size:14px;font-weight:600;color:var(--sl-page-navy);line-height:1.25}
.sl-sap-page .sl-contact-layout{display:grid;gap:28px;align-items:start}
@media(min-width:900px){.sl-sap-page .sl-contact-layout{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}}
.sl-sap-page .sl-contact-form-card{max-width:none;margin:0}
@media(max-width:767px){.sl-sa-dashboard__metrics,.sl-sa-compliance__metrics{grid-template-columns:1fr}.sl-sa-hero h1,.sl-sa-platform h2,.sl-sa-definition h2,.sl-suite-intro h2,.sl-sa-behaviour h2,.sl-sa-lifecycle h2,.sl-sa-achieve h2,.sl-sa-leadership h2,.sl-sa-annual-training h2,.sl-sa-process h2,.sl-sa-traditional h2,.sl-sa-comparison h2,.sl-sa-compliance h2{font-size:24px}.sl-sa-dashboard__activity-label{display:none}}

<?php
/**
 * Security Awareness AMP — Compliance requirements + dashboard mock.
 *
 * Expected vars: $activity_values
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$activity_values = ( isset( $activity_values ) && is_array( $activity_values ) )
	? $activity_values
	: array( 62, 68, 71, 76, 73, 82, 79, 86, 84, 91, 88, 94 );

$month_labels = array( 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' );
?>
<section
	class="sl-sa-compliance"
	id="security-awareness-compliance"
	aria-labelledby="sl-sa-compliance-title"
>
	<div class="sl-wrap">
		<div class="sl-sa-compliance__content">
			<div class="sl-sa-compliance__text">
				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Security, Awareness & Compliance', 'succeedlearn-amp' ); ?>
				</span>

				<h2 id="sl-sa-compliance-title">
					<?php esc_html_e( 'Support', 'succeedlearn-amp' ); ?>
					<span><?php esc_html_e( 'Security Awareness & Compliance Requirements', 'succeedlearn-amp' ); ?></span>
				</h2>

				<p>
					<?php esc_html_e( 'Security awareness plays an important role in helping organisations establish and maintain effective information security practices.', 'succeedlearn-amp' ); ?>
				</p>

				<p>
					<?php esc_html_e( 'SucceedLEARN helps organisations deliver structured awareness programmes, reinforce security responsibilities, and maintain ongoing employee engagement through training, simulations, microlearning, campaigns, and analytics.', 'succeedlearn-amp' ); ?>
				</p>

				<p>
					<?php esc_html_e( 'For organisations working towards or maintaining ISO/IEC 27001, security awareness activities can form an important part of broader information security management and employee awareness programmes.', 'succeedlearn-amp' ); ?>
				</p>

				<p>
					<?php esc_html_e( 'Rather than treating compliance training as a standalone annual activity, organisations can use continuous security awareness to keep employees informed about their responsibilities and reinforce secure behaviours throughout the year.', 'succeedlearn-amp' ); ?>
				</p>

				<p>
					<?php esc_html_e( 'SucceedLEARN can help bring these activities together within a consistent security awareness programme while providing visibility into participation and programme activity.', 'succeedlearn-amp' ); ?>
				</p>
			</div>

			<div class="sl-sa-compliance__visual">
				<div class="sl-sa-compliance__dashboard">
					<div class="sl-sa-compliance__dashboard-header">
						<div>
							<span class="sl-sa-compliance__dashboard-label">
								<?php esc_html_e( 'Security Awareness', 'succeedlearn-amp' ); ?>
							</span>
							<strong>
								<?php esc_html_e( 'Programme Overview', 'succeedlearn-amp' ); ?>
							</strong>
						</div>
						<span class="sl-sa-compliance__status">
							<?php esc_html_e( 'Active', 'succeedlearn-amp' ); ?>
						</span>
					</div>

					<div class="sl-sa-compliance__metrics">
						<div class="sl-sa-compliance__metric">
							<span><?php esc_html_e( 'Training', 'succeedlearn-amp' ); ?></span>
							<strong>94%</strong>
							<small><?php esc_html_e( 'Completion', 'succeedlearn-amp' ); ?></small>
						</div>
						<div class="sl-sa-compliance__metric">
							<span><?php esc_html_e( 'Awareness', 'succeedlearn-amp' ); ?></span>
							<strong>87%</strong>
							<small><?php esc_html_e( 'Participation', 'succeedlearn-amp' ); ?></small>
						</div>
						<div class="sl-sa-compliance__metric">
							<span><?php esc_html_e( 'Campaigns', 'succeedlearn-amp' ); ?></span>
							<strong>12</strong>
							<small><?php esc_html_e( 'This year', 'succeedlearn-amp' ); ?></small>
						</div>
					</div>

					<div class="sl-sa-compliance__panel">
						<div class="sl-sa-compliance__panel-heading">
							<strong><?php esc_html_e( 'Programme Activity', 'succeedlearn-amp' ); ?></strong>
							<span><?php esc_html_e( '12 months', 'succeedlearn-amp' ); ?></span>
						</div>

						<div
							class="sl-sa-dashboard__activity-chart"
							role="img"
							aria-label="<?php esc_attr_e( 'Programme activity over 12 months', 'succeedlearn-amp' ); ?>"
						>
							<div class="sl-sa-dashboard__activity-bars">
								<?php foreach ( $activity_values as $index => $value ) : ?>
									<?php
									$pct   = max( 0, min( 100, (int) $value ) );
									$label = isset( $month_labels[ $index ] ) ? $month_labels[ $index ] : '';
									?>
									<div class="sl-sa-dashboard__activity-column">
										<span class="sl-sa-dashboard__activity-value">
											<?php echo esc_html( (string) $pct . '%' ); ?>
										</span>
										<div class="sl-sa-dashboard__activity-bar-track">
											<span
												class="sl-sa-dashboard__activity-bar"
												style="height: <?php echo esc_attr( (string) $pct ); ?>%"
												aria-hidden="true"
											></span>
										</div>
										<?php if ( '' !== $label ) : ?>
											<span class="sl-sa-dashboard__activity-label">
												<?php echo esc_html( $label ); ?>
											</span>
										<?php endif; ?>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>

					<div class="sl-sa-compliance__coverage">
						<div class="sl-sa-compliance__coverage-heading">
							<strong><?php esc_html_e( 'Awareness Coverage', 'succeedlearn-amp' ); ?></strong>
							<span>92%</span>
						</div>
						<div class="sl-sa-compliance__progress" role="presentation">
							<span style="width:92%"></span>
						</div>
					</div>

					<div class="sl-sa-compliance__footer">
						<span>✓ <?php esc_html_e( 'Training', 'succeedlearn-amp' ); ?></span>
						<span>✓ <?php esc_html_e( 'Campaigns', 'succeedlearn-amp' ); ?></span>
						<span>✓ <?php esc_html_e( 'Reporting', 'succeedlearn-amp' ); ?></span>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

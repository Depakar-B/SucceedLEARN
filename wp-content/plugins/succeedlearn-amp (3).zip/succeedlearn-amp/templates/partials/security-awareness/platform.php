<?php
/**
 * Security Awareness AMP — Platform overview section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-sa-platform" id="security-awareness-suite" aria-labelledby="sl-sa-platform-title">
	<div class="sl-wrap">
		<div class="sl-sa-platform__grid">
			<div class="sl-sa-platform__media">
				<div
					class="sl-sa-platform__image-placeholder"
					role="img"
					aria-label="<?php esc_attr_e( 'Security awareness platform image placeholder', 'succeedlearn-amp' ); ?>"
				>
					<span class="sl-sa-platform__image-size"><?php esc_html_e( 'Image: 720 × 760 px', 'succeedlearn-amp' ); ?></span>
					<span class="sl-sa-platform__image-note"><?php esc_html_e( 'Security Awareness Platform Image', 'succeedlearn-amp' ); ?></span>
				</div>
			</div>
			<div class="sl-sa-platform__content">
				<span class="sl-home-sub-heading"><?php esc_html_e( 'Security Behaviour Platform', 'succeedlearn-amp' ); ?></span>
				<h2 id="sl-sa-platform-title">
					<?php esc_html_e( 'One Platform.', 'succeedlearn-amp' ); ?>
					<span><?php esc_html_e( 'Continuous Security Behaviour Change.', 'succeedlearn-amp' ); ?></span>
				</h2>
				<p class="sl-sa-platform__lead"><?php esc_html_e( 'Annual awareness training alone is no longer enough to address today’s evolving cyber threats. Employees require continuous reinforcement, practical learning experiences, phishing simulations and real-time behavioural insights to develop lasting secure habits.', 'succeedlearn-amp' ); ?></p>
				<p><?php esc_html_e( 'The SucceedLEARN Security Behaviour & Culture Suite brings together everything organisations need—from awareness courses and phishing simulations to microlearning, gamification, analytics and awareness campaigns—through a single, integrated platform designed to reduce human cyber risk.', 'succeedlearn-amp' ); ?></p>
			</div>
		</div>
	</div>
</section>

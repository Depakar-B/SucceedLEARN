<?php
/**
 * Security Awareness AMP — Suite products (accordion explorer).
 *
 * Mirrors desktop suite content with amp-accordion (expand one product at a time).
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $suite_products ) || ! is_array( $suite_products ) ) {
	$suite_products = succeedlearn_amp_get_sa_suite_products();
}

if ( empty( $suite_products ) || ! is_array( $suite_products ) ) {
	return;
}
?>
<section class="sl-suite-section" id="security-behaviour-suite" aria-labelledby="sl-sa-behaviour-suite-title">
	<div class="sl-wrap">
		<div class="sl-suite-intro">
			<span class="sl-home-sub-heading"><?php esc_html_e( 'Introduction to the Suite', 'succeedlearn-amp' ); ?></span>
			<h2 id="sl-sa-behaviour-suite-title">
				<?php esc_html_e( 'Everything You Need to Build a', 'succeedlearn-amp' ); ?>
				<span><?php esc_html_e( 'Security-Aware Organisation', 'succeedlearn-amp' ); ?></span>
			</h2>
			<p><?php esc_html_e( 'Whether your objective is improving phishing resilience, meeting ISO 27001 awareness requirements, strengthening regulatory compliance, or reducing human cyber risk, the SucceedLEARN Security Behaviour & Culture Suite provides a comprehensive set of integrated solutions that work together throughout the employee lifecycle.', 'succeedlearn-amp' ); ?></p>
		</div>

		<amp-accordion class="sl-suite-accordion" expand-single-section animate>
			<?php foreach ( $suite_products as $index => $product ) : ?>
				<section<?php echo 0 === $index ? ' expanded' : ''; ?>>
					<h3 class="sl-suite-accordion__header">
						<span class="sl-suite-nav-number"><?php echo esc_html( $product['number'] ); ?></span>
						<span class="sl-suite-accordion__titles">
							<strong class="sl-suite-card__name"><?php echo esc_html( $product['name'] ); ?></strong>
							<?php if ( ! empty( $product['tagline'] ) ) : ?>
								<small class="sl-suite-card__tagline"><?php echo esc_html( $product['tagline'] ); ?></small>
							<?php endif; ?>
						</span>
					</h3>
					<div class="sl-suite-accordion__panel">
						<h4 class="sl-suite-card__title"><?php echo esc_html( $product['title'] ); ?></h4>
						<?php if ( ! empty( $product['subtitle'] ) ) : ?>
							<p class="sl-suite-card__subtitle"><?php echo esc_html( $product['subtitle'] ); ?></p>
						<?php endif; ?>

						<?php if ( ! empty( $product['paras'] ) && is_array( $product['paras'] ) ) : ?>
							<?php foreach ( $product['paras'] as $para ) : ?>
								<?php if ( $para ) : ?>
									<p class="sl-suite-card__text"><?php echo esc_html( $para ); ?></p>
								<?php endif; ?>
							<?php endforeach; ?>
						<?php endif; ?>

						<?php if ( ! empty( $product['highlight'] ) ) : ?>
							<strong class="sl-suite-highlight"><?php echo esc_html( $product['highlight'] ); ?></strong>
						<?php endif; ?>
					</div>
				</section>
			<?php endforeach; ?>
		</amp-accordion>
	</div>
</section>

<?php
/**
 * Shared AMP FAQ accordion helpers.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render the shared numbered AMP FAQ accordion.
 *
 * Use this UI on all AMP pages regardless of desktop FAQ styling.
 *
 * @param array  $items FAQ items with question/answer keys.
 * @param string $extra_class Optional extra wrapper class.
 */
function succeedlearn_amp_render_faq_accordion( $items, $extra_class = '' ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return;
	}

	$classes = trim( 'sl-amp-faq ' . (string) $extra_class );
	?>
	<div class="<?php echo esc_attr( $classes ); ?>">
		<amp-accordion class="sl-amp-faq__accordion" animate expand-single-section disable-session-states>
			<?php
			$is_first = true;
			foreach ( $items as $index => $item ) :
				$question = isset( $item['question'] ) ? (string) $item['question'] : '';
				$answer   = isset( $item['answer'] ) ? (string) $item['answer'] : '';
				if ( '' === $question || '' === $answer ) {
					continue;
				}
				$num      = str_pad( (string) ( (int) $index + 1 ), 2, '0', STR_PAD_LEFT ) . '.';
				$has_html = false !== strpos( $answer, '<' );
				?>
				<section class="sl-amp-faq__item"<?php echo $is_first ? ' expanded' : ''; ?>>
					<h3 class="sl-amp-faq__summary">
						<span class="sl-amp-faq__num" aria-hidden="true"><?php echo esc_html( $num ); ?></span>
						<span class="sl-amp-faq__q"><?php echo esc_html( $question ); ?></span>
					</h3>
					<div class="sl-amp-faq__panel">
						<?php if ( $has_html ) : ?>
							<div class="sl-amp-faq__answer">
								<?php echo wp_kses_post( $answer ); ?>
							</div>
						<?php else : ?>
							<p><?php echo esc_html( $answer ); ?></p>
						<?php endif; ?>
					</div>
				</section>
				<?php
				$is_first = false;
			endforeach;
			?>
		</amp-accordion>
	</div>
	<?php
}

/**
 * Critical FAQ accordion CSS with !important.
 *
 * AMPforWP strips !important from amp-custom, then AMP runtime forces
 * `amp-accordion > section > * { display:block !important }`. Re-inject
 * after that strip so the shared numbered FAQ stays a flex row.
 *
 * @return string
 */
function succeedlearn_amp_get_faq_accordion_force_css() {
	return '.sl-amp-faq{margin:12px 0 0}'
		. '.sl-amp-faq__item{border:1px solid rgba(107,124,147,.18);border-radius:12px;margin:0 0 10px;background:#fff;overflow:hidden}'
		. '.sl-amp-faq__item:last-child{margin-bottom:0}'
		. 'amp-accordion.sl-amp-faq__accordion>section>.sl-amp-faq__summary,.sl-amp-faq__summary{'
		. 'display:flex!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;'
		. 'width:100%!important;margin:0!important;padding:16px 20px!important;box-sizing:border-box!important;'
		. 'font-size:15px!important;line-height:1.45!important;font-weight:700!important;color:#16234e!important;'
		. 'background:#fff!important;background-image:none!important;border:0!important;cursor:pointer}'
		. 'amp-accordion.sl-amp-faq__accordion>section>.sl-amp-faq__summary::after,.sl-amp-faq__summary::after{'
		. 'content:"+";display:flex!important;align-items:center!important;justify-content:center!important;'
		. 'flex:0 0 1.5rem!important;width:1.5rem!important;height:1.5rem!important;margin:0 0 0 auto!important;'
		. 'padding:0!important;border:0!important;color:#1472ba!important;font-size:1.4rem!important;'
		. 'font-weight:400!important;line-height:1!important;text-align:center!important}'
		. '.sl-amp-faq__num{display:inline-block!important;flex:0 0 auto!important;min-width:1.75rem;color:#000;'
		. 'font-size:14px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1.45}'
		. '.sl-amp-faq__q{flex:1 1 auto!important;min-width:0;padding-right:12px;color:#16234e}'
		. '.sl-amp-faq__item[expanded] .sl-amp-faq__summary{color:#1472ba!important}'
		. '.sl-amp-faq__item[expanded] .sl-amp-faq__summary::after{content:"-"}'
		. '.sl-amp-faq__panel{padding:0 20px 16px;font-size:14px;line-height:1.65;color:#4A4A4A;background:#fff}'
		. '@media(max-width:480px){amp-accordion.sl-amp-faq__accordion>section>.sl-amp-faq__summary,.sl-amp-faq__summary{padding:14px 16px!important}.sl-amp-faq__panel{padding:0 16px 14px}}';
}

/**
 * After AMPforWP strips !important, restore shared FAQ accordion layout CSS.
 *
 * @param string $html Full AMP HTML.
 * @return string
 */
function succeedlearn_amp_reinforce_faq_accordion_css( $html ) {
	if ( ! is_string( $html ) || '' === $html ) {
		return $html;
	}
	if ( function_exists( 'succeedlearn_amp_is_serving_amp' ) && ! succeedlearn_amp_is_serving_amp() ) {
		return $html;
	}
	if ( false === strpos( $html, 'sl-amp-faq' ) ) {
		return $html;
	}

	$faq_css = succeedlearn_amp_get_faq_accordion_force_css();
	if ( '' === $faq_css ) {
		return $html;
	}

	if ( preg_match( '/<style\b[^>]*\bamp-custom\b[^>]*>.*?<\/style>/is', $html ) ) {
		return (string) preg_replace(
			'/(<style\b[^>]*\bamp-custom\b[^>]*>)(.*?)(<\/style>)/is',
			'$1$2' . $faq_css . '$3',
			$html,
			1
		);
	}

	return $html;
}

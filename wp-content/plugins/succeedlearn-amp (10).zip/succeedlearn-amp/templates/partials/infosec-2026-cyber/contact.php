<?php
/**
 * Infosec 2026 Cyber AMP - Contact section.
 *
 * Uses the same Campaign Registration form as desktop:
 * [cybersecurity_form variant="infosec"]
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$form_title = __( 'Campaign Registration', 'succeedlearn-amp' );
?>

<section
	class="sl-section sl-section--alt sl-infosec-2026-contact"
	id="contact"
	aria-labelledby="sl-infosec-2026-contact-title"
>
	<div class="sl-wrap">
		<div class="sl-infosec-2026-contact__grid">

			<div class="sl-infosec-2026-contact__content">
				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Cyber Readiness Challenge', 'succeedlearn-amp' ); ?>
				</span>

				<h2
					id="sl-infosec-2026-contact-title"
					class="sl-h2"
				>
					<?php
					echo wp_kses_post(
						__(
							'Ready to See How <span>Cyber-Ready</span> Your Workforce Is?',
							'succeedlearn-amp'
						)
					);
					?>
				</h2>

				<p class="sl-lead sl-infosec-2026-contact__lead">
					<?php
					esc_html_e(
						'Start the Cyber Readiness Challenge.',
						'succeedlearn-amp'
					);
					?>
				</p>

				<div class="sl-infosec-2026-contact__price">
					<span class="sl-infosec-2026-contact__price-amount">
						<?php esc_html_e( '$2', 'succeedlearn-amp' ); ?>
					</span>

					<span class="sl-infosec-2026-contact__price-label">
						<?php
						esc_html_e(
							'user/month',
							'succeedlearn-amp'
						);
						?>
					</span>
				</div>

				<p class="sl-infosec-2026-contact__description">
					<?php
					esc_html_e(
						"Whatever your score, we'll help you take the next step toward stronger employee cybersecurity awareness.",
						'succeedlearn-amp'
					);
					?>
				</p>
			</div>

			<div class="sl-infosec-2026-contact__form-wrap">
				<?php
				if ( shortcode_exists( 'cybersecurity_form' ) ) {
					echo do_shortcode( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						sprintf(
							'[cybersecurity_form variant="infosec" title="%s" subtitle=""]',
							esc_attr( $form_title )
						)
					);
				} elseif ( shortcode_exists( 'seo_form' ) ) {
					echo do_shortcode( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						sprintf(
							'[seo_form variant="infosec" title="%s" subtitle=""]',
							esc_attr( $form_title )
						)
					);
				}
				?>
			</div>

		</div>
	</div>
</section>

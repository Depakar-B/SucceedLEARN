# SucceedLearn linked pages (test UI → live desktop + AMP)

Working set of pages built in the test theme (`akaza-adventure`) and wired for live via:

- **Desktop:** `succeedlearn-landing-bridge` (Eduma stays active; allowlisted slugs switch to akaza)
- **AMP (live):** `succeedlearn-amp-custom` new-UI wrappers under `template/new-ui/`
- **AMP (staging):** `succeedlearn-amp` config + templates

Update this file whenever a page is added to the live allowlist.

## Primary pages

| Page | Live slug(s) | Desktop bridge template | Desktop enqueue | Live AMP wrapper | AMP new-UI page | Status |
|---|---|---|---|---|---|---|
| Cyber Awareness (US) | `us-cyber-aware-october` | `page-templates/cybersecurity-awareness.php` | `akaza_enqueue_csa_assets` | `template/us-cyber-aware-october.php` | `new-ui/pages/cybersecurity-awareness.php` | OK |
| Cyber Awareness (UK) | `uk-cyber-aware-october` | `page-templates/cybersecurity-awareness-uk.php` | `akaza_enqueue_csa_assets` | `template/uk-cyber-aware-october.php` | `new-ui/pages/cybersecurity-awareness.php` (UK) | OK |
| Infosec 2026 Cyber (SEO) | `cybersecurity-awareness` | `page-templates/infosec-2026-cyber.php` | `akaza_enqueue_infosec_2026_cyber_assets` | `template/cybersecurity-awareness.php` | `new-ui/pages/infosec-2026-cyber.php` | OK |
| Security Awareness / SAP | `security-awareness` | `page-templates/security-awareness-and-phishing.php` | `akaza_enqueue_sap_assets` | `template/security-awareness.php` | `new-ui/pages/security-awareness.php` | OK |

## Alias slugs

| Alias slug | Resolves to | Desktop bridge | Live AMP map | Force mobile AMP | Status |
|---|---|---|---|---|---|
| `infosec-cybersecurity-awareness-month-2026` | Infosec | Yes | Yes (→ Infosec AMP) | Yes | OK |
| `infosec-cybersecurity-awareness` | Infosec | Yes | Yes | Yes | OK |
| `infosec-2026-cyber` | Infosec | Yes | Yes | Yes | OK |
| `infosec-2026` | Infosec | Yes | Yes | Yes | OK |
| `security-awareness-and-phishing` | SAP | Yes | Yes (→ SAP AMP) | Yes | OK |

## Checks (keep green)

- [x] Theme page templates exist for all 4 primary pages
- [x] Bridge allowlist includes all primary + alias slugs
- [x] Bridge editor templates list all 4 primary templates
- [x] Live AMP slug router maps all primary + Infosec/SAP aliases to new-UI
- [x] Live AMP force-AMP slug list matches the working set
- [x] SAP AMP section order matches desktop (no old `definition` section)
- [x] Infosec AMP images wired (hero / campaign works / understand / testing)

## Not in this live working set

Course pages (gifts, tax evasion, SMCR, whistleblowing, etc.) stay on the test site / full akaza theme. Do **not** add them to the bridge until intentionally approved.

## How to add a page later

1. Build desktop in `akaza-adventure` (template + enqueue + parts).
2. Build AMP in `succeedlearn-amp` (and sync into `succeedlearn-amp-custom/template/new-ui/`).
3. Add slug(s) to bridge allowlist + template label.
4. Add slug map + force-AMP entry in `succeedlearn-amp-custom.php`.
5. Update this list.

<?php
/**
 * Plugin Name: SucceedLearn Landing Bridge (Cyber + Infosec)
 * Description: Safely serves only Cybersecurity Awareness and Infosec 2026 pages from akaza-adventure while Eduma stays the active site theme. Deactivate this plugin anytime to restore Eduma-only behavior.
 * Version: 1.0.0
 * Author: SucceedLearn
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * SAFE LIVE USAGE:
 * 1. Keep Eduma as the active theme (Appearance → Themes).
 * 2. Upload akaza-adventure into wp-content/themes/ but do NOT activate it.
 * 3. Upload/activate this plugin.
 * 4. Create/publish only the two landing pages and assign the templates below.
 * 5. If anything looks wrong: deactivate this plugin. The rest of the site is untouched.
 *
 * @package SucceedLearn\LandingBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Allowed front-end URL slugs that may switch to akaza-adventure.
 * Add/remove only these landing pages. Nothing else is affected.
 *
 * @return string[]
 */
function sl_landing_bridge_allowed_slugs() {
	return array(
		'cybersecurity-awareness',
		'infosec-cybersecurity-awareness-month-2026',
		'infosec-cybersecurity-awareness',
		'infosec-2026-cyber',
		'infosec-2026',
	);
}

/**
 * Page templates exposed in the editor (Eduma stays active).
 *
 * @return array<string,string> Relative template path => label.
 */
function sl_landing_bridge_templates() {
	return array(
		'page-templates/cybersecurity-awareness.php' => 'SucceedLearn: Cybersecurity Awareness',
		'page-templates/infosec-2026-cyber.php'      => 'SucceedLearn: Infosec 2026 Cyber',
	);
}

/**
 * Absolute path to the dormant akaza-adventure theme.
 *
 * @return string
 */
function sl_landing_bridge_akaza_dir() {
	return trailingslashit( get_theme_root() ) . 'akaza-adventure';
}

/**
 * Whether akaza-adventure exists on disk (not necessarily active).
 *
 * @return bool
 */
function sl_landing_bridge_akaza_exists() {
	$dir = sl_landing_bridge_akaza_dir();
	return is_dir( $dir ) && is_readable( $dir . '/style.css' ) && is_readable( $dir . '/functions.php' );
}

/**
 * Detect if the current front request is one of the allowlisted landings.
 * Uses the request path only (safe before main query).
 *
 * @return bool
 */
function sl_landing_bridge_is_landing_request() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return false;
	}

	if ( empty( $_SERVER['REQUEST_URI'] ) ) {
		return false;
	}

	$path = (string) wp_parse_url( (string) $_SERVER['REQUEST_URI'], PHP_URL_PATH );
	$path = trim( $path, '/' );

	// Strip site subdirectory if WP is in a subfolder.
	$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	$home_path = trim( $home_path, '/' );
	if ( '' !== $home_path && 0 === strpos( $path, $home_path . '/' ) ) {
		$path = substr( $path, strlen( $home_path ) + 1 );
	} elseif ( $path === $home_path ) {
		$path = '';
	}

	$path = trim( (string) $path, '/' );
	if ( '' === $path ) {
		return false;
	}

	// AMP endpoints: /page/amp/ or /page/?amp=1 still match the page slug.
	$parts = explode( '/', $path );
	$slug  = $parts[0];

	// Common AMP-for-WP path style: cybersecurity-awareness/amp
	if ( isset( $parts[1] ) && 'amp' === $parts[1] ) {
		$slug = $parts[0];
	}

	return in_array( $slug, sl_landing_bridge_allowed_slugs(), true );
}

/**
 * Show templates in Page Attributes while Eduma is active.
 *
 * @param array $templates Templates.
 * @return array
 */
function sl_landing_bridge_register_templates( $templates ) {
	if ( ! sl_landing_bridge_akaza_exists() ) {
		return $templates;
	}
	return array_merge( (array) $templates, sl_landing_bridge_templates() );
}
add_filter( 'theme_page_templates', 'sl_landing_bridge_register_templates' );

/**
 * For these landings only, load akaza-adventure for the current request.
 * Eduma remains the saved/active theme in wp-admin.
 *
 * @param string $theme Theme stylesheet/template slug.
 * @return string
 */
function sl_landing_bridge_maybe_switch_theme( $theme ) {
	if ( ! sl_landing_bridge_akaza_exists() ) {
		return $theme;
	}
	if ( ! sl_landing_bridge_is_landing_request() ) {
		return $theme;
	}
	return 'akaza-adventure';
}
add_filter( 'template', 'sl_landing_bridge_maybe_switch_theme', 1 );
add_filter( 'stylesheet', 'sl_landing_bridge_maybe_switch_theme', 1 );

/**
 * Admin notice if theme folder is missing.
 */
function sl_landing_bridge_admin_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( sl_landing_bridge_akaza_exists() ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>';
	echo esc_html__( 'SucceedLearn Landing Bridge: upload the akaza-adventure theme folder to wp-content/themes/ (do not activate it). Until then, Cyber/Infosec templates will not load.', 'succeedlearn-landing-bridge' );
	echo '</p></div>';
}
add_action( 'admin_notices', 'sl_landing_bridge_admin_notice' );

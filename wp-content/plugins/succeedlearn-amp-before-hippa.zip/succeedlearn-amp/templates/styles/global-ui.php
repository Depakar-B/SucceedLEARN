<?php
/**
 * Shared AMP UI tokens — gradient primary CTAs, accent color, chrome.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
:root{
	--sl-heading-accent:#135db7;
	--sl-btn-primary-fill:linear-gradient(180deg,#4d7ed6 0%,#1a3b87 100%);
	--sl-btn-primary-shadow:rgba(26,59,135,.22);
	--sl-chrome-fill:var(--sl-btn-primary-fill);
}
.sl-btn--primary,
a.sl-btn--primary,
button.sl-btn--primary,
.sl-amp-btn,
.sl-courses-card__cta,
a.sl-courses-card__cta,
.sl-courses-page .sl-courses-card__cta,
.sl-courses-page a.sl-courses-card__cta.sl-btn--primary,
.sl-about-page .sl-btn--primary,
.sl-contact-page .sl-btn--primary,
.sl-dd-page .sl-btn--primary,
.sl-sap-page .sl-btn--primary,
.sl-sap-page .sl-clients__cta .sl-btn,
.sl-sap-page .sl-clients__cta a,
.sl-gwct-page .sl-btn--primary{
	background:var(--sl-btn-primary-fill)!important;
	background-color:transparent!important;
	border:1px solid transparent!important;
	color:#fff!important;
	box-shadow:0 6px 16px var(--sl-btn-primary-shadow);
}
.scf-submit,
button.scf-submit{
	background:var(--sl-btn-primary-fill)!important;
	background-color:transparent!important;
	border:1px solid transparent!important;
	color:#fff!important;
	box-shadow:0 6px 16px var(--sl-btn-primary-shadow);
}
.scf-lightbox-button{
	background:var(--sl-btn-primary-fill)!important;
	background-color:transparent!important;
	border:1px solid transparent!important;
	color:#fff!important;
}

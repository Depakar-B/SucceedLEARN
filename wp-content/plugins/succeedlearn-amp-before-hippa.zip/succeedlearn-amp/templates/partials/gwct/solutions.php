<?php
/**
 * GWCT AMP — Workplace learning solutions section.
 *
 * Expected vars: $solutions
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-section" id="solutions">
	<div class="sl-wrap">
		<h2 class="sl-h2"><?php esc_html_e( 'Workplace Learning Solutions', 'succeedlearn-amp' ); ?></h2>
		<div class="sl-gwct-solutions">
			<?php foreach ( $solutions as $solution ) : ?>
				<article id="<?php echo esc_attr( $solution['id'] ); ?>" class="sl-gwct-solution">
					<h3><?php echo esc_html( $solution['title'] ); ?></h3>
					<?php if ( ! empty( $solution['subtitle'] ) ) : ?>
						<p class="sl-gwct-solution__subtitle"><?php echo esc_html( $solution['subtitle'] ); ?></p>
					<?php endif; ?>
					<?php if ( ! empty( $solution['intro'] ) ) : ?>
						<p><?php echo esc_html( $solution['intro'] ); ?></p>
					<?php endif; ?>
					<?php if ( ! empty( $solution['body'] ) ) : ?>
						<p><?php echo esc_html( $solution['body'] ); ?></p>
					<?php endif; ?>
					<?php if ( ! empty( $solution['body_extra'] ) ) : ?>
						<p><?php echo esc_html( $solution['body_extra'] ); ?></p>
					<?php endif; ?>
					<div class="sl-gwct-solution__meta">
						<?php if ( ! empty( $solution['courses'] ) ) : ?>
							<div class="sl-gwct-solution__block">
								<h4><?php esc_html_e( 'Included Learning Courses', 'succeedlearn-amp' ); ?></h4>
								<ul>
									<?php foreach ( $solution['courses'] as $course ) : ?>
										<?php
										$course_label = is_array( $course ) ? ( $course['label'] ?? '' ) : $course;
										$course_flag  = ( is_array( $course ) && ! empty( $course['flag'] ) ) ? sanitize_key( $course['flag'] ) : '';
										?>
										<li class="<?php echo $course_flag ? 'sl-gwct-course--flag' : ''; ?>">
											<?php if ( $course_flag ) : ?>
												<span class="sl-gwct-course-flag" aria-hidden="true">
													<amp-img
														src="<?php echo esc_url( 'https://flagcdn.com/w40/' . $course_flag . '.png' ); ?>"
														srcset="<?php echo esc_url( 'https://flagcdn.com/w80/' . $course_flag . '.png' ); ?> 2x"
														width="24"
														height="18"
														alt=""
														layout="fixed"
													></amp-img>
												</span>
											<?php endif; ?>
											<?php echo esc_html( $course_label ); ?>
										</li>
									<?php endforeach; ?>
								</ul>
							</div>
						<?php endif; ?>
						<?php if ( ! empty( $solution['outcomes'] ) ) : ?>
							<div class="sl-gwct-solution__block">
								<h4><?php esc_html_e( 'Key Learning Outcomes', 'succeedlearn-amp' ); ?></h4>
								<ul>
									<?php foreach ( $solution['outcomes'] as $outcome ) : ?>
										<li><?php echo esc_html( $outcome ); ?></li>
									<?php endforeach; ?>
								</ul>
							</div>
						<?php endif; ?>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

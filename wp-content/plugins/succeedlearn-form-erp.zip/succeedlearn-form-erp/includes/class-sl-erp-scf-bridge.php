<?php
/**
 * Bridge Succeed Common Contact Form submissions to ERPNext.
 *
 * All common contact form submissions are forwarded to ERP with utm_source
 * resolved from the page where the form was submitted (source_tag).
 *
 * @package SucceedLEARN_Form_ERP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hooks scf_after_submission into succeedlearn_form_send_to_erp().
 */
class SL_ERP_SCF_Bridge {

	/**
	 * Map SCF source_tag values to ERP form_key identifiers.
	 *
	 * @var array<string, string>
	 */
	private static $form_key_map = array(
		'SucceedLEARN HomePage'  => 'scf_homepage',
		'SucceedLEARN InfoSEC'   => 'scf_infosec',
		'SucceedLEARN Blog'      => 'scf_blog',
		'SucceedLEARN ContactUs' => 'scf_contact',
		'SucceedLEARN Others'    => 'scf_others',
	);

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'scf_after_submission', array( __CLASS__, 'handle_submission' ), 10, 2 );
	}

	/**
	 * Forward contact form data to ERP with page-based utm_source.
	 *
	 * @param array       $data     Submission data.
	 * @param array|false $response ERP HTTP response (unused).
	 */
	public static function handle_submission( $data, $response ) {
		if ( ! function_exists( 'succeedlearn_form_send_to_erp' ) ) {
			return;
		}

		$form_variant = 'default';
		if ( ! empty( $data['form_variant'] ) ) {
			$form_variant = sanitize_text_field( (string) $data['form_variant'] );
		} elseif ( isset( $_POST['scf_form_variant'] ) ) {
			$form_variant = sanitize_text_field( wp_unslash( (string) $_POST['scf_form_variant'] ) );
		}

		$source_tag = '';
		if ( ! empty( $data['source_tag'] ) ) {
			$source_tag = sanitize_text_field( (string) $data['source_tag'] );
		}

		// Course demo form always maps to RequestDemo in the mapper.
		if ( 'course' === $form_variant ) {
			$form_key = 'scf_course';
		} elseif ( isset( self::$form_key_map[ $source_tag ] ) ) {
			$form_key = self::$form_key_map[ $source_tag ];
		} else {
			$form_key = 'scf_contact';
		}

		$submission                 = $data;
		$submission['form_variant'] = $form_variant;
		if ( '' !== $source_tag ) {
			$submission['source_tag'] = $source_tag;
		}

		succeedlearn_form_send_to_erp(
			$submission,
			array(
				'form_key'     => $form_key,
				'form_variant' => $form_variant,
			)
		);
	}
}

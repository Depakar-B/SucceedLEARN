<?php
/**
 * Security Awareness AMP — Hero section.
 *
 * Expected vars: $page_title
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$hero_title = ! empty( $page_title )
	? $page_title
	: __( 'SucceedLEARN Security Behaviour & Culture Suite', 'succeedlearn-amp' );
?>
<section class="sl-sa-hero" aria-labelledby="sl-sa-hero-title">
	<div class="sl-wrap">
		<div class="sl-sa-hero__top">
			<?php
			if ( function_exists( 'succeedlearn_amp_render_hero_breadcrumbs' ) ) {
				succeedlearn_amp_render_hero_breadcrumbs( $hero_title );
			}
			?>
			<span class="sl-home-sub-heading sl-sa-hero__eyebrow"><?php esc_html_e( 'Security Awareness & Human Risk', 'succeedlearn-amp' ); ?></span>
			<h1 id="sl-sa-hero-title">
				<?php
				echo wp_kses(
					__( 'SucceedLEARN Security Behaviour & <span>Culture Suite</span>', 'succeedlearn-amp' ),
					array( 'span' => array() )
				);
				?>
			</h1>
		</div>
		<div class="sl-sa-hero__grid">
			<div class="sl-sa-hero__content">
				<h2 class="sl-sa-hero__subheading"><?php esc_html_e( 'Build a Security-Aware Workforce. Strengthen Human Risk Resilience.', 'succeedlearn-amp' ); ?></h2>
				<p class="sl-sa-hero__description"><?php esc_html_e( 'The SucceedLEARN Security Behaviour & Culture Suite combines awareness training, phishing simulations, microlearning, gamification, visual nudges, analytics, and seamless integrations into one unified platform that helps organisations reduce human cyber risk while meeting global compliance requirements.', 'succeedlearn-amp' ); ?></p>
				<div class="sl-sa-hero__actions">
					<button type="button" class="sl-btn sl-btn--primary" <?php echo succeedlearn_amp_scroll_tap_attr( 'contact' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php esc_html_e( 'Request a Demo', 'succeedlearn-amp' ); ?></button>
					<button type="button" class="sl-btn sl-btn--secondary" <?php echo succeedlearn_amp_scroll_tap_attr( 'security-awareness-suite' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php esc_html_e( 'Explore the Suite', 'succeedlearn-amp' ); ?></button>
				</div>
			</div>

			<div class="sl-sa-hero__visual">
				<div
					class="sl-sa-hero__image-placeholder"
					role="img"
					aria-label="<?php esc_attr_e( 'Security Behaviour & Culture Suite hero image placeholder', 'succeedlearn-amp' ); ?>"
				>
					<span class="sl-sa-hero__image-size"><?php esc_html_e( 'Image: 720 × 800 px', 'succeedlearn-amp' ); ?></span>
					<span class="sl-sa-hero__image-note"><?php esc_html_e( 'Security Behaviour Hero Image', 'succeedlearn-amp' ); ?></span>
					<small class="sl-sa-hero__image-hint"><?php esc_html_e( 'Displays in the hero visual column', 'succeedlearn-amp' ); ?></small>
				</div>
			</div>
		</div>
	</div>
</section>

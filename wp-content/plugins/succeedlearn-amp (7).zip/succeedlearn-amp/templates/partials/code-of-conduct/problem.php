<?php
/**
 * Code of Conduct AMP — Problem section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

<?php
/**
 * Code of Conduct AMP — Learning section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

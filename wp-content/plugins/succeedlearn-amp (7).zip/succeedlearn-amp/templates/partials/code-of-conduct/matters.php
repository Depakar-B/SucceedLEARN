<?php
/**
 * Code of Conduct AMP — Matters section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

<?php
/**
 * Code of Conduct AMP — Decision section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

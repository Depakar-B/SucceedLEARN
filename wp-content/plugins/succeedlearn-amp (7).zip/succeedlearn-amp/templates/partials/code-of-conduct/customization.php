<?php
/**
 * Code of Conduct AMP — Customization section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

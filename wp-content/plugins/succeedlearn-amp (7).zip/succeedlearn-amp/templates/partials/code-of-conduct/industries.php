<?php
/**
 * Code of Conduct AMP — Industries section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

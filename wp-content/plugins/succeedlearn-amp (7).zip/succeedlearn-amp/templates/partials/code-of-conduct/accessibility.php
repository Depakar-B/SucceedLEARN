<?php
/**
 * Code of Conduct AMP — Accessibility section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

<?php
/**
 * Code of Conduct AMP — Deployment section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

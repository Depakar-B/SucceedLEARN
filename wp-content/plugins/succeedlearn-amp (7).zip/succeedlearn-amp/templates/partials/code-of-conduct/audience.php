<?php
/**
 * Code of Conduct AMP — Audience section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

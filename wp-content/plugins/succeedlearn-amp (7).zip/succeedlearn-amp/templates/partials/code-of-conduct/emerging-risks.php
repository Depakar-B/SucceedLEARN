<?php
/**
 * Code of Conduct AMP — Emerging Risks section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

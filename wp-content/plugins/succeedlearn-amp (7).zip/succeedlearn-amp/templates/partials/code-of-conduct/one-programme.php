<?php
/**
 * Code of Conduct AMP — One Programme section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

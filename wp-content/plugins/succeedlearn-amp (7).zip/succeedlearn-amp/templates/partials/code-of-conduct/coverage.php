<?php
/**
 * Code of Conduct AMP — Coverage section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

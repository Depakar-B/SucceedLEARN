<?php
/**
 * Code of Conduct AMP — Reporting section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

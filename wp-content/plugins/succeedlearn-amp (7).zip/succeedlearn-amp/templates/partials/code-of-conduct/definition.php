<?php
/**
 * Code of Conduct AMP — Definition section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

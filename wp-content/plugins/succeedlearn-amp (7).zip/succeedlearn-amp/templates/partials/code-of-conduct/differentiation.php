<?php
/**
 * Code of Conduct AMP — Differentiation section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

<?php
/**
 * Code of Conduct AMP — Stats section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

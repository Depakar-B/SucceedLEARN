<?php
/**
 * Code of Conduct AMP — Customer Story section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

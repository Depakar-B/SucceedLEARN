<?php
/**
 * Code of Conduct — AMP data helpers.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include a Code of Conduct section partial.
 *
 * @param string $name Partial basename without .php.
 */
function succeedlearn_amp_coc_partial( $name ) {
	$path = SUCCEEDLEARN_AMP_TEMPLATES_DIR . 'partials/code-of-conduct/' . sanitize_file_name( (string) $name ) . '.php';
	if ( is_readable( $path ) ) {
		include $path;
	}
}

/**
 * @return string
 */
function succeedlearn_amp_get_coc_canonical_url() {
	$canonical = home_url( '/code-of-conduct/' );
	foreach ( array( 'code-of-conduct' ) as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			$link = get_permalink( $page );
			if ( $link ) {
				return $link;
			}
		}
	}
	return $canonical;
}

/**
 * @return string
 */
function succeedlearn_amp_get_coc_page_title() {
	return __( 'Code of Conduct', 'succeedlearn-amp' );
}

/**
 * @return string
 */
function succeedlearn_amp_get_coc_meta_description() {
	return '';
}

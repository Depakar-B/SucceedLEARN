<?php
/**
 * Plugin Name: SucceedLearn Landing Bridge (Cyber + Infosec + SAP)
 * Description: Safely serves Cybersecurity Awareness, Infosec 2026, and Security Awareness (SAP) pages from akaza-adventure while Eduma stays the active site theme. Deactivate this plugin anytime to restore Eduma-only behavior.
 * Version: 1.0.8
 * Author: SucceedLearn
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * SAFE LIVE USAGE:
 * 1. Keep Eduma as the active theme (Appearance → Themes).
 * 2. Upload akaza-adventure into wp-content/themes/ but do NOT activate it.
 * 3. Upload/activate this plugin.
 * 4. Create/publish the allowlisted landing pages and assign the templates below.
 * 5. If anything looks wrong: deactivate this plugin. The rest of the site is untouched.
 *
 * @package SucceedLearn\LandingBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Allowed front-end URL slugs that may switch to akaza-adventure.
 * Add/remove only these landing pages. Nothing else is affected.
 *
 * @return string[]
 */
function sl_landing_bridge_allowed_slugs() {
	return array(
		// Cyber (US October campaign).
		'us-cyber-aware-october',
		// Cyber (UK October campaign).
		'uk-cyber-aware-october',
		// Infosec (live SEO URL).
		'infosec-cybersecurity-awareness',
		// Infosec aliases (older / retired links; AMP redirects missing ones to SEO URL).
		'cybersecurity-awareness',
		'infosec-cybersecurity-awareness-month-2026',
		'infosec-2026-cyber',
		'infosec-2026',
		// Security Awareness / SAP (live SEO URL).
		'security-awareness',
		// SAP staging / alternate slug.
		'security-awareness-and-phishing',
	);
}

/**
 * Page templates exposed in the editor (Eduma stays active).
 *
 * @return array<string,string> Relative template path => label.
 */
function sl_landing_bridge_templates() {
	return array(
		'page-templates/cybersecurity-awareness.php'         => 'SucceedLearn: Cybersecurity Awareness',
		'page-templates/cybersecurity-awareness-uk.php'      => 'SucceedLearn: Cybersecurity Awareness (UK)',
		'page-templates/infosec-2026-cyber.php'              => 'SucceedLearn: Infosec 2026 Cyber',
		'page-templates/security-awareness-and-phishing.php' => 'SucceedLearn: Security Awareness and Phishing',
	);
}

/**
 * Absolute path to the dormant akaza-adventure theme.
 *
 * @return string
 */
function sl_landing_bridge_akaza_dir() {
	return trailingslashit( get_theme_root() ) . 'akaza-adventure';
}

/**
 * Whether akaza-adventure exists on disk (not necessarily active).
 *
 * @return bool
 */
function sl_landing_bridge_akaza_exists() {
	$dir = sl_landing_bridge_akaza_dir();
	return is_dir( $dir ) && is_readable( $dir . '/style.css' ) && is_readable( $dir . '/functions.php' );
}

/**
 * Detect if the current front request is one of the allowlisted landings.
 * Uses the request path only (safe before main query).
 *
 * @return bool
 */
function sl_landing_bridge_is_landing_request() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return false;
	}

	if ( empty( $_SERVER['REQUEST_URI'] ) ) {
		return false;
	}

	$path = (string) wp_parse_url( (string) $_SERVER['REQUEST_URI'], PHP_URL_PATH );
	$path = trim( $path, '/' );

	// Strip site subdirectory if WP is in a subfolder.
	$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	$home_path = trim( $home_path, '/' );
	if ( '' !== $home_path && 0 === strpos( $path, $home_path . '/' ) ) {
		$path = substr( $path, strlen( $home_path ) + 1 );
	} elseif ( $path === $home_path ) {
		$path = '';
	}

	$path = trim( (string) $path, '/' );
	if ( '' === $path ) {
		return false;
	}

	// AMP endpoints: /page/amp/ or /page/?amp=1 still match the page slug.
	$parts = explode( '/', $path );
	$slug  = $parts[0];

	// Common AMP-for-WP path style: us-cyber-aware-october/amp
	if ( isset( $parts[1] ) && 'amp' === $parts[1] ) {
		$slug = $parts[0];
	}

	return in_array( $slug, sl_landing_bridge_allowed_slugs(), true );
}

/**
 * Current request path slug (first segment), or empty string.
 *
 * @return string
 */
function sl_landing_bridge_request_slug() {
	if ( empty( $_SERVER['REQUEST_URI'] ) ) {
		return '';
	}

	$path = (string) wp_parse_url( (string) $_SERVER['REQUEST_URI'], PHP_URL_PATH );
	$path = trim( $path, '/' );

	$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	$home_path = trim( $home_path, '/' );
	if ( '' !== $home_path && 0 === strpos( $path, $home_path . '/' ) ) {
		$path = substr( $path, strlen( $home_path ) + 1 );
	} elseif ( $path === $home_path ) {
		$path = '';
	}

	$path = trim( (string) $path, '/' );
	if ( '' === $path ) {
		return '';
	}

	$parts = explode( '/', $path );
	return (string) $parts[0];
}

/**
 * Page slugs that use the secondary global header (custom header, Eduma footer).
 *
 * Keep in sync with akaza_secondary_header_slugs() in the theme.
 *
 * @return string[]
 */
function sl_landing_bridge_secondary_header_slugs() {
	$slugs = array(
		'security-awareness',
		'security-awareness-and-phishing',
	);

	if ( function_exists( 'akaza_secondary_header_slugs' ) ) {
		$slugs = akaza_secondary_header_slugs();
	}

	/**
	 * Filter secondary-header slugs for the landing bridge.
	 *
	 * @param string[] $slugs Slugs.
	 */
	return array_values( array_unique( array_map( 'strval', (array) apply_filters( 'sl_landing_bridge_secondary_header_slugs', $slugs ) ) ) );
}

/**
 * Whether this request should use the secondary global header.
 *
 * @return bool
 */
function sl_landing_bridge_uses_secondary_header() {
	if ( function_exists( 'akaza_uses_secondary_header' ) ) {
		return (bool) akaza_uses_secondary_header();
	}

	return in_array( sl_landing_bridge_request_slug(), sl_landing_bridge_secondary_header_slugs(), true );
}

/**
 * SAP landing helper (subset of secondary-header pages).
 *
 * @return bool
 */
function sl_landing_bridge_is_sap_request() {
	return in_array(
		sl_landing_bridge_request_slug(),
		array(
			'security-awareness',
			'security-awareness-and-phishing',
		),
		true
	);
}

/**
 * Show templates in Page Attributes while Eduma is active.
 *
 * @param array $templates Templates.
 * @return array
 */
function sl_landing_bridge_register_templates( $templates ) {
	if ( ! sl_landing_bridge_akaza_exists() ) {
		return $templates;
	}
	return array_merge( (array) $templates, sl_landing_bridge_templates() );
}
add_filter( 'theme_page_templates', 'sl_landing_bridge_register_templates' );

/**
 * For these landings only, load akaza-adventure for the current request.
 * Eduma remains the saved/active theme in wp-admin.
 *
 * @param string $theme Theme stylesheet/template slug.
 * @return string
 */
function sl_landing_bridge_maybe_switch_theme( $theme ) {
	if ( ! sl_landing_bridge_akaza_exists() ) {
		return $theme;
	}
	if ( ! sl_landing_bridge_is_landing_request() ) {
		return $theme;
	}
	return 'akaza-adventure';
}
add_filter( 'template', 'sl_landing_bridge_maybe_switch_theme', 1 );
add_filter( 'stylesheet', 'sl_landing_bridge_maybe_switch_theme', 1 );

/**
 * Strip Elementor kit body classes on bridged landings so theme typography wins.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function sl_landing_bridge_strip_elementor_body_classes( $classes ) {
	if ( ! sl_landing_bridge_is_landing_request() ) {
		return $classes;
	}

	// Secondary-header landings keep Eduma footer; leave Elementor body classes alone.
	if ( sl_landing_bridge_uses_secondary_header() ) {
		return $classes;
	}

	return array_values(
		array_filter(
			(array) $classes,
			static function ( $class ) {
				return 0 !== strpos( (string) $class, 'elementor-' );
			}
		)
	);
}
add_filter( 'body_class', 'sl_landing_bridge_strip_elementor_body_classes', 9999 );

/**
 * Drop Elementor kit / frontend CSS on bridged landings.
 * Prevents rules like `.elementor-kit-XXXX h2` from overriding SucceedLearn h1–h4.
 */
function sl_landing_bridge_dequeue_elementor_assets() {
	if ( ! sl_landing_bridge_is_landing_request() ) {
		return;
	}

	// Secondary-header landings need Elementor CSS for the live Eduma footer chrome.
	if ( sl_landing_bridge_uses_secondary_header() ) {
		return;
	}

	$kit_id = (int) get_option( 'elementor_active_kit' );

	$style_handles = array(
		'elementor-frontend',
		'elementor-frontend-css',
		'elementor-frontend-legacy',
		'elementor-icons',
		'elementor-common',
		'elementor-wp-admin-bar',
		'elementor-global',
		'font-awesome',
		'e-animations',
		'e-swiper',
		'swiper',
	);

	if ( $kit_id ) {
		$style_handles[] = 'elementor-post-' . $kit_id;
	}

	foreach ( $style_handles as $handle ) {
		wp_dequeue_style( $handle );
		wp_deregister_style( $handle );
	}

	global $wp_styles;
	if ( $wp_styles instanceof WP_Styles ) {
		foreach ( array_keys( $wp_styles->registered ) as $handle ) {
			if (
				0 === strpos( $handle, 'elementor-post-' )
				|| 0 === strpos( $handle, 'elementor-gf-' )
				|| 0 === strpos( $handle, 'elementor-' )
			) {
				wp_dequeue_style( $handle );
				wp_deregister_style( $handle );
			}
		}
	}

	$script_handles = array(
		'elementor-frontend',
		'elementor-frontend-modules',
		'elementor-webpack-runtime',
		'elementor-common',
		'elementor-dialog',
		'swiper',
	);

	foreach ( $script_handles as $handle ) {
		wp_dequeue_script( $handle );
		wp_deregister_script( $handle );
	}
}
add_action( 'wp_enqueue_scripts', 'sl_landing_bridge_dequeue_elementor_assets', 9999 );

/**
 * Stop Elementor Theme Builder from swapping header/footer on bridged landings.
 * Secondary-header pages: custom akaza header, keep Eduma footer.
 */
function sl_landing_bridge_disable_builder_header_footer() {
	if ( ! sl_landing_bridge_is_landing_request() ) {
		return;
	}

	if ( sl_landing_bridge_uses_secondary_header() ) {
		if ( class_exists( '\Thim_EL_Kit\Modules\HeaderFooter\FrontEnd' ) ) {
			$fe = \Thim_EL_Kit\Modules\HeaderFooter\FrontEnd::instance();
			remove_action( 'get_header', array( $fe, 'override_header' ) );
		}

		if ( class_exists( '\ElementorPro\Plugin' ) && function_exists( 'elementor_theme_do_location' ) ) {
			add_filter( 'elementor/theme/get_location_templates/header', '__return_empty_array', 99 );
		}

		return;
	}

	if ( class_exists( '\Thim_EL_Kit\Modules\HeaderFooter\FrontEnd' ) ) {
		$fe = \Thim_EL_Kit\Modules\HeaderFooter\FrontEnd::instance();
		remove_action( 'get_header', array( $fe, 'override_header' ) );
		remove_action( 'get_footer', array( $fe, 'override_footer' ) );
	}

	if ( class_exists( '\ElementorPro\Plugin' ) && function_exists( 'elementor_theme_do_location' ) ) {
		add_filter( 'elementor/theme/get_location_templates/header', '__return_empty_array', 99 );
		add_filter( 'elementor/theme/get_location_templates/footer', '__return_empty_array', 99 );
	}
}
add_action( 'template_redirect', 'sl_landing_bridge_disable_builder_header_footer', 99 );

/**
 * Admin notice if theme folder is missing.
 */
function sl_landing_bridge_admin_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( sl_landing_bridge_akaza_exists() ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>';
	echo esc_html__( 'SucceedLearn Landing Bridge: upload the akaza-adventure theme folder to wp-content/themes/ (do not activate it). Until then, Cyber/Infosec/SAP templates will not load.', 'succeedlearn-landing-bridge' );
	echo '</p></div>';
}
add_action( 'admin_notices', 'sl_landing_bridge_admin_notice' );

﻿<?php
/**
 * Political Donations Training for PE/VC course marketing assets.
 *
 * CSS lives in assets/css/courses/political-donations-pe-vc/
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue course foundation + per-section styles.
 */
function akaza_enqueue_political_donations_assets() {
	akaza_enqueue_course_marketing_styles(
		'',
		array(
			'shared_sections' => false,
		)
	);

	$folder = 'courses/political-donations-pe-vc';
	$deps   = array( 'akaza-course-global' );

	$sections = array(
		'sl-political-donations-hero',
		'sl-political-donations-context',
		'sl-political-donations-overview',
		'sl-political-donations-regulatory-context',
		'sl-political-donations-learning-outcomes',
		'sl-political-donations-activity',
		'sl-political-donations-inside',
		'sl-political-donations-practical',
	);

	foreach ( $sections as $section ) {
		akaza_enqueue_theme_style(
			'akaza-' . $section,
			"{$folder}/{$section}.css",
			$deps
		);
	}
}

<?php
/**
 * Global Workplace Compliance Training for Employees — More Than Compliance section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$behaviour_modules = array(
	array(
		'icon'   => 'bi-people-fill',
		'title'  => __( 'Respectful Workplace Culture', 'akaza-adventure' ),
		'meta'   => __( '92% completed', 'akaza-adventure' ),
		'status' => 'bi-check-circle-fill',
		'done'   => true,
	),
	array(
		'icon'   => 'bi-shield-check',
		'title'  => __( 'Ethics & Code of Conduct', 'akaza-adventure' ),
		'meta'   => __( '88% completed', 'akaza-adventure' ),
		'status' => 'bi-check-circle-fill',
		'done'   => true,
	),
	array(
		'icon'   => 'bi-chat-square-text',
		'title'  => __( 'Inclusive Communication', 'akaza-adventure' ),
		'meta'   => __( 'In progress', 'akaza-adventure' ),
		'status' => 'bi-hourglass-split',
		'done'   => false,
	),
	array(
		'icon'   => 'bi-graph-up-arrow',
		'title'  => __( 'Applied Behaviour Change', 'akaza-adventure' ),
		'meta'   => __( 'Scenario-based', 'akaza-adventure' ),
		'status' => 'bi-check-circle-fill',
		'done'   => true,
	),
);
?>
<section class="sl-global-behaviour-section">

	<div class="container">

		<div class="row align-items-center gy-5">

			<div class="col-lg-5">

				<div class="sl-global-behaviour-visual">

					<div class="sl-global-behaviour-visual-card">

						<div class="sl-global-behaviour-visual-top">
							<span class="sl-global-behaviour-dot"></span>
							<span class="sl-global-behaviour-dot"></span>
							<span class="sl-global-behaviour-dot"></span>
							<span class="sl-global-behaviour-visual-top-title">
								<?php esc_html_e( 'Learning Dashboard', 'akaza-adventure' ); ?>
							</span>
						</div>

						<div class="sl-global-behaviour-visual-body">

							<div class="sl-global-behaviour-dashboard-head">
								<div class="sl-global-behaviour-visual-icon" aria-hidden="true">
									<i class="bi bi-mortarboard-fill"></i>
								</div>

								<div>
									<p class="sl-global-behaviour-dashboard-label">
										<?php esc_html_e( 'Workplace Compliance', 'akaza-adventure' ); ?>
									</p>
									<h3 class="sl-global-behaviour-dashboard-title">
										<?php esc_html_e( 'Employee Learning Progress', 'akaza-adventure' ); ?>
									</h3>
								</div>
							</div>

							<div class="sl-global-behaviour-progress">
								<div class="sl-global-behaviour-progress__meta">
									<span><?php esc_html_e( 'Overall completion', 'akaza-adventure' ); ?></span>
									<strong>87%</strong>
								</div>
								<div class="sl-global-behaviour-progress__bar" role="presentation">
									<span style="width: 87%;"></span>
								</div>
								<p class="sl-global-behaviour-progress__note">
									<?php esc_html_e( '1,248 employees trained across 6 global modules', 'akaza-adventure' ); ?>
								</p>
							</div>

							<div class="sl-global-behaviour-visual-items">

								<?php foreach ( $behaviour_modules as $module ) : ?>
									<div class="sl-global-behaviour-visual-item<?php echo empty( $module['done'] ) ? ' is-pending' : ''; ?>">
										<span class="sl-global-behaviour-visual-item__icon" aria-hidden="true">
											<i class="bi <?php echo esc_attr( $module['icon'] ); ?>"></i>
										</span>
										<div class="sl-global-behaviour-visual-item__content">
											<strong><?php echo esc_html( $module['title'] ); ?></strong>
											<small><?php echo esc_html( $module['meta'] ); ?></small>
										</div>
										<span class="sl-global-behaviour-visual-item__status" aria-hidden="true">
											<i class="bi <?php echo esc_attr( $module['status'] ); ?>"></i>
										</span>
									</div>
								<?php endforeach; ?>

							</div>

						</div>

					</div>

					<div class="sl-global-behaviour-floating-card">

						<span class="sl-global-behaviour-floating-icon" aria-hidden="true">
							<i class="bi bi-lightning-charge-fill"></i>
						</span>

						<div>
							<strong><?php esc_html_e( 'Learning', 'akaza-adventure' ); ?></strong>
							<small><?php esc_html_e( 'Behaviour Change', 'akaza-adventure' ); ?></small>
						</div>

					</div>

				</div>

			</div>

			<div class="col-lg-7">

				<div class="sl-global-behaviour-content">

					<h2 class="sl-global-behaviour-title">
						<?php esc_html_e( 'More Than Compliance. Learning That Changes Workplace Behaviour', 'akaza-adventure' ); ?>
					</h2>

					<ul class="sl-global-behaviour-points">

						<li class="sl-global-behaviour-point">
							<span class="sl-global-behaviour-point__icon" aria-hidden="true">
								<i class="bi bi-journal-check"></i>
							</span>
							<p class="sl-global-behaviour-point__text">
								<?php esc_html_e( 'Policies establish expectations.', 'akaza-adventure' ); ?>
							</p>
						</li>

						<li class="sl-global-behaviour-point">
							<span class="sl-global-behaviour-point__icon" aria-hidden="true">
								<i class="bi bi-people-fill"></i>
							</span>
							<p class="sl-global-behaviour-point__text">
								<?php esc_html_e( 'People shape workplace culture.', 'akaza-adventure' ); ?>
							</p>
						</li>

					</ul>

					<p class="sl-global-behaviour-description">
						<?php esc_html_e( 'Effective workplace learning goes beyond checking compliance boxes. It empowers employees to make better decisions, build stronger relationships, and contribute to workplaces where everyone feels respected, valued, and able to succeed.', 'akaza-adventure' ); ?>
					</p>

					<p class="sl-global-behaviour-description">
						<?php esc_html_e( 'SucceedLEARN combines storytelling, realistic workplace scenarios, interactive decision-making, and globally relevant content to help learners confidently apply what they’ve learned in everyday workplace situations.', 'akaza-adventure' ); ?>
					</p>

				</div>

			</div>

		</div>

	</div>

</section>

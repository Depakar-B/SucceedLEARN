<?php
/**
 * Security Awareness Training — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'eyebrow' => __( 'Security Awareness', 'akaza-adventure' ),
		'title'   => __( 'Security Awareness Training', 'akaza-adventure' ),
		'lead'    => __( 'Reduce human cyber risk with engaging security awareness training.', 'akaza-adventure' ),
	)
);

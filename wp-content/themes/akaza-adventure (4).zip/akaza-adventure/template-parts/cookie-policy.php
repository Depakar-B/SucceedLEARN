<?php
/**
 * Cookie Policy page content wrapper.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="slf-section">
	<?php get_template_part( 'template-parts/cookie-policy/hero' ); ?>
</main>

<?php
/**
 * DPDPA Compliance Training — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="dpdpa-hero">

    <div class="dpdpa-container">

        <div class="dpdpa-hero__wrapper">

            <!-- ==========================================
                 LEFT CONTENT
            =========================================== -->

            <div class="dpdpa-hero__content">

                <!-- Eyebrow -->

                <div class="dpdpa-hero__eyebrow">

                    <span class="dpdpa-hero__eyebrow-line"></span>

                    <span class="dpdpa-hero__eyebrow-text">

					Harassment crosses borders. Your training must understand them. 

                    </span>

                </div>

                <!-- Heading -->

                <h1 class="dpdpa-hero__title">

				Workplace Harassment Prevention Training Harassment crosses borders. Your training must understand them. </h1>

                <!-- Description -->

                <p class="dpdpa-hero__description">

				A comment made in a meeting. A message sent after working hours. An invitation linked to a career opportunity. Conduct at a conference, client site, business dinner or virtual workplace. </p>

                <p class="dpdpa-hero__description">

                Workplace sexual harassment does not always arrive as an obvious incident. It can develop through patterns of behaviour, misuse of authority, unwelcome communication or conduct that one person dismisses as harmless but another experiences very differently. </p>


                <p class="dpdpa-hero__description">

				The challenge becomes greater when an organisation operates across countries. The meaning of “workplace,” the responsibilities placed on managers, the available complaint channels and the required response procedures can change from one jurisdiction to another. </p>

                <p class="dpdpa-hero__description">

                A generic course may raise awareness. It may not tell employees what they need to know where they actually work. 
                </p>

                

                <!-- CTA -->

                <div class="dpdpa-hero__actions">

                    <a href="#contact"
                       class="dpdpa-btn dpdpa-btn--primary">

                        Request a Demo

                    </a>

                    <a href="#pricing"
                       class="dpdpa-btn dpdpa-btn--secondary">

                        Take the Readliness Scorecard

                    </a>

                </div>

               
				<div class="dpdpa-hero__trust">
					<p>
						No obligation. Most demos take 20 minutes.
						Or <a href="#check-pricing" onclick="event.preventDefault();document.getElementById('check-pricing').scrollIntoView({ behavior: 'smooth' });" style="cursor:pointer; text-decoration:underline; color:#F35A2B; font-weight:700;">see what it costs first</a>.
					</p>

</div>

            </div>

            <!-- ==========================================
                 RIGHT SIDE
            =========================================== -->

            <div class="dpdpa-hero__visual">

                <div class="dpdpa-illustration">

                    <div class="dpdpa-dashboard">
                        <div class="dpdpa-dashboard__header">
                            <div class="dpdpa-dashboard__dots">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                            <div class="dpdpa-dashboard__title">
                                Incident Preview
                            </div>
                        </div>

                        <div class="dpdpa-dashboard__body">
                            <div class="dpdpa-email-card">
                                <div class="dpdpa-email-card__header">
                                    <small>To</small>
                                    <div class="dpdpa-email-users">
                                        <span>Finance Team</span>
                                        <span>Operations</span>
                                        <span class="danger">+214 Recipients</span>
                                    </div>
                                </div>

                                <div class="dpdpa-email-subject">
                                    <strong>SucceedLearn Workplace Harassment Prevention Training helps organisations deliver learning aligned with the region, audience and responsibility involved. </strong>
                                </div>

                                <p class="dpdpa-email-message">
                                Part of the Global HR Compliance Suite, the category includes separate training options for: 
                                </p>

                                <div class="dpdpa-attachment">
                                    <div class="dpdpa-attachment__icon">XLS</div>
                                    <div class="dpdpa-attachment__content">
                                        <strong>International and globally distributed workforces </strong>
                                        <span>1,204 personal data records</span>
                                    </div>
                                </div>

                                <div class="dpdpa-attachment">
                                    <div class="dpdpa-attachment__icon">XLS</div>
                                    <div class="dpdpa-attachment__content">
                                        <strong>Employees working in the United States </strong>
                                        <span>1,204 personal data records</span>
                                    </div>
                                </div>



                                <div class="dpdpa-attachment">
                                    <div class="dpdpa-attachment__icon">XLS</div>
                                    <div class="dpdpa-attachment__content">
                                        <strong>Supervisors working in the United States </strong>
                                        <span>1,204 personal data records</span>
                                    </div>
                                </div>


                                <div class="dpdpa-attachment">
                                    <div class="dpdpa-attachment__icon">XLS</div>
                                    <div class="dpdpa-attachment__content">
                                        <strong>Workers in the United Kingdom</strong>
                                        <span>1,204 personal data records</span>
                                    </div>
                                </div>


                                <div class="dpdpa-attachment">
                                    <div class="dpdpa-attachment__icon">XLS</div>
                                    <div class="dpdpa-attachment__content">
                                        <strong>Employees in India </strong>
                                        <span>1,204 personal data records</span>
                                    </div>
                                </div>


                                
                                <div class="dpdpa-attachment">
                                    <div class="dpdpa-attachment__icon">XLS</div>
                                    <div class="dpdpa-attachment__content">
                                        <strong>Managers in India  </strong>
                                        <span>1,204 personal data records</span>
                                    </div>
                                </div>


                                
                                <div class="dpdpa-attachment">
                                    <div class="dpdpa-attachment__icon">XLS</div>
                                    <div class="dpdpa-attachment__content">
                                        <strong>Internal Committee members in India </strong>
                                        <span>1,204 personal data records</span>
                                    </div>
                                </div>


                                <p class="dpdpa-email-message">
                                Each is a distinct course designed for a specific audience or regional context. Organisations can select the individual training that applies to their workforce.  
                                </p>

                                <p class="dpdpa-email-message">
                                Train for the law, role and workplace your people actually operate in. 
                                </p>



                                <div class="dpdpa-email-footer">
                                    <button type="button">Explore Regional Training</button>
                                    <button type="button">Request a Demo</button>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

            </div>

        </div>

    </div>

</section>

<?php
/**
 * Security Awareness and Phishing page assets.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function akaza_enqueue_sap_assets() {
	$folder = 'security-awareness-and-phishing';
	$base    = array( 'akaza-main', 'akaza-fonts' );

	akaza_enqueue_theme_style( 'akaza-sl-sa-hero', "{$folder}/sl-sa-hero.css", $base );

	$annual_deps = $base;
	akaza_enqueue_theme_style( 'akaza-sl-sa-annual-training', "{$folder}/sl-sa-annual-training.css", $annual_deps );

	$sections = array(
		'sl-sa-platform'                 => array( 'sl-sa-platform.css', $annual_deps ),
		'sl-sa-definition'               => array( 'sl-sa-definition.css', $annual_deps ),
		'sl-sa-traditional'              => array( 'sl-sa-traditional.css', $annual_deps ),
		'sl-sa-comparison'                 => array( 'sl-sa-comparison.css', $annual_deps ),
		'sl-sa-compliance'                 => array( 'sl-sa-compliance.css', $annual_deps ),
		'sl-sa-security-behaviour-suite'   => array( 'sl-sa-security-behaviour-suite.css', $annual_deps ),
		'sl-sa-lifecycle'                  => array( 'sl-sa-lifecycle.css', $annual_deps ),
		'sl-sa-process'                    => array( 'sl-sa-process.css', array_merge( $annual_deps, array( 'akaza-sl-sa-annual-training' ) ) ),
		'sl-sa-leadership'                 => array( 'sl-sa-leadership.css', array_merge( $annual_deps, array( 'akaza-sl-sa-annual-training' ) ) ),
		'sl-sa-achieve'                    => array( 'sl-sa-achieve.css', array_merge( $annual_deps, array( 'akaza-sl-sa-annual-training' ) ) ),
		'sl-sa-behaviour'                  => array( 'sl-sa-behaviour.css', array_merge( $annual_deps, array( 'akaza-sl-sa-annual-training' ) ) ),
	);

	foreach ( $sections as $handle => $config ) {
		akaza_enqueue_theme_style( "akaza-{$handle}", "{$folder}/{$config[0]}", $config[1] );
	}

	akaza_enqueue_theme_script( 'akaza-sl-sa-dashboard-activity', "{$folder}/sl-sa-dashboard-activity.js" );
	akaza_enqueue_theme_script( 'akaza-sl-sa-security-behaviour-suite', "{$folder}/sl-sa-security-behaviour-suite.js" );

	akaza_enqueue_theme_style( 'akaza-contact-form', 'contact-from.css', $base );
	akaza_enqueue_theme_style(
		'akaza-sl-sa-contact',
		"{$folder}/sl-sa-contact.css",
		array_merge( $base, array( 'akaza-sl-sa-hero', 'akaza-contact-form' ) )
	);
}

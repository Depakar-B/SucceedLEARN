<?php
/**
 * SucceedLEARN — Cybersecurity Awareness Month Hero.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$csa_hero_image_url = function_exists( 'akaza_upload_url' )
	? akaza_upload_url( '2026/09/october-cybersecurity-awareness-hero.webp' )
	: 'https://succeedlearn.com/wp-content/uploads/2026/09/october-cybersecurity-awareness-hero.webp';

// Replace with the live Stripe Payment Link when available.
$csa_stripe_url = 'https://buy.stripe.com/PLACEHOLDER';
?>

<section class="sl-cyber-awareness-hero" aria-labelledby="sl-cyber-awareness-hero-title">
	<div class="container">

		<div class="sl-cyber-awareness-hero__grid">

			<div class="sl-cyber-awareness-hero__content">

				<span class="sl-home-sub-heading">
					<?php
					echo wp_kses(
						__( 'Special offer for October 2026', 'akaza-adventure' ),
						array( 'span' => array() )
					);
					?>
				</span>

				<h1 id="sl-cyber-awareness-hero-title">
					<?php
					echo wp_kses(
						__( 'Cybersecurity Awareness Month <span>October 2026</span>', 'akaza-adventure' ),
						array( 'span' => array() )
					);
					?>
				</h1>

				<h2 class="sl-cyber-awareness-hero__tagline">
					<?php esc_html_e( 'Train your people. Test their readiness. Strengthen your human firewall.', 'akaza-adventure' ); ?>
				</h2>

				<p class="sl-cyber-awareness-hero__description">
					<?php esc_html_e( 'Turn Cybersecurity Awareness Month into measurable action. Combine practical employee training, realistic phishing simulations, simple suspicious-email reporting and clear campaign results in one coordinated experience.', 'akaza-adventure' ); ?>
				</p>

				<div class="sl-cyber-awareness-hero__actions">

					<a
						class="sl-cyber-awareness-hero__cta sl-cyber-awareness-hero__cta--primary"
						href="<?php echo esc_url( $csa_stripe_url ); ?>"
						target="_blank"
						rel="noopener noreferrer"
					>
						<?php esc_html_e( 'Buy the special offer', 'akaza-adventure' ); ?>

						<svg
							viewBox="0 0 24 24"
							aria-hidden="true"
							focusable="false"
						>
							<path d="M5 12h13M13 6l6 6-6 6" />
						</svg>
					</a>

					<a
						class="sl-cyber-awareness-hero__cta sl-cyber-awareness-hero__cta--secondary"
						href="#contact"
					>
						<?php esc_html_e( 'Book a demo', 'akaza-adventure' ); ?>
					</a>

				</div>

			</div>

			<div class="sl-cyber-awareness-hero__visual">
				<div class="sl-cyber-awareness-hero__image">
					<img
						src="<?php echo esc_url( $csa_hero_image_url ); ?>"
						alt="<?php esc_attr_e( 'October Cybersecurity Awareness: measurable action', 'akaza-adventure' ); ?>"
						width="1200"
						height="900"
						loading="eager"
						decoding="async"
					/>
				</div>
			</div>

		</div>

	</div>
</section>

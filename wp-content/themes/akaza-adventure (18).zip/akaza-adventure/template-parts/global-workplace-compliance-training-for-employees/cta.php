<?php
/**
 * Global Workplace Compliance Training for Employees — CTA section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$contact_url  = '#contact';
$whatsapp_url = 'https://wa.me/916362021778';
$phone_label  = '+91 63620 21778';
?>
<section class="sl-global-cta-section" aria-labelledby="sl-global-cta-heading">

	<div class="container">

		<div class="sl-global-cta-wrapper">

			<span class="sl-home-sub-heading"><?php esc_html_e( 'Get started', 'akaza-adventure' ); ?></span>

			<h2 id="sl-global-cta-heading" class="sl-global-cta-title">
				<?php esc_html_e( 'Ready to Build a Better Workplace?', 'akaza-adventure' ); ?>
			</h2>

			<p class="sl-global-cta-text">
				<?php esc_html_e( 'Whether you’re strengthening workplace inclusion, delivering harassment prevention training, or preparing your workforce for responsible AI adoption, SucceedLEARN is ready to help.', 'akaza-adventure' ); ?>
			</p>

			<div class="sl-global-cta-actions">
				<a href="<?php echo esc_url( $contact_url ); ?>" class="sl-global-btn sl-global-btn-primary">
					<?php esc_html_e( 'Request a Demo', 'akaza-adventure' ); ?>
				</a>

				<a
					class="sl-global-cta__whatsapp"
					href="<?php echo esc_url( $whatsapp_url ); ?>"
					target="_blank"
					rel="noopener noreferrer"
					aria-label="<?php echo esc_attr( sprintf( /* translators: %s: phone number */ __( 'Chat on WhatsApp at %s', 'akaza-adventure' ), $phone_label ) ); ?>"
				>
					<span class="sl-global-cta__whatsapp-icon" aria-hidden="true">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="22" height="22" focusable="false">
							<path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.49-8.413z"/>
						</svg>
					</span>
					<span class="sl-global-cta__whatsapp-text">
						<span class="sl-global-cta__whatsapp-label"><?php esc_html_e( 'WhatsApp us', 'akaza-adventure' ); ?></span>
						<span class="sl-global-cta__whatsapp-number"><?php echo esc_html( $phone_label ); ?></span>
					</span>
				</a>
			</div>

		</div>

	</div>

</section>

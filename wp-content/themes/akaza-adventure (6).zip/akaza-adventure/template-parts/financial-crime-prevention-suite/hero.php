<?php
/**
 * Financial Crime Prevention Suite — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'eyebrow' => __( 'By Solution', 'akaza-adventure' ),
		'title'   => __( 'Financial Crime Prevention Suite', 'akaza-adventure' ),
		'lead'    => __( 'Train teams to recognise and prevent financial crime risks.', 'akaza-adventure' ),
	)
);

<?php
/**
 * Security Awareness — What is Security Awareness & Behaviour Change section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section
	class="sl-sa-definition"
	id="what-is-security-awareness"
	aria-labelledby="sl-sa-definition-title"
>

	<div class="container">

		<div class="sl-sa-definition__layout">

			<div class="sl-sa-definition__content">

				<div class="sl-sa-definition__heading">

					<span class="sl-home-sub-heading">
						<?php esc_html_e( 'Security Awareness Fundamentals', 'akaza-adventure' ); ?>
					</span>

					<h2 id="sl-sa-definition-title">
						<?php esc_html_e( 'What Is', 'akaza-adventure' ); ?>
						<span><?php esc_html_e( 'Security Awareness & Behaviour Change?', 'akaza-adventure' ); ?></span>
					</h2>

				</div>

				<p class="sl-sa-definition__lead">
					<?php esc_html_e(
						'Security awareness is more than teaching employees how to recognise cybersecurity threats. Effective security awareness helps people understand the risks associated with their everyday actions and develop the knowledge, confidence, and behaviours needed to respond securely.',
						'akaza-adventure'
					); ?>
				</p>

				<div class="sl-sa-definition__callout">

					<h3>
						<?php esc_html_e( 'From Awareness to Everyday Security Behaviour', 'akaza-adventure' ); ?>
					</h3>

					<p>
						<?php esc_html_e(
							'A modern security awareness programme combines education with continuous reinforcement. Instead of relying on a single annual training session, organisations can use security awareness training, phishing simulations, microlearning, security campaigns, behavioural nudges, and practical learning experiences to keep security relevant throughout the employee lifecycle.',
							'akaza-adventure'
						); ?>
					</p>

				</div>

				<p>
					<?php esc_html_e(
						'Security behaviour change focuses on turning awareness into consistent action. This means helping employees recognise suspicious emails, report potential threats, protect sensitive information, use secure authentication practices, and make safer decisions when faced with social engineering and other cyber risks.',
						'akaza-adventure'
					); ?>
				</p>

				<p>
					<?php esc_html_e(
						'The SucceedLEARN Security Behaviour & Culture Suite brings these activities together within one integrated platform, helping organisations move from training completion to measurable security behaviour change.',
						'akaza-adventure'
					); ?>
				</p>

			</div>

			<div class="sl-sa-definition__media">
				<?php /* Temporary stand-in — swap for the final definition image URL when ready. */ ?>
				<img
					src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/security-awareness-platform.jpg' ); ?>"
					alt="<?php esc_attr_e( 'Security awareness and behaviour change', 'akaza-adventure' ); ?>"
					width="640"
					height="720"
					loading="lazy"
					decoding="async"
				>
			</div>

		</div>

	</div>

</section>

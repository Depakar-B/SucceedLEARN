<?php
/**
 * Global Workplace Compliance Training for Employees — Contact / demo section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section id="contact" class="sl-home-contact-section sl-gwct-contact-section" aria-labelledby="sl-gwct-contact-heading">

	<div class="container">

		<div class="row align-items-start gy-5">

			<div class="col-lg-6">

				<div class="sl-home-contact-content sl-gwct-contact-content">

					<span class="sl-home-sub-heading">
						<?php esc_html_e( 'Talk to our team', 'akaza-adventure' ); ?>
					</span>

					<h2 id="sl-gwct-contact-heading">
						<?php esc_html_e( 'See how workplace compliance training works for your organisation', 'akaza-adventure' ); ?>
					</h2>

					<p>
						<?php esc_html_e( 'Book a short, no-obligation demo and we will walk you through our inclusion, harassment prevention, and responsible AI programmes — including learner experience, admin reporting, and how training can be deployed across your global workforce.', 'akaza-adventure' ); ?>
					</p>

					<div class="sl-gwct-contact-note">
						<strong><?php esc_html_e( 'Need more than one programme?', 'akaza-adventure' ); ?></strong>
						<?php esc_html_e( 'Many organisations combine inclusive workplace training, harassment prevention, and generative AI readiness into one learning plan. Mention your priorities on the form and we will tailor the conversation.', 'akaza-adventure' ); ?>
					</div>

					<div class="sl-gwct-contact-direct">
						<p class="sl-gwct-contact-direct__label">
							<?php esc_html_e( 'Prefer to reach us directly?', 'akaza-adventure' ); ?>
						</p>

						<div class="sl-gwct-contact-direct__grid">

							<a href="mailto:sales@succeedtech.com" class="sl-gwct-contact-direct__item">
								<span class="sl-gwct-contact-direct__icon" aria-hidden="true">
									<i class="bi bi-envelope"></i>
								</span>
								<span class="sl-gwct-contact-direct__body">
									<span class="sl-gwct-contact-direct__title"><?php esc_html_e( 'Email us', 'akaza-adventure' ); ?></span>
									<span class="sl-gwct-contact-direct__value">sales@succeedtech.com</span>
								</span>
							</a>

							<a href="tel:+916362021778" class="sl-gwct-contact-direct__item">
								<span class="sl-gwct-contact-direct__icon" aria-hidden="true">
									<i class="bi bi-telephone"></i>
								</span>
								<span class="sl-gwct-contact-direct__body">
									<span class="sl-gwct-contact-direct__title"><?php esc_html_e( 'Call us', 'akaza-adventure' ); ?></span>
									<span class="sl-gwct-contact-direct__value">+91 63620 21778</span>
								</span>
							</a>

						</div>
					</div>

				</div>

			</div>

			<div class="col-lg-6">

				<div class="sl-home-form-wrapper sl-home-form-wrapper--slim">
					<?php echo do_shortcode( '[contact_form form_variant="course"]' ); ?>
				</div>

			</div>

		</div>

	</div>

</section>

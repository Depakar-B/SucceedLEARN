/**
 * Scroll-to-top — show after scroll, smooth return to top.
 * Owns reading-progress width (viewport-safe) and syncs page primary to chrome.
 */
(function () {
  'use strict';

  var PAGE_ROOT_SELECTORS = [
    '.sl-about-page',
    '.sl-contact-page',
    '.sl-legal-page',
    '.sl-gwct-page',
    '.sl-inclusive-training-page',
    '.sl-course-page',
    '.slf-courses-archive',
    'body.slf-courses-archive-page',
    '[class*="-page"]'
  ].join(',');

  function removeLegacyScrollTop() {
    var legacy = document.getElementById('scrollTopBtn');
    if (!legacy) {
      return;
    }
    var next = legacy.nextElementSibling;
    if (next && next.tagName === 'STYLE') {
      next.parentNode.removeChild(next);
    }
    next = legacy.nextElementSibling;
    if (next && next.tagName === 'SCRIPT' && (next.textContent || '').indexOf('scrollTopBtn') !== -1) {
      next.parentNode.removeChild(next);
    }
    legacy.parentNode.removeChild(legacy);
  }

  function normalizeHex(value) {
    if (!value) {
      return '';
    }
    var v = String(value).trim().toLowerCase();
    if (!v) {
      return '';
    }
    if (v.indexOf('rgb') === 0) {
      var parts = v.match(/(\d+)/g);
      if (!parts || parts.length < 3) {
        return '';
      }
      return (
        '#' +
        [parts[0], parts[1], parts[2]]
          .map(function (n) {
            var h = parseInt(n, 10).toString(16);
            return h.length === 1 ? '0' + h : h;
          })
          .join('')
      );
    }
    if (v.charAt(0) !== '#') {
      v = '#' + v;
    }
    if (/^#[0-9a-f]{3}$/.test(v)) {
      return (
        '#' +
        v.charAt(1) +
        v.charAt(1) +
        v.charAt(2) +
        v.charAt(2) +
        v.charAt(3) +
        v.charAt(3)
      );
    }
    return /^#[0-9a-f]{6}$/.test(v) ? v : '';
  }

  function hexToRgbChannels(hex) {
    var h = normalizeHex(hex);
    if (!h) {
      return '';
    }
    return [
      parseInt(h.slice(1, 3), 16),
      parseInt(h.slice(3, 5), 16),
      parseInt(h.slice(5, 7), 16)
    ].join(', ');
  }

  function findPagePrimaryRoot() {
    var nodes = document.querySelectorAll(PAGE_ROOT_SELECTORS);
    var i;
    for (i = 0; i < nodes.length; i++) {
      var primary = getComputedStyle(nodes[i]).getPropertyValue('--sl-page-primary').trim();
      if (normalizeHex(primary)) {
        return nodes[i];
      }
    }
    return null;
  }

  function syncPagePrimaryToChrome() {
    var root = findPagePrimaryRoot();
    if (!root) {
      return;
    }

    var styles = getComputedStyle(root);
    var primary = normalizeHex(styles.getPropertyValue('--sl-page-primary'));
    if (!primary) {
      return;
    }

    var hover =
      normalizeHex(styles.getPropertyValue('--sl-page-primary-dark')) || primary;
    var rgb = hexToRgbChannels(primary);
    var docEl = document.documentElement;
    var current = normalizeHex(
      getComputedStyle(docEl).getPropertyValue('--sl-page-brand')
    );

    if (current === primary) {
      return;
    }

    docEl.style.setProperty('--sl-page-brand', primary);
    docEl.style.setProperty('--sl-page-brand-hover', hover);
    if (rgb) {
      docEl.style.setProperty('--sl-page-brand-rgb', rgb);
    }

    var rect = document.querySelector('.progress-square__rect');
    if (rect) {
      rect.setAttribute('stroke', primary);
    }
  }

  /**
   * Use viewport height — documentElement.clientHeight can equal scrollHeight
   * when html is sized to content, which left the bar stuck at 0%.
   * Drive fill via --sl-read-progress + scaleX so the footer snippet
   * cannot zero out width with its broken clientHeight math.
   */
  function updateReadProgress() {
    var bar = document.getElementById('read-progress-bar');
    if (!bar) {
      return;
    }

    var scrollTop = window.scrollY || document.documentElement.scrollTop || 0;
    var docHeight =
      Math.max(
        document.body ? document.body.scrollHeight : 0,
        document.documentElement.scrollHeight
      ) - (window.innerHeight || document.documentElement.clientHeight || 0);

    var progress = docHeight > 0 ? scrollTop / docHeight : 0;
    if (progress < 0) {
      progress = 0;
    } else if (progress > 1) {
      progress = 1;
    }

    document.documentElement.style.setProperty(
      '--sl-read-progress',
      progress.toFixed(4)
    );
    // Keep a sensible inline width for a11y/legacy, but CSS scaleX is authoritative.
    bar.style.width = '100%';
  }

  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  onReady(function () {
    removeLegacyScrollTop();
    syncPagePrimaryToChrome();
    updateReadProgress();
  });

  var progressTicking = false;
  window.addEventListener(
    'scroll',
    function () {
      if (!progressTicking) {
        window.requestAnimationFrame(function () {
          updateReadProgress();
          progressTicking = false;
        });
        progressTicking = true;
      }
    },
    { passive: true }
  );
  window.addEventListener('resize', updateReadProgress, { passive: true });

  var wrap = document.getElementById('sl-scroll-top');
  if (!wrap) {
    return;
  }

  var btn = wrap.querySelector('.sl-scroll-top');
  var threshold = 200;
  var ticking = false;

  function update() {
    var y = window.scrollY || document.documentElement.scrollTop || 0;
    wrap.classList.toggle('is-visible', y > threshold);
    ticking = false;
  }

  function onScroll() {
    if (!ticking) {
      window.requestAnimationFrame(update);
      ticking = true;
    }
  }

  if (btn) {
    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  update();
})();

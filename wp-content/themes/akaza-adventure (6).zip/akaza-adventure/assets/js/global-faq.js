/**
 * Global FAQ — accordion: only one details item open at a time.
 */
(function () {
	'use strict';

	function initSection(section) {
		var items = Array.prototype.slice.call(section.querySelectorAll('details.faq'));
		if (!items.length) {
			return;
		}

		items.forEach(function (details) {
			details.addEventListener('toggle', function () {
				if (!details.open) {
					return;
				}

				items.forEach(function (other) {
					if (other !== details && other.open) {
						other.open = false;
					}
				});
			});
		});
	}

	function init() {
		document.querySelectorAll('.sl-faq-section').forEach(initSection);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();

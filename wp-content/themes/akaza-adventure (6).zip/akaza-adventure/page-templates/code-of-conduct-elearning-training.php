<?php
/**
 * Template Name: Code of Conduct eLearning Training
 * Description: Desktop shell for Code of Conduct eLearning Training page.
 *
 * @package Akaza_Adventure
 */

get_header();
get_template_part( 'template-parts/code-of-conduct-elearning-training' );
get_footer();

<?php
/**
 * Template Name: Clients
 *
 * Placeholder page for the full client-logo grid.
 * Add your logo plugin shortcode/block in the page editor when ready.
 *
 * @package Akaza_Adventure
 */

get_header();
?>
<main id="main-content" class="slf-section slf-section--cream">
	<div class="slf-container">
		<?php
		get_template_part(
			'template-parts/page-hero',
			null,
			array(
				'eyebrow' => __( 'Our Clients', 'akaza-adventure' ),
				'title'   => __( 'Trusted by leading organisations worldwide', 'akaza-adventure' ),
				'lead'    => __( 'Organisations across industries rely on SucceedLEARN to build safer, more compliant workplaces.', 'akaza-adventure' ),
			)
		);
		?>

		<?php
		while ( have_posts() ) :
			the_post();
			$content = get_the_content( null, false );
			if ( $content && false === stripos( $content, 'elementor' ) ) :
				?>
				<div class="slf-page-content slf-clients-page__content">
					<?php echo apply_filters( 'the_content', $content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<?php
			endif;
		endwhile;
		?>
	</div>
</main>
<?php
get_footer();

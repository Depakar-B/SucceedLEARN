/**
 * Secondary global footer: back-to-top helper.
 */
(function () {
	'use strict';

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
		} else {
			document.addEventListener('DOMContentLoaded', fn);
		}
	}

	ready(function () {
		var topBtn = document.querySelector('[data-sl-secondary-top]');
		if (!topBtn) {
			return;
		}

		topBtn.addEventListener('click', function (event) {
			event.preventDefault();
			window.scrollTo({ top: 0, behavior: 'smooth' });
		});
	});
})();

<?php
/**
 * Political Donations Training for PE/VC — hero section.
 *
 * Paste hero markup below.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

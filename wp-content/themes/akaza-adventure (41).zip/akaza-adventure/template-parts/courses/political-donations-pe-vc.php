﻿<?php
/**
 * Political Donations Training for PE/VC course page wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-course-page sl-course-page--political-donations-pe-vc">
	<?php get_template_part( 'template-parts/courses/political-donations-pe-vc/sl-political-donations-hero' ); ?>
</main>

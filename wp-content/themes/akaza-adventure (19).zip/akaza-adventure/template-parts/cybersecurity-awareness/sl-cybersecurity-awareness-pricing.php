<?php
/**
 * Cybersecurity Awareness Month
 * Pricing Section
 *
 * @package Akaza_Adventure
 */
?>

<section
    class="sl-cybersecurity-awareness-pricing"
    id="pricing"
    aria-labelledby="sl-cybersecurity-awareness-pricing-title"
>
    <div class="container">

        <!-- Section Heading -->
        <div class="sl-cybersecurity-awareness-pricing__heading">

            <span class="sl-home-sub-heading">
                <?php esc_html_e( 'Fixed October Campaign Fee', 'akaza-adventure' ); ?>
            </span>

            <h2 id="sl-cybersecurity-awareness-pricing-title">
                <?php
                echo wp_kses(
                    __( 'Clear pricing for teams <span>of every size</span>', 'akaza-adventure' ),
                    array( 'span' => array() )
                );
                ?>
            </h2>

            <p>
                <?php esc_html_e(
                    'One domain. One fixed campaign fee. No additional per-user charge within your selected employee band.',
                    'akaza-adventure'
                ); ?>
            </p>

        </div>


        <!-- Pricing Plans -->
        <div class="sl-cybersecurity-awareness-pricing__plans">

            <!-- Plan 1 -->
            <article class="sl-cybersecurity-awareness-pricing__card">

                <div class="sl-cybersecurity-awareness-pricing__card-head">

                    <span
                        class="sl-cybersecurity-awareness-pricing__icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                            <circle cx="9" cy="7" r="4"/>
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                        </svg>
                    </span>

                    <h3>
                        <?php esc_html_e( 'Up to 100 users', 'akaza-adventure' ); ?>
                    </h3>

                </div>

                <div class="sl-cybersecurity-awareness-pricing__price">
                    $50
                </div>

                <p class="sl-cybersecurity-awareness-pricing__price-note">
                    <?php esc_html_e( 'Fixed campaign price', 'akaza-adventure' ); ?>
                </p>

                <a
                    href="#contact"
                    class="sl-btn sl-btn--primary sl-cybersecurity-awareness-pricing__cta"
                >
                    <?php
                    echo wp_kses(
                        __( 'Claim the <span class="sl-csa-oct-tag">October</span> Offer', 'akaza-adventure' ),
                        array(
                            'span' => array(
                                'class' => array(),
                            ),
                        )
                    );
                    ?>

                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M5 12h14"/>
                        <path d="m13 6 6 6-6 6"/>
                    </svg>
                </a>

            </article>


            <!-- Plan 2 — Featured -->
            <article class="sl-cybersecurity-awareness-pricing__card sl-cybersecurity-awareness-pricing__card--featured">

                <span class="sl-cybersecurity-awareness-pricing__badge">
                    <?php esc_html_e( 'Best for most organisations', 'akaza-adventure' ); ?>
                </span>

                <div class="sl-cybersecurity-awareness-pricing__card-head">

                    <span
                        class="sl-cybersecurity-awareness-pricing__icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                            <circle cx="9" cy="7" r="4"/>
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                        </svg>
                    </span>

                    <h3>
                        <?php esc_html_e( '101–1,000 users', 'akaza-adventure' ); ?>
                    </h3>

                </div>

                <div class="sl-cybersecurity-awareness-pricing__price">
                    $100
                </div>

                <p class="sl-cybersecurity-awareness-pricing__price-note">
                    <?php esc_html_e( 'Fixed campaign price', 'akaza-adventure' ); ?>
                </p>

                <a
                    href="#contact"
                    class="sl-btn sl-btn--primary sl-cybersecurity-awareness-pricing__cta"
                >
                    <?php
                    echo wp_kses(
                        __( 'Claim the <span class="sl-csa-oct-tag">October</span> Offer', 'akaza-adventure' ),
                        array(
                            'span' => array(
                                'class' => array(),
                            ),
                        )
                    );
                    ?>

                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M5 12h14"/>
                        <path d="m13 6 6 6-6 6"/>
                    </svg>
                </a>

            </article>


            <!-- Plan 3 -->
            <article class="sl-cybersecurity-awareness-pricing__card">

                <div class="sl-cybersecurity-awareness-pricing__card-head">

                    <span
                        class="sl-cybersecurity-awareness-pricing__icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M3 21h18"/>
                            <path d="M6 21V9h5v12"/>
                            <path d="M11 21V4h7v17"/>
                            <path d="M14 8h1"/>
                            <path d="M14 12h1"/>
                            <path d="M14 16h1"/>
                        </svg>
                    </span>

                    <h3>
                        <?php esc_html_e( '1,001–5,000 users', 'akaza-adventure' ); ?>
                    </h3>

                </div>

                <div class="sl-cybersecurity-awareness-pricing__price">
                    $500
                </div>

                <p class="sl-cybersecurity-awareness-pricing__price-note">
                    <?php esc_html_e( 'Fixed campaign price', 'akaza-adventure' ); ?>
                </p>

                <a
                    href="#contact"
                    class="sl-btn sl-btn--primary sl-cybersecurity-awareness-pricing__cta"
                >
                    <?php
                    echo wp_kses(
                        __( 'Claim the <span class="sl-csa-oct-tag">October</span> Offer', 'akaza-adventure' ),
                        array(
                            'span' => array(
                                'class' => array(),
                            ),
                        )
                    );
                    ?>

                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M5 12h14"/>
                        <path d="m13 6 6 6-6 6"/>
                    </svg>
                </a>

            </article>


            <!-- Plan 4 -->
            <article class="sl-cybersecurity-awareness-pricing__card">

                <div class="sl-cybersecurity-awareness-pricing__card-head">

                    <span
                        class="sl-cybersecurity-awareness-pricing__icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M4 20V10"/>
                            <path d="M10 20V4"/>
                            <path d="M16 20v-7"/>
                            <path d="M22 20V7"/>
                        </svg>
                    </span>

                    <h3>
                        <?php esc_html_e( '5,001–10,000 users', 'akaza-adventure' ); ?>
                    </h3>

                </div>

                <div class="sl-cybersecurity-awareness-pricing__price">
                    $1,000
                </div>

                <p class="sl-cybersecurity-awareness-pricing__price-note">
                    <?php esc_html_e( 'Fixed campaign price', 'akaza-adventure' ); ?>
                </p>

                <a
                    href="#contact"
                    class="sl-btn sl-btn--primary sl-cybersecurity-awareness-pricing__cta"
                >
                    <?php
                    echo wp_kses(
                        __( 'Claim the <span class="sl-csa-oct-tag">October</span> Offer', 'akaza-adventure' ),
                        array(
                            'span' => array(
                                'class' => array(),
                            ),
                        )
                    );
                    ?>

                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M5 12h14"/>
                        <path d="m13 6 6 6-6 6"/>
                    </svg>
                </a>

            </article>

        </div>


        <!-- Included at Every Level -->
        <div class="sl-cybersecurity-awareness-pricing__included">

            <div class="sl-cybersecurity-awareness-pricing__included-heading">

                <span class="sl-home-sub-heading">
                    <?php esc_html_e( 'Included at every level', 'akaza-adventure' ); ?>
                </span>

                <h3>
                    <?php esc_html_e(
                        'Everything needed to launch, test and measure',
                        'akaza-adventure'
                    ); ?>
                </h3>

                <p>
                    <?php esc_html_e(
                        'Each pricing band includes the same core campaign capabilities, only the number of participating users changes.',
                        'akaza-adventure'
                    ); ?>
                </p>

            </div>


            <?php
            $included_features = array(
                array(
                    'text'      => __( 'Comprehensive security awareness training', 'akaza-adventure' ),
                    'highlight' => false,
                ),
                array(
                    'text'      => __( 'Up to 10 phishing simulation emails per user', 'akaza-adventure' ),
                    'highlight' => false,
                ),
                array(
                    'text'      => __( 'Access to 300+ phishing templates', 'akaza-adventure' ),
                    'highlight' => false,
                ),
                array(
                    'text'      => __( 'PhishCue reported-email workflow', 'akaza-adventure' ),
                    'highlight' => false,
                ),
                array(
                    'text'      => __( 'Standard Microsoft 365 implementation support', 'akaza-adventure' ),
                    'highlight' => false,
                ),
                array(
                    'text'      => __( 'SSO and SCIM integration', 'akaza-adventure' ),
                    'highlight' => false,
                ),
                array(
                    'text'      => __( 'Campaign dashboard and outcome report', 'akaza-adventure' ),
                    'highlight' => false,
                ),
                array(
                    'text'      => __( '50% discount for the first-year extension', 'akaza-adventure' ),
                    'highlight' => true,
                ),
            );
            ?>

            <ol class="sl-cybersecurity-awareness-pricing__features">
                <?php foreach ( $included_features as $feature ) : ?>
                    <li class="sl-cybersecurity-awareness-pricing__feature<?php echo ! empty( $feature['highlight'] ) ? ' sl-cybersecurity-awareness-pricing__feature--highlight' : ''; ?>">
                        <?php echo esc_html( $feature['text'] ); ?>
                    </li>
                <?php endforeach; ?>
            </ol>

        </div>


        <p class="sl-cybersecurity-awareness-pricing__disclaimer">
            <?php esc_html_e(
                'Applicable taxes are additional. Offer is subject to eligibility, campaign terms, technical prerequisites and available onboarding capacity.',
                'akaza-adventure'
            ); ?>
        </p>

    </div>
</section>
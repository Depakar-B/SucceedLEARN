<?php
/**
 * Workplace Harassment Prevention Training page content wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-whp-page">
	<?php get_template_part( 'template-parts/workplace-harassment-prevention-training/sl-whp-hero' ); ?>
	<?php get_template_part( 'template-parts/workplace-harassment-prevention-training/sl-whp-regions' ); ?>
</main>

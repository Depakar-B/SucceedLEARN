<?php
/**
 * Workplace Harassment Prevention Training page assets.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue WHP page styles (and scripts when needed).
 */
function akaza_enqueue_whp_assets() {
	$folder = 'workplace-harassment-prevention-training';
	$global = 'akaza-sl-whp-global';

	akaza_enqueue_theme_style( $global, "{$folder}/sl-whp-global.css" );
	akaza_enqueue_theme_style( 'akaza-sl-whp-hero', "{$folder}/sl-whp-hero.css", array( $global ) );
	akaza_enqueue_theme_style( 'akaza-sl-whp-regions', "{$folder}/sl-whp-regions.css", array( $global ) );
}

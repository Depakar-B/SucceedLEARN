<?php
/**
 * GDPR Employee Awareness Training page assets.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue GDPR page styles (and scripts when needed).
 */
function akaza_enqueue_gdpr_assets() {
	$folder = 'gdpr-employee-awareness-training';
	$global = 'akaza-sl-gdpr-global';

	akaza_enqueue_theme_style( $global, "{$folder}/sl-gdpr-global.css" );
	akaza_enqueue_theme_style( 'akaza-sl-gdpr-hero', "{$folder}/sl-gdpr-hero.css", array( $global ) );
	akaza_enqueue_theme_style( 'akaza-sl-gdpr-trust', "{$folder}/sl-gdpr-trust.css", array( $global ) );
	akaza_enqueue_theme_style( 'akaza-gdpr-everyday-risk', "{$folder}/gdpr-everyday-risk.css", array( $global ) );
	akaza_enqueue_theme_style( 'akaza-sl-gdpr-reasons', "{$folder}/sl-gdpr-reasons.css", array( $global ) );
}

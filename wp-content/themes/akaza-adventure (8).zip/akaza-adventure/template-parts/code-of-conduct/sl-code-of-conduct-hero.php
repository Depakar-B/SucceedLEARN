<?php
/**
 * Code of Conduct — Hero section.
 *
 * Paste final hero markup here.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-code-of-conduct-hero" aria-labelledby="sl-code-of-conduct-hero-title">
	<div class="container">
		<div class="sl-code-of-conduct-hero__grid">
			<div class="sl-code-of-conduct-hero__content">
				<?php
				if ( function_exists( 'akaza_render_hero_breadcrumbs' ) ) {
					akaza_render_hero_breadcrumbs();
				}
				?>

				<span class="sl-home-sub-heading sl-code-of-conduct-hero__eyebrow">
					<?php esc_html_e( 'Code of Conduct', 'akaza-adventure' ); ?>
				</span>

				<h1 id="sl-code-of-conduct-hero-title">
					<?php esc_html_e( 'Code of Conduct Training', 'akaza-adventure' ); ?>
				</h1>

				<p class="sl-code-of-conduct-hero__description">
					<?php esc_html_e( 'Replace this placeholder copy with the final hero content.', 'akaza-adventure' ); ?>
				</p>

				<div class="sl-code-of-conduct-hero__actions">
					<a href="#contact" class="sl-code-of-conduct-hero__button sl-code-of-conduct-hero__button--primary">
						<?php esc_html_e( 'Request a Demo', 'akaza-adventure' ); ?>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
/**
 * Template Name: Infosec 2026 Cyber
 * Description: Desktop shell for Infosec 2026 Cyber page.
 *
 * @package Akaza_Adventure
 */

get_header( 'infosec' );
get_template_part( 'template-parts/infosec-2026-cyber' );
get_footer( 'infosec' );

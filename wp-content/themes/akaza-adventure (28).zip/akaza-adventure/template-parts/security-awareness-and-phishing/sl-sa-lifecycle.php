<?php
/**
 * Security Awareness — Employee Lifecycle
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-sa-lifecycle" id="employee-lifecycle">
	<div class="container">

		<div class="sl-sa-lifecycle__layout">

			<div class="sl-sa-lifecycle__content">

				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'CONTINUOUS SECURITY AWARENESS', 'akaza-adventure' ); ?>
				</span>

				<h2>
					<?php esc_html_e( 'Build Security Awareness Around the', 'akaza-adventure' ); ?>
					<span><?php esc_html_e( 'Employee Lifecycle', 'akaza-adventure' ); ?></span>
				</h2>

				<p>
					<?php esc_html_e( 'Cyber risk does not begin and end with annual compliance training. Employees encounter different risks depending on their roles, responsibilities, access levels and stage within the organisation.', 'akaza-adventure' ); ?>
				</p>

				<p>
					<?php esc_html_e( 'A continuous awareness programme can support employees throughout their journey — from initial onboarding and foundational learning to ongoing reinforcement, phishing simulations, refresher learning and targeted interventions.', 'akaza-adventure' ); ?>
				</p>

				<p>
					<?php esc_html_e( 'This allows organisations to deliver the right awareness experiences at the right moments while maintaining consistent security messaging across the workforce.', 'akaza-adventure' ); ?>
				</p>

			</div>

			<div class="sl-sa-lifecycle__media">

				<div
					class="sl-sa-lifecycle__image-placeholder"
					role="img"
					aria-label="<?php esc_attr_e( 'Security awareness employee lifecycle image placeholder', 'akaza-adventure' ); ?>"
				>
					<span class="sl-sa-lifecycle__image-size">
						<?php esc_html_e( 'Image: 640 × 520 px', 'akaza-adventure' ); ?>
					</span>

					<span class="sl-sa-lifecycle__image-note">
						<?php esc_html_e( 'Security Awareness Employee Lifecycle Image', 'akaza-adventure' ); ?>
					</span>
				</div>

			</div>

		</div>

	</div>
</section>
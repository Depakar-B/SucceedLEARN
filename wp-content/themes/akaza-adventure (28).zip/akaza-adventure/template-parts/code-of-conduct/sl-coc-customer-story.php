<?php
/**
 * Code of Conduct — Customer Story Section
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section
	class="sl-coc-customer-story"
	aria-labelledby="sl-coc-customer-story-title"
>
	<div class="container">

		<div class="sl-coc-customer-story__heading">

			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Customer Story', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-customer-story-title">
				<?php
				echo wp_kses(
					__( 'From Policy Rollout to <span>Employee Understanding</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>

			<p>
				<?php esc_html_e(
					'A consistent Code of Conduct learning experience can help employees understand expectations, apply them in practical situations and make better workplace decisions.',
					'akaza-adventure'
				); ?>
			</p>

		</div>

		<div class="sl-coc-customer-story__cycle">

			<svg
				class="sl-coc-customer-story__ring"
				viewBox="0 0 100 100"
				preserveAspectRatio="none"
				aria-hidden="true"
				focusable="false"
			>
				<polygon points="24,14 76,14 50,86" />
			</svg>

			<article class="sl-coc-customer-story__card sl-coc-customer-story__card--challenge">

				<span class="sl-coc-customer-story__number" aria-hidden="true">
					<?php esc_html_e( '01', 'akaza-adventure' ); ?>
				</span>

				<div class="sl-coc-customer-story__card-body">
					<h3>
						<?php esc_html_e( 'Challenge', 'akaza-adventure' ); ?>
					</h3>

					<p>
						<?php esc_html_e(
							'The organization needed to communicate its Code consistently across a geographically distributed workforce.',
							'akaza-adventure'
						); ?>
					</p>
				</div>

			</article>

			<article class="sl-coc-customer-story__card sl-coc-customer-story__card--solution">

				<span class="sl-coc-customer-story__number" aria-hidden="true">
					<?php esc_html_e( '02', 'akaza-adventure' ); ?>
				</span>

				<div class="sl-coc-customer-story__card-body">
					<h3>
						<?php esc_html_e( 'Solution', 'akaza-adventure' ); ?>
					</h3>

					<p>
						<?php esc_html_e(
							'SucceedLEARN customized the course around the organization’s policies, branding, reporting procedures and workplace scenarios.',
							'akaza-adventure'
						); ?>
					</p>
				</div>

			</article>

			<div class="sl-coc-customer-story__centre">
				<p class="sl-coc-customer-story__centre-line">
					<?php esc_html_e( 'Turning policy into', 'akaza-adventure' ); ?>
				</p>
				<p class="sl-coc-customer-story__centre-line">
					<?php esc_html_e( 'practical understanding', 'akaza-adventure' ); ?>
				</p>
			</div>

			<article class="sl-coc-customer-story__card sl-coc-customer-story__card--outcome">

				<span class="sl-coc-customer-story__number" aria-hidden="true">
					<?php esc_html_e( '03', 'akaza-adventure' ); ?>
				</span>

				<div class="sl-coc-customer-story__card-body">
					<h3>
						<?php esc_html_e( 'Outcome', 'akaza-adventure' ); ?>
					</h3>

					<p>
						<?php esc_html_e(
							'Employees received a consistent learning experience while HR and compliance gained centralized visibility into completion and assessment.',
							'akaza-adventure'
						); ?>
					</p>
				</div>

			</article>

		</div>

		<div class="sl-coc-customer-story__action">

			<a
				class="sl-content-btn sl-content-btn-primary"
				href="#"
			>
				<?php esc_html_e( 'Read Customer Success Stories', 'akaza-adventure' ); ?>

				<span aria-hidden="true">→</span>
			</a>

		</div>

	</div>
</section>

<?php
/**
 * S-Phish — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'eyebrow' => __( 'Security Awareness', 'akaza-adventure' ),
		'title'   => __( 'S-Phish', 'akaza-adventure' ),
		'lead'    => __( 'Phishing simulations that test and strengthen employee vigilance.', 'akaza-adventure' ),
	)
);

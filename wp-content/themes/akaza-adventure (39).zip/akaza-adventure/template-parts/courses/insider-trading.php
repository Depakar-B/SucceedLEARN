﻿<?php
/**
 * Insider Trading eLearning course page wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-course-page sl-course-page--insider-trading">
	<?php get_template_part( 'template-parts/courses/insider-trading/sl-insider-trading-hero' ); ?>
</main>

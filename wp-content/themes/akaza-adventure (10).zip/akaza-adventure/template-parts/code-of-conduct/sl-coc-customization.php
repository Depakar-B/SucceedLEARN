<?php
/**
 * Code of Conduct — Customization.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-coc-customization" aria-labelledby="sl-coc-customization-title">
	<div class="container">

		<div class="sl-coc-customization__heading">

			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Customization', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-customization-title">
				<?php
				echo wp_kses(
					__( 'Your Code. Your Policies. <span>Your Training.</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>

			<p>
				<?php esc_html_e( 'Every organization has different values, policies, reporting procedures and compliance requirements.', 'akaza-adventure' ); ?>
			</p>

		</div>

		<div class="sl-coc-customization__intro">
			<h3>
				<?php esc_html_e( "SucceedLEARN's custom Code of Conduct training can be adapted to incorporate:", 'akaza-adventure' ); ?>
			</h3>
		</div>

		<div class="sl-coc-customization__lists">

			<div class="sl-coc-customization__list-box">
				<ul>
					<li><?php esc_html_e( 'Company branding and colours', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Your Code of Conduct', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Organization-specific policies', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Leadership messages', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Reporting channels', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Whistleblowing procedures', 'akaza-adventure' ); ?></li>
				</ul>
			</div>

			<div class="sl-coc-customization__list-box">
				<ul>
					<li><?php esc_html_e( 'Gift thresholds', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Organization-specific scenarios', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Industry-specific examples', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Assessments', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Certificates', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Languages', 'akaza-adventure' ); ?></li>
				</ul>
			</div>

		</div>

		<div class="sl-coc-customization__closing">

			<p>
				<?php
				echo wp_kses(
					__( 'The result is a course that feels like your organization’s Code of Conduct programme, rather than generic off-the-shelf training.', 'akaza-adventure' ),
					array( 'strong' => array() )
				);
				?>
			</p>

			<a class="sl-coc-customization__cta" href="#contact">
				<?php esc_html_e( 'Discuss Your Customization Requirements', 'akaza-adventure' ); ?>
				<span aria-hidden="true">→</span>
			</a>

		</div>

	</div>
</section>
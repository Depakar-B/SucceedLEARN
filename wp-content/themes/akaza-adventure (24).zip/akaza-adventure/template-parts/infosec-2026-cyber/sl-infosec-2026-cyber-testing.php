<?php
/**
 * Cybersecurity Awareness Month 2026
 * Testing Doesn't Have to Be
 *
 * @package Akaza_Adventure
 */
?>

<section
	class="sl-infosec-2026-cyber-testing"
	aria-labelledby="sl-infosec-2026-cyber-testing-title"
>
	<div class="container">

		<div class="sl-infosec-2026-cyber-testing__grid">

			<!-- Content -->
			<div class="sl-infosec-2026-cyber-testing__content">

				<span class="sl-home-sub-heading">
					<?php
					esc_html_e(
						'FROM AWARENESS TO ACTION',
						'akaza-adventure'
					);
					?>
				</span>

				<h2 id="sl-infosec-2026-cyber-testing-title">
					<?php
					echo wp_kses_post(
						__(
							'One Click Can Be <span>Expensive.</span> Testing Doesn’t Have to Be.',
							'akaza-adventure'
						)
					);
					?>
				</h2>

				<p>
					<?php
					esc_html_e(
						'Cybersecurity awareness shouldn’t end when an employee completes a course.',
						'akaza-adventure'
					);
					?>
				</p>

				<p>
					<?php
					esc_html_e(
						'A phishing simulation allows you to see how awareness translates into real-world decisions.',
						'akaza-adventure'
					);
					?>
				</p>

				<ul class="sl-infosec-2026-cyber-testing__questions">

					<li>
						<span class="sl-infosec-2026-cyber-testing__number">01</span>
						<span class="sl-infosec-2026-cyber-testing__question">
							<?php
							esc_html_e(
								'Will employees recognise the warning signs?',
								'akaza-adventure'
							);
							?>
						</span>
					</li>

					<li>
						<span class="sl-infosec-2026-cyber-testing__number">02</span>
						<span class="sl-infosec-2026-cyber-testing__question">
							<?php
							esc_html_e(
								'Will they resist the click?',
								'akaza-adventure'
							);
							?>
						</span>
					</li>

					<li>
						<span class="sl-infosec-2026-cyber-testing__number">03</span>
						<span class="sl-infosec-2026-cyber-testing__question">
							<?php
							esc_html_e(
								'Will they know what to do next?',
								'akaza-adventure'
							);
							?>
						</span>
					</li>

				</ul>

				<p class="sl-infosec-2026-cyber-testing__important">
					<?php
					esc_html_e(
						'And most importantly: Where can you help them become stronger?',
						'akaza-adventure'
					);
					?>
				</p>

				<p>
					<?php
					esc_html_e(
						'This campaign isn’t about catching employees out or highlighting failure.',
						'akaza-adventure'
					);
					?>
				</p>

				<div class="sl-highlight">
					<p>
						<?php
						esc_html_e(
							"It's about turning employee behaviour into an opportunity to learn.",
							'akaza-adventure'
						);
						?>
					</p>
				</div>

			</div>

			<!-- Image Placeholder -->
			<div class="sl-infosec-2026-cyber-testing__visual">

				<div class="sl-infosec-2026-cyber-testing__image-placeholder">
					<span>
						<?php
						esc_html_e(
							'Image placeholder',
							'akaza-adventure'
						);
						?>
					</span>

					<small>
						<?php
						esc_html_e(
							'Recommended: 600 × 600 px',
							'akaza-adventure'
						);
						?>
					</small>
				</div>

			</div>

		</div>

	</div>
</section>
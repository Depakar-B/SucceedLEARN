<?php
/**
 * Homepage — Contact form section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section id="contact" class="sl-home-contact-section" aria-labelledby="contact-heading">

    <div class="container">

        <div class="row align-items-center gy-5">

            <div class="col-lg-6">

                <div class="sl-home-contact-content">

                    <span class="sl-home-sub-heading">
                        Get Your Personalized Demo
                    </span>

                    <h2 id="contact-heading">
                        Need Help or Have a Query?
                    </h2>

                    <p>
                        Tell us a bit about your organisation and we'll show you
                        exactly how SucceedLEARN reduces risk, simplifies
                        compliance, and drives measurable behaviour change —
                        for your team.
                    </p>

                    <div class="sl-home-contact-image">
                        <img src="<?php echo esc_url( home_url( '/wp-content/uploads/2026/07/Get-Your-Personalized.webp' ) ); ?>"
                             alt="<?php esc_attr_e( 'SucceedLEARN demo', 'akaza-adventure' ); ?>"
                             class="img-fluid rounded"
                             width="720"
                             height="640"
                             loading="lazy"
                             decoding="async">
                    </div>

                </div>

            </div>

            <div class="col-lg-6">

                <div class="sl-home-form-wrapper">
                    <?php echo do_shortcode( '[contact_form]' ); ?>
                </div>

            </div>

        </div>

    </div>

</section>

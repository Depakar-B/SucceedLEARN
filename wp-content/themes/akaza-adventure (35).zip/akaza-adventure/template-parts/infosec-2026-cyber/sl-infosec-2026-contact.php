<?php
/**
 * SucceedLEARN
 * Cybersecurity Awareness Month 2026
 * Contact Section
 */

defined( 'ABSPATH' ) || exit;
?>

<section
	class="sl-infosec-2026-contact"
	id="contact"
	aria-labelledby="sl-infosec-2026-contact-title"
>
	<div class="container">

		<div class="sl-infosec-2026-contact__grid">

			<!-- LEFT: Contact Content -->
			<div class="sl-infosec-2026-contact__content">

				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Cyber Readiness Challenge', 'akaza-adventure' ); ?>
				</span>

				<h2 id="sl-infosec-2026-contact-title">
					<?php
					echo wp_kses_post(
						__( 'Ready to See How <span>Cyber-Ready</span> Your Workforce Is?', 'akaza-adventure' )
					);
					?>
				</h2>

				<p class="sl-infosec-2026-contact__lead">
					<?php esc_html_e( 'Start the Cyber Readiness Challenge.', 'akaza-adventure' ); ?>
				</p>

				<div class="sl-infosec-2026-contact__price">
					<span class="sl-infosec-2026-contact__price-amount">
						$2
					</span>

					<span class="sl-infosec-2026-contact__price-label">
						<?php esc_html_e( '/User/month', 'akaza-adventure' ); ?>
					</span>
				</div>

				<p class="sl-infosec-2026-contact__description">
					<?php
					esc_html_e(
						'Whatever your score, we\'ll help you take the next step toward stronger employee cybersecurity awareness.',
						'akaza-adventure'
					);
					?>
				</p>

			</div>


			<!-- RIGHT: Cybersecurity Campaign Registration Form -->
			<div class="sl-infosec-2026-contact__form-wrap">

				<div class="sl-home-form-wrapper sl-home-form-wrapper--slim">

					<?php
					$form_title     = __( 'Campaign Registration', 'akaza-adventure' );
					$form_shortcode = sprintf(
						'[cybersecurity_form variant="infosec" title="%s" subtitle=""]',
						esc_attr( $form_title )
					);

					if ( shortcode_exists( 'cybersecurity_form' ) ) {

						echo do_shortcode( $form_shortcode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

					} elseif ( shortcode_exists( 'seo_form' ) ) {

						echo do_shortcode(
							sprintf(
								'[seo_form variant="infosec" title="%s" subtitle=""]',
								esc_attr( $form_title )
							)
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

					}
					?>

				</div>

			</div>

		</div>

	</div>
</section>

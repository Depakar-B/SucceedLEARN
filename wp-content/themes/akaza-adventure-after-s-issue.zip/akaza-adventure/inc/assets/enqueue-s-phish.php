<?php
/**
 * S-Phish page assets.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue S-Phish page styles (and scripts when needed).
 */
function akaza_enqueue_s_phish_assets() {
	$folder     = 's-phish';
	$foundation = akaza_enqueue_page_foundation();

	akaza_enqueue_theme_style(
		'akaza-sl-s-phish-hero',
		"{$folder}/sl-s-phish-hero.css",
		array( $foundation )
	);

	// Add later section CSS here, e.g.:
	// akaza_enqueue_theme_style( 'akaza-sl-s-phish-overview', "{$folder}/sl-s-phish-overview.css", array( $foundation ) );
}

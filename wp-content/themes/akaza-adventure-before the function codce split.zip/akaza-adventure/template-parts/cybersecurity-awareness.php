<?php
/**
 * Cybersecurity Awareness page content wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-csa-page">
	<?php get_template_part( 'template-parts/cybersecurity-awareness/sl-cybersecurity-awareness-hero' ); ?>
</main>

<?php
/**
 * Cybersecurity Awareness — Hero Section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$csa_hero_image = function_exists( 'akaza_upload_url' )
	? akaza_upload_url( '2026/01/BFSI-and-PE-VC-Security-Awareness-Hero-Section-1.webp' )
	: 'https://succeedlearn.com/wp-content/uploads/2026/01/BFSI-and-PE-VC-Security-Awareness-Hero-Section-1.webp';
?>

<section
	class="sl-cybersecurity-awareness-hero"
	aria-labelledby="sl-cybersecurity-awareness-hero-title"
>
	<div class="container">

		<div class="sl-cybersecurity-awareness-hero__grid">

			<div class="sl-cybersecurity-awareness-hero__content">

				<div class="sl-cybersecurity-awareness-hero__breadcrumb">
					<span>
						<?php esc_html_e( 'Home / Cybersecurity Awareness', 'akaza-adventure' ); ?>
					</span>
				</div>

				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Interactive cybersecurity learning', 'akaza-adventure' ); ?>
				</span>

				<h1 id="sl-cybersecurity-awareness-hero-title">
					<?php
					echo wp_kses(
						sprintf(
							/* translators: %s: highlighted word "knowledge" */
							__( 'Interactive cybersecurity awareness training that turns %s into everyday behaviour', 'akaza-adventure' ),
							'<span class="sl-cybersecurity-awareness-hero__highlight">' . esc_html__( 'knowledge', 'akaza-adventure' ) . '</span>'
						),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					);
					?>
				</h1>

				<p class="sl-cybersecurity-awareness-hero__lead">
					<?php
					esc_html_e(
						'Build a workforce that understands not only what cyber threats look like, but how to respond when they appear in everyday work.',
						'akaza-adventure'
					);
					?>
				</p>

				<div class="sl-cybersecurity-awareness-hero__actions">

					<a
						class="sl-cybersecurity-awareness-hero__button sl-cybersecurity-awareness-hero__button--primary"
						href="#contact"
						data-cta="csa-hero-demo"
					>
						<?php esc_html_e( 'Book a Demo', 'akaza-adventure' ); ?>
					</a>

					<a
						class="sl-cybersecurity-awareness-hero__button sl-cybersecurity-awareness-hero__button--secondary"
						href="#preview"
					>
						<?php esc_html_e( 'Watch Course Preview', 'akaza-adventure' ); ?>
						<svg
							class="sl-cybersecurity-awareness-hero__button-icon"
							width="12"
							height="14"
							viewBox="0 0 12 14"
							fill="currentColor"
							aria-hidden="true"
							focusable="false"
						>
							<path d="M0 0v14l12-7L0 0z" />
						</svg>
					</a>

					<a
						class="sl-cybersecurity-awareness-hero__brochure"
						href="#brochure"
					>
						<?php esc_html_e( 'Download Brochure', 'akaza-adventure' ); ?>
					</a>

				</div>

			</div>

			<div class="sl-cybersecurity-awareness-hero__visual">

				<div class="sl-cybersecurity-awareness-hero__image">
					<img
						src="<?php echo esc_url( $csa_hero_image ); ?>"
						alt="<?php esc_attr_e( 'Employees practising cybersecurity awareness in the workplace', 'akaza-adventure' ); ?>"
						width="1200"
						height="800"
						loading="eager"
						decoding="async"
					/>
				</div>

				<div class="sl-cybersecurity-awareness-hero__floating-label">

					<span class="sl-cybersecurity-awareness-hero__status-dot"></span>

					<span>
						<?php esc_html_e( 'Real workplace threats', 'akaza-adventure' ); ?>
					</span>

				</div>

			</div>

			<div
				class="sl-cybersecurity-awareness-hero__assessment"
				data-cybersecurity-awareness-assessment
			>

				<div class="sl-cybersecurity-awareness-hero__assessment-top">

					<span class="sl-cybersecurity-awareness-hero__assessment-category">
						<?php esc_html_e( 'Phishing & Social Engineering', 'akaza-adventure' ); ?>
					</span>

					<span class="sl-cybersecurity-awareness-hero__assessment-label">
						<?php esc_html_e( 'Decision point', 'akaza-adventure' ); ?>
					</span>

				</div>

				<h3 class="sl-cybersecurity-awareness-hero__question">
					<?php
					esc_html_e(
						'You receive an urgent email from “IT Support” asking you to click a link and confirm your password. What should you do?',
						'akaza-adventure'
					);
					?>
				</h3>

				<div class="sl-cybersecurity-awareness-hero__options">

					<button
						type="button"
						class="sl-cybersecurity-awareness-hero__option"
						data-answer="wrong"
					>
						<?php esc_html_e( 'Click the link — it looks like an official IT request.', 'akaza-adventure' ); ?>
					</button>

					<button
						type="button"
						class="sl-cybersecurity-awareness-hero__option"
						data-answer="correct"
					>
						<?php esc_html_e( 'Do not click. Report it through the official channel.', 'akaza-adventure' ); ?>
					</button>

					<button
						type="button"
						class="sl-cybersecurity-awareness-hero__option"
						data-answer="wrong"
					>
						<?php esc_html_e( 'Reply with your password so they can verify your account.', 'akaza-adventure' ); ?>
					</button>

				</div>

				<div
					class="sl-cybersecurity-awareness-hero__feedback"
					aria-live="polite"
				></div>

			</div>

		</div>

	</div>
</section>

<?php
/**
 * Template Name: Cybersecurity Awareness
 * Description: Desktop shell for Cybersecurity Awareness solution page.
 *
 * @package Akaza_Adventure
 */

get_header();
get_template_part( 'template-parts/cybersecurity-awareness' );
get_footer();

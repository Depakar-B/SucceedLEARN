<?php
/**
 * Code of Conduct page content wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-coc-page">
	<?php get_template_part( 'template-parts/code-of-conduct/sl-code-of-conduct-hero' ); ?>
	<?php get_template_part( 'template-parts/code-of-conduct/sl-code-conduct-features' ); ?>
	<?php get_template_part( 'template-parts/code-of-conduct/sl-code-conduct-definition' ); ?>
	<?php get_template_part( 'template-parts/code-of-conduct/sl-code-conduct-matters' ); ?>
</main>

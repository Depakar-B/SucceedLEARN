<?php
/**
 * Code of Conduct — Hero Section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section
	class="sl-code-of-conduct-hero"
	aria-labelledby="sl-code-of-conduct-hero-title"
>
	<div class="container">

		<div class="sl-code-of-conduct-hero__grid">

			<!-- Hero Content -->
			<div class="sl-code-of-conduct-hero__content">

				<div class="sl-code-of-conduct-hero__breadcrumb">
					<span>
						<?php esc_html_e( 'Home / Code of Conduct', 'akaza-adventure' ); ?>
					</span>
				</div>

				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Interactive compliance learning', 'akaza-adventure' ); ?>
				</span>

				<h1 id="sl-code-of-conduct-hero-title">
					<?php esc_html_e( 'Interactive Code of Conduct training that turns policy into everyday behaviour', 'akaza-adventure' ); ?>
				</h1>

				<p class="sl-code-of-conduct-hero__lead">
					<?php
					esc_html_e(
						'Build a workplace where employees understand not only what your Code of Conduct says, but how to apply it when real situations arise.',
						'akaza-adventure'
					);
					?>
				</p>

				<div class="sl-code-of-conduct-hero__actions">

					<a
						class="sl-code-of-conduct-hero__button sl-code-of-conduct-hero__button--primary"
						href="#contact"
					>
						<?php esc_html_e( 'Book a Demo', 'akaza-adventure' ); ?>
					</a>

					<a
						class="sl-code-of-conduct-hero__button sl-code-of-conduct-hero__button--secondary"
						href="#preview"
					>
						<?php esc_html_e( 'Watch Course Preview', 'akaza-adventure' ); ?>
					</a>

					<a
						class="sl-code-of-conduct-hero__brochure"
						href="#brochure"
					>
						<?php esc_html_e( 'Download Brochure', 'akaza-adventure' ); ?>
					</a>

				</div>

			</div>


			<!-- Hero Visual -->
			<div class="sl-code-of-conduct-hero__visual">

				<!-- Image Placeholder -->
				<div class="sl-code-of-conduct-hero__image">

					<div class="sl-code-of-conduct-hero__image-placeholder">

						<span>
							<?php esc_html_e( 'IMAGE PLACEHOLDER', 'akaza-adventure' ); ?>
						</span>

						<small>
							<?php esc_html_e( 'Recommended: 900 × 800 px', 'akaza-adventure' ); ?>
						</small>

					</div>

				</div>


				<!-- Floating Label -->
				<div class="sl-code-of-conduct-hero__floating-label">

					<span class="sl-code-of-conduct-hero__status-dot"></span>

					<span>
						<?php esc_html_e( 'Real workplace decisions', 'akaza-adventure' ); ?>
					</span>

				</div>


				<!-- Interactive Assessment -->
				<div
					class="sl-code-of-conduct-hero__assessment"
					data-code-of-conduct-assessment
				>

					<div class="sl-code-of-conduct-hero__assessment-top">

						<span class="sl-code-of-conduct-hero__assessment-category">
							<?php esc_html_e( 'Gifts & Hospitality', 'akaza-adventure' ); ?>
						</span>

						<span class="sl-code-of-conduct-hero__assessment-label">
							<?php esc_html_e( 'Decision point', 'akaza-adventure' ); ?>
						</span>

					</div>


					<div class="sl-code-of-conduct-hero__question">
						<?php
						esc_html_e(
							'A supplier participating in a tender sends you an expensive gift. What should you do?',
							'akaza-adventure'
						);
						?>
					</div>


					<div class="sl-code-of-conduct-hero__options">

						<button
							type="button"
							class="sl-code-of-conduct-hero__option"
							data-answer="wrong"
						>
							<?php esc_html_e( 'Accept it — the tender decision is not final.', 'akaza-adventure' ); ?>
						</button>

						<button
							type="button"
							class="sl-code-of-conduct-hero__option"
							data-answer="correct"
						>
							<?php esc_html_e( 'Decline it and disclose the situation.', 'akaza-adventure' ); ?>
						</button>

						<button
							type="button"
							class="sl-code-of-conduct-hero__option"
							data-answer="wrong"
						>
							<?php esc_html_e( 'Accept it once the tender is complete.', 'akaza-adventure' ); ?>
						</button>

					</div>


					<div
						class="sl-code-of-conduct-hero__feedback"
						aria-live="polite"
					></div>

				</div>


				<!-- Floating Card 1 -->
				<div class="sl-code-of-conduct-hero__mini-card sl-code-of-conduct-hero__mini-card--one">

					<span class="sl-code-of-conduct-hero__mini-icon">
						✓
					</span>

					<div>
						<strong>
							<?php esc_html_e( 'Good decision', 'akaza-adventure' ); ?>
						</strong>

						<span>
							<?php esc_html_e( 'Protect integrity', 'akaza-adventure' ); ?>
						</span>
					</div>

				</div>


				<!-- Floating Card 2 -->
				<div class="sl-code-of-conduct-hero__mini-card sl-code-of-conduct-hero__mini-card--two">

					<span class="sl-code-of-conduct-hero__mini-number">
						3
					</span>

					<div>
						<strong>
							<?php esc_html_e( 'Decision points', 'akaza-adventure' ); ?>
						</strong>

						<span>
							<?php esc_html_e( 'Real workplace scenarios', 'akaza-adventure' ); ?>
						</span>
					</div>

				</div>

			</div>

		</div>

	</div>
</section>
<?php
/**
 * Code of Conduct — Why It Matters section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-code-conduct-matters" aria-labelledby="sl-code-conduct-matters-title">
	<div class="container">

		<div class="sl-code-conduct-matters__heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Why It Matters', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-code-conduct-matters-title">
				<?php esc_html_e( 'Why Code of Conduct Training Matters', 'akaza-adventure' ); ?>
			</h2>

			<p>
				<?php
				esc_html_e(
					'Employees make decisions every day that can affect colleagues, customers, business partners and the reputation of the organization.',
					'akaza-adventure'
				);
				?>
			</p>

			<p class="sl-code-conduct-matters__intro">
				<?php esc_html_e( 'Some decisions are obvious. Others are not.', 'akaza-adventure' ); ?>
			</p>
		</div>

		<div class="sl-code-conduct-matters__grid">

			<article class="sl-code-conduct-matters__card">
				<div class="sl-code-conduct-matters__icon" aria-hidden="true">
					<span>◆</span>
				</div>

				<p>
					<?php esc_html_e( 'Should an employee accept a gift from a supplier?', 'akaza-adventure' ); ?>
				</p>
			</article>

			<article class="sl-code-conduct-matters__card">
				<div class="sl-code-conduct-matters__icon" aria-hidden="true">
					<span>◆</span>
				</div>

				<p>
					<?php esc_html_e( 'What happens when a close relative applies for a position?', 'akaza-adventure' ); ?>
				</p>
			</article>

			<article class="sl-code-conduct-matters__card">
				<div class="sl-code-conduct-matters__icon" aria-hidden="true">
					<span>◆</span>
				</div>

				<p>
					<?php esc_html_e( 'Can confidential company information be entered into a public AI tool?', 'akaza-adventure' ); ?>
				</p>
			</article>

			<article class="sl-code-conduct-matters__card">
				<div class="sl-code-conduct-matters__icon" aria-hidden="true">
					<span>◆</span>
				</div>

				<p>
					<?php esc_html_e( 'Should an employee respond to a customer complaint on social media?', 'akaza-adventure' ); ?>
				</p>
			</article>

			<article class="sl-code-conduct-matters__card">
				<div class="sl-code-conduct-matters__icon" aria-hidden="true">
					<span>◆</span>
				</div>

				<p>
					<?php esc_html_e( 'What should someone do when they suspect misconduct but are not certain?', 'akaza-adventure' ); ?>
				</p>
			</article>

		</div>

		<div class="sl-code-conduct-matters__message">
			<div class="sl-code-conduct-matters__message-content">
				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Practical Decision-Making', 'akaza-adventure' ); ?>
				</span>

				<h3>
					<?php esc_html_e( 'A policy cannot anticipate every situation.', 'akaza-adventure' ); ?>
				</h3>

				<p>
					<?php
					esc_html_e(
						'Effective employee Code of Conduct training helps employees develop the judgement required to apply organisational values when situations are unclear.',
						'akaza-adventure'
					);
					?>
				</p>
			</div>

			<div class="sl-code-conduct-matters__cta">
				<a class="sl-code-conduct-matters__button" href="#contact">
					<?php esc_html_e( 'Explore Code of Conduct Training', 'akaza-adventure' ); ?>
				</a>
			</div>
		</div>

	</div>
</section>
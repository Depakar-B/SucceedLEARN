<?php
/**
 * SMCR Training for PE/VC Firms — hero section.
 *
 * Paste hero markup below.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

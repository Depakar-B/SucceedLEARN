﻿<?php
/**
 * Whistleblowing Training for PE/VC course page wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-course-page sl-course-page--whistleblowing-pe-vc">
	<?php get_template_part( 'template-parts/courses/whistleblowing-pe-vc/sl-whistleblowing-hero' ); ?>
</main>

﻿<?php
/**
 * Anti-Bribery and Anti-Corruption eLearning course page wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-course-page sl-course-page--anti-bribery-anti-corruption">
	<?php get_template_part( 'template-parts/courses/anti-bribery-anti-corruption/sl-anti-bribery-hero' ); ?>
</main>

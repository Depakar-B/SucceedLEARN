﻿<?php
/**
 * SMCR Training for PE/VC Firms course page wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-course-page sl-course-page--smcr-pe-vc">
	<?php get_template_part( 'template-parts/courses/smcr-pe-vc/sl-smcr-hero' ); ?>
</main>

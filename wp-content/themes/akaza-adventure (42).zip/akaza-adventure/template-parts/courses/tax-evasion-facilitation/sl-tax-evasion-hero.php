<?php
/**
 * Preventing the Facilitation of Tax Evasion Training — hero section.
 *
 * Paste hero markup below.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

﻿<?php
/**
 * Preventing the Facilitation of Tax Evasion Training course page wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-course-page sl-course-page--tax-evasion-facilitation">
	<?php get_template_part( 'template-parts/courses/tax-evasion-facilitation/sl-tax-evasion-hero' ); ?>
</main>

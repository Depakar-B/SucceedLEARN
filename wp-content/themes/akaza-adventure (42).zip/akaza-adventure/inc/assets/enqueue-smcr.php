﻿<?php
/**
 * SMCR Training for PE/VC Firms course marketing assets.
 *
 * CSS lives in assets/css/courses/smcr-pe-vc/
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue course foundation + per-section styles.
 */
function akaza_enqueue_smcr_assets() {
	akaza_enqueue_course_marketing_styles(
		'',
		array(
			'shared_sections' => false,
		)
	);

	$folder = 'courses/smcr-pe-vc';
	$deps   = array( 'akaza-course-global' );

	$sections = array(
		'sl-smcr-hero',
	);

	foreach ( $sections as $section ) {
		akaza_enqueue_theme_style(
			'akaza-' . $section,
			"{$folder}/{$section}.css",
			$deps
		);
	}
}

﻿<?php
/**
 * Whistleblowing Training for PE/VC course marketing assets.
 *
 * CSS lives in assets/css/courses/whistleblowing-pe-vc/
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue course foundation + per-section styles.
 */
function akaza_enqueue_whistleblowing_assets() {
	akaza_enqueue_course_marketing_styles(
		'',
		array(
			'shared_sections' => false,
		)
	);

	$folder = 'courses/whistleblowing-pe-vc';
	$deps   = array( 'akaza-course-global' );

	$sections = array(
		'sl-whistleblowing-hero',
	);

	foreach ( $sections as $section ) {
		akaza_enqueue_theme_style(
			'akaza-' . $section,
			"{$folder}/{$section}.css",
			$deps
		);
	}
}

﻿<?php
/**
 * Preventing the Facilitation of Tax Evasion Training course marketing assets.
 *
 * CSS lives in assets/css/courses/tax-evasion-facilitation/
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue course foundation + per-section styles.
 */
function akaza_enqueue_tax_evasion_assets() {
	akaza_enqueue_course_marketing_styles(
		'',
		array(
			'shared_sections' => false,
		)
	);

	$folder = 'courses/tax-evasion-facilitation';
	$deps   = array( 'akaza-course-global' );

	$sections = array(
		'sl-tax-evasion-hero',
	);

	foreach ( $sections as $section ) {
		akaza_enqueue_theme_style(
			'akaza-' . $section,
			"{$folder}/{$section}.css",
			$deps
		);
	}
}

<?php
/**
 * Gifts and Entertainment course marketing assets.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue shared course marketing styles for Gifts and Entertainment.
 */
function akaza_enqueue_gifts_entertainment_assets() {
	akaza_enqueue_course_marketing_styles( 'gifts-and-entertainment' );
}

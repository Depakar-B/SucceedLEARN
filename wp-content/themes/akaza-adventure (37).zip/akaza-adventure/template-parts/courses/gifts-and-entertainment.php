<?php
/**
 * Gifts and Entertainment course page wrapper.
 *
 * Add new section template-parts below the hero as you paste them.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-course-page sl-course-page--gifts-and-entertainment">
	<?php get_template_part( 'template-parts/courses/gifts-and-entertainment/hero' ); ?>
</main>

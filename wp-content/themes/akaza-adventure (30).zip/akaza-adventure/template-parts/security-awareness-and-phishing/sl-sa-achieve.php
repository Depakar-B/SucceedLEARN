<?php
/**
 * Security Awareness — What Can Your Organization Achieve?
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sa_outcomes = array(
	'Building stronger employee understanding of cybersecurity risks.',
	'Improving employees\' ability to recognise and respond to phishing and social engineering attempts.',
	'Reinforcing secure behaviours throughout the year.',
	'Identifying areas of potential human cyber risk through measurable data.',
	'Delivering targeted interventions where additional support is required.',
	'Creating greater visibility for security, compliance and leadership teams.',
	'Supporting security awareness and regulatory compliance initiatives.',
	'Building a culture in which employees understand their role in protecting organisational information.',
);
?>

<section
	class="sl-sa-achieve"
	id="what-can-your-organization-achieve"
	aria-labelledby="sl-sa-achieve-title"
>
	<div class="container">

		<div class="sl-sa-achieve__intro">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Measurable Security Behaviour Change', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-sa-achieve-title">
				<?php esc_html_e( 'What Can Your Organization', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'Achieve?', 'akaza-adventure' ); ?></span>
			</h2>

			<p>
				<?php esc_html_e( 'The objective of security awareness should extend beyond training completion, with an integrated behaviour and culture programme, organisations can work towards:', 'akaza-adventure' ); ?>
			</p>
		</div>

		<div class="sl-sa-achieve__grid">

			<?php foreach ( $sa_outcomes as $outcome_text ) : ?>

				<article class="sl-sa-achieve__card">
					<p class="sl-sa-achieve__text">
						<?php echo esc_html( $outcome_text ); ?>
					</p>
				</article>

			<?php endforeach; ?>

		</div>

	</div>
</section>

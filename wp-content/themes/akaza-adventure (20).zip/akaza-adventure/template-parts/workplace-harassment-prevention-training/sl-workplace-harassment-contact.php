<?php
/**
 * SucceedLEARN — Workplace Harassment Prevention
 *
 * Section: Contact / Request a Demo
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section
	class="sl-workplace-harassment-contact"
	id="contact"
	aria-labelledby="sl-workplace-harassment-contact-title"
>

	<div class="container">

		<div class="sl-workplace-harassment-contact__grid">

			<!-- =====================================
			     LEFT: CONTACT CONTENT
			===================================== -->

			<div class="sl-workplace-harassment-contact__content">

				<span class="sl-home-sub-heading">
					<?php
					esc_html_e(
						'Workplace Harassment Prevention Training',
						'akaza-adventure'
					);
					?>
				</span>

				<h2 id="sl-workplace-harassment-contact-title">
					<?php
					esc_html_e(
						'Give every employee the right answer to',
						'akaza-adventure'
					);
					?>
					<span>
						<?php
						esc_html_e(
							'“What happens next?”',
							'akaza-adventure'
						);
						?>
					</span>
				</h2>

				<div class="sl-workplace-harassment-contact__moments">

					<p>
						<strong>
							<?php
							esc_html_e(
								'An employee experiences unwelcome conduct.',
								'akaza-adventure'
							);
							?>
						</strong>
					</p>

					<p>
						<strong>
							<?php
							esc_html_e(
								'A witness is uncertain whether to intervene.',
								'akaza-adventure'
							);
							?>
						</strong>
					</p>

					<p>
						<strong>
							<?php
							esc_html_e(
								'A supervisor receives a disclosure.',
								'akaza-adventure'
							);
							?>
						</strong>
					</p>

					<p>
						<strong>
							<?php
							esc_html_e(
								'An Internal Committee receives a complaint.',
								'akaza-adventure'
							);
							?>
						</strong>
					</p>

				</div>

				<p class="sl-workplace-harassment-contact__lead">
					<?php
					esc_html_e(
						'Each moment requires different knowledge, and the response can shape what happens next.',
						'akaza-adventure'
					);
					?>
				</p>

				<p>
					<?php
					esc_html_e(
						'Give your workforce training designed for their region, role and responsibilities.',
						'akaza-adventure'
					);
					?>
				</p>


				<!-- =====================================
				     CONTACT DETAILS
				===================================== -->

				<div class="sl-workplace-harassment-contact__details">

					<a
						class="sl-workplace-harassment-contact__detail"
						href="mailto:sales@succeedtech.com"
					>
						<span class="sl-workplace-harassment-contact__detail-label">
							<?php
							esc_html_e(
								'Email',
								'akaza-adventure'
							);
							?>
						</span>

						<span class="sl-workplace-harassment-contact__detail-value">
							sales@succeedtech.com
						</span>
					</a>

					<a
						class="sl-workplace-harassment-contact__detail"
						href="https://wa.me/916362021778"
						target="_blank"
						rel="noopener noreferrer"
					>
						<span class="sl-workplace-harassment-contact__detail-label">
							<?php
							esc_html_e(
								'WhatsApp',
								'akaza-adventure'
							);
							?>
						</span>

						<span class="sl-workplace-harassment-contact__detail-value">
							+91 63620 21778
						</span>
					</a>

				</div>

			</div>


			<!-- =====================================
			     RIGHT: COMMON CONTACT FORM
			===================================== -->

			<div class="sl-workplace-harassment-contact__form-wrap">

				<div class="sl-home-form-wrapper sl-home-form-wrapper--slim">

					<?php
					$form_title     = __( 'Request a Demo', 'akaza-adventure' );
					$form_shortcode = sprintf(
						'[contact_form form_variant="course" title="%s"]',
						esc_attr( $form_title )
					);

					if ( shortcode_exists( 'contact_form' ) ) {

						echo do_shortcode( $form_shortcode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

					} elseif ( shortcode_exists( 'succeedlearn_course_form' ) ) {

						echo do_shortcode(
							sprintf(
								'[succeedlearn_course_form title="%s"]',
								esc_attr( $form_title )
							)
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

					}
					?>

				</div>

			</div>

		</div>

	</div>

</section>
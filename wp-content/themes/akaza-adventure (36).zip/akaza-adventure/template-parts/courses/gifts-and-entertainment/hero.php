<?php
/**
 * Gifts and Entertainment — hero section.
 *
 * Paste hero markup below (or call template-parts/courses/components/hero like defensive-driving).
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<?php
/**
 * Anti-Bribery and Anti-Corruption eLearning course marketing assets.
 *
 * CSS lives in assets/css/courses/anti-bribery-anti-corruption/
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue course foundation + per-section styles.
 */
function akaza_enqueue_anti_bribery_assets() {
	akaza_enqueue_course_marketing_styles(
		'',
		array(
			'shared_sections' => false,
		)
	);

	$folder = 'courses/anti-bribery-anti-corruption';
	$deps   = array( 'akaza-course-global' );

	$sections = array(
		'sl-anti-bribery-hero',
	);

	foreach ( $sections as $section ) {
		akaza_enqueue_theme_style(
			'akaza-' . $section,
			"{$folder}/{$section}.css",
			$deps
		);
	}
}

<?php
/**
 * Anti-Bribery and Anti-Corruption eLearning — hero section.
 *
 * Paste hero markup below.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

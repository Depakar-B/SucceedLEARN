(function () {
	'use strict';

	var header = document.getElementById('sl-csa-header');
	if (!header) {
		return;
	}

	var links = header.querySelectorAll('a[href^="#"]');
	if (!links.length) {
		return;
	}

	function getScrollOffset() {
		var value = getComputedStyle(document.documentElement).getPropertyValue('--sl-csa-scroll-offset');
		var parsed = parseInt(value, 10);
		return Number.isFinite(parsed) ? parsed : 128;
	}

	function scrollToHash(hash, pushState) {
		if (!hash || hash === '#') {
			return;
		}

		var id = hash.slice(1);
		var target = document.getElementById(id);
		if (!target) {
			return;
		}

		var top = target.getBoundingClientRect().top + window.pageYOffset - getScrollOffset();

		window.scrollTo({
			top: Math.max(top, 0),
			behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
		});

		if (pushState !== false && history.replaceState) {
			history.replaceState(null, '', hash);
		}

		target.setAttribute('tabindex', '-1');
		target.focus({ preventScroll: true });
	}

	links.forEach(function (link) {
		link.addEventListener('click', function (event) {
			var href = link.getAttribute('href');
			if (!href || href.charAt(0) !== '#') {
				return;
			}

			var target = document.getElementById(href.slice(1));
			if (!target) {
				return;
			}

			event.preventDefault();
			scrollToHash(href, true);
		});
	});

	if (window.location.hash) {
		window.requestAnimationFrame(function () {
			scrollToHash(window.location.hash, false);
		});
	}
})();

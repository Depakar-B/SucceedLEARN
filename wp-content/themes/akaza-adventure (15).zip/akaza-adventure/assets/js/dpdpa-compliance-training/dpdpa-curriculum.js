/**
 * DPDPA curriculum accordion toggle.
 */
(function () {
	"use strict";

	function initCurriculum() {
		var toggle = document.querySelector(".sl-dpdpa-curriculum__toggle");
		var content = document.querySelector(".sl-dpdpa-curriculum__content");
		var panel = document.getElementById("dpdpa-curriculum-panel");

		if (!toggle || !content) {
			return;
		}

		toggle.addEventListener("click", function () {
			var isOpen = toggle.getAttribute("aria-expanded") === "true";
			toggle.setAttribute("aria-expanded", isOpen ? "false" : "true");
			content.toggleAttribute("hidden", isOpen);
			if (panel) {
				panel.classList.toggle("is-open", !isOpen);
			}
		});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", initCurriculum);
	} else {
		initCurriculum();
	}
})();

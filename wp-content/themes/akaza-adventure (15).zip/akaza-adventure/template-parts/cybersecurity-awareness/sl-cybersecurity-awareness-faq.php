<?php
/**
 * Cybersecurity Awareness — FAQ section.
 *
 * Uses the shared global FAQ component (global-faq.css / global-faq.js).
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$faq_items = array(
	array(
		'question' => __( 'Is this an annual subscription?', 'akaza-adventure' ),
		'answer'   => __( 'No, not under this special offer. The offer covers the Cybersecurity Awareness Month campaign for October 2026. If you extend the service beyond October, you will receive a 50% discount on the first-year extension.', 'akaza-adventure' ),
	),
	array(
		'question' => __( 'Does ‘up to 10 emails per user’ mean the same 10 simulations must be sent to everyone?', 'akaza-adventure' ),
		'answer'   => __( 'No. Administrators can choose from a library of 300+ phishing templates and assign different simulations to different departments or employee groups. For example, the Finance team can receive 10 finance-relevant campaigns, while another department can receive a different set of templates. Each individual end user will receive a maximum of 10 simulation emails overall during the campaign.', 'akaza-adventure' ),
	),
	array(
		'question' => __( 'Are there unlimited users?', 'akaza-adventure' ),
		'answer'   => __( 'There is no separate per-user charge within the selected employee band. Choose the band that matches the number of active participants in your business.', 'akaza-adventure' ),
	),
	array(
		'question' => __( 'Is Microsoft 365 integration included?', 'akaza-adventure' ),
		'answer'   => __( 'Standard support for one Microsoft 365 tenant is included. Custom development, complex tenant remediation and third-party integrations are outside the promotional package.', 'akaza-adventure' ),
	),
	array(
		'question' => __( 'What is PhishCue?', 'akaza-adventure' ),
		'answer'   => __( 'PhishCue is SucceedLEARN’s reported-email solution. It gives employees a simple way to report suspicious emails and provides security teams with one place to review and manage those reports.', 'akaza-adventure' ),
	),
	array(
		'question' => __( 'Can different phishing simulations be used for different departments?', 'akaza-adventure' ),
		'answer'   => __( 'Yes. Administrators can select department-relevant templates from the library, so teams such as Finance, HR and IT can receive simulations that reflect the risks they are most likely to face.', 'akaza-adventure' ),
	),
);

get_template_part(
	'template-parts/global/faq',
	null,
	array(
		'id'            => 'frequently-asked-questions',
		'section_class' => 'sl-csa-faq',
		'eyebrow'       => __( 'FAQ', 'akaza-adventure' ),
		'title_html'    => __( 'Frequently Asked Questions About <span>Cybersecurity Awareness Month</span>', 'akaza-adventure' ),
		'description'   => __( 'Need to discuss your environment or campaign scope? Our team can walk you through it.', 'akaza-adventure' ),
		'cta_text'      => __( 'Speak to a specialist', 'akaza-adventure' ),
		'cta_url'       => '#contact',
		'items'         => $faq_items,
		'schema'        => true,
	)
);

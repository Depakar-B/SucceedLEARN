<?php
/**
 * SucceedLEARN — Cybersecurity Awareness Month Hero.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-cyber-awareness-hero" aria-labelledby="sl-cyber-awareness-hero-title">
	<div class="container">

		<div class="sl-cyber-awareness-hero__grid">

			<div class="sl-cyber-awareness-hero__content">

				<span class="sl-home-sub-heading">
					<?php
					echo wp_kses(
						__( 'Special offerfor October 2026', 'akaza-adventure' ),
						array( 'span' => array() )
					);
					?>
				</span>

				<h1 id="sl-cyber-awareness-hero-title">
					<?php
					echo wp_kses(
						__( 'Cybersecurity Awareness Month <span>October 2026</span>', 'akaza-adventure' ),
						array( 'span' => array() )
					);
					?>
				</h1>

				<h2 class="sl-cyber-awareness-hero__tagline">
					<?php esc_html_e( 'Train your people. Test their readiness. Strengthen your human firewall.', 'akaza-adventure' ); ?>
				</h2>

				<p class="sl-cyber-awareness-hero__description">
					<?php esc_html_e( 'Turn Cybersecurity Awareness Month into measurable action. Combine practical employee training, realistic phishing simulations, simple suspicious-email reporting and clear campaign results in one coordinated experience.', 'akaza-adventure' ); ?>
				</p>

				<div class="sl-cyber-awareness-hero__actions">

					<a
						class="sl-cyber-awareness-hero__cta sl-cyber-awareness-hero__cta--primary"
						href="#contact"
					>
						<?php esc_html_e( 'Buy the special offer', 'akaza-adventure' ); ?>

						<svg
							viewBox="0 0 24 24"
							aria-hidden="true"
							focusable="false"
						>
							<path d="M5 12h13M13 6l6 6-6 6" />
						</svg>
					</a>

					<a
						class="sl-cyber-awareness-hero__cta sl-cyber-awareness-hero__cta--secondary"
						href="mailto:info@succeedtech.com"
					>
						<?php esc_html_e( 'Book a demo', 'akaza-adventure' ); ?>
					</a>

				</div>

			</div>

			<div class="sl-cyber-awareness-hero__visual">

				<div class="sl-cyber-awareness-hero__dashboard">

					<div class="sl-cyber-awareness-hero__dashboard-icon" aria-hidden="true">
						<svg viewBox="0 0 64 64">
							<rect x="17" y="30" width="8" height="20" rx="2" />
							<rect x="28" y="20" width="8" height="30" rx="2" />
							<rect x="39" y="26" width="8" height="24" rx="2" />
						</svg>
					</div>

					<span class="sl-cyber-awareness-hero__dashboard-label">
						<?php esc_html_e( 'IMAGE PLACEHOLDER', 'akaza-adventure' ); ?>
					</span>

					<span class="sl-cyber-awareness-hero__dashboard-text">
						<?php esc_html_e( 'Employees with cybersecurity dashboard', 'akaza-adventure' ); ?>
					</span>

				</div>

				<div class="sl-cyber-awareness-hero__notification">

					<div class="sl-cyber-awareness-hero__notification-icon" aria-hidden="true">
						<svg viewBox="0 0 24 24">
							<path d="M3 5h18v14H3z" />
							<path d="m4 7 8 6 8-6" />
						</svg>
					</div>

					<div class="sl-cyber-awareness-hero__notification-copy">
						<strong>
							<?php esc_html_e( 'Suspicious email reported', 'akaza-adventure' ); ?>
						</strong>

						<span>
							<?php esc_html_e( 'PhishCue review started', 'akaza-adventure' ); ?>
						</span>
					</div>

					<div class="sl-cyber-awareness-hero__notification-status" aria-hidden="true">
						<svg viewBox="0 0 24 24">
							<path d="M12 3 14 5.2l3-.1.9 2.8 2.5 1.5-1.1 2.8 2.3 1.9-.8 2.8-2.9-.2-2.9 1.1-2.3-1.8-2.1 1-2.8-2.5-1.5-3 .1L12 3Z" />
							<path d="m8 12 2.5 2.5L16 9" />
						</svg>
					</div>

				</div>

			</div>

		</div>

	</div>
</section>

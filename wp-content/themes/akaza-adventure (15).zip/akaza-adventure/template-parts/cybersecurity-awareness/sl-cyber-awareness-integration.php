<?php
/**
 * Cybersecurity Awareness — Integration Section
 *
 * @package Akaza_Adventure
 */
?>

<section
    class="sl-cyber-awareness-integration"
    aria-labelledby="sl-cyber-awareness-integration-title"
>
    <div class="container">

        <div class="sl-cyber-awareness-integration__grid">

            <!-- Image -->
            <div class="sl-cyber-awareness-integration__visual">

                <div
                    class="sl-cyber-awareness-integration__image-placeholder"
                    role="img"
                    aria-label="<?php esc_attr_e( 'Image placeholder', 'akaza-adventure' ); ?>"
                >

                    <span
                        class="sl-cyber-awareness-integration__placeholder-icon"
                        aria-hidden="true"
                    >
                        <svg
                            width="44"
                            height="44"
                            viewBox="0 0 44 44"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M11 34V25"
                                stroke="currentColor"
                                stroke-width="3"
                                stroke-linecap="round"
                            />

                            <path
                                d="M22 34V16"
                                stroke="currentColor"
                                stroke-width="3"
                                stroke-linecap="round"
                            />

                            <path
                                d="M33 34V21"
                                stroke="currentColor"
                                stroke-width="3"
                                stroke-linecap="round"
                            />
                        </svg>
                    </span>

                    <span class="sl-cyber-awareness-integration__placeholder-label">
                        <?php esc_html_e( 'Image Placeholder', 'akaza-adventure' ); ?>
                    </span>

                </div>

            </div>


            <!-- Content -->
            <div class="sl-cyber-awareness-integration__content">

                <div class="sl-cyber-awareness-integration__heading">

                    <span class="sl-home-sub-heading">
                        <?php esc_html_e( 'Free Integration Setup', 'akaza-adventure' ); ?>
                    </span>

                    <h2 id="sl-cyber-awareness-integration-title">
                        <?php
                        echo wp_kses(
                            __( 'Built to work with your <span>Microsoft environment.</span>', 'akaza-adventure' ),
                            array( 'span' => array() )
                        );
                        ?>
                    </h2>

                    <p>
                        <?php esc_html_e( 'Connect the campaign with the enterprise tools your team already uses. Standard integration setup is included at no additional cost.', 'akaza-adventure' ); ?>
                    </p>

                </div>


                <!-- Integration list -->
                <div class="sl-cyber-awareness-integration__list">

                    <div class="sl-cyber-awareness-integration__item">

                        <div class="sl-cyber-awareness-integration__item-title">
                            <?php esc_html_e( 'Integrations', 'akaza-adventure' ); ?>
                        </div>

                        <div class="sl-cyber-awareness-integration__item-text">
                            <?php esc_html_e( 'Free integration setup with your favourite enterprise tools', 'akaza-adventure' ); ?>
                        </div>

                    </div>


                    <div class="sl-cyber-awareness-integration__item">

                        <div class="sl-cyber-awareness-integration__item-title">
                            <?php esc_html_e( 'SSO', 'akaza-adventure' ); ?>
                        </div>

                        <div class="sl-cyber-awareness-integration__item-text">
                            <?php esc_html_e( 'Entra ID, OneLogin, Okta, JumpCloud and Google Workspace', 'akaza-adventure' ); ?>
                        </div>

                    </div>


                    <div class="sl-cyber-awareness-integration__item">

                        <div class="sl-cyber-awareness-integration__item-title">
                            <?php esc_html_e( 'HRIS Systems', 'akaza-adventure' ); ?>
                        </div>

                        <div class="sl-cyber-awareness-integration__item-text">
                            <?php esc_html_e( 'Darwinbox, Keka, Workday and more', 'akaza-adventure' ); ?>
                        </div>

                    </div>


                    <div class="sl-cyber-awareness-integration__item">

                        <div class="sl-cyber-awareness-integration__item-title">
                            <?php esc_html_e( 'GRC Systems', 'akaza-adventure' ); ?>
                        </div>

                        <div class="sl-cyber-awareness-integration__item-text">
                            <?php esc_html_e( 'Vanta customers receive a 50% discount on the price', 'akaza-adventure' ); ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>
</section>
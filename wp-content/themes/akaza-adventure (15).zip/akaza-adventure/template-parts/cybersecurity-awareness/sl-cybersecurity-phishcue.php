<?php
/**
 * Cybersecurity Awareness — PhishCue Section
 *
 * @package Akaza_Adventure
 */
?>

<section
    class="sl-cyber-awareness-phishcue"
    id="phishcue"
    aria-labelledby="sl-cyber-awareness-phishcue-title"
>
    <div class="container">

        <div class="sl-cyber-awareness-phishcue__grid">

            <!-- Content -->
            <div class="sl-cyber-awareness-phishcue__content">

                <span class="sl-home-sub-heading">
                    <?php esc_html_e( 'PhishCue', 'akaza-adventure' ); ?>
                </span>


                <div class="sl-cyber-awareness-phishcue__heading">

                    <h2 id="sl-cyber-awareness-phishcue-title">
                        <?php
                        echo wp_kses(
                            __( 'When an employee spots a suspicious email, <span>what happens next?</span>', 'akaza-adventure' ),
                            array( 'span' => array() )
                        );
                        ?>
                    </h2>

                    <p>
                        PhishCue gives employees a simple way to report suspicious
                        emails and helps security teams review and manage those
                        reports in one place.
                    </p>

                </div>


                <!-- Feature checklist -->
                <ul class="sl-cyber-awareness-phishcue__features">

                    <li class="sl-cyber-awareness-phishcue__feature">
                        <span
                            class="sl-cyber-awareness-phishcue__check"
                            aria-hidden="true"
                        >
                            <svg
                                width="15"
                                height="15"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M5 12.5L9.2 16.5L19 6.5"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                        </span>

                        <span>Simple Outlook reporting workflow</span>
                    </li>


                    <li class="sl-cyber-awareness-phishcue__feature">
                        <span
                            class="sl-cyber-awareness-phishcue__check"
                            aria-hidden="true"
                        >
                            <svg
                                width="15"
                                height="15"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M5 12.5L9.2 16.5L19 6.5"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                        </span>

                        <span>Central collection of reported emails</span>
                    </li>


                    <li class="sl-cyber-awareness-phishcue__feature">
                        <span
                            class="sl-cyber-awareness-phishcue__check"
                            aria-hidden="true"
                        >
                            <svg
                                width="15"
                                height="15"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M5 12.5L9.2 16.5L19 6.5"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                        </span>

                        <span>Header, link and attachment analysis</span>
                    </li>


                    <li class="sl-cyber-awareness-phishcue__feature">
                        <span
                            class="sl-cyber-awareness-phishcue__check"
                            aria-hidden="true"
                        >
                            <svg
                                width="15"
                                height="15"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M5 12.5L9.2 16.5L19 6.5"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                        </span>

                        <span>Message classification and tracking</span>
                    </li>


                    <li class="sl-cyber-awareness-phishcue__feature">
                        <span
                            class="sl-cyber-awareness-phishcue__check"
                            aria-hidden="true"
                        >
                            <svg
                                width="15"
                                height="15"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M5 12.5L9.2 16.5L19 6.5"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                        </span>

                        <span>Automated employee confirmation</span>
                    </li>


                    <li class="sl-cyber-awareness-phishcue__feature">
                        <span
                            class="sl-cyber-awareness-phishcue__check"
                            aria-hidden="true"
                        >
                            <svg
                                width="15"
                                height="15"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M5 12.5L9.2 16.5L19 6.5"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                        </span>

                        <span>Security-team review dashboard</span>
                    </li>

                </ul>


                <!-- CTA -->
                <a
                    class="sl-cyber-awareness-phishcue__cta"
                    href="#contact"
                >
                    <span>Explore PhishCue in a demo</span>

                    <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        aria-hidden="true"
                    >
                        <path
                            d="M5 12H19"
                            stroke="currentColor"
                            stroke-width="2"
                            stroke-linecap="round"
                        />
                        <path
                            d="M13 6L19 12L13 18"
                            stroke="currentColor"
                            stroke-width="2"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        />
                    </svg>
                </a>

            </div>


            <!-- Image / Visual -->
            <div class="sl-cyber-awareness-phishcue__visual">

                <div
                    class="sl-cyber-awareness-phishcue__image-placeholder"
                    role="img"
                    aria-label="Image placeholder"
                >

                    <span
                        class="sl-cyber-awareness-phishcue__placeholder-icon"
                        aria-hidden="true"
                    >
                        <svg
                            width="46"
                            height="46"
                            viewBox="0 0 46 46"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M12 35V25"
                                stroke="currentColor"
                                stroke-width="3"
                                stroke-linecap="round"
                            />

                            <path
                                d="M23 35V17"
                                stroke="currentColor"
                                stroke-width="3"
                                stroke-linecap="round"
                            />

                            <path
                                d="M34 35V22"
                                stroke="currentColor"
                                stroke-width="3"
                                stroke-linecap="round"
                            />
                        </svg>
                    </span>

                    <span class="sl-cyber-awareness-phishcue__placeholder-label">
                        IMAGE PLACEHOLDER
                    </span>

                </div>

            </div>

        </div>

    </div>
</section>
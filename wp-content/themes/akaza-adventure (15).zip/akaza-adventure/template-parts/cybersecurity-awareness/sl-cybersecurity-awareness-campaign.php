<?php
/**
 * Cybersecurity Awareness Campaign Section
 *
 * @package Akaza_Adventure
 */
?>

<section
    class="sl-cybersecurity-campaign"
    id="campaign"
    aria-labelledby="sl-cybersecurity-campaign-title"
>
    <div class="container">

        <!-- Section Intro -->
        <div class="sl-cybersecurity-campaign__heading">

            <div class="sl-cybersecurity-campaign__heading-content">
                <span class="sl-home-sub-heading">
                    <?php esc_html_e( 'One Complete Campaign', 'akaza-adventure' ); ?>
                </span>

                <h2 id="sl-cybersecurity-campaign-title">
                    <?php
                    echo wp_kses(
                        __( 'From awareness to <span>measurable action</span>', 'akaza-adventure' ),
                        array( 'span' => array() )
                    );
                    ?>
                </h2>
            </div>

            <p class="sl-cybersecurity-campaign__intro-text">
                <?php
                esc_html_e(
                    'Learning, testing and active email reporting — delivered as one coordinated Cybersecurity Awareness Month campaign.',
                    'akaza-adventure'
                );
                ?>
            </p>

        </div>


        <!-- Campaign Row 01 -->
        <div class="sl-cybersecurity-campaign__row">

            <!-- Content -->
            <div class="sl-cybersecurity-campaign__content">

                <span class="sl-cybersecurity-campaign__number">
                    <?php esc_html_e( '01', 'akaza-adventure' ); ?>
                </span>

                <h3>
                    <?php esc_html_e( 'Comprehensive security awareness training', 'akaza-adventure' ); ?>
                </h3>

                <p>
                    <?php
                    esc_html_e(
                        'Equip employees to identify common cyber risks, verify unusual requests, protect business information and make safer decisions in everyday work.',
                        'akaza-adventure'
                    );
                    ?>
                </p>

                <div class="sl-cybersecurity-campaign__checklist">

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Phishing & spear phishing', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Business email compromise', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'QR-code phishing', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Passwords & MFA', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Ransomware & malware', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Microsoft 365 safety', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Remote & mobile security', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Secure use of AI', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Data protection', 'akaza-adventure' ); ?></span>
                    </div>

                    <div class="sl-cybersecurity-campaign__check-item">
                        <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                            <svg viewBox="0 0 16 16" role="img">
                                <path d="M3 8.5 6.2 12 13 4.5" />
                            </svg>
                        </span>
                        <span><?php esc_html_e( 'Reporting suspicious activity', 'akaza-adventure' ); ?></span>
                    </div>

                </div>

            </div>


            <!-- Image -->
            <div class="sl-cybersecurity-campaign__media">
                <div class="sl-cybersecurity-campaign__image-placeholder">
                    <span class="sl-cybersecurity-campaign__image-icon" aria-hidden="true">
                        <svg viewBox="0 0 48 48" role="img">
                            <path d="M14 38V25" />
                            <path d="M24 38V14" />
                            <path d="M34 38V20" />
                        </svg>
                    </span>

                    <span class="sl-cybersecurity-campaign__image-label">
                        <?php esc_html_e( 'IMAGE PLACEHOLDER', 'akaza-adventure' ); ?>
                    </span>

                    <span class="sl-cybersecurity-campaign__image-caption">
                        <?php esc_html_e( 'Training interface or employee learning image', 'akaza-adventure' ); ?>
                    </span>
                </div>
            </div>

        </div>


        <!-- Campaign Row 02 -->
        <div class="sl-cybersecurity-campaign__row sl-cybersecurity-campaign__row--reverse">

            <!-- Image -->
            <div class="sl-cybersecurity-campaign__media">
                <div class="sl-cybersecurity-campaign__image-placeholder">
                    <span class="sl-cybersecurity-campaign__image-icon" aria-hidden="true">
                        <svg viewBox="0 0 48 48" role="img">
                            <path d="M14 38V25" />
                            <path d="M24 38V14" />
                            <path d="M34 38V20" />
                        </svg>
                    </span>

                    <span class="sl-cybersecurity-campaign__image-label">
                        <?php esc_html_e( 'IMAGE PLACEHOLDER', 'akaza-adventure' ); ?>
                    </span>

                    <span class="sl-cybersecurity-campaign__image-caption">
                        <?php esc_html_e( 'Phishing simulation campaign dashboard', 'akaza-adventure' ); ?>
                    </span>
                </div>
            </div>


            <!-- Content -->
            <div class="sl-cybersecurity-campaign__content">

                <span class="sl-cybersecurity-campaign__number">
                    <?php esc_html_e( '02', 'akaza-adventure' ); ?>
                </span>

                <h3>
                    <?php esc_html_e( 'Realistic phishing simulations', 'akaza-adventure' ); ?>
                </h3>

                <p>
                    <?php
                    esc_html_e(
                        'Test how employees respond to realistic but controlled phishing scenarios. Each simulation is approved in advance, safely delivered and measured without collecting genuine passwords.',
                        'akaza-adventure'
                    );
                    ?>
                </p>


                <!-- Phishing Checklist -->
                <div class="sl-cybersecurity-campaign__checklist">

                    <?php
                    $phishing_topics = array(
                        'Link-click phishing',
                        'Credential harvesting',
                        'Malicious attachments',
                        'QR-code phishing',
                        'Reply-to-email attacks',
                        'Business email compromise',
                        'Spear-phishing scenarios',
                        'Executive impersonation',
                    );
                    ?>

                    <?php foreach ( $phishing_topics as $topic ) : ?>
                        <div class="sl-cybersecurity-campaign__check-item">
                            <span class="sl-cybersecurity-campaign__check-icon" aria-hidden="true">
                                <svg viewBox="0 0 16 16" role="img">
                                    <circle cx="8" cy="8" r="5.5" />
                                    <circle cx="8" cy="8" r="1.5" />
                                </svg>
                            </span>

                            <span>
                                <?php echo esc_html( $topic ); ?>
                            </span>
                        </div>
                    <?php endforeach; ?>

                </div>

            </div>

        </div>

    </div>
</section>
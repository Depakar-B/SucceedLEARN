<?php
/**
 * Security Awareness — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'eyebrow' => __( 'By Solution', 'akaza-adventure' ),
		'title'   => __( 'Security Awareness', 'akaza-adventure' ),
		'lead'    => __( 'Reduce human cyber risk with engaging security awareness training.', 'akaza-adventure' ),
	)
);

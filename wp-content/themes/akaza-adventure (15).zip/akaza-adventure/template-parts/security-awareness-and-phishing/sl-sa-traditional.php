<?php
/**
 * Security Awareness — Why traditional security awareness falls short.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section
	class="sl-sa-traditional"
	id="traditional-security-awareness"
	aria-labelledby="sl-sa-traditional-title"
>

	<div class="container">

		<div class="sl-sa-traditional__content">

			<div class="sl-sa-traditional__text">

				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Moving Beyond Annual Training', 'akaza-adventure' ); ?>
				</span>

				<h2 id="sl-sa-traditional-title">
					<?php esc_html_e( 'Why Traditional Security Awareness', 'akaza-adventure' ); ?>
					<span><?php esc_html_e( 'Falls Short', 'akaza-adventure' ); ?></span>
				</h2>

				<p>
					<?php esc_html_e(
						'Annual awareness sessions often become a compliance exercise rather than a meaningful behaviour change initiative. Employees forget what they learned, phishing threats continue to evolve, and organisations struggle to measure whether awareness programmes are genuinely reducing risk.',
						'akaza-adventure'
					); ?>
				</p>

				<p>
					<?php esc_html_e(
						'Building a security-conscious workforce requires continuous learning, regular reinforcement, realistic simulations, measurable outcomes, and leadership visibility — not a once-a-year training event.',
						'akaza-adventure'
					); ?>
				</p>

			</div>

			<div class="sl-sa-traditional__visual">

				<div
					class="sl-sa-traditional__image-placeholder"
					role="img"
					aria-label="<?php esc_attr_e( 'Security awareness traditional training image placeholder', 'akaza-adventure' ); ?>"
				>
					<span class="sl-sa-traditional__image-size">
						<?php esc_html_e( 'Image: 700 × 520 px', 'akaza-adventure' ); ?>
					</span>

					<span class="sl-sa-traditional__image-note">
						<?php esc_html_e( 'Traditional Security Awareness Image', 'akaza-adventure' ); ?>
					</span>
				</div>

			</div>

		</div>

	</div>

</section>
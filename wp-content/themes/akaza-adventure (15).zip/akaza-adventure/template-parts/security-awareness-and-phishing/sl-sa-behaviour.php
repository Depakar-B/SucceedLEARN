<?php
/**
 * Security Awareness — From Awareness to Behaviour Change.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$behaviour_steps = array(
	array(
		'number' => '01',
		'title'  => 'Learn',
		'text'   => 'through structured security awareness training with S-Aware.',
	),
	array(
		'number' => '02',
		'title'  => 'Reinforce',
		'text'   => 'key concepts throughout the year with S-Bytes and S-Sign.',
	),
	array(
		'number' => '03',
		'title'  => 'Practise',
		'text'   => 'responses to realistic cyber threats through S-Phish and S-Play.',
	),
	array(
		'number' => '04',
		'title'  => 'Measure',
		'text'   => 'engagement, performance and behavioural indicators through S-Metrics.',
	),
	array(
		'number' => '05',
		'title'  => 'Connect',
		'text'   => 'the programme with your broader learning and technology environment through S-Sync.',
	),
);
?>

<section class="sl-sa-behaviour" id="from-awareness-to-behaviour-change">

	<div class="container">

		<div class="sl-sa-behaviour__header">

			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'CONTINUOUS SECURITY BEHAVIOUR CHANGE', 'akaza-adventure' ); ?>
			</span>

			<h2>
				<?php esc_html_e( 'Connect your', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'systems', 'akaza-adventure' ); ?></span><?php esc_html_e( '. Simplify', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'administration', 'akaza-adventure' ); ?></span><?php esc_html_e( '. Scale your', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'awareness programme', 'akaza-adventure' ); ?></span><?php esc_html_e( '.', 'akaza-adventure' ); ?>
			</h2>
            <h3>
                <?php esc_html_e( 'From Awareness to Behaviour Change', 'akaza-adventure' ); ?>
            </h3>

			<p>
				<?php esc_html_e(
					'A strong security culture is not created through a single intervention. It develops through repeated experiences that help employees learn, practise, recognise, respond and improve.',
					'akaza-adventure'
				); ?>
			</p>

			<p>
				<?php esc_html_e(
					'The SucceedLEARN Security Behaviour & Culture Suite brings these experiences together into one continuous cycle.',
					'akaza-adventure'
				); ?>
			</p>

		</div>

		<div class="sl-sa-behaviour__steps">

			<?php foreach ( $behaviour_steps as $index => $step ) : ?>

				<article class="sl-sa-behaviour__card">

					<div class="sl-sa-behaviour__card-top">

						<span class="sl-sa-behaviour__number">
							<?php echo esc_html( $step['number'] ); ?>
						</span>

						<?php if ( $index < count( $behaviour_steps ) - 1 ) : ?>
							<span class="sl-sa-behaviour__line" aria-hidden="true"></span>
						<?php endif; ?>

					</div>

					<div class="sl-sa-behaviour__card-body">

						<h3>
							<?php echo esc_html( $step['title'] ); ?>
						</h3>

						<p>
							<?php echo esc_html( $step['text'] ); ?>
						</p>

					</div>

				</article>

			<?php endforeach; ?>

		</div>

		<div class="sl-sa-behaviour__closing">

			<span class="sl-sa-behaviour__closing-label">
				<?php esc_html_e( 'A CONNECTED APPROACH', 'akaza-adventure' ); ?>
			</span>

			<p>
				<?php esc_html_e(
					'Instead of managing disconnected awareness activities, organisations can build a coordinated programme in which each intervention supports the next.',
					'akaza-adventure'
				); ?>
			</p>

		</div>

	</div>

</section>
<?php
/**
 * Security Awareness — Platform overview section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section
	class="sl-sa-platform"
	id="security-awareness-suite"
	aria-labelledby="sl-sa-platform-title"
>

	<div class="container">

		<div class="sl-sa-platform__grid">

			<div class="sl-sa-platform__media">

				<div
					class="sl-sa-platform__image-placeholder"
					role="img"
					aria-label="<?php esc_attr_e( 'Security awareness platform image placeholder', 'akaza-adventure' ); ?>"
				>
					<span class="sl-sa-platform__image-size">
						<?php esc_html_e( 'Image: 720 × 760 px', 'akaza-adventure' ); ?>
					</span>

					<span class="sl-sa-platform__image-note">
						<?php esc_html_e( 'Security Awareness Platform Image', 'akaza-adventure' ); ?>
					</span>
				</div>

			</div>

			<div class="sl-sa-platform__content">

				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Security Behaviour Platform', 'akaza-adventure' ); ?>
				</span>

			<h2 id="sl-sa-platform-title">
				<?php esc_html_e( 'One Platform.', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'Continuous Security Behaviour Change.', 'akaza-adventure' ); ?></span>
			</h2>

				<p class="sl-sa-platform__lead">
					<?php esc_html_e(
						'Annual awareness training alone is no longer enough to address today’s evolving cyber threats. Employees require continuous reinforcement, practical learning experiences, phishing simulations and real-time behavioural insights to develop lasting secure habits.',
						'akaza-adventure'
					); ?>
				</p>

				<p>
					<?php esc_html_e(
						'The SucceedLEARN Security Behaviour & Culture Suite brings together everything organisations need—from awareness courses and phishing simulations to microlearning, gamification, analytics and awareness campaigns—through a single, integrated platform designed to reduce human cyber risk.',
						'akaza-adventure'
					); ?>
				</p>

			</div>

		</div>

	</div>

</section>
<?php
/**
 * Security Awareness — Security Awareness & Compliance Requirements.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section
	class="sl-sa-compliance"
	id="security-awareness-compliance"
	aria-labelledby="sl-sa-compliance-title"
>

	<div class="container">

		<div class="sl-sa-compliance__content">

			<div class="sl-sa-compliance__text">

				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'Security, Awareness & Compliance', 'akaza-adventure' ); ?>
				</span>

				<h2 id="sl-sa-compliance-title">
					<?php esc_html_e( 'Support', 'akaza-adventure' ); ?>
					<span><?php esc_html_e( 'Security Awareness & Compliance Requirements', 'akaza-adventure' ); ?></span>
				</h2>

				<p>
					<?php esc_html_e(
						'Security awareness plays an important role in helping organisations establish and maintain effective information security practices.',
						'akaza-adventure'
					); ?>
				</p>

				<p>
					<?php esc_html_e(
						'SucceedLEARN helps organisations deliver structured awareness programmes, reinforce security responsibilities, and maintain ongoing employee engagement through training, simulations, microlearning, campaigns, and analytics.',
						'akaza-adventure'
					); ?>
				</p>

				<p>
					<?php esc_html_e(
						'For organisations working towards or maintaining ISO/IEC 27001, security awareness activities can form an important part of broader information security management and employee awareness programmes.',
						'akaza-adventure'
					); ?>
				</p>

				<p>
					<?php esc_html_e(
						'Rather than treating compliance training as a standalone annual activity, organisations can use continuous security awareness to keep employees informed about their responsibilities and reinforce secure behaviours throughout the year.',
						'akaza-adventure'
					); ?>
				</p>

				<p>
					<?php esc_html_e(
						'SucceedLEARN can help bring these activities together within a consistent security awareness programme while providing visibility into participation and programme activity.',
						'akaza-adventure'
					); ?>
				</p>

			</div>

			<div class="sl-sa-compliance__visual">

				<div class="sl-sa-compliance__dashboard">

					<div class="sl-sa-compliance__dashboard-header">

						<div>
							<span class="sl-sa-compliance__dashboard-label">
								<?php esc_html_e( 'Security Awareness', 'akaza-adventure' ); ?>
							</span>

							<strong>
								<?php esc_html_e( 'Programme Overview', 'akaza-adventure' ); ?>
							</strong>
						</div>

						<span class="sl-sa-compliance__status">
							<?php esc_html_e( 'Active', 'akaza-adventure' ); ?>
						</span>

					</div>

					<div class="sl-sa-compliance__metrics">

						<div class="sl-sa-compliance__metric">
							<span><?php esc_html_e( 'Training', 'akaza-adventure' ); ?></span>
							<strong>94%</strong>
							<small><?php esc_html_e( 'Completion', 'akaza-adventure' ); ?></small>
						</div>

						<div class="sl-sa-compliance__metric">
							<span><?php esc_html_e( 'Awareness', 'akaza-adventure' ); ?></span>
							<strong>87%</strong>
							<small><?php esc_html_e( 'Participation', 'akaza-adventure' ); ?></small>
						</div>

						<div class="sl-sa-compliance__metric">
							<span><?php esc_html_e( 'Campaigns', 'akaza-adventure' ); ?></span>
							<strong>12</strong>
							<small><?php esc_html_e( 'This year', 'akaza-adventure' ); ?></small>
						</div>

					</div>

					<div class="sl-sa-compliance__panel">

						<div class="sl-sa-compliance__panel-heading">
							<strong>
								<?php esc_html_e( 'Programme Activity', 'akaza-adventure' ); ?>
							</strong>

							<span>
								<?php esc_html_e( '12 months', 'akaza-adventure' ); ?>
							</span>
						</div>

						<div
							class="sl-sa-dashboard__activity-chart"
							data-activity="62,68,71,76,73,82,79,86,84,91,88,94"
							aria-label="<?php esc_attr_e( 'Programme activity over 12 months', 'akaza-adventure' ); ?>"
						></div>

					</div>

					<div class="sl-sa-compliance__coverage">

						<div class="sl-sa-compliance__coverage-heading">
							<strong>
								<?php esc_html_e( 'Awareness Coverage', 'akaza-adventure' ); ?>
							</strong>

							<span>92%</span>
						</div>

						<div class="sl-sa-compliance__progress">
							<span></span>
						</div>

					</div>

					<div class="sl-sa-compliance__footer">

						<span>✓ <?php esc_html_e( 'Training', 'akaza-adventure' ); ?></span>
						<span>✓ <?php esc_html_e( 'Campaigns', 'akaza-adventure' ); ?></span>
						<span>✓ <?php esc_html_e( 'Reporting', 'akaza-adventure' ); ?></span>

					</div>

				</div>

			</div>

		</div>

	</div>

</section>
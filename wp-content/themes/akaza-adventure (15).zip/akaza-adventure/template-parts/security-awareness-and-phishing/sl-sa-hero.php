<?php
/**
 * Security Awareness — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<section class="sl-sa-hero" aria-labelledby="sl-sa-hero-title">

    <div class="container">

        <div class="sl-sa-hero__grid">

            <div class="sl-sa-hero__content">

                <?php
                if ( function_exists( 'akaza_render_hero_breadcrumbs' ) ) {
                    akaza_render_hero_breadcrumbs();
                }
                ?>

                <span class="sl-home-sub-heading sl-sa-hero__eyebrow">
                    <?php esc_html_e( 'Security Awareness & Human Risk', 'akaza-adventure' ); ?>
                </span>

                <h1 id="sl-sa-hero-title">
                    <?php esc_html_e( 'SucceedLEARN Security Behaviour & Culture Suite', 'akaza-adventure' ); ?>
                </h1>

                <h2 class="sl-sa-hero__subheading">
                    <?php esc_html_e( 'Build a Security-Aware Workforce. Strengthen Human Risk Resilience.', 'akaza-adventure' ); ?>
                </h2>

                <p class="sl-sa-hero__description">
                    <?php esc_html_e( 'The SucceedLEARN Security Behaviour & Culture Suite combines awareness training, phishing simulations, microlearning, gamification, visual nudges, analytics, and seamless integrations into one unified platform that helps organisations reduce human cyber risk while meeting global compliance requirements.', 'akaza-adventure' ); ?>
                </p>

                <div class="sl-sa-hero__actions">

                    <a
                        href="#contact"
                        class="sl-sa-hero__button sl-sa-hero__button--primary"
                    >
                        <?php esc_html_e( 'Request a Demo', 'akaza-adventure' ); ?>
                    </a>

                    <a
                        href="#security-awareness-suite"
                        class="sl-sa-hero__button sl-sa-hero__button--secondary"
                    >
                        <?php esc_html_e( 'Explore the Suite', 'akaza-adventure' ); ?>
                    </a>

                </div>

            </div>

            <div class="sl-sa-hero__visual" aria-label="<?php esc_attr_e( 'Security awareness analytics dashboard preview', 'akaza-adventure' ); ?>">

                <div class="sl-sa-dashboard">

                    <div class="sl-sa-dashboard__topbar">

                        <div class="sl-sa-dashboard__brand">
                            <span class="sl-sa-dashboard__brand-mark">S</span>
                            <span>Security Behaviour</span>
                        </div>

                        <span class="sl-sa-dashboard__status">
                            <span></span>
                            <?php esc_html_e( 'Protected', 'akaza-adventure' ); ?>
                        </span>

                    </div>

                    <div class="sl-sa-dashboard__heading">

                        <div>
                            <span class="sl-sa-dashboard__label">
                                <?php esc_html_e( 'Human Risk Overview', 'akaza-adventure' ); ?>
                            </span>

                            <h3>
                                <?php esc_html_e( 'Security Awareness', 'akaza-adventure' ); ?>
                            </h3>
                        </div>

                        <span class="sl-sa-dashboard__period">
                            <?php esc_html_e( 'Last 30 days', 'akaza-adventure' ); ?>
                        </span>

                    </div>

                    <div class="sl-sa-dashboard__metrics">

                        <div class="sl-sa-dashboard__metric">
                            <span class="sl-sa-dashboard__metric-label">
                                <?php esc_html_e( 'Risk Score', 'akaza-adventure' ); ?>
                            </span>

                            <strong>18%</strong>

                            <span class="sl-sa-dashboard__metric-change">
                                ↓ 12.4%
                            </span>
                        </div>

                        <div class="sl-sa-dashboard__metric">
                            <span class="sl-sa-dashboard__metric-label">
                                <?php esc_html_e( 'Training Completion', 'akaza-adventure' ); ?>
                            </span>

                            <strong>94%</strong>

                            <span class="sl-sa-dashboard__metric-change">
                                ↑ 8.2%
                            </span>
                        </div>

                        <div class="sl-sa-dashboard__metric">
                            <span class="sl-sa-dashboard__metric-label">
                                <?php esc_html_e( 'Phishing Resilience', 'akaza-adventure' ); ?>
                            </span>

                            <strong>87%</strong>

                            <span class="sl-sa-dashboard__metric-change">
                                ↑ 14.6%
                            </span>
                        </div>

                    </div>

                    <div class="sl-sa-dashboard__body">

                        <div class="sl-sa-dashboard__chart">

                            <div class="sl-sa-dashboard__chart-header">
                                <strong>
                                    <?php esc_html_e( 'Human Risk Trend', 'akaza-adventure' ); ?>
                                </strong>

                                <span>
                                    <?php esc_html_e( 'Risk ↓', 'akaza-adventure' ); ?>
                                </span>
                            </div>

                            <div class="sl-sa-dashboard__chart-area">

                                <div class="sl-sa-dashboard__chart-grid"></div>

                                <svg
                                    class="sl-sa-dashboard__line"
                                    viewBox="0 0 500 150"
                                    preserveAspectRatio="none"
                                    aria-hidden="true"
                                >
                                    <polyline
                                        points="0,35 70,48 135,42 200,78 265,70 330,96 400,105 500,125"
                                        fill="none"
                                        stroke="currentColor"
                                        stroke-width="5"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                    />
                                </svg>

                            </div>

                        </div>

                        <div class="sl-sa-dashboard__risk">

                            <div class="sl-sa-dashboard__chart-header">
                                <strong>
                                    <?php esc_html_e( 'Risk Areas', 'akaza-adventure' ); ?>
                                </strong>
                            </div>

                            <div class="sl-sa-dashboard__risk-item">
                                <span><?php esc_html_e( 'Phishing', 'akaza-adventure' ); ?></span>
                                <div class="sl-sa-dashboard__progress">
                                    <span style="width: 82%;"></span>
                                </div>
                                <strong>82%</strong>
                            </div>

                            <div class="sl-sa-dashboard__risk-item">
                                <span><?php esc_html_e( 'Password Security', 'akaza-adventure' ); ?></span>
                                <div class="sl-sa-dashboard__progress">
                                    <span style="width: 91%;"></span>
                                </div>
                                <strong>91%</strong>
                            </div>

                            <div class="sl-sa-dashboard__risk-item">
                                <span><?php esc_html_e( 'Data Protection', 'akaza-adventure' ); ?></span>
                                <div class="sl-sa-dashboard__progress">
                                    <span style="width: 76%;"></span>
                                </div>
                                <strong>76%</strong>
                            </div>

                        </div>

                    </div>

                    <div class="sl-sa-dashboard__footer">

                        <span>
                            <?php esc_html_e( '1,248 employees monitored', 'akaza-adventure' ); ?>
                        </span>

                        <span>
                            <?php esc_html_e( '12 active learning campaigns', 'akaza-adventure' ); ?>
                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>
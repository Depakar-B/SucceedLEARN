<?php
/**
 * Code of Conduct — Final contact / CTA section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$form_title     = __( 'Request a Demo', 'akaza-adventure' );
$form_shortcode = sprintf(
	'[contact_form form_variant="course" title="%s"]',
	esc_attr( $form_title )
);
?>

<section class="sl-coc-contact" id="contact" aria-labelledby="sl-coc-contact-title">
	<div class="container">

		<div class="sl-coc-contact__grid">

			<div class="sl-coc-contact__content">

				<div class="sl-coc-contact__heading">

					<span class="sl-home-sub-heading">
						<?php esc_html_e( 'Final Call to Action', 'akaza-adventure' ); ?>
					</span>

					<h2 id="sl-coc-contact-title">
						<?php
						echo wp_kses(
							__( 'Turn Your Code of Conduct Into <span>Everyday Behavior</span>', 'akaza-adventure' ),
							array( 'span' => array() )
						);
						?>
					</h2>

				</div>

				<div class="sl-coc-contact__cards">

					<div class="sl-coc-contact__card">
						<p>
							<?php esc_html_e( 'Your employees shouldn\'t have to memorize every rule.', 'akaza-adventure' ); ?>
						</p>
					</div>

					<div class="sl-coc-contact__card">
						<p>
							<?php
							echo wp_kses(
								__( 'They should know how to <span>recognize risk, stop, think</span> and make the right decision.', 'akaza-adventure' ),
								array( 'span' => array() )
							);
							?>
						</p>
					</div>

					<div class="sl-coc-contact__card">
						<p>
							<?php
							echo wp_kses(
								__( 'Give your workforce practical, engaging and measurable <span>Code of Conduct training</span> built around the situations they face at work.', 'akaza-adventure' ),
								array( 'span' => array() )
							);
							?>
						</p>
					</div>

				</div>

			</div>

			<div class="sl-coc-contact__form-wrap">
				<div class="sl-home-form-wrapper sl-home-form-wrapper--slim">
					<?php
					if ( shortcode_exists( 'contact_form' ) ) {
						echo do_shortcode( $form_shortcode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					} elseif ( shortcode_exists( 'succeedlearn_course_form' ) ) {
						echo do_shortcode( sprintf( '[succeedlearn_course_form title="%s"]', esc_attr( $form_title ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					}
					?>
				</div>
			</div>

		</div>

	</div>
</section>

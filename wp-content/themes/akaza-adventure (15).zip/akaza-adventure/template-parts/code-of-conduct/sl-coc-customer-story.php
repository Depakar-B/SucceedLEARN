<?php
/**
 * Code of Conduct — Customer Story section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-coc-customer-story" aria-labelledby="sl-coc-customer-story-title">
	<div class="container">

		<div class="sl-coc-customer-story__heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Customer Story', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-customer-story-title">
				<?php
				echo wp_kses(
					__( 'From Policy Rollout to <span>Employee Understanding</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>
		</div>

		<div class="sl-coc-customer-story__grid">

			<article class="sl-coc-customer-story__card">
				<div class="sl-coc-customer-story__card-head">
					<span class="sl-coc-customer-story__number">01</span>
					<h3><?php esc_html_e( 'Challenge', 'akaza-adventure' ); ?></h3>
				</div>

				<p>
					<?php
					esc_html_e(
						'The organization needed to communicate its Code consistently across a geographically distributed workforce.',
						'akaza-adventure'
					);
					?>
				</p>
			</article>

			<article class="sl-coc-customer-story__card">
				<div class="sl-coc-customer-story__card-head">
					<span class="sl-coc-customer-story__number">02</span>
					<h3><?php esc_html_e( 'Solution', 'akaza-adventure' ); ?></h3>
				</div>

				<p>
					<?php
					esc_html_e(
						"SucceedLEARN customized the course around the organization's policies, branding, reporting procedures and workplace scenarios.",
						'akaza-adventure'
					);
					?>
				</p>
			</article>

			<article class="sl-coc-customer-story__card">
				<div class="sl-coc-customer-story__card-head">
					<span class="sl-coc-customer-story__number">03</span>
					<h3><?php esc_html_e( 'Outcome', 'akaza-adventure' ); ?></h3>
				</div>

				<p>
					<?php
					esc_html_e(
						'Employees received a consistent learning experience while HR and compliance gained centralized visibility into completion and assessment.',
						'akaza-adventure'
					);
					?>
				</p>
			</article>

		</div>

		<div class="sl-coc-customer-story__cta-wrap">
			<a class="sl-coc-customer-story__cta" href="#">
				<?php esc_html_e( 'Read Customer Success Stories', 'akaza-adventure' ); ?>
			</a>
		</div>

	</div>
</section>
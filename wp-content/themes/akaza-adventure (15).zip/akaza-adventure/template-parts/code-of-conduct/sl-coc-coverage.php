<?php
/**
 * Code of Conduct — Course Coverage grid.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-coc-coverage" aria-labelledby="sl-coc-coverage-title">
	<div class="container">

		<div class="sl-coc-coverage__heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Course Coverage', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-coverage-title">
				<?php
				echo wp_kses(
					__( 'What should your <span>Code of Conduct Training Cover?</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>

			<p>
				<?php esc_html_e( 'The course can be configured around your organisation’s Code of Conduct, policies, industry and employee requirements.', 'akaza-adventure' ); ?>
			</p>
		</div>

		<div class="sl-coc-coverage__grid">

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">01</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Understanding the Code of Conduct', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Understand organisational values, employee responsibilities and how the Code applies to everyday business decisions.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">02</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Respectful Workplace & Inclusion', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Learn how respectful, equal opportunity and professional behaviour contribute to a safe and productive workplace.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">03</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Professional Conduct & Workplace Behaviour', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Explore expectations around professional behaviour, meetings, communication, workplace safety and personal accountability.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">04</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Conflicts of Interest', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Learn to identify actual, potential and perceived conflicts involving personal relationships, outside employment, vendors, financial interests and business opportunities.', 'akaza-adventure' ); ?></p>
				<p><?php esc_html_e( 'Employees also learn an important principle:', 'akaza-adventure' ); ?></p>
				<p class="sl-coc-coverage__card-principle"><?php esc_html_e( 'When in doubt — disclose.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">05</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Gifts, Hospitality & Business Courtesies', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Understand when gifts, meals, entertainment and hospitality may be appropriate and when they could improperly influence a business decision.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">06</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Anti-Bribery & Anti-Corruption', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Recognize bribery, improper payments and other forms of corruption and understand the importance of ethical business relationships.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">07</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Fair Competition & Business Integrity', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Understand responsible interactions with competitors, customers, suppliers and other business partners, including risks such as price fixing, bid manipulation and other anti-competitive practices.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">08</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Financial Integrity & Responsible Recordkeeping', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Learn the importance of accurate financial records, appropriate expenses, documentation, contracts and preservation of records.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">09</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Data Privacy & Responsible Information Handling', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Understand how personal information should be collected, accessed, processed, stored and shared responsibly.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">10</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Confidential Information & Intellectual Property', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Learn how to protect confidential business information, intellectual property, customer information and other sensitive organizational assets.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">11</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Protecting Company Assets', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Understand responsible use of physical assets, technology, software, information, equipment and other company resources.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">12</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Social Media & External Communication', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Learn what employees can and cannot communicate publicly, how to behave responsibly on social media and when communication should be handled by authorized representatives.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">13</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Working Responsibly with Third Parties', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Understand ethical expectations when interacting with suppliers, consultants, contractors, business partners and other third parties.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">14</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Speak Up, Reporting & Non-Retaliation', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Help employees recognize when concerns should be raised, understand available reporting channels and build confidence to speak up when something does not seem right.', 'akaza-adventure' ); ?></p>
			</article>

			<article class="sl-coc-coverage__card">
				<span class="sl-coc-coverage__icon" aria-hidden="true">15</span>
				<div class="sl-coc-coverage__card-head">
					<h3><?php esc_html_e( 'Living the Code', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Bring the learning together through practical decision-making principles employees can use when they encounter situations that are not explicitly covered by a policy.', 'akaza-adventure' ); ?></p>
			</article>

		</div>

	</div>
</section>

<?php
/**
 * Global Workplace Compliance Training for Employees — CTA section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$contact_url = '#contact';
?>
<section class="sl-global-cta-section" aria-labelledby="sl-global-cta-heading">

	<div class="container">

		<div class="sl-global-cta-wrapper">

			<h2 id="sl-global-cta-heading" class="sl-global-cta-title">
				<?php esc_html_e( 'Ready to Build a Better Workplace?', 'akaza-adventure' ); ?>
			</h2>

			<p class="sl-global-cta-text">
				<?php esc_html_e( 'Whether you’re strengthening workplace inclusion, delivering harassment prevention training, or preparing your workforce for responsible AI adoption, Succeed Learn is ready to help.', 'akaza-adventure' ); ?>
			</p>

			<div class="sl-global-cta-actions">
				<a href="<?php echo esc_url( $contact_url ); ?>" class="sl-global-btn sl-global-btn-primary">
					<?php esc_html_e( 'Request a Demo', 'akaza-adventure' ); ?>
				</a>

				<a href="<?php echo esc_url( $contact_url ); ?>" class="sl-global-btn sl-global-btn-secondary">
					<?php esc_html_e( 'Talk to Our Team', 'akaza-adventure' ); ?>
				</a>
			</div>

		</div>

	</div>

</section>

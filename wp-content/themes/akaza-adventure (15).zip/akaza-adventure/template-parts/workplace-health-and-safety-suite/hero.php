<?php
/**
 * Workplace Health and Safety Suite — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'eyebrow' => __( 'By Solution', 'akaza-adventure' ),
		'title'   => __( 'Workplace Health and Safety Suite', 'akaza-adventure' ),
		'lead'    => __( 'Help employees build safer habits across everyday workplace risks.', 'akaza-adventure' ),
	)
);

<?php
/**
 * GDPR Employee Awareness Training page content wrapper.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<main id="main-content" class="sl-gdpr-page">
	<?php get_template_part( 'template-parts/gdpr-employee-awareness-training/hero' ); ?>
	<?php get_template_part( 'template-parts/home/stats' ); ?>
	<?php get_template_part( 'template-parts/home/clients' ); ?>
</main>

<?php
/**
 * DPDPA Compliance Training — Curriculum accordion.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$modules = array(
	array( 'Introduction and objectives', 'Why this training matters in everyday work.' ),
	array( 'Why data protection matters', 'The real world impact of poor data handling.' ),
	array( 'What is the DPDPA', 'Overview of the Act and consequences of non-compliance.' ),
	array( 'Key DPDPA terms', 'Personal Data, Data Principal, Data Fiduciary, Data Processor.' ),
	array( 'Scope of the DPDPA', 'What data and which organisations are covered.' ),
	array( 'Lawful grounds for processing', 'Valid consent and the legitimate uses that do not require it.' ),
	array( 'Privacy by design', 'Building privacy into everyday decisions and processes.' ),
	array( 'Handling data across its lifecycle', 'Collection, classification, storage, sharing, retention, deletion.' ),
	array( 'Data Principal rights and requests', 'Consent withdrawal, access, correction, erasure, grievance redressal. Knowledge check included.' ),
	array( 'Grievances and escalation', 'Recognising and routing privacy concerns correctly.' ),
	array( 'Breach awareness and reporting', 'What counts as a breach and how to report it without delay. Knowledge check included.' ),
	array( 'Your responsibilities', 'Practical dos and don\'ts for everyday data handling.' ),
	array( 'Final assessment and certificate', '5 randomised questions, minimum 4 correct to pass.' ),
);
?>
<section class="sl-dpdpa-curriculum" aria-labelledby="sl-dpdpa-curriculum-title">
	<div class="container">
		<div class="sl-dpdpa-curriculum__intro">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Course curriculum', 'akaza-adventure' ); ?>
			</span>
		</div>

		<div class="sl-dpdpa-curriculum__panel" id="dpdpa-curriculum-panel">
			<h2 class="sl-dpdpa-curriculum__heading" id="sl-dpdpa-curriculum-title">
				<button
					class="sl-dpdpa-curriculum__toggle"
					type="button"
					aria-expanded="false"
					aria-controls="dpdpa-curriculum-list"
				>
					<span class="sl-dpdpa-curriculum__title">
						<?php esc_html_e( 'Full', 'akaza-adventure' ); ?>
						<span><?php esc_html_e( '13-module DPDPA course curriculum', 'akaza-adventure' ); ?></span>
					</span>
					<span class="sl-dpdpa-curriculum__toggle-action">
						<span class="sl-dpdpa-curriculum__toggle-count">
							<?php esc_html_e( 'Show all curriculum (13 modules)', 'akaza-adventure' ); ?>
						</span>
						<span class="sl-dpdpa-curriculum__toggle-icon" aria-hidden="true">
							<svg class="icon" width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg" focusable="false">
								<path d="M6 8.5L10.5 13L15 8.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</span>
					</span>
				</button>
			</h2>

			<div class="sl-dpdpa-curriculum__content" id="dpdpa-curriculum-list" hidden>
				<ol class="sl-dpdpa-curriculum__list">
					<?php foreach ( $modules as $index => $module ) : ?>
						<li class="sl-dpdpa-curriculum__item">
							<span class="sl-dpdpa-curriculum__number"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
							<div class="sl-dpdpa-curriculum__info">
								<h3><?php echo esc_html( $module[0] ); ?></h3>
								<p><?php echo esc_html( $module[1] ); ?></p>
							</div>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>
		</div>

		<div class="sl-dpdpa-curriculum__image">
			<figure class="sl-dpdpa-curriculum__image-figure">
				<img
					src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/dpdpa-course-screenshot.webp' ); ?>"
					alt="<?php esc_attr_e( 'DPDPA employee compliance training course screenshot', 'akaza-adventure' ); ?>"
					width="1200"
					height="650"
					loading="lazy"
					decoding="async"
				>
				<figcaption class="sl-dpdpa-curriculum__note">
					<?php esc_html_e( 'What a lesson actually looks like.', 'akaza-adventure' ); ?>
				</figcaption>
			</figure>
		</div>
	</div>
</section>

<?php
/**
 * DPDPA Compliance Training — Who signs off section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-dpdpa-signoff" aria-labelledby="sl-dpdpa-signoff-title">
	<div class="container">
		<div class="sl-dpdpa-section-heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Stakeholders', 'akaza-adventure' ); ?>
			</span>
			<h2 id="sl-dpdpa-signoff-title">
				<?php esc_html_e( 'Who signs off on', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'DPDPA employee training', 'akaza-adventure' ); ?></span>
			</h2>
			<p>
				<?php esc_html_e( 'Three people usually own this decision. Whichever one you are, this answers the part that\'s actually yours to worry about.', 'akaza-adventure' ); ?>
			</p>
		</div>

		<div class="sl-dpdpa-signoff__wrap">
			<table class="sl-dpdpa-signoff__table">
				<caption class="screen-reader-text">
					<?php esc_html_e( 'Stakeholders who sign off on DPDPA employee training', 'akaza-adventure' ); ?>
				</caption>
				<tbody>
					<tr>
						<th scope="row" class="sl-dpdpa-signoff__role">
							<span class="sl-dpdpa-signoff__role-title"><?php esc_html_e( 'Data Protection Officer', 'akaza-adventure' ); ?></span>
							<span class="sl-dpdpa-signoff__tag"><?php esc_html_e( 'Accountability', 'akaza-adventure' ); ?></span>
						</th>
						<td class="sl-dpdpa-signoff__body">
							<p class="sl-dpdpa-signoff__q"><?php esc_html_e( '"If the Board or a regulator asks what training we have actually done, what do I show them?"', 'akaza-adventure' ); ?></p>
							<p class="sl-dpdpa-signoff__a"><?php esc_html_e( 'A completion record, an assessment score and a certificate for every employee, timestamped and exportable. Not a slide deck saying training took place.', 'akaza-adventure' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row" class="sl-dpdpa-signoff__role">
							<span class="sl-dpdpa-signoff__role-title"><?php esc_html_e( 'CISO / CIO', 'akaza-adventure' ); ?></span>
							<span class="sl-dpdpa-signoff__tag"><?php esc_html_e( 'Risk', 'akaza-adventure' ); ?></span>
						</th>
						<td class="sl-dpdpa-signoff__body">
							<p class="sl-dpdpa-signoff__q"><?php esc_html_e( '"We already run DLP, email security and access controls. Why did this still happen?"', 'akaza-adventure' ); ?></p>
							<p class="sl-dpdpa-signoff__a"><?php esc_html_e( 'Because most incidents in this category start with a person, not a system. This closes the gap your tooling cannot reach, without adding another dashboard to babysit.', 'akaza-adventure' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row" class="sl-dpdpa-signoff__role">
							<span class="sl-dpdpa-signoff__role-title"><?php esc_html_e( 'Head of HR', 'akaza-adventure' ); ?></span>
							<span class="sl-dpdpa-signoff__tag"><?php esc_html_e( 'Rollout', 'akaza-adventure' ); ?></span>
						</th>
						<td class="sl-dpdpa-signoff__body">
							<p class="sl-dpdpa-signoff__q"><?php esc_html_e( '"I am the one who has to roll this out to thousands of people who have never heard of the DPDPA."', 'akaza-adventure' ); ?></p>
							<p class="sl-dpdpa-signoff__a"><?php esc_html_e( '25 minutes, SSO and HRIS integration, automated reminders, and a dashboard showing exactly who has and has not finished. Live in weeks, not a quarter.', 'akaza-adventure' ); ?></p>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

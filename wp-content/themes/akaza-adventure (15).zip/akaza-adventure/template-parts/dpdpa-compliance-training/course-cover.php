<?php
/**
 * DPDPA Compliance Training — What the course covers.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cards = array(
	array(
		'title' => 'Recognise personal data',
		'text'  => 'What counts, directly or indirectly, before it gets mishandled.',
	),
	array(
		'title' => 'Consent and lawful grounds',
		'text'  => 'What makes consent valid, and the legitimate uses that do not need it.',
	),
	array(
		'title' => 'The full data lifecycle',
		'text'  => 'Collect, classify, store, share, retain and delete, the way the Act expects.',
	),
	array(
		'title' => 'Data Principal rights',
		'text'  => 'Recognise a request and route it, rather than answering it informally.',
	),
	array(
		'title' => 'Breach recognition and reporting',
		'text'  => 'Act in the first minutes, not after checking with five people.',
	),
	array(
		'title' => 'A real assessment',
		'text'  => '5 questions, 4 correct required, certificate issued automatically.',
	),
);
?>
<section class="sl-dpdpa-course-cover" aria-labelledby="sl-dpdpa-course-cover-title">
	<div class="container">
		<div class="sl-dpdpa-section-heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'What the DPDPA course covers', 'akaza-adventure' ); ?>
			</span>
			<h2 id="sl-dpdpa-course-cover-title">
				<?php esc_html_e( 'Built for', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'every employee', 'akaza-adventure' ); ?></span>
				<?php esc_html_e( 'who handles personal data.', 'akaza-adventure' ); ?>
			</h2>
			<p>
				<?php esc_html_e( "This isn't role-based training, and it isn't written for a DPO. It's built for the person who has never read the Act and never will, and still needs to get this right.", 'akaza-adventure' ); ?>
			</p>
		</div>

		<div class="sl-dpdpa-course-cover__grid">
			<?php foreach ( $cards as $card ) : ?>
				<article class="sl-dpdpa-course-cover__card">
					<div class="sl-dpdpa-course-cover__head">
						<span class="sl-dpdpa-course-cover__icon" aria-hidden="true">✓</span>
						<h3><?php echo esc_html( $card['title'] ); ?></h3>
					</div>
					<p><?php echo esc_html( $card['text'] ); ?></p>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

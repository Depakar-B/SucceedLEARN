<?php
/**
 * DPDPA Compliance Training — How it teaches.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$features = array(
	array(
		'label' => 'Module 04',
		'title' => 'Click to reveal, not read and scroll',
		'text'  => 'Personal data, data fiduciary, data principal, data processor. Each term is a tile you click open, with a real workplace example behind it, not a dictionary entry.',
	),
	array(
		'label' => 'Throughout',
		'title' => 'Sorting and decision activities',
		'text'  => 'Is this personal data or not? Drag it into the right pile and find out immediately if you were right.',
	),
	array(
		'label' => 'Module 09',
		'title' => 'A rights request, mid-course',
		'text'  => 'A knowledge check built around an actual request, not a multiple-choice definition of "Data Principal rights."',
	),
	array(
		'label' => 'Module 11',
		'title' => 'A breach, while it\'s still happening',
		'text'  => 'The scenario above isn\'t a hypothetical we wrote for this page. It\'s the knowledge check inside the course.',
	),
);
?>
<section class="sl-dpdpa-how-it-teaches" aria-labelledby="sl-dpdpa-how-it-teaches-title">
	<div class="container">
		<div class="sl-dpdpa-section-heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'How it actually teaches', 'akaza-adventure' ); ?>
			</span>
			<h2 id="sl-dpdpa-how-it-teaches-title">
				<?php esc_html_e( 'Not a PDF with a quiz', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'stapled to the end.', 'akaza-adventure' ); ?></span>
			</h2>
			<p>
				<?php esc_html_e( 'Most compliance courses hand you a definition and move on. This one makes you do something with it before it moves on.', 'akaza-adventure' ); ?>
			</p>
		</div>

		<div class="sl-dpdpa-how-it-teaches__features">
			<?php foreach ( $features as $feature ) : ?>
				<article class="sl-dpdpa-how-it-teaches__feature">
					<div class="sl-dpdpa-how-it-teaches__head">
						<span class="sl-dpdpa-how-it-teaches__label"><?php echo esc_html( $feature['label'] ); ?></span>
						<h3><?php echo esc_html( $feature['title'] ); ?></h3>
					</div>
					<p><?php echo esc_html( $feature['text'] ); ?></p>
				</article>
			<?php endforeach; ?>
		</div>

		<div class="sl-dpdpa-how-it-teaches__screenshots">
			<figure class="sl-dpdpa-how-it-teaches__screenshot">
				<div class="sl-dpdpa-how-it-teaches__image">
					<img
						src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/dpdpa-module-04.webp' ); ?>"
						alt="<?php esc_attr_e( 'DPDPA Module 04 click to reveal learning activity', 'akaza-adventure' ); ?>"
						width="900"
						height="560"
						loading="lazy"
						decoding="async"
					>
				</div>
				<figcaption><?php esc_html_e( 'A term, opened, not just defined', 'akaza-adventure' ); ?></figcaption>
			</figure>

			<figure class="sl-dpdpa-how-it-teaches__screenshot">
				<div class="sl-dpdpa-how-it-teaches__image">
					<img
						src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/dpdpa-sorting-activity.webp' ); ?>"
						alt="<?php esc_attr_e( 'DPDPA sorting and decision learning activity', 'akaza-adventure' ); ?>"
						width="900"
						height="560"
						loading="lazy"
						decoding="async"
					>
				</div>
				<figcaption><?php esc_html_e( 'Something to do, not just watch', 'akaza-adventure' ); ?></figcaption>
			</figure>
		</div>
	</div>
</section>

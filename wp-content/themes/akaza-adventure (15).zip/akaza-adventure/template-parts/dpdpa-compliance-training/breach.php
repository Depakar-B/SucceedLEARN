<?php
/**
 * DPDPA Compliance Training — Breach story section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-dpdpa-breach" aria-labelledby="sl-dpdpa-breach-title">
	<div class="container">
		<div class="sl-dpdpa-section-heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'How a DPDPA breach actually happens', 'akaza-adventure' ); ?>
			</span>
			<h2 id="sl-dpdpa-breach-title">
				<?php esc_html_e( 'Four ordinary steps,', 'akaza-adventure' ); ?>
				<span><?php esc_html_e( 'one reportable incident.', 'akaza-adventure' ); ?></span>
			</h2>
			<p>
				<?php esc_html_e( 'No malware, no intrusion. Just a routine task handled a little too fast, by someone who was never told what the rules were.', 'akaza-adventure' ); ?>
			</p>
		</div>

		<div class="sl-dpdpa-breach__steps" role="list" aria-label="<?php esc_attr_e( 'DPDPA breach steps', 'akaza-adventure' ); ?>">
			<article class="sl-dpdpa-breach__card" role="listitem">
				<p class="sl-dpdpa-breach__meta">01 · 2:14pm</p>
				<div class="sl-dpdpa-breach__head">
					<h3><?php esc_html_e( 'A routine task', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Someone needs to send an updated customer list to three colleagues.', 'akaza-adventure' ); ?></p>
			</article>

			<span class="sl-dpdpa-breach__connector sl-dpdpa-breach__connector--across" aria-hidden="true"></span>

			<article class="sl-dpdpa-breach__card" role="listitem">
				<p class="sl-dpdpa-breach__meta">02 · 2:15pm</p>
				<div class="sl-dpdpa-breach__head">
					<h3><?php esc_html_e( 'The wrong list', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'It goes to a saved group of 217 people instead of the three intended.', 'akaza-adventure' ); ?></p>
			</article>

			<span class="sl-dpdpa-breach__connector sl-dpdpa-breach__connector--down" aria-hidden="true"></span>

			<article class="sl-dpdpa-breach__card" role="listitem">
				<p class="sl-dpdpa-breach__meta">03 · 2:15pm</p>
				<div class="sl-dpdpa-breach__head">
					<h3><?php esc_html_e( 'The exposure', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( '1,204 customer records are now visible to people with no reason to see them.', 'akaza-adventure' ); ?></p>
			</article>

			<span class="sl-dpdpa-breach__connector sl-dpdpa-breach__connector--across" aria-hidden="true"></span>

			<article class="sl-dpdpa-breach__card" role="listitem">
				<p class="sl-dpdpa-breach__meta"><?php esc_html_e( '04 · What should happen', 'akaza-adventure' ); ?></p>
				<div class="sl-dpdpa-breach__head">
					<h3><?php esc_html_e( 'Report immediately', 'akaza-adventure' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'Not delete it, not fix it quietly. Report through the incident process, right away.', 'akaza-adventure' ); ?></p>
			</article>
		</div>

		<figure class="sl-dpdpa-breach__image">
			<img
				src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/dpdpa-module-04.webp' ); ?>"
				alt="<?php esc_attr_e( 'DPDPA knowledge check scenario from the employee training course', 'akaza-adventure' ); ?>"
				width="900"
				height="560"
				loading="lazy"
				decoding="async"
			>
		</figure>

		<p class="sl-dpdpa-breach__note">
			<?php esc_html_e( "This isn't a hypothetical. It's the knowledge check your employees will actually see.", 'akaza-adventure' ); ?>
		</p>
	</div>
</section>

<?php
/**
 * Page assets: akaza_enqueue_gdpr_assets
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function akaza_enqueue_gdpr_assets() {
	$dpdpa_hero_css = AKAZA_DIR . '/assets/css/dpdpa-hero.css';
	$dpdpa_hero_js  = AKAZA_DIR . '/assets/js/dpdpa-hero.js';
	$stats_css      = AKAZA_DIR . '/assets/css/stats.css';
	$stats_js       = AKAZA_DIR . '/assets/js/stats.js';
	$clients_css    = AKAZA_DIR . '/assets/css/clients.css';
	$clients_js     = AKAZA_DIR . '/assets/js/clients.js';

	wp_enqueue_style(
		'akaza-dpdpa-hero',
		AKAZA_URI . '/assets/css/dpdpa-hero.css',
		array( 'akaza-main' ),
		file_exists( $dpdpa_hero_css ) ? (string) filemtime( $dpdpa_hero_css ) : AKAZA_VERSION
	);

	wp_enqueue_style(
		'akaza-stats',
		AKAZA_URI . '/assets/css/stats.css',
		array( 'akaza-main' ),
		file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
	);

	wp_enqueue_script(
		'akaza-stats',
		AKAZA_URI . '/assets/js/stats.js',
		array(),
		file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);

	wp_enqueue_style(
		'akaza-clients',
		AKAZA_URI . '/assets/css/clients.css',
		array( 'akaza-main' ),
		file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
	);

	wp_enqueue_script(
		'akaza-clients',
		AKAZA_URI . '/assets/js/clients.js',
		array(),
		file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);

	wp_enqueue_script(
		'akaza-dpdpa-hero',
		AKAZA_URI . '/assets/js/dpdpa-hero.js',
		array(),
		file_exists( $dpdpa_hero_js ) ? (string) filemtime( $dpdpa_hero_js ) : AKAZA_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);
}

<?php
/**
 * Template Name: GDPR Employee Awareness Training
 * Description: Page template for GDPR Employee Awareness Training.
 *
 * @package Akaza_Adventure
 */

get_header();
get_template_part( 'template-parts/gdpr-employee-awareness-training' );
get_footer();

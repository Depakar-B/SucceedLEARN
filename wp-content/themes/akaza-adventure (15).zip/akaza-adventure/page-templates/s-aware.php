<?php
/**
 * Template Name: S-Aware
 * Description: Desktop shell for S-Aware page.
 *
 * @package Akaza_Adventure
 */

get_header();
get_template_part( 'template-parts/s-aware' );
get_footer();

<?php
/**
 * Minimal document close for Cybersecurity Awareness page.
 * Custom campaign footer is rendered before this template is loaded.
 *
 * @package Akaza_Adventure
 */

if ( has_action( 'ahf_render_site_footer' ) ) {
	do_action( 'ahf_render_site_footer' );
}

wp_footer();
?>
</body>
</html>

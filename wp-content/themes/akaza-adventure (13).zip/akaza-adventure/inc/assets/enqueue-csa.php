<?php
/**
 * Cybersecurity Awareness page assets.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Suppress the global site footer on the Cybersecurity Awareness page.
 *
 * @param bool $show Whether the AHF footer should render.
 * @return bool
 */
function akaza_csa_hide_default_footer( $show ) {
	if ( is_page_template( 'page-templates/cybersecurity-awareness.php' ) ) {
		return false;
	}

	return $show;
}
add_filter( 'ahf_footer_should_show', 'akaza_csa_hide_default_footer' );

/**
 * Suppress the global site header on the Cybersecurity Awareness page.
 *
 * @param bool $show Whether the AHF header should render.
 * @return bool
 */
function akaza_csa_hide_default_header( $show ) {
	if ( is_page_template( 'page-templates/cybersecurity-awareness.php' ) ) {
		return false;
	}

	return $show;
}
add_filter( 'ahf_classic_header_should_render', 'akaza_csa_hide_default_header' );

/**
 * Suppress the global AHF top bar on the Cybersecurity Awareness page.
 *
 * @param bool $show Whether the AHF top bar should render.
 * @return bool
 */
function akaza_csa_hide_default_top_bar( $show ) {
	if ( is_page_template( 'page-templates/cybersecurity-awareness.php' ) ) {
		return false;
	}

	return $show;
}
add_filter( 'ahf_top_bar_should_show', 'akaza_csa_hide_default_top_bar' );

function akaza_enqueue_csa_assets() {
	$base_deps = array( 'akaza-main', 'akaza-fonts' );

	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-awareness-header',
		'cybersecurity-awareness/sl-cybersecurity-awareness-header.css',
		$base_deps
	);
	akaza_enqueue_theme_script(
		'akaza-sl-cybersecurity-awareness-header',
		'cybersecurity-awareness/sl-cybersecurity-awareness-header.js'
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-awareness-top-bar',
		'cybersecurity-awareness/sl-cybersecurity-awareness-top-bar.css',
		array( 'akaza-sl-cybersecurity-awareness-header' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-awareness-hero',
		'cybersecurity-awareness/sl-cybersecurity-awareness-hero.css',
		array( 'akaza-sl-cybersecurity-awareness-top-bar' )
	);
	akaza_enqueue_theme_script(
		'akaza-sl-cybersecurity-awareness-hero',
		'cybersecurity-awareness/sl-cybersecurity-awareness-hero.js'
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-awareness-offer-strip',
		'cybersecurity-awareness/sl-cybersecurity-awareness-offer-strip.css',
		array( 'akaza-sl-cybersecurity-awareness-hero' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cyber-awareness-readiness',
		'cybersecurity-awareness/sl-cyber-awareness-readiness.css',
		array( 'akaza-sl-cybersecurity-awareness-offer-strip' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-awareness-campaign',
		'cybersecurity-awareness/sl-cybersecurity-awareness-campaign.css',
		array( 'akaza-sl-cyber-awareness-readiness' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-phishcue',
		'cybersecurity-awareness/sl-cybersecurity-phishcue.css',
		array( 'akaza-sl-cybersecurity-awareness-campaign' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cyber-awareness-integration',
		'cybersecurity-awareness/sl-cyber-awareness-integration.css',
		array( 'akaza-sl-cybersecurity-phishcue' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-awareness-pricing',
		'cybersecurity-awareness/sl-cybersecurity-awareness-pricing.css',
		array( 'akaza-sl-cyber-awareness-integration' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-campaign-journey',
		'cybersecurity-awareness/sl-cybersecurity-campaign-journey.css',
		array( 'akaza-sl-cybersecurity-awareness-pricing' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-campaign-measure',
		'cybersecurity-awareness/sl-cybersecurity-campaign-measure.css',
		array( 'akaza-sl-cybersecurity-campaign-journey' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-awareness-contact',
		'cybersecurity-awareness/sl-cybersecurity-awareness-contact.css',
		array( 'akaza-sl-cybersecurity-campaign-measure' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-csa-section-rhythm',
		'cybersecurity-awareness/sl-csa-section-rhythm.css',
		array( 'akaza-sl-cybersecurity-awareness-contact', 'akaza-global-faq' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-cybersecurity-awareness-footer',
		'cybersecurity-awareness/sl-cybersecurity-awareness-footer.css',
		array( 'akaza-sl-csa-section-rhythm' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-csa-typography',
		'cybersecurity-awareness/sl-csa-typography.css',
		array( 'akaza-sl-cybersecurity-awareness-footer' )
	);
}

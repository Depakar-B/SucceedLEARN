<?php
/**
 * Security Awareness and Phishing page assets.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current request is the SAP / Security Awareness landing page.
 *
 * @return bool
 */
function akaza_is_sap_landing_page() {
	static $is_sap = null;

	if ( null !== $is_sap ) {
		return $is_sap;
	}

	$is_sap = is_page_template( 'page-templates/security-awareness-and-phishing.php' )
		|| is_page(
			array(
				'security-awareness',
				'security-awareness-and-phishing',
			)
		);

	return $is_sap;
}

/**
 * Stop theme-builder headers/footers from replacing the SAP landing shell.
 */
function akaza_sap_disable_builder_header_footer() {
	if ( ! akaza_is_sap_landing_page() ) {
		return;
	}

	if ( class_exists( '\Thim_EL_Kit\Modules\HeaderFooter\FrontEnd' ) ) {
		$fe = \Thim_EL_Kit\Modules\HeaderFooter\FrontEnd::instance();
		remove_action( 'get_header', array( $fe, 'override_header' ) );
		remove_action( 'get_footer', array( $fe, 'override_footer' ) );
	}

	if ( class_exists( '\ElementorPro\Plugin' ) && function_exists( 'elementor_theme_do_location' ) ) {
		add_filter( 'elementor/theme/get_location_templates/header', '__return_empty_array', 99 );
		add_filter( 'elementor/theme/get_location_templates/footer', '__return_empty_array', 99 );
	}
}
add_action( 'template_redirect', 'akaza_sap_disable_builder_header_footer', 99 );

/**
 * Strip Elementor kit body classes that fight SucceedLearn typography.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function akaza_sap_body_class( $classes ) {
	if ( ! akaza_is_sap_landing_page() ) {
		return $classes;
	}

	return array_values(
		array_filter(
			(array) $classes,
			static function ( $class ) {
				return 0 !== strpos( (string) $class, 'elementor-' );
			}
		)
	);
}
add_filter( 'body_class', 'akaza_sap_body_class', 9999 );

/**
 * Dequeue Elementor kit/frontend CSS on SAP so global h1–h4 styles apply.
 */
function akaza_sap_dequeue_elementor_assets() {
	if ( ! akaza_is_sap_landing_page() ) {
		return;
	}

	$kit_id = (int) get_option( 'elementor_active_kit' );

	$style_handles = array(
		'elementor-frontend',
		'elementor-frontend-css',
		'elementor-frontend-legacy',
		'elementor-icons',
		'elementor-common',
		'elementor-wp-admin-bar',
		'elementor-global',
		'font-awesome',
		'e-animations',
		'e-swiper',
		'swiper',
	);

	if ( $kit_id ) {
		$style_handles[] = 'elementor-post-' . $kit_id;
	}

	foreach ( $style_handles as $handle ) {
		wp_dequeue_style( $handle );
		wp_deregister_style( $handle );
	}

	global $wp_styles;
	if ( $wp_styles instanceof WP_Styles ) {
		foreach ( array_keys( $wp_styles->registered ) as $handle ) {
			if (
				0 === strpos( $handle, 'elementor-post-' )
				|| 0 === strpos( $handle, 'elementor-gf-' )
				|| 0 === strpos( $handle, 'elementor-' )
			) {
				wp_dequeue_style( $handle );
				wp_deregister_style( $handle );
			}
		}
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_sap_dequeue_elementor_assets', 9999 );

/**
 * Enqueue Security Awareness and Phishing page styles/scripts.
 */
function akaza_enqueue_sap_assets() {
	if (
		( function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint() )
		|| ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() )
		|| ( function_exists( 'succeedlearn_amp_is_serving_amp' ) && succeedlearn_amp_is_serving_amp() )
	) {
		return;
	}

	$folder = 'security-awareness-and-phishing';
	$base   = array( 'akaza-main', 'akaza-fonts' );

	akaza_enqueue_theme_style( 'akaza-sl-sa-hero', "{$folder}/sl-sa-hero.css", $base );

	$annual_deps = $base;
	akaza_enqueue_theme_style( 'akaza-sl-sa-annual-training', "{$folder}/sl-sa-annual-training.css", $annual_deps );

	$sections = array(
		'sl-sa-platform'                 => array( 'sl-sa-platform.css', $annual_deps ),
		'sl-sa-definition'               => array( 'sl-sa-definition.css', $annual_deps ),
		'sl-sa-comparison'               => array( 'sl-sa-comparison.css', $annual_deps ),
		'sl-sa-security-behaviour-suite' => array( 'sl-sa-security-behaviour-suite.css', $annual_deps ),
		'sl-sa-lifecycle'                => array( 'sl-sa-lifecycle.css', $annual_deps ),
		'sl-sa-process'                  => array( 'sl-sa-process.css', array_merge( $annual_deps, array( 'akaza-sl-sa-annual-training' ) ) ),
		'sl-sa-leadership'               => array( 'sl-sa-leadership.css', array_merge( $annual_deps, array( 'akaza-sl-sa-annual-training' ) ) ),
		'sl-sa-achieve'                  => array( 'sl-sa-achieve.css', array_merge( $annual_deps, array( 'akaza-sl-sa-annual-training' ) ) ),
		'sl-sa-behaviour'                => array( 'sl-sa-behaviour.css', array_merge( $annual_deps, array( 'akaza-sl-sa-annual-training' ) ) ),
	);

	foreach ( $sections as $handle => $config ) {
		akaza_enqueue_theme_style( "akaza-{$handle}", "{$folder}/{$config[0]}", $config[1] );
	}

	akaza_enqueue_theme_script( 'akaza-sl-sa-dashboard-activity', "{$folder}/sl-sa-dashboard-activity.js" );
	akaza_enqueue_theme_script( 'akaza-sl-sa-security-behaviour-suite', "{$folder}/sl-sa-security-behaviour-suite.js" );

	akaza_enqueue_theme_style( 'akaza-contact-form', 'contact-from.css', $base );
	akaza_enqueue_theme_style(
		'akaza-sl-sa-contact',
		"{$folder}/sl-sa-contact.css",
		array_merge( $base, array( 'akaza-sl-sa-hero', 'akaza-contact-form' ) )
	);

	// Global FAQ accordion (CSS + JS). Registered in enqueue-core.php.
	wp_enqueue_style( 'akaza-global-faq' );
	wp_enqueue_script( 'akaza-global-faq' );

	akaza_enqueue_theme_style(
		'akaza-sl-sa-faq',
		"{$folder}/sl-sa-faq.css",
		array_merge( $base, array( 'akaza-global-faq' ) )
	);

	// Load last so SucceedLearn h1–h4 win over Elementor kit / Eduma leftovers.
	akaza_enqueue_theme_style(
		'akaza-sl-sa-typography',
		"{$folder}/sl-sa-typography.css",
		array_merge(
			$base,
			array(
				'akaza-sl-sa-hero',
				'akaza-sl-sa-contact',
				'akaza-sl-sa-faq',
				'akaza-global-faq',
				'akaza-global-title-accent',
				'akaza-global-panel-title',
			)
		)
	);
}

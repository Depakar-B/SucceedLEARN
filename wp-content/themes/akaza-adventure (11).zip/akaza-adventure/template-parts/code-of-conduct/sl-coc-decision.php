<?php
/**
 * Code of Conduct — Decision-Based Interactive Experience.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-coc-decision" aria-labelledby="sl-coc-decision-title">
	<div class="container">

		<div class="sl-coc-decision__heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Interactive Experience', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-decision-title">
				<?php
				echo wp_kses(
					__( 'Experience Code of Conduct Through <span>Real-World Scenarios</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>

			<p>
				<?php esc_html_e( 'Employees learn differently when they participate rather than simply read. SucceedLEARN uses realistic workplace scenarios to help employees practise ethical judgement in situations they could genuinely encounter.', 'akaza-adventure' ); ?>
			</p>
		</div>

		<div class="sl-coc-decision__experience">

			<!-- Scenario navigation -->
			<div class="sl-coc-decision__tabs" role="tablist" aria-label="<?php esc_attr_e( 'Training scenarios', 'akaza-adventure' ); ?>">

				<button
					class="sl-coc-decision__tab is-active"
					id="sl-coc-decision-tab-1"
					type="button"
					role="tab"
					aria-selected="true"
					aria-controls="sl-coc-decision-panel-1"
					data-scenario="1"
				>
					<span class="sl-coc-decision__tab-number">01</span>

					<span class="sl-coc-decision__tab-content">
						<span class="sl-coc-decision__tab-label">
							<?php esc_html_e( 'Conflict of Interest', 'akaza-adventure' ); ?>
						</span>

						<span class="sl-coc-decision__tab-description">
							<?php esc_html_e( 'Navigating potential conflicts', 'akaza-adventure' ); ?>
						</span>
					</span>

					<span class="sl-coc-decision__tab-arrow" aria-hidden="true">→</span>
				</button>

				<button
					class="sl-coc-decision__tab"
					id="sl-coc-decision-tab-2"
					type="button"
					role="tab"
					aria-selected="false"
					aria-controls="sl-coc-decision-panel-2"
					data-scenario="2"
				>
					<span class="sl-coc-decision__tab-number">02</span>

					<span class="sl-coc-decision__tab-content">
						<span class="sl-coc-decision__tab-label">
							<?php esc_html_e( 'Confidentiality', 'akaza-adventure' ); ?>
						</span>

						<span class="sl-coc-decision__tab-description">
							<?php esc_html_e( 'Protecting sensitive information', 'akaza-adventure' ); ?>
						</span>
					</span>

					<span class="sl-coc-decision__tab-arrow" aria-hidden="true">→</span>
				</button>

				<button
					class="sl-coc-decision__tab"
					id="sl-coc-decision-tab-3"
					type="button"
					role="tab"
					aria-selected="false"
					aria-controls="sl-coc-decision-panel-3"
					data-scenario="3"
				>
					<span class="sl-coc-decision__tab-number">03</span>

					<span class="sl-coc-decision__tab-content">
						<span class="sl-coc-decision__tab-label">
							<?php esc_html_e( 'Speak Up', 'akaza-adventure' ); ?>
						</span>

						<span class="sl-coc-decision__tab-description">
							<?php esc_html_e( 'Recognising when to raise concerns', 'akaza-adventure' ); ?>
						</span>
					</span>

					<span class="sl-coc-decision__tab-arrow" aria-hidden="true">→</span>
				</button>

			</div>

			<!-- Scenario content -->
			<div class="sl-coc-decision__panels">

				<!-- Scenario 1 -->
				<div
					class="sl-coc-decision__panel is-active"
					id="sl-coc-decision-panel-1"
					role="tabpanel"
					aria-labelledby="sl-coc-decision-tab-1"
					data-scenario-panel="1"
				>
					<div class="sl-coc-decision__panel-top">
						<span class="sl-coc-decision__panel-eyebrow">
							<?php esc_html_e( 'Scenario 01', 'akaza-adventure' ); ?>
						</span>

						<h3>
							<?php esc_html_e( 'Conflict of Interest', 'akaza-adventure' ); ?>
						</h3>
					</div>

					<div class="sl-coc-decision__situation">
						<span class="sl-coc-decision__label">
							<?php esc_html_e( 'The Situation', 'akaza-adventure' ); ?>
						</span>

						<p>
							<?php esc_html_e( 'Your team is evaluating three vendors. One of the vendors is owned by a close relative.', 'akaza-adventure' ); ?>
						</p>
					</div>

					<div class="sl-coc-decision__question">
						<span class="sl-coc-decision__label">
							<?php esc_html_e( 'The Decision', 'akaza-adventure' ); ?>
						</span>

						<p>
							<?php esc_html_e( 'What should you do?', 'akaza-adventure' ); ?>
						</p>
					</div>

					<div class="sl-coc-decision__feedback">
						<span class="sl-coc-decision__feedback-icon" aria-hidden="true">✓</span>

						<div>
							<span class="sl-coc-decision__label">
								<?php esc_html_e( 'Immediate Feedback', 'akaza-adventure' ); ?>
							</span>

							<p>
								<?php esc_html_e( 'The learner makes a decision and receives immediate feedback explaining the ethical considerations involved.', 'akaza-adventure' ); ?>
							</p>
						</div>
					</div>
				</div>

				<!-- Scenario 2 -->
				<div
					class="sl-coc-decision__panel"
					id="sl-coc-decision-panel-2"
					role="tabpanel"
					aria-labelledby="sl-coc-decision-tab-2"
					data-scenario-panel="2"
					hidden
				>
					<div class="sl-coc-decision__panel-top">
						<span class="sl-coc-decision__panel-eyebrow">
							<?php esc_html_e( 'Scenario 02', 'akaza-adventure' ); ?>
						</span>

						<h3>
							<?php esc_html_e( 'Confidentiality', 'akaza-adventure' ); ?>
						</h3>
					</div>

					<div class="sl-coc-decision__situation">
						<span class="sl-coc-decision__label">
							<?php esc_html_e( 'The Situation', 'akaza-adventure' ); ?>
						</span>

						<p>
							<?php esc_html_e( 'An employee receives a confidential presentation before travelling.', 'akaza-adventure' ); ?>
						</p>
					</div>

					<div class="sl-coc-decision__question">
						<span class="sl-coc-decision__label">
							<?php esc_html_e( 'The Decision', 'akaza-adventure' ); ?>
						</span>

						<p>
							<?php esc_html_e( 'Would it be appropriate to review the presentation in a crowded airport lounge?', 'akaza-adventure' ); ?>
						</p>
					</div>

					<div class="sl-coc-decision__feedback">
						<span class="sl-coc-decision__feedback-icon" aria-hidden="true">✓</span>

						<div>
							<span class="sl-coc-decision__label">
								<?php esc_html_e( 'Immediate Feedback', 'akaza-adventure' ); ?>
							</span>

							<p>
								<?php esc_html_e( 'The learner considers the confidentiality risks involved and receives immediate feedback on the ethical considerations.', 'akaza-adventure' ); ?>
							</p>
						</div>
					</div>
				</div>

				<!-- Scenario 3 -->
				<div
					class="sl-coc-decision__panel"
					id="sl-coc-decision-panel-3"
					role="tabpanel"
					aria-labelledby="sl-coc-decision-tab-3"
					data-scenario-panel="3"
					hidden
				>
					<div class="sl-coc-decision__panel-top">
						<span class="sl-coc-decision__panel-eyebrow">
							<?php esc_html_e( 'Scenario 03', 'akaza-adventure' ); ?>
						</span>

						<h3>
							<?php esc_html_e( 'Speak Up', 'akaza-adventure' ); ?>
						</h3>
					</div>

					<div class="sl-coc-decision__situation">
						<span class="sl-coc-decision__label">
							<?php esc_html_e( 'The Situation', 'akaza-adventure' ); ?>
						</span>

						<p>
							<?php esc_html_e( 'You notice behaviour that appears inconsistent with the Code, but you are not certain a violation has occurred.', 'akaza-adventure' ); ?>
						</p>
					</div>

					<div class="sl-coc-decision__question">
						<span class="sl-coc-decision__label">
							<?php esc_html_e( 'The Decision', 'akaza-adventure' ); ?>
						</span>

						<p>
							<?php esc_html_e( 'Should you report the concern?', 'akaza-adventure' ); ?>
						</p>
					</div>

					<div class="sl-coc-decision__feedback">
						<span class="sl-coc-decision__feedback-icon" aria-hidden="true">✓</span>

						<div>
							<span class="sl-coc-decision__label">
								<?php esc_html_e( 'Immediate Feedback', 'akaza-adventure' ); ?>
							</span>

							<p>
								<?php esc_html_e( 'The learner receives guidance on recognising when an ethical concern should be raised.', 'akaza-adventure' ); ?>
							</p>
						</div>
					</div>
				</div>

			</div>

		</div>

		<div class="sl-coc-decision__closing">
			<p>
				<?php
				echo wp_kses(
					__( 'These scenarios help employees develop <strong>ethical judgement</strong>, not simply recall policy statements.', 'akaza-adventure' ),
					array( 'strong' => array() )
				);
				?>
			</p>
		</div>

	</div>
</section>  
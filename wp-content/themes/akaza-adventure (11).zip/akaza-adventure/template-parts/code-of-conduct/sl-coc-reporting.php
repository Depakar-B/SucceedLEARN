<?php
/**
 * Code of Conduct — Reporting.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-coc-reporting" aria-labelledby="sl-coc-reporting-title">
	<div class="container">

		<div class="sl-coc-reporting__heading">

			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Reporting', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-reporting-title">
				<?php
				echo wp_kses(
					__( 'Turn Training Completion Into <span>Compliance Visibility</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>

			<h3>
				<?php esc_html_e( 'Knowing that training was assigned is not enough.', 'akaza-adventure' ); ?>
			</h3>

			<p>
				<?php esc_html_e( 'Compliance, HR and L&D teams need visibility into programme participation and learning outcomes. Depending on deployment configuration, SucceedLEARN reporting can help organizations monitor:', 'akaza-adventure' ); ?>
			</p>

		</div>

		<div class="sl-coc-reporting__grid">

			<div class="sl-coc-reporting__card">

				<ul>
					<li><?php esc_html_e( 'Training assignments', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Course completion', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Assessment performance', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Completion status', 'akaza-adventure' ); ?></li>
				</ul>

			</div>

			<div class="sl-coc-reporting__card">

				<ul>
					<li><?php esc_html_e( 'Learner progress', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Certificates', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Policy acknowledgement', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Compliance reporting', 'akaza-adventure' ); ?></li>
				</ul>

			</div>

		</div>

		<div class="sl-coc-reporting__closing">

	<p>
		<?php esc_html_e( 'Use training data to identify gaps, follow up with employees and support internal compliance and audit requirements.', 'akaza-adventure' ); ?>
	</p>

	<div class="sl-coc-reporting__cta-wrap">
		<a class="sl-coc-reporting__cta" href="#contact" data-cta="coc-reporting-demo">
			<?php esc_html_e( 'Discuss Your Reporting Requirements', 'akaza-adventure' ); ?>
			<span aria-hidden="true">→</span>
		</a>
	</div>

</div>

	</div>
</section>
<?php
/**
 * Code of Conduct — Industries.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$industries = array(
	__( 'Banking & Financial Services', 'akaza-adventure' ),
	__( 'Information Technology', 'akaza-adventure' ),
	__( 'Healthcare', 'akaza-adventure' ),
	__( 'Pharmaceuticals', 'akaza-adventure' ),
	__( 'Manufacturing', 'akaza-adventure' ),
	__( 'Retail', 'akaza-adventure' ),
	__( 'Professional Services', 'akaza-adventure' ),
	__( 'Education', 'akaza-adventure' ),
	__( 'Government & Public Sector', 'akaza-adventure' ),
	__( 'Global Enterprises', 'akaza-adventure' ),
);
?>

<section class="sl-coc-industries" aria-labelledby="sl-coc-industries-title">
	<div class="container">

		<div class="sl-coc-industries__heading">

			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Industries', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-industries-title">
				<?php
				echo wp_kses(
					__( 'Code of Conduct Training <span>Across Industries</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>

			<h3>
				<?php esc_html_e( 'Ethical risks differ across industries.', 'akaza-adventure' ); ?>
			</h3>

		</div>

		<div class="sl-coc-industries__main">

			<div class="sl-coc-industries__content">

				<div class="sl-coc-industries__intro">
					<p>
						<?php esc_html_e( 'SucceedLEARN can adapt training scenarios and examples for organisations operating in:', 'akaza-adventure' ); ?>
					</p>
				</div>

				<div class="sl-coc-industries__list" aria-label="<?php esc_attr_e( 'Industries covered', 'akaza-adventure' ); ?>">

					<?php foreach ( $industries as $industry ) : ?>
						<span class="sl-coc-industries__pill">
							<?php echo esc_html( $industry ); ?>
						</span>
					<?php endforeach; ?>

				</div>

			</div>

			<div class="sl-coc-industries__image">
				<div class="sl-coc-industries__image-placeholder" role="img" aria-label="<?php esc_attr_e( 'Code of Conduct training across industries image placeholder', 'akaza-adventure' ); ?>">
					<span><?php esc_html_e( 'IMAGE PLACEHOLDER', 'akaza-adventure' ); ?></span>
					<small><?php esc_html_e( 'Recommended: 560 × 640 px', 'akaza-adventure' ); ?></small>
				</div>
			</div>

		</div>

		<div class="sl-coc-industries__statement">
			<p>
				<?php esc_html_e( 'Industry-specific versions can focus on the ethical risks employees are most likely to encounter in their roles.', 'akaza-adventure' ); ?>
			</p>
		</div>

	</div>
</section>

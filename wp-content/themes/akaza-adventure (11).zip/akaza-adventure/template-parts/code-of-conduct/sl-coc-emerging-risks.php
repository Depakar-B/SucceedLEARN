<?php
/**
 * Code of Conduct — Emerging Ethical Risks.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-coc-emerging-risks" aria-labelledby="sl-coc-emerging-risks-title">
	<div class="container">

		<div class="sl-coc-emerging-risks__heading">
			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Emerging Topic', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-emerging-risks-title">
				<?php
				echo wp_kses(
					__( 'Prepare Employees for <span>New Ethical Risks</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>

			<h3>
				<?php esc_html_e( 'Codes of Conduct are evolving as technology changes the workplace.', 'akaza-adventure' ); ?>
			</h3>

			<p>
				<?php esc_html_e( "Where relevant to your organisation's policies, SucceedLEARN can incorporate emerging topics such as:", 'akaza-adventure' ); ?>
			</p>
		</div>



		<div class="sl-coc-emerging-risks__main">

			<div class="sl-coc-emerging-risks__image">
				<img
					src="<?php echo esc_url( akaza_upload_url( '2026/08/Prepare-Employees.webp' ) ); ?>"
					alt="<?php esc_attr_e( 'Employees navigating a difficult workplace ethics situation', 'akaza-adventure' ); ?>"
					width="760"
					height="500"
					loading="lazy"
					decoding="async"
				/>
			</div>

			<div class="sl-coc-emerging-risks__topics">

				<ul class="sl-coc-emerging-risks__list">
					<li><?php esc_html_e( 'Responsible AI Use', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Generative AI & Confidential Information', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Data Privacy', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Digital Workplace Behaviour', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Remote & Hybrid Working', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Cybersecurity Responsibilities', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Third-Party Risk', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Sustainability & Responsible Business', 'akaza-adventure' ); ?></li>
				</ul>

			</div>

		</div>

        <div class="sl-coc-emerging-risks__example">

<div class="sl-coc-emerging-risks__example-content">
    <span class="sl-coc-emerging-risks__example-label">
        <?php esc_html_e( 'For example:', 'akaza-adventure' ); ?>
    </span>

    <p>
        <?php esc_html_e( 'Is it acceptable to paste confidential customer information into a public Generative AI tool to summarize it?', 'akaza-adventure' ); ?>
    </p>
</div>

<div class="sl-coc-emerging-risks__insight">
    <span class="sl-coc-emerging-risks__insight-icon" aria-hidden="true">
        !
    </span>

    <p>
        <?php esc_html_e( "Modern workplace ethics training should help employees think through new situations — not simply memorize yesterday's rules.", 'akaza-adventure' ); ?>
    </p>
</div>

</div>

	</div>
</section>
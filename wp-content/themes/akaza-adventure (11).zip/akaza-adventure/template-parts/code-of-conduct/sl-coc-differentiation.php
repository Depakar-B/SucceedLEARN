<?php
/**
 * Code of Conduct — Differentiation.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="sl-coc-differentiation" aria-labelledby="sl-coc-differentiation-title">
	<div class="container">

		<div class="sl-coc-differentiation__heading">

			<span class="sl-home-sub-heading">
				<?php esc_html_e( 'Differentiation', 'akaza-adventure' ); ?>
			</span>

			<h2 id="sl-coc-differentiation-title">
				<?php
				echo wp_kses(
					__( 'More Than Traditional <span>Code of Conduct Training</span>', 'akaza-adventure' ),
					array( 'span' => array() )
				);
				?>
			</h2>

		</div>

		<div class="sl-coc-differentiation__grid">

			<article class="sl-coc-differentiation__card">

				<div class="sl-coc-differentiation__card-head">
					<h3>
						<?php esc_html_e( 'Traditional Compliance Training', 'akaza-adventure' ); ?>
					</h3>
				</div>

				<ul class="sl-coc-differentiation__list">
					<li><?php esc_html_e( 'Policy-heavy', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Passive learning', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Generic examples', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Standard course', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Completion focused', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Generic branding', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Limited deployment flexibility', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Basic reporting', 'akaza-adventure' ); ?></li>
				</ul>

			</article>

			<article class="sl-coc-differentiation__card">

				<div class="sl-coc-differentiation__card-head">
					<h3>
						<?php esc_html_e( 'SucceedLEARN Code of Conduct eLearning', 'akaza-adventure' ); ?>
					</h3>
				</div>

				<ul class="sl-coc-differentiation__list">
					<li><?php esc_html_e( 'Scenario-driven', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Interactive decision-making', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Customizable workplace scenarios', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Organization-specific experience', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Understanding + assessment', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Organization branding', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'LMS or hosted deployment', 'akaza-adventure' ); ?></li>
					<li><?php esc_html_e( 'Learning and compliance visibility', 'akaza-adventure' ); ?></li>
				</ul>

			</article>

		</div>

		<div class="sl-coc-differentiation__closing">

			<p>
				<?php esc_html_e( 'The goal isn’t simply to get employees through another mandatory course. The goal is to help employees recognize ethical risks and make better decisions.', 'akaza-adventure' ); ?>
			</p>

			<a class="sl-coc-differentiation__cta" href="#contact" data-cta="coc-differentiation-demo">
				<?php esc_html_e( 'Explore Code of Conduct Training', 'akaza-adventure' ); ?>
				<span aria-hidden="true">→</span>
			</a>

		</div>

	</div>
</section>
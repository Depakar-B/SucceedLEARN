
/**
 * SucceedLEARN — Code of Conduct Decision Experience.
 */

document.addEventListener('DOMContentLoaded', function () {
	const sections = document.querySelectorAll('.sl-coc-decision');

	sections.forEach(function (section) {
		const tabs = section.querySelectorAll('[data-scenario]');
		const panels = section.querySelectorAll('[data-scenario-panel]');

		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				const scenario = tab.getAttribute('data-scenario');

				tabs.forEach(function (item) {
					const isActive = item === tab;

					item.classList.toggle('is-active', isActive);
					item.setAttribute('aria-selected', isActive ? 'true' : 'false');
				});

				panels.forEach(function (panel) {
					const isActive = panel.getAttribute('data-scenario-panel') === scenario;

					panel.classList.toggle('is-active', isActive);
					panel.hidden = !isActive;
				});
			});
		});
	});
});

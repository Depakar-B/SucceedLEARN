<?php
/**
 * Akaza Adventure — performance-first SucceedLEARN theme.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AKAZA_VERSION', '1.2.1' );
define( 'AKAZA_DIR', get_template_directory() );
define( 'AKAZA_URI', get_template_directory_uri() );

require_once AKAZA_DIR . '/inc/courses-archive.php';
require_once AKAZA_DIR . '/inc/blog-archive.php';
require_once AKAZA_DIR . '/inc/blog-seed.php';
require_once AKAZA_DIR . '/inc/single-post.php';
require_once AKAZA_DIR . '/inc/single-course.php';
require_once AKAZA_DIR . '/inc/breadcrumbs.php';
require_once AKAZA_DIR . '/inc/contact-form-brand.php';
require_once AKAZA_DIR . '/inc/client-testimonials.php';
require_once AKAZA_DIR . '/inc/client-logos.php';
require_once AKAZA_DIR . '/inc/site-search.php';
require_once AKAZA_DIR . '/inc/inclusive-courses-data.php';

/**
 * Theme setup.
 */
function akaza_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 56,
			'width'       => 180,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'akaza-adventure' ),
			'footer'  => __( 'Footer Menu', 'akaza-adventure' ),
		)
	);

	add_image_size( 'akaza-course-card', 640, 400, true );
	add_image_size( 'akaza-blog-card', 640, 400, true );
	add_image_size( 'akaza-course-hero', 1200, 675, true );
}
add_action( 'after_setup_theme', 'akaza_setup' );

/**
 * Enqueue assets — deferred JS, versioned by filemtime.
 */
function akaza_enqueue_assets() {
	$css_path = AKAZA_DIR . '/assets/css/main.css';
	$js_path  = AKAZA_DIR . '/assets/js/main.js';

	wp_enqueue_style(
		'akaza-main',
		AKAZA_URI . '/assets/css/main.css',
		array( 'akaza-fonts' ),
		file_exists( $css_path ) ? (string) filemtime( $css_path ) : AKAZA_VERSION
	);

	$global_faq_css = AKAZA_DIR . '/assets/css/global-faq.css';
	wp_enqueue_style(
		'akaza-global-faq',
		AKAZA_URI . '/assets/css/global-faq.css',
		array( 'akaza-main' ),
		file_exists( $global_faq_css ) ? (string) filemtime( $global_faq_css ) : AKAZA_VERSION
	);

	$global_faq_js = AKAZA_DIR . '/assets/js/global-faq.js';
	wp_enqueue_script(
		'akaza-global-faq',
		AKAZA_URI . '/assets/js/global-faq.js',
		array(),
		file_exists( $global_faq_js ) ? (string) filemtime( $global_faq_js ) : AKAZA_VERSION,
		true
	);

	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		$hero_css       = AKAZA_DIR . '/assets/css/home-hero.css';
		$stats_css      = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js       = AKAZA_DIR . '/assets/js/stats.js';
		$clients_css    = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js     = AKAZA_DIR . '/assets/js/clients.js';
		$challenges_css = AKAZA_DIR . '/assets/css/todays-challenges.css';
		$solution_css   = AKAZA_DIR . '/assets/css/the-solution.css';
		$solution_js    = AKAZA_DIR . '/assets/js/the-solution.js';
		$platform_css   = AKAZA_DIR . '/assets/css/platform.css';
		$feature_css    = AKAZA_DIR . '/assets/css/feature-product-section.css';
		$outcomes_css   = AKAZA_DIR . '/assets/css/outcomes.css';
		$started_css    = AKAZA_DIR . '/assets/css/Getting-Started-Section.css';
		$started_js     = AKAZA_DIR . '/assets/js/getting-started.js';
		$cta_css           = AKAZA_DIR . '/assets/css/cta-section.css';
		$contact_css       = AKAZA_DIR . '/assets/css/contact-from.css';
		$testimonials_css  = AKAZA_DIR . '/assets/css/dpdpa-testimonials.css';

		wp_enqueue_style(
			'akaza-home-hero',
			AKAZA_URI . '/assets/css/home-hero.css',
			array( 'akaza-main' ),
			file_exists( $hero_css ) ? (string) filemtime( $hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main' ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main' ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-todays-challenges',
			AKAZA_URI . '/assets/css/todays-challenges.css',
			array( 'akaza-main' ),
			file_exists( $challenges_css ) ? (string) filemtime( $challenges_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-the-solution',
			AKAZA_URI . '/assets/css/the-solution.css',
			array( 'akaza-main' ),
			file_exists( $solution_css ) ? (string) filemtime( $solution_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-the-solution',
			AKAZA_URI . '/assets/js/the-solution.js',
			array(),
			file_exists( $solution_js ) ? (string) filemtime( $solution_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-platform',
			AKAZA_URI . '/assets/css/platform.css',
			array( 'akaza-main' ),
			file_exists( $platform_css ) ? (string) filemtime( $platform_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-feature-product',
			AKAZA_URI . '/assets/css/feature-product-section.css',
			array( 'akaza-main' ),
			file_exists( $feature_css ) ? (string) filemtime( $feature_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-outcomes',
			AKAZA_URI . '/assets/css/outcomes.css',
			array( 'akaza-main' ),
			file_exists( $outcomes_css ) ? (string) filemtime( $outcomes_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-home-testimonials',
			AKAZA_URI . '/assets/css/dpdpa-testimonials.css',
			array( 'akaza-main' ),
			file_exists( $testimonials_css ) ? (string) filemtime( $testimonials_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'bootstrap-icons',
			'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
			array(),
			'1.11.3'
		);

		wp_enqueue_style(
			'akaza-getting-started',
			AKAZA_URI . '/assets/css/Getting-Started-Section.css',
			array( 'akaza-main', 'bootstrap-icons' ),
			file_exists( $started_css ) ? (string) filemtime( $started_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-getting-started',
			AKAZA_URI . '/assets/js/getting-started.js',
			array(),
			file_exists( $started_js ) ? (string) filemtime( $started_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-cta-section',
			AKAZA_URI . '/assets/css/cta-section.css',
			array( 'akaza-main' ),
			file_exists( $cta_css ) ? (string) filemtime( $cta_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main' ),
			file_exists( $contact_css ) ? (string) filemtime( $contact_css ) : AKAZA_VERSION
		);
	}

	$is_dpdpa_page = is_page_template( 'page-templates/dpdpa-compliance-training.php' );
	$is_gdpr_page  = is_page_template( 'page-templates/gdpr-employee-awareness-training.php' );
	$is_gwct_page  = is_page_template( 'page-templates/global-workplace-compliance-training-for-employees.php' )
		|| is_page( 'hr-compliance-suite' );
	$is_inclusive_training_page = is_page_template( 'page-templates/inclusive-workplace-training.php' );
	$is_iwc_course_page         = is_page_template( 'page-templates/equality-diversity-inclusion-training.php' )
		|| is_page_template( 'page-templates/unconscious-bias-training.php' )
		|| is_page_template( 'page-templates/bystander-intervention-training.php' );
	$is_about_page              = is_page_template( 'page-templates/page-about.php' );
	$is_contact_page            = is_page_template( 'page-templates/page-contact.php' );
	$is_clients_page            = is_page_template( 'page-templates/page-clients.php' );
	$is_privacy_page            = is_page_template( 'page-templates/privacy-policy.php' );
	$is_terms_page              = is_page_template( 'page-templates/terms-and-conditions.php' );
	$is_sphish_report_page      = is_page_template( 'page-templates/s-phish-report.php' );
	$is_defensive_driving_page  = is_page_template( 'page-templates/defensive-driving.php' );
	$is_fcp_page                = is_page_template( 'page-templates/financial-crime-prevention.php' );
	$is_sap_page                = is_page_template( 'page-templates/security-awareness-and-phishing.php' );
	$is_coc_page                = is_page_template( 'page-templates/code-of-conduct.php' )
		|| is_page_template( 'page-templates/code-of-conduct-elearning-training.php' );

	if ( $is_about_page || $is_contact_page ) {
		akaza_enqueue_solutions_carousel();
	}

	if ( $is_privacy_page || $is_terms_page || $is_sphish_report_page ) {
		$legal_css = AKAZA_DIR . '/assets/css/legal-page.css';
		wp_enqueue_style(
			'akaza-legal-page',
			AKAZA_URI . '/assets/css/legal-page.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $legal_css ) ? (string) filemtime( $legal_css ) : AKAZA_VERSION
		);
	}

	if ( $is_defensive_driving_page ) {
		akaza_enqueue_course_marketing_styles( 'defensive-driving' );
	}

	if ( $is_fcp_page ) {
		$fcp_global_css     = AKAZA_DIR . '/assets/css/fcp-global.css';
		$fcp_hero_css       = AKAZA_DIR . '/assets/css/fcp-hero.css';
		$fcp_page_guide_css = AKAZA_DIR . '/assets/css/fcp-page-guide.css';
		$fcp_what_is_financial_crime_css = AKAZA_DIR . '/assets/css/fcp-what-is-financial-crime.css';
		$fcp_why_it_matters_css = AKAZA_DIR . '/assets/css/fcp-why-it-matters.css';
		$fcp_online_employee_training_css = AKAZA_DIR . '/assets/css/fcp-online-employee-training.css';
		$fcp_six_core_course_areas_css = AKAZA_DIR . '/assets/css/fcp-six-core-course-areas.css';
		$fcp_training_at_a_glance_css = AKAZA_DIR . '/assets/css/fcp-training-at-a-glance.css';
		$fcp_training_by_role_css = AKAZA_DIR . '/assets/css/fcp-training-by-role.css';
		$fcp_flexible_implementation_css = AKAZA_DIR . '/assets/css/fcp-flexible-implementation.css';
		$fcp_sl_fcp_cpd_css = AKAZA_DIR . '/assets/css/fcp-sl-fcp-cpd.css';
		$fcp_sl_fcp_contact_css = AKAZA_DIR . '/assets/css/fcp-sl-fcp-contact.css';
		$fcp_contact_form_css = AKAZA_DIR . '/assets/css/contact-from.css';	
		wp_enqueue_style(
			'akaza-fcp-global',
			AKAZA_URI . '/assets/css/fcp-global.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $fcp_global_css ) ? (string) filemtime( $fcp_global_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-fcp-hero',
			AKAZA_URI . '/assets/css/fcp-hero.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_hero_css ) ? (string) filemtime( $fcp_hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-fcp-page-guide',
			AKAZA_URI . '/assets/css/fcp-page-guide.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_page_guide_css ) ? (string) filemtime( $fcp_page_guide_css ) : AKAZA_VERSION
		);
		wp_enqueue_style(
			'akaza-fcp-what-is-financial-crime',
			AKAZA_URI . '/assets/css/fcp-what-is-financial-crime.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_what_is_financial_crime_css ) ? (string) filemtime( $fcp_what_is_financial_crime_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-fcp-why-it-matters',
			AKAZA_URI . '/assets/css/fcp-why-it-matters.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_why_it_matters_css ) ? (string) filemtime( $fcp_why_it_matters_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-fcp-online-employee-training',
			AKAZA_URI . '/assets/css/fcp-online-employee-training.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_online_employee_training_css ) ? (string) filemtime( $fcp_online_employee_training_css ) : AKAZA_VERSION
		);
		wp_enqueue_style(
			'akaza-fcp-six-core-course-areas',
			AKAZA_URI . '/assets/css/fcp-six-core-course-areas.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_six_core_course_areas_css ) ? (string) filemtime( $fcp_six_core_course_areas_css ) : AKAZA_VERSION
		);
		wp_enqueue_style(
			'akaza-fcp-training-at-a-glance',
			AKAZA_URI . '/assets/css/fcp-training-at-a-glance.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_training_at_a_glance_css ) ? (string) filemtime( $fcp_training_at_a_glance_css ) : AKAZA_VERSION
		);
		wp_enqueue_style(
			'akaza-fcp-training-by-role',
			AKAZA_URI . '/assets/css/fcp-training-by-role.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_training_by_role_css ) ? (string) filemtime( $fcp_training_by_role_css ) : AKAZA_VERSION
		);
		wp_enqueue_style(
			'akaza-fcp-flexible-implementation',
			AKAZA_URI . '/assets/css/fcp-flexible-implementation.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_flexible_implementation_css ) ? (string) filemtime( $fcp_flexible_implementation_css ) : AKAZA_VERSION
		);
		wp_enqueue_style(
			'akaza-fcp-sl-fcp-cpd',
			AKAZA_URI . '/assets/css/fcp-sl-fcp-cpd.css',
			array( 'akaza-fcp-global' ),
			file_exists( $fcp_sl_fcp_cpd_css ) ? (string) filemtime( $fcp_sl_fcp_cpd_css ) : AKAZA_VERSION
		);
		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $fcp_contact_form_css ) ? (string) filemtime( $fcp_contact_form_css ) : AKAZA_VERSION
		);
		wp_enqueue_style(
			'akaza-fcp-sl-fcp-contact',
			AKAZA_URI . '/assets/css/fcp-sl-fcp-contact.css',
			array( 'akaza-fcp-global', 'akaza-contact-form' ),
			file_exists( $fcp_sl_fcp_contact_css ) ? (string) filemtime( $fcp_sl_fcp_contact_css ) : AKAZA_VERSION
		);
	}

	if ( $is_sap_page ) {
		$sap_hero_css  = AKAZA_DIR . '/assets/css/sl-sa-hero.css';
		$sap_stats_css = AKAZA_DIR . '/assets/css/stats.css';
		$sap_stats_js  = AKAZA_DIR . '/assets/js/stats.js';
		$sap_clients_css = AKAZA_DIR . '/assets/css/clients.css';
		$sap_clients_js  = AKAZA_DIR . '/assets/js/clients.js';
		$sap_platform_css = AKAZA_DIR . '/assets/css/sl-sa-platform.css';
		$sap_definition_css = AKAZA_DIR . '/assets/css/sl-sa-definition.css';
		$sap_annual_training_css = AKAZA_DIR . '/assets/css/sl-sa-annual-training.css';
		$sap_process_css = AKAZA_DIR . '/assets/css/sl-sa-process.css';
		$sap_traditional_css = AKAZA_DIR . '/assets/css/sl-sa-traditional.css';
		$sap_comparison_css = AKAZA_DIR . '/assets/css/sl-sa-comparison.css';
		$sap_leadership_css = AKAZA_DIR . '/assets/css/sl-sa-leadership.css';
		$sap_compliance_css = AKAZA_DIR . '/assets/css/sl-sa-compliance.css';
		$sap_dashboard_js = AKAZA_DIR . '/assets/js/sl-sa-dashboard-activity.js';
		$sap_security_behaviour_suite_css = AKAZA_DIR . '/assets/css/sl-sa-security-behaviour-suite.css';
		$sap_security_behaviour_suite_js = AKAZA_DIR . '/assets/js/sl-sa-security-behaviour-suite.js';
		$sap_achieve_css = AKAZA_DIR . '/assets/css/sl-sa-achieve.css';	
		$sap_lifecycle_css = AKAZA_DIR . '/assets/css/sl-sa-lifecycle.css';
		$sap_behaviour_css = AKAZA_DIR . '/assets/css/sl-sa-behaviour.css';
		$sap_contact_css = AKAZA_DIR . '/assets/css/sl-sa-contact.css';
		$sap_contact_form_css = AKAZA_DIR . '/assets/css/contact-from.css';
		wp_enqueue_style(
			'akaza-sl-sa-hero',
			AKAZA_URI . '/assets/css/sl-sa-hero.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_hero_css ) ? (string) filemtime( $sap_hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main' ),
			file_exists( $sap_stats_css ) ? (string) filemtime( $sap_stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $sap_stats_js ) ? (string) filemtime( $sap_stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main' ),
			file_exists( $sap_clients_css ) ? (string) filemtime( $sap_clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $sap_clients_js ) ? (string) filemtime( $sap_clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-sl-sa-platform',
			AKAZA_URI . '/assets/css/sl-sa-platform.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_platform_css ) ? (string) filemtime( $sap_platform_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-definition',
			AKAZA_URI . '/assets/css/sl-sa-definition.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_definition_css ) ? (string) filemtime( $sap_definition_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-annual-training',
			AKAZA_URI . '/assets/css/sl-sa-annual-training.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_annual_training_css ) ? (string) filemtime( $sap_annual_training_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-process',
			AKAZA_URI . '/assets/css/sl-sa-process.css',
			array( 'akaza-main', 'akaza-fonts', 'akaza-sl-sa-annual-training' ),
			file_exists( $sap_process_css ) ? (string) filemtime( $sap_process_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-traditional',
			AKAZA_URI . '/assets/css/sl-sa-traditional.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_traditional_css ) ? (string) filemtime( $sap_traditional_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-comparison',
			AKAZA_URI . '/assets/css/sl-sa-comparison.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_comparison_css ) ? (string) filemtime( $sap_comparison_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-leadership',
			AKAZA_URI . '/assets/css/sl-sa-leadership.css',
			array( 'akaza-main', 'akaza-fonts', 'akaza-sl-sa-annual-training' ),
			file_exists( $sap_leadership_css ) ? (string) filemtime( $sap_leadership_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-compliance',
			AKAZA_URI . '/assets/css/sl-sa-compliance.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_compliance_css ) ? (string) filemtime( $sap_compliance_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-sl-sa-dashboard-activity',
			AKAZA_URI . '/assets/js/sl-sa-dashboard-activity.js',
			array(),
			file_exists( $sap_dashboard_js ) ? (string) filemtime( $sap_dashboard_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-sl-sa-security-behaviour-suite',
			AKAZA_URI . '/assets/css/sl-sa-security-behaviour-suite.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_security_behaviour_suite_css ) ? (string) filemtime( $sap_security_behaviour_suite_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-sl-sa-security-behaviour-suite',
			AKAZA_URI . '/assets/js/sl-sa-security-behaviour-suite.js',
			array(),
			file_exists( $sap_security_behaviour_suite_js ) ? (string) filemtime( $sap_security_behaviour_suite_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-sl-sa-achieve',
			AKAZA_URI . '/assets/css/sl-sa-achieve.css',
			array( 'akaza-main', 'akaza-fonts', 'akaza-sl-sa-annual-training' ),
			file_exists( $sap_achieve_css ) ? (string) filemtime( $sap_achieve_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-lifecycle',
			AKAZA_URI . '/assets/css/sl-sa-lifecycle.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_lifecycle_css ) ? (string) filemtime( $sap_lifecycle_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-behaviour',
			AKAZA_URI . '/assets/css/sl-sa-behaviour.css',
			array( 'akaza-main', 'akaza-fonts', 'akaza-sl-sa-annual-training' ),
			file_exists( $sap_behaviour_css ) ? (string) filemtime( $sap_behaviour_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $sap_contact_form_css ) ? (string) filemtime( $sap_contact_form_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-sa-contact',
			AKAZA_URI . '/assets/css/sl-sa-contact.css',
			array( 'akaza-sl-sa-hero', 'akaza-contact-form' ),
			file_exists( $sap_contact_css ) ? (string) filemtime( $sap_contact_css ) : AKAZA_VERSION
		);
	}

	if ( $is_coc_page ) {
		$coc_hero_css = AKAZA_DIR . '/assets/css/sl-code-of-conduct-hero.css';
		$coc_hero_js  = AKAZA_DIR . '/assets/js/sl-code-of-conduct-hero.js';
		$coc_features_css = AKAZA_DIR . '/assets/css/sl-code-conduct-features.css';
		$coc_features_js = AKAZA_DIR . '/assets/js/sl-code-conduct-features.js';
		$coc_definition_css = AKAZA_DIR . '/assets/css/sl-code-conduct-definition.css';
		$coc_definition_js = AKAZA_DIR . '/assets/js/sl-code-conduct-definition.js';
		$coc_matters_css = AKAZA_DIR . '/assets/css/sl-code-conduct-matters.css';
		$coc_matters_js = AKAZA_DIR . '/assets/js/sl-code-conduct-matters.js';
		$coc_problem_css = AKAZA_DIR . '/assets/css/sl-coc-problem.css';
		$coc_problem_js = AKAZA_DIR . '/assets/js/sl-coc-problem.js';
		$coc_coverage_css = AKAZA_DIR . '/assets/css/sl-coc-coverage.css';
		$coc_coverage_js = AKAZA_DIR . '/assets/js/sl-coc-coverage.js';
		$coc_cta_css = AKAZA_DIR . '/assets/css/sl-coc-cta.css';
		$coc_cta_js = AKAZA_DIR . '/assets/js/sl-coc-cta.js';
		$coc_emerging_risks_css = AKAZA_DIR . '/assets/css/sl-coc-emerging-risks.css';
		$coc_emerging_risks_js = AKAZA_DIR . '/assets/js/sl-coc-emerging-risks.js';

		wp_enqueue_style(
			'akaza-sl-code-of-conduct-hero',
			AKAZA_URI . '/assets/css/sl-code-of-conduct-hero.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $coc_hero_css ) ? (string) filemtime( $coc_hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-sl-code-of-conduct-hero',
			AKAZA_URI . '/assets/js/sl-code-of-conduct-hero.js',
			array(),
			file_exists( $coc_hero_js ) ? (string) filemtime( $coc_hero_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		$coc_features_css = AKAZA_DIR . '/assets/css/sl-code-conduct-features.css';
		wp_enqueue_style(
			'akaza-sl-code-conduct-features',
			AKAZA_URI . '/assets/css/sl-code-conduct-features.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_features_css ) ? (string) filemtime( $coc_features_css ) : AKAZA_VERSION
		);

		$coc_definition_css = AKAZA_DIR . '/assets/css/sl-code-conduct-definition.css';
		wp_enqueue_style(
			'akaza-sl-code-conduct-definition',
			AKAZA_URI . '/assets/css/sl-code-conduct-definition.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_definition_css ) ? (string) filemtime( $coc_definition_css ) : AKAZA_VERSION
		);
		$coc_matters_css = AKAZA_DIR . '/assets/css/sl-code-conduct-matters.css';
		wp_enqueue_style(
			'akaza-sl-code-conduct-matters',
			AKAZA_URI . '/assets/css/sl-code-conduct-matters.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_matters_css ) ? (string) filemtime( $coc_matters_css ) : AKAZA_VERSION
		);

		$coc_problem_css = AKAZA_DIR . '/assets/css/sl-coc-problem.css';
		wp_enqueue_style(
			'akaza-sl-coc-problem',
			AKAZA_URI . '/assets/css/sl-coc-problem.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_problem_css ) ? (string) filemtime( $coc_problem_css ) : AKAZA_VERSION
		);
		$coc_coverage_css = AKAZA_DIR . '/assets/css/sl-coc-coverage.css';
		wp_enqueue_style(
			'akaza-sl-coc-coverage',
			AKAZA_URI . '/assets/css/sl-coc-coverage.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_coverage_css ) ? (string) filemtime( $coc_coverage_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-sl-coc-coverage',
			AKAZA_URI . '/assets/js/sl-coc-coverage.js',
			array(),
			file_exists( $coc_coverage_js ) ? (string) filemtime( $coc_coverage_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		$coc_cta_css = AKAZA_DIR . '/assets/css/sl-coc-cta.css';
		wp_enqueue_style(
			'akaza-sl-coc-cta',
			AKAZA_URI . '/assets/css/sl-coc-cta.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_cta_css ) ? (string) filemtime( $coc_cta_css ) : AKAZA_VERSION
		);
		$coc_cta_js = AKAZA_DIR . '/assets/js/sl-coc-cta.js';
		wp_enqueue_script(
			'akaza-sl-coc-cta',
			AKAZA_URI . '/assets/js/sl-coc-cta.js',
			array(),
			file_exists( $coc_cta_js ) ? (string) filemtime( $coc_cta_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
		$coc_emerging_risks_css = AKAZA_DIR . '/assets/css/sl-coc-emerging-risks.css';
		wp_enqueue_style(
			'akaza-sl-coc-emerging-risks',
			AKAZA_URI . '/assets/css/sl-coc-emerging-risks.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_emerging_risks_css ) ? (string) filemtime( $coc_emerging_risks_css ) : AKAZA_VERSION
		);
		$coc_interactive_css = AKAZA_DIR . '/assets/css/sl-coc-interactive.css';
		wp_enqueue_style(
			'akaza-sl-coc-interactive',
			AKAZA_URI . '/assets/css/sl-coc-interactive.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_interactive_css ) ? (string) filemtime( $coc_interactive_css ) : AKAZA_VERSION
		);
		$coc_decision_css = AKAZA_DIR . '/assets/css/sl-coc-decision.css';
		wp_enqueue_style(
			'akaza-sl-coc-decision',
			AKAZA_URI . '/assets/css/sl-coc-decision.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_decision_css ) ? (string) filemtime( $coc_decision_css ) : AKAZA_VERSION
		);
		$coc_decision_js = AKAZA_DIR . '/assets/js/sl-coc-decision.js';
		wp_enqueue_script(
			'akaza-sl-coc-decision',
			AKAZA_URI . '/assets/js/sl-coc-decision.js',
			array(),
			file_exists( $coc_decision_js ) ? (string) filemtime( $coc_decision_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
		$coc_learning_css = AKAZA_DIR . '/assets/css/sl-coc-learning.css';
		wp_enqueue_style(
			'akaza-sl-coc-learning',
			AKAZA_URI . '/assets/css/sl-coc-learning.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_learning_css ) ? (string) filemtime( $coc_learning_css ) : AKAZA_VERSION
		);

		$coc_customization_css = AKAZA_DIR . '/assets/css/sl-coc-customization.css';
		wp_enqueue_style(
			'akaza-sl-coc-customization',
			AKAZA_URI . '/assets/css/sl-coc-customization.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_customization_css ) ? (string) filemtime( $coc_customization_css ) : AKAZA_VERSION
		);
		$coc_deployment_css = AKAZA_DIR . '/assets/css/sl-coc-deployment.css';
		wp_enqueue_style(
			'akaza-sl-coc-deployment',
			AKAZA_URI . '/assets/css/sl-coc-deployment.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_deployment_css ) ? (string) filemtime( $coc_deployment_css ) : AKAZA_VERSION
		);
		$coc_accessibility_css = AKAZA_DIR . '/assets/css/sl-coc-accessibility.css';
		wp_enqueue_style(
			'akaza-sl-coc-accessibility',
			AKAZA_URI . '/assets/css/sl-coc-accessibility.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_accessibility_css ) ? (string) filemtime( $coc_accessibility_css ) : AKAZA_VERSION
		);
		$coc_reporting_css = AKAZA_DIR . '/assets/css/sl-coc-reporting.css';
		wp_enqueue_style(
			'akaza-sl-coc-reporting',
			AKAZA_URI . '/assets/css/sl-coc-reporting.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_reporting_css ) ? (string) filemtime( $coc_reporting_css ) : AKAZA_VERSION
		);
		$coc_audience_css = AKAZA_DIR . '/assets/css/sl-coc-audience.css';
		wp_enqueue_style(
			'akaza-sl-coc-audience',
			AKAZA_URI . '/assets/css/sl-coc-audience.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_audience_css ) ? (string) filemtime( $coc_audience_css ) : AKAZA_VERSION
		);
		$coc_buyer_personas_css = AKAZA_DIR . '/assets/css/sl-coc-buyer-personas.css';
		wp_enqueue_style(
			'akaza-sl-coc-buyer-personas',
			AKAZA_URI . '/assets/css/sl-coc-buyer-personas.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_buyer_personas_css ) ? (string) filemtime( $coc_buyer_personas_css ) : AKAZA_VERSION
		);
		$coc_cta_section_css = AKAZA_DIR . '/assets/css/sl-coc-cta-section.css';
		wp_enqueue_style(
			'akaza-sl-coc-cta-section',
			AKAZA_URI . '/assets/css/sl-coc-cta-section.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_cta_section_css ) ? (string) filemtime( $coc_cta_section_css ) : AKAZA_VERSION
		);
		$coc_cta_section_js = AKAZA_DIR . '/assets/js/sl-coc-cta-section.js';
		wp_enqueue_script(
			'akaza-sl-coc-cta-section',
			AKAZA_URI . '/assets/js/sl-coc-cta-section.js',
			array(),
			file_exists( $coc_cta_section_js ) ? (string) filemtime( $coc_cta_section_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
		$coc_industries_css = AKAZA_DIR . '/assets/css/sl-coc-industries.css';
		wp_enqueue_style(
			'akaza-sl-coc-industries',
			AKAZA_URI . '/assets/css/sl-coc-industries.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_industries_css ) ? (string) filemtime( $coc_industries_css ) : AKAZA_VERSION
		);
		$coc_differentiation_css = AKAZA_DIR . '/assets/css/sl-coc-differentiation.css';
		wp_enqueue_style(
			'akaza-sl-coc-differentiation',
			AKAZA_URI . '/assets/css/sl-coc-differentiation.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_differentiation_css ) ? (string) filemtime( $coc_differentiation_css ) : AKAZA_VERSION
		);
		$coc_stats_css = AKAZA_DIR . '/assets/css/sl-coc-stats.css';
		wp_enqueue_style(
			'akaza-sl-coc-stats',
			AKAZA_URI . '/assets/css/sl-coc-stats.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_stats_css ) ? (string) filemtime( $coc_stats_css ) : AKAZA_VERSION
			);
		$coc_customer_story_css = AKAZA_DIR . '/assets/css/sl-coc-customer-story.css';
		wp_enqueue_style(
			'akaza-sl-coc-customer-story',
			AKAZA_URI . '/assets/css/sl-coc-customer-story.css',
			array( 'akaza-sl-code-of-conduct-hero' ),
			file_exists( $coc_customer_story_css ) ? (string) filemtime( $coc_customer_story_css ) : AKAZA_VERSION
		);

		$coc_stats_js = AKAZA_DIR . '/assets/js/sl-coc-stats.js';
		wp_enqueue_script(
			'akaza-sl-coc-stats',
			AKAZA_URI . '/assets/js/sl-coc-stats.js',
			array(),
			file_exists( $coc_stats_js ) ? (string) filemtime( $coc_stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		$coc_contact_form_css = AKAZA_DIR . '/assets/css/contact-from.css';
		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $coc_contact_form_css ) ? (string) filemtime( $coc_contact_form_css ) : AKAZA_VERSION
		);

		$coc_contact_css = AKAZA_DIR . '/assets/css/sl-coc-contact.css';
		wp_enqueue_style(
			'akaza-sl-coc-contact',
			AKAZA_URI . '/assets/css/sl-coc-contact.css',
			array( 'akaza-sl-code-of-conduct-hero', 'akaza-contact-form' ),
			file_exists( $coc_contact_css ) ? (string) filemtime( $coc_contact_css ) : AKAZA_VERSION
		);
	}

	if ( $is_about_page || $is_contact_page ) {
		$stats_css   = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js    = AKAZA_DIR . '/assets/js/stats.js';
		$clients_css = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js  = AKAZA_DIR . '/assets/js/clients.js';
		$page_style  = $is_about_page ? 'akaza-about-us' : 'akaza-contact-us';

		if ( $is_about_page ) {
			$about_css = AKAZA_DIR . '/assets/css/about-us.css';
			wp_enqueue_style(
				'akaza-about-us',
				AKAZA_URI . '/assets/css/about-us.css',
				array( 'akaza-main', 'akaza-fonts' ),
				file_exists( $about_css ) ? (string) filemtime( $about_css ) : AKAZA_VERSION
			);
		}

		if ( $is_contact_page ) {
			$contact_page_css = AKAZA_DIR . '/assets/css/contact-us.css';
			$contact_form_css = AKAZA_DIR . '/assets/css/contact-from.css';

			wp_enqueue_style(
				'akaza-contact-form',
				AKAZA_URI . '/assets/css/contact-from.css',
				array( 'akaza-main', 'akaza-fonts' ),
				file_exists( $contact_form_css ) ? (string) filemtime( $contact_form_css ) : AKAZA_VERSION
			);

			wp_enqueue_style(
				'akaza-contact-us',
				AKAZA_URI . '/assets/css/contact-us.css',
				array( 'akaza-main', 'akaza-fonts', 'akaza-contact-form' ),
				file_exists( $contact_page_css ) ? (string) filemtime( $contact_page_css ) : AKAZA_VERSION
			);
		}

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main', 'akaza-fonts', $page_style ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main', 'akaza-fonts', $page_style ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	if ( $is_clients_page ) {
		$clients_page_css = AKAZA_DIR . '/assets/css/clients-page.css';
		$stats_css        = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js         = AKAZA_DIR . '/assets/js/stats.js';

		wp_enqueue_style(
			'akaza-clients-page',
			AKAZA_URI . '/assets/css/clients-page.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $clients_page_css ) ? (string) filemtime( $clients_page_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main', 'akaza-fonts', 'akaza-clients-page' ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	if ( $is_inclusive_training_page ) {
		$inclusive_training_css = AKAZA_DIR . '/assets/css/inclusive-workplace-training.css';
		$gwct_hero_css          = AKAZA_DIR . '/assets/css/global-workplace-hero.css';
		$gwct_behaviour_css     = AKAZA_DIR . '/assets/css/global-workplace-behaviour.css';
		$gwct_cta_css           = AKAZA_DIR . '/assets/css/global-workplace-cta.css';
		$contact_css            = AKAZA_DIR . '/assets/css/contact-from.css';
		$stats_css              = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js               = AKAZA_DIR . '/assets/js/stats.js';
		$clients_css            = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js             = AKAZA_DIR . '/assets/js/clients.js';

		wp_enqueue_style(
			'bootstrap-icons',
			'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
			array(),
			'1.11.3'
		);

		wp_enqueue_style(
			'akaza-global-workplace-hero',
			AKAZA_URI . '/assets/css/global-workplace-hero.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $gwct_hero_css ) ? (string) filemtime( $gwct_hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-behaviour',
			AKAZA_URI . '/assets/css/global-workplace-behaviour.css',
			array( 'akaza-main', 'akaza-fonts', 'bootstrap-icons' ),
			file_exists( $gwct_behaviour_css ) ? (string) filemtime( $gwct_behaviour_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-cta',
			AKAZA_URI . '/assets/css/global-workplace-cta.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $gwct_cta_css ) ? (string) filemtime( $gwct_cta_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $contact_css ) ? (string) filemtime( $contact_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-inclusive-workplace-training',
			AKAZA_URI . '/assets/css/inclusive-workplace-training.css',
			array( 'akaza-main', 'akaza-fonts', 'akaza-global-workplace-hero', 'akaza-global-workplace-behaviour', 'akaza-global-workplace-cta', 'akaza-contact-form' ),
			file_exists( $inclusive_training_css ) ? (string) filemtime( $inclusive_training_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	if ( $is_iwc_course_page ) {
		$iwc_course_css  = AKAZA_DIR . '/assets/css/sl-iwc-course.css';
		$contact_css     = AKAZA_DIR . '/assets/css/contact-from.css';
		$contact_form_css = AKAZA_DIR . '/assets/css/contact-form-brand.css';
		$clients_css     = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js      = AKAZA_DIR . '/assets/js/clients.js';

		wp_enqueue_style(
			'bootstrap-icons',
			'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
			array(),
			'1.11.3'
		);

		wp_enqueue_style(
			'akaza-sl-iwc-course',
			AKAZA_URI . '/assets/css/sl-iwc-course.css',
			array( 'akaza-main', 'akaza-fonts', 'bootstrap-icons' ),
			file_exists( $iwc_course_css ) ? (string) filemtime( $iwc_course_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main' ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main' ),
			file_exists( $contact_css ) ? (string) filemtime( $contact_css ) : AKAZA_VERSION
		);

		if ( file_exists( $contact_form_css ) ) {
			wp_enqueue_style(
				'akaza-contact-form-brand',
				AKAZA_URI . '/assets/css/contact-form-brand.css',
				array( 'akaza-contact-form' ),
				(string) filemtime( $contact_form_css )
			);
		}
	}

	if ( $is_gwct_page ) {
		$gwct_hero_css      = AKAZA_DIR . '/assets/css/global-workplace-hero.css';
		$gwct_behaviour_css = AKAZA_DIR . '/assets/css/global-workplace-behaviour.css';
		$gwct_solutions_css  = AKAZA_DIR . '/assets/css/global-workplace-solutions.css';
		$gwct_why_choose_css = AKAZA_DIR . '/assets/css/global-workplace-why-choose.css';
		$gwct_impact_css     = AKAZA_DIR . '/assets/css/global-workplace-impact.css';
		$gwct_cta_css        = AKAZA_DIR . '/assets/css/global-workplace-cta.css';
		$gwct_contact_css    = AKAZA_DIR . '/assets/css/global-workplace-contact.css';
		$gwct_faq_css        = AKAZA_DIR . '/assets/css/global-workplace-faq.css';
		$gwct_testimonials_css = AKAZA_DIR . '/assets/css/global-workplace-testimonials.css';
		$contact_css         = AKAZA_DIR . '/assets/css/contact-from.css';
		$stats_css           = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js           = AKAZA_DIR . '/assets/js/stats.js';
		$clients_css        = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js         = AKAZA_DIR . '/assets/js/clients.js';

		wp_enqueue_style(
			'bootstrap-icons',
			'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
			array(),
			'1.11.3'
		);

		wp_enqueue_style(
			'akaza-global-workplace-hero',
			AKAZA_URI . '/assets/css/global-workplace-hero.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $gwct_hero_css ) ? (string) filemtime( $gwct_hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-behaviour',
			AKAZA_URI . '/assets/css/global-workplace-behaviour.css',
			array( 'akaza-main', 'akaza-fonts', 'bootstrap-icons' ),
			file_exists( $gwct_behaviour_css ) ? (string) filemtime( $gwct_behaviour_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-solutions',
			AKAZA_URI . '/assets/css/global-workplace-solutions.css',
			array( 'akaza-main', 'akaza-fonts', 'bootstrap-icons', 'akaza-global-workplace-hero' ),
			file_exists( $gwct_solutions_css ) ? (string) filemtime( $gwct_solutions_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-why-choose',
			AKAZA_URI . '/assets/css/global-workplace-why-choose.css',
			array( 'akaza-main', 'akaza-fonts', 'bootstrap-icons' ),
			file_exists( $gwct_why_choose_css ) ? (string) filemtime( $gwct_why_choose_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-impact',
			AKAZA_URI . '/assets/css/global-workplace-impact.css',
			array( 'akaza-main', 'akaza-fonts', 'bootstrap-icons', 'akaza-global-workplace-behaviour' ),
			file_exists( $gwct_impact_css ) ? (string) filemtime( $gwct_impact_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-cta',
			AKAZA_URI . '/assets/css/global-workplace-cta.css',
			array( 'akaza-main', 'akaza-fonts', 'akaza-global-workplace-hero' ),
			file_exists( $gwct_cta_css ) ? (string) filemtime( $gwct_cta_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $contact_css ) ? (string) filemtime( $contact_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-contact',
			AKAZA_URI . '/assets/css/global-workplace-contact.css',
			array( 'akaza-main', 'akaza-fonts', 'akaza-contact-form' ),
			file_exists( $gwct_contact_css ) ? (string) filemtime( $gwct_contact_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-faq',
			AKAZA_URI . '/assets/css/global-workplace-faq.css',
			array( 'akaza-main', 'akaza-fonts', 'bootstrap-icons' ),
			file_exists( $gwct_faq_css ) ? (string) filemtime( $gwct_faq_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-global-workplace-testimonials',
			AKAZA_URI . '/assets/css/global-workplace-testimonials.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $gwct_testimonials_css ) ? (string) filemtime( $gwct_testimonials_css ) : AKAZA_VERSION
		);
	}

	if ( $is_gdpr_page ) {
		$dpdpa_hero_css = AKAZA_DIR . '/assets/css/dpdpa-hero.css';
		$dpdpa_hero_js  = AKAZA_DIR . '/assets/js/dpdpa-hero.js';
		$stats_css      = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js       = AKAZA_DIR . '/assets/js/stats.js';
		$clients_css    = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js     = AKAZA_DIR . '/assets/js/clients.js';

		wp_enqueue_style(
			'akaza-dpdpa-hero',
			AKAZA_URI . '/assets/css/dpdpa-hero.css',
			array( 'akaza-main' ),
			file_exists( $dpdpa_hero_css ) ? (string) filemtime( $dpdpa_hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main' ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main' ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_script(
			'akaza-dpdpa-hero',
			AKAZA_URI . '/assets/js/dpdpa-hero.js',
			array(),
			file_exists( $dpdpa_hero_js ) ? (string) filemtime( $dpdpa_hero_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	if ( $is_dpdpa_page ) {
		$stats_css       = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js        = AKAZA_DIR . '/assets/js/stats.js';
		$clients_css     = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js      = AKAZA_DIR . '/assets/js/clients.js';
		$contact_css     = AKAZA_DIR . '/assets/css/contact-from.css';
		$contact_form_css = AKAZA_DIR . '/assets/css/contact-form-brand.css';

		$dpdpa_global_css            = AKAZA_DIR . '/assets/css/sl-dpdpa-global.css';
		$dpdpa_hero_css              = AKAZA_DIR . '/assets/css/sl-dpdpa-hero.css';
		$dpdpa_breach_css            = AKAZA_DIR . '/assets/css/sl-dpdpa-breach.css';
		$dpdpa_signoff_css           = AKAZA_DIR . '/assets/css/sl-dpdpa-signoff.css';
		$dpdpa_course_cover_css      = AKAZA_DIR . '/assets/css/sl-dpdpa-course-cover.css';
		$dpdpa_curriculum_css        = AKAZA_DIR . '/assets/css/sl-dpdpa-curriculum.css';
		$dpdpa_how_it_teaches_css    = AKAZA_DIR . '/assets/css/sl-dpdpa-how-it-teaches.css';
		$dpdpa_pricing_css           = AKAZA_DIR . '/assets/css/sl-dpdpa-pricing.css';
		$dpdpa_scorecard_cta_css     = AKAZA_DIR . '/assets/css/sl-dpdpa-scorecard-cta.css';
		$dpdpa_training_records_css  = AKAZA_DIR . '/assets/css/sl-dpdpa-training-records.css';
		$dpdpa_format_delivery_css   = AKAZA_DIR . '/assets/css/sl-dpdpa-format-delivery.css';
		$dpdpa_contact_css           = AKAZA_DIR . '/assets/css/sl-dpdpa-contact.css';
		$dpdpa_workday_js            = AKAZA_DIR . '/assets/js/dpdpa-workday.js';
		$dpdpa_curriculum_js         = AKAZA_DIR . '/assets/js/dpdpa-curriculum.js';
		$dpdpa_pricing_js            = AKAZA_DIR . '/assets/js/dpdpa-pricing.js';

		wp_enqueue_style(
			'akaza-sl-dpdpa-global',
			AKAZA_URI . '/assets/css/sl-dpdpa-global.css',
			array( 'akaza-main', 'akaza-fonts' ),
			file_exists( $dpdpa_global_css ) ? (string) filemtime( $dpdpa_global_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-hero',
			AKAZA_URI . '/assets/css/sl-dpdpa-hero.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_hero_css ) ? (string) filemtime( $dpdpa_hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main' ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main' ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-breach',
			AKAZA_URI . '/assets/css/sl-dpdpa-breach.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_breach_css ) ? (string) filemtime( $dpdpa_breach_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-signoff',
			AKAZA_URI . '/assets/css/sl-dpdpa-signoff.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_signoff_css ) ? (string) filemtime( $dpdpa_signoff_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-course-cover',
			AKAZA_URI . '/assets/css/sl-dpdpa-course-cover.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_course_cover_css ) ? (string) filemtime( $dpdpa_course_cover_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-curriculum',
			AKAZA_URI . '/assets/css/sl-dpdpa-curriculum.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_curriculum_css ) ? (string) filemtime( $dpdpa_curriculum_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-how-it-teaches',
			AKAZA_URI . '/assets/css/sl-dpdpa-how-it-teaches.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_how_it_teaches_css ) ? (string) filemtime( $dpdpa_how_it_teaches_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-pricing',
			AKAZA_URI . '/assets/css/sl-dpdpa-pricing.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_pricing_css ) ? (string) filemtime( $dpdpa_pricing_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-scorecard-cta',
			AKAZA_URI . '/assets/css/sl-dpdpa-scorecard-cta.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_scorecard_cta_css ) ? (string) filemtime( $dpdpa_scorecard_cta_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-training-records',
			AKAZA_URI . '/assets/css/sl-dpdpa-training-records.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_training_records_css ) ? (string) filemtime( $dpdpa_training_records_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-sl-dpdpa-format-delivery',
			AKAZA_URI . '/assets/css/sl-dpdpa-format-delivery.css',
			array( 'akaza-sl-dpdpa-global' ),
			file_exists( $dpdpa_format_delivery_css ) ? (string) filemtime( $dpdpa_format_delivery_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main' ),
			file_exists( $contact_css ) ? (string) filemtime( $contact_css ) : AKAZA_VERSION
		);

		if ( file_exists( $contact_form_css ) ) {
			wp_enqueue_style(
				'akaza-contact-form-brand',
				AKAZA_URI . '/assets/css/contact-form-brand.css',
				array( 'akaza-contact-form' ),
				(string) filemtime( $contact_form_css )
			);
		}

		wp_enqueue_style(
			'akaza-sl-dpdpa-contact',
			AKAZA_URI . '/assets/css/sl-dpdpa-contact.css',
			array( 'akaza-sl-dpdpa-global', 'akaza-contact-form' ),
			file_exists( $dpdpa_contact_css ) ? (string) filemtime( $dpdpa_contact_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-dpdpa-workday',
			AKAZA_URI . '/assets/js/dpdpa-workday.js',
			array(),
			file_exists( $dpdpa_workday_js ) ? (string) filemtime( $dpdpa_workday_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_script(
			'akaza-dpdpa-curriculum',
			AKAZA_URI . '/assets/js/dpdpa-curriculum.js',
			array(),
			file_exists( $dpdpa_curriculum_js ) ? (string) filemtime( $dpdpa_curriculum_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_script(
			'akaza-dpdpa-pricing',
			AKAZA_URI . '/assets/js/dpdpa-pricing.js',
			array(),
			file_exists( $dpdpa_pricing_js ) ? (string) filemtime( $dpdpa_pricing_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	wp_enqueue_script(
		'akaza-main',
		AKAZA_URI . '/assets/js/main.js',
		array(),
		file_exists( $js_path ) ? (string) filemtime( $js_path ) : AKAZA_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);

	// Theme header CSS/JS only when Akaza Header Footer plugin is not rendering.
	if ( ! has_action( 'ahf_render_site_header' ) ) {
		$fb_css = AKAZA_DIR . '/assets/css/header-fallback.css';
		$fb_js  = AKAZA_DIR . '/assets/js/header-fallback.js';

		wp_enqueue_style(
			'akaza-header-fallback',
			AKAZA_URI . '/assets/css/header-fallback.css',
			array( 'akaza-main' ),
			file_exists( $fb_css ) ? (string) filemtime( $fb_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-header-fallback',
			AKAZA_URI . '/assets/js/header-fallback.js',
			array(),
			file_exists( $fb_js ) ? (string) filemtime( $fb_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	$global_buttons_css = AKAZA_DIR . '/assets/css/sl-global-buttons.css';
	wp_enqueue_style(
		'akaza-global-buttons',
		AKAZA_URI . '/assets/css/sl-global-buttons.css',
		array( 'akaza-main' ),
		file_exists( $global_buttons_css ) ? (string) filemtime( $global_buttons_css ) : AKAZA_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'akaza_enqueue_assets' );

/**
 * Late title accent spans — wins over combined/minified CSS bundles.
 */
function akaza_print_global_title_accent_css() {
	if ( is_admin() ) {
		return;
	}
	?>
	<style id="akaza-global-title-accent">
		body.slf-body h1 > span,
		body.slf-body h2 > span,
		body.slf-body h3 > span,
		body.slf-body h1 [class$="__highlight"],
		body.slf-body h2 [class$="__highlight"],
		body.slf-body h3 [class$="__highlight"],
		body.slf-body [class$="__title-highlight"],
		body.slf-body .sl-home-sub-heading,
		body.slf-body .sl-home-card-tag,
		body.slf-body .sl-home-step-label,
		body.slf-body .sl-code-conduct-definition__accent {
			color: var(--sl-heading-accent, #1472ba);
		}

		body.slf-body [class$="__title-highlight"] {
			background: none;
			-webkit-background-clip: unset;
			background-clip: unset;
			-webkit-text-fill-color: currentColor;
		}

		body.slf-body .sl-home-sub-heading::before {
			background: var(--sl-heading-accent, #1472ba);
		}

		body.slf-body a[class*="btn-primary"]:not([class*="secondary"]),
		body.slf-body a[class*="btn--primary"],
		body.slf-body a[class*="button--primary"],
		body.slf-body .sl-home-btn-primary,
		body.slf-body .sl-home-btn,
		body.slf-body .sl-coc-problem__cta,
		body.slf-body .sl-coc-customer-story__cta,
		body.slf-body .slf-clients__cta,
		body.slf-body a.sl-btn--primary,
		body.slf-body a[class*="btn-primary"]:not([class*="secondary"]):visited,
		body.slf-body a[class*="btn--primary"]:visited,
		body.slf-body a[class*="button--primary"]:visited,
		body.slf-body .sl-home-btn-primary:visited,
		body.slf-body .sl-home-btn:visited,
		body.slf-body .sl-coc-problem__cta:visited,
		body.slf-body .sl-coc-customer-story__cta:visited,
		body.slf-body .slf-clients__cta:visited,
		body.slf-body a.sl-btn--primary:visited,
		body.slf-body a[class*="btn-primary"]:not([class*="secondary"]):hover,
		body.slf-body a[class*="btn--primary"]:hover,
		body.slf-body a[class*="button--primary"]:hover,
		body.slf-body .sl-home-btn-primary:hover,
		body.slf-body .sl-home-btn:hover,
		body.slf-body .sl-coc-problem__cta:hover,
		body.slf-body .sl-coc-customer-story__cta:hover,
		body.slf-body .slf-clients__cta:hover,
		body.slf-body a.sl-btn--primary:hover,
		body.slf-body a[class*="btn-primary"]:not([class*="secondary"]):focus,
		body.slf-body a[class*="btn--primary"]:focus,
		body.slf-body a[class*="button--primary"]:focus,
		body.slf-body .sl-home-btn-primary:focus,
		body.slf-body .sl-home-btn:focus,
		body.slf-body .sl-coc-problem__cta:focus,
		body.slf-body .sl-coc-customer-story__cta:focus,
		body.slf-body .slf-clients__cta:focus,
		body.slf-body a.sl-btn--primary:focus {
			background: var(--sl-btn-primary-fill, linear-gradient(180deg, #4d7ed6 0%, #1a3b87 100%)) !important;
			background-color: transparent !important;
			border-color: transparent !important;
			color: #ffffff !important;
		}

		body.slf-body .scf-submit,
		body.slf-body .scf-lightbox-button,
		body.slf-body button.epsh-search-panel__submit,
		body.slf-body .sl-search-form__submit,
		body.slf-body header.slf-header .slf-header-cta,
		body.slf-body .slf-btn--primary,
		body.slf-body .epsh-site-footer .ans-footer-submit-btn,
		body.slf-body .scf-submit:hover,
		body.slf-body .scf-submit:focus,
		body.slf-body .scf-lightbox-button:hover,
		body.slf-body .scf-lightbox-button:focus,
		body.slf-body button.epsh-search-panel__submit:hover,
		body.slf-body button.epsh-search-panel__submit:focus-visible,
		body.slf-body .sl-search-form__submit:hover,
		body.slf-body .sl-search-form__submit:focus-visible,
		body.slf-body header.slf-header .slf-header-cta:hover,
		body.slf-body header.slf-header .slf-header-cta:focus-visible,
		body.slf-body .slf-btn--primary:hover,
		body.slf-body .slf-btn--primary:focus-visible,
		body.slf-body .epsh-site-footer .ans-footer-submit-btn:hover:not(:disabled) {
			background: var(--sl-btn-primary-fill, linear-gradient(180deg, #4d7ed6 0%, #1a3b87 100%)) !important;
			background-color: transparent !important;
			border-color: transparent !important;
			color: #ffffff !important;
		}

		body.slf-body .epsh-search-panel__input:focus {
			border-color: rgba(19, 93, 183, 0.45) !important;
			box-shadow: 0 0 0 3px rgba(19, 93, 183, 0.14) !important;
		}

		body.slf-body .epsh-search-panel__view-all,
		body.slf-body .epsh-search-panel__view-all:hover,
		body.slf-body .epsh-search-panel__view-all:focus-visible {
			background: var(--sl-btn-primary-fill, linear-gradient(180deg, #4d7ed6 0%, #1a3b87 100%)) !important;
			background-color: transparent !important;
			border-color: transparent !important;
			color: #ffffff !important;
		}

		#read-progress-bar {
			background: var(--sl-chrome-fill, var(--sl-btn-primary-fill, linear-gradient(180deg, #4d7ed6 0%, #1a3b87 100%))) !important;
		}

		.progress-square__rect {
			stroke: var(--sl-chrome-accent, var(--sl-heading-accent, #135db7)) !important;
		}

		#sl-scroll-top .sl-scroll-top,
		.sl-scroll-top-wrap .sl-scroll-top {
			background: var(--sl-chrome-fill, var(--sl-btn-primary-fill, linear-gradient(180deg, #4d7ed6 0%, #1a3b87 100%)));
			box-shadow: 0 6px 18px rgba(var(--sl-chrome-shadow-rgb, 26, 59, 135), 0.38);
		}

		#sl-scroll-top .sl-scroll-top:hover,
		#sl-scroll-top .sl-scroll-top:focus,
		.sl-scroll-top-wrap .sl-scroll-top:hover,
		.sl-scroll-top-wrap .sl-scroll-top:focus {
			filter: brightness(1.06);
		}

		body.slf-body a[class*="btn-secondary"]:not(.sl-btn--secondary),
		body.slf-body a[class*="btn--secondary"]:not([class*="primary"]):not(.sl-btn--secondary),
		body.slf-body a[class*="button--secondary"],
		body.slf-body .sl-home-btn-secondary,
		body.slf-body .sl-fcp-btn-secondary,
		body.slf-body .sl-global-btn-secondary,
		body.slf-body .sl-dpdpa-btn-secondary,
		body.slf-body .sl-iwc-btn-secondary,
		body.slf-body .sl-sa-hero__button--secondary,
		body.slf-body .sl-code-of-conduct-hero__button--secondary,
		body.slf-body .dpdpa-btn--secondary,
		body.slf-body a[class*="btn-secondary"]:not(.sl-btn--secondary):visited,
		body.slf-body a[class*="btn--secondary"]:not([class*="primary"]):not(.sl-btn--secondary):visited,
		body.slf-body a[class*="button--secondary"]:visited,
		body.slf-body .sl-home-btn-secondary:visited,
		body.slf-body .sl-fcp-btn-secondary:visited,
		body.slf-body .sl-global-btn-secondary:visited,
		body.slf-body .sl-dpdpa-btn-secondary:visited,
		body.slf-body .sl-iwc-btn-secondary:visited,
		body.slf-body .sl-sa-hero__button--secondary:visited,
		body.slf-body .sl-code-of-conduct-hero__button--secondary:visited,
		body.slf-body .dpdpa-btn--secondary:visited,
		body.slf-body a[class*="btn-secondary"]:not(.sl-btn--secondary):hover,
		body.slf-body a[class*="btn--secondary"]:not([class*="primary"]):not(.sl-btn--secondary):hover,
		body.slf-body a[class*="button--secondary"]:hover,
		body.slf-body .sl-home-btn-secondary:hover,
		body.slf-body .sl-fcp-btn-secondary:hover,
		body.slf-body .sl-global-btn-secondary:hover,
		body.slf-body .sl-dpdpa-btn-secondary:hover,
		body.slf-body .sl-iwc-btn-secondary:hover,
		body.slf-body .sl-sa-hero__button--secondary:hover,
		body.slf-body .sl-code-of-conduct-hero__button--secondary:hover,
		body.slf-body .dpdpa-btn--secondary:hover,
		body.slf-body a[class*="btn-secondary"]:not(.sl-btn--secondary):focus,
		body.slf-body a[class*="btn--secondary"]:not([class*="primary"]):not(.sl-btn--secondary):focus,
		body.slf-body a[class*="button--secondary"]:focus,
		body.slf-body .sl-home-btn-secondary:focus,
		body.slf-body .sl-fcp-btn-secondary:focus,
		body.slf-body .sl-global-btn-secondary:focus,
		body.slf-body .sl-dpdpa-btn-secondary:focus,
		body.slf-body .sl-iwc-btn-secondary:focus,
		body.slf-body .sl-sa-hero__button--secondary:focus,
		body.slf-body .sl-code-of-conduct-hero__button--secondary:focus,
		body.slf-body .dpdpa-btn--secondary:focus,
		body.slf-body a[class*="btn-secondary"]:not(.sl-btn--secondary):active,
		body.slf-body a[class*="btn--secondary"]:not([class*="primary"]):not(.sl-btn--secondary):active,
		body.slf-body a[class*="button--secondary"]:active,
		body.slf-body .sl-home-btn-secondary:active,
		body.slf-body .sl-fcp-btn-secondary:active,
		body.slf-body .sl-global-btn-secondary:active,
		body.slf-body .sl-dpdpa-btn-secondary:active,
		body.slf-body .sl-iwc-btn-secondary:active,
		body.slf-body .sl-sa-hero__button--secondary:active,
		body.slf-body .sl-code-of-conduct-hero__button--secondary:active,
		body.slf-body .dpdpa-btn--secondary:active {
			background:
				linear-gradient(var(--sl-btn-secondary-surface, #ffffff), var(--sl-btn-secondary-surface, #ffffff)) padding-box,
				var(--sl-btn-primary-fill, linear-gradient(180deg, #4d7ed6 0%, #1a3b87 100%)) border-box !important;
			background-color: transparent !important;
			border: 2px solid transparent !important;
			color: var(--sl-heading-accent, #135db7) !important;
			-webkit-text-fill-color: currentColor;
		}

		body.slf-body .sl-coc-page a[class*="btn-secondary"],
		body.slf-body .sl-coc-page a[class*="button--secondary"],
		body.slf-body .sl-coc-page .sl-code-of-conduct-hero__button--secondary {
			--sl-btn-secondary-surface: var(--sl-page-bg, #f5f3ef);
		}

		body.slf-body .sl-hero a.sl-btn--secondary,
		body.slf-body .sl-hero a.sl-btn--secondary:visited,
		body.slf-body .sl-hero a.sl-btn--secondary:focus,
		body.slf-body .sl-hero a.sl-btn--secondary:active {
			background: rgba(255, 255, 255, 0.06) !important;
			background-color: rgba(255, 255, 255, 0.06) !important;
			border: 2px solid rgba(255, 255, 255, 0.75) !important;
			color: #ffffff !important;
			-webkit-text-fill-color: #ffffff;
			box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.08);
		}

		body.slf-body .sl-hero a.sl-btn--secondary:hover,
		body.slf-body .sl-hero a.sl-btn--secondary:focus-visible {
			background: #ffffff !important;
			background-color: #ffffff !important;
			border-color: #ffffff !important;
			color: #16234e !important;
			-webkit-text-fill-color: #16234e;
			box-shadow: 0 8px 24px rgba(0, 0, 0, 0.18);
		}
	</style>
	<?php
}
add_action( 'wp_head', 'akaza_print_global_title_accent_css', 9999 );

/**
 * Enqueue reusable solutions card grid assets.
 * Safe to call from About, Contact, or any page that includes the template part.
 */
function akaza_enqueue_solutions_carousel() {
	$css = AKAZA_DIR . '/assets/css/solutions-carousel.css';

	wp_enqueue_style(
		'akaza-solutions-carousel',
		AKAZA_URI . '/assets/css/solutions-carousel.css',
		array( 'akaza-main', 'akaza-fonts' ),
		file_exists( $css ) ? (string) filemtime( $css ) : AKAZA_VERSION
	);
}

/**
 * Whether the current request is AMP (skip theme scroll-to-top).
 *
 * @return bool
 */
function akaza_is_amp() {
	if ( class_exists( 'AHF_AMP' ) && method_exists( 'AHF_AMP', 'is_amp' ) ) {
		return (bool) AHF_AMP::is_amp();
	}
	if ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() ) {
		return true;
	}
	if ( function_exists( 'amp_is_request' ) && amp_is_request() ) {
		return true;
	}
	return false;
}

/**
 * Enqueue shared scroll-to-top assets (non-AMP only).
 */
function akaza_enqueue_scroll_to_top() {
	if ( akaza_is_amp() || is_admin() ) {
		return;
	}

	$css = AKAZA_DIR . '/assets/css/scroll-to-top.css';
	$js  = AKAZA_DIR . '/assets/js/scroll-to-top.js';

	wp_enqueue_style(
		'akaza-scroll-to-top',
		AKAZA_URI . '/assets/css/scroll-to-top.css',
		array( 'akaza-main' ),
		file_exists( $css ) ? (string) filemtime( $css ) : AKAZA_VERSION
	);

	$brand_css = AKAZA_DIR . '/assets/css/contact-form-brand.css';
	if ( file_exists( $brand_css ) ) {
		wp_enqueue_style(
			'akaza-contact-form-brand',
			AKAZA_URI . '/assets/css/contact-form-brand.css',
			array( 'akaza-scroll-to-top' ),
			(string) filemtime( $brand_css )
		);
	}

	wp_enqueue_script(
		'akaza-scroll-to-top',
		AKAZA_URI . '/assets/js/scroll-to-top.js',
		array(),
		file_exists( $js ) ? (string) filemtime( $js ) : AKAZA_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);
}
add_action( 'wp_enqueue_scripts', 'akaza_enqueue_scroll_to_top', 30 );

/**
 * Print scroll-to-top markup once in the footer (non-AMP only).
 */
function akaza_render_scroll_to_top() {
	static $done = false;
	if ( $done || akaza_is_amp() || is_admin() ) {
		return;
	}
	$done = true;
	?>
	<div id="sl-scroll-top" class="sl-scroll-top-wrap is-branded">
		<button
			type="button"
			class="sl-scroll-top"
			aria-label="<?php esc_attr_e( 'Back to top', 'akaza-adventure' ); ?>"
			title="<?php esc_attr_e( 'Back to top', 'akaza-adventure' ); ?>"
		>
			<span class="sl-scroll-top__icon" aria-hidden="true"></span>
		</button>
	</div>
	<?php
}
add_action( 'wp_footer', 'akaza_render_scroll_to_top', 40 );

/**
 * Preload LCP hero + critical fonts (homepage only for hero).
 */
function akaza_resource_hints() {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";

	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		$hero = AKAZA_URI . '/assets/images/hero.jpg';
		echo '<link rel="preload" as="image" href="' . esc_url( $hero ) . '" fetchpriority="high">' . "\n";
	}
}
add_action( 'wp_head', 'akaza_resource_hints', 1 );

/**
 * Load brand fonts site-wide (same stack as the homepage).
 */
function akaza_enqueue_fonts() {
	if ( is_admin() ) {
		return;
	}

	wp_enqueue_style(
		'akaza-fonts',
		'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&display=swap',
		array(),
		null
	);
}
add_action( 'wp_enqueue_scripts', 'akaza_enqueue_fonts', 5 );

/**
 * Ensure plugin/header styles load after theme fonts.
 */
function akaza_font_dependencies() {
	if ( ! wp_style_is( 'akaza-fonts', 'enqueued' ) ) {
		return;
	}

	$wp_styles = wp_styles();
	if ( ! $wp_styles ) {
		return;
	}

	foreach ( array( 'epsh-header-shell', 'epsh-desktop-nav', 'epsh-mobile-header', 'epsh-footer' ) as $handle ) {
		if ( ! isset( $wp_styles->registered[ $handle ] ) ) {
			continue;
		}

		$deps = (array) $wp_styles->registered[ $handle ]->deps;
		if ( ! in_array( 'akaza-fonts', $deps, true ) ) {
			$wp_styles->registered[ $handle ]->deps[] = 'akaza-fonts';
		}
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_font_dependencies', 50 );

/**
 * Whether Rank Math owns SEO output (titles, meta, schema, sitemap).
 *
 * @return bool
 */
function akaza_rank_math_active() {
	return defined( 'RANK_MATH_VERSION' );
}

/**
 * Clean document titles (fallback only when Rank Math is not active).
 *
 * @param array $parts Title parts.
 * @return array
 */
function akaza_document_title( $parts ) {
	if ( akaza_rank_math_active() ) {
		return $parts;
	}

	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		$parts['title']   = 'SucceedLEARN | Global Compliance & Security Training';
		$parts['tagline'] = '';
	} elseif ( ( function_exists( 'akaza_is_courses_archive' ) && akaza_is_courses_archive() ) || ( function_exists( 'learn_press_is_courses' ) && learn_press_is_courses() ) ) {
		$parts['title']   = 'Courses | SucceedLEARN Compliance Training';
		$parts['tagline'] = '';
	} elseif ( function_exists( 'learn_press_is_course' ) && learn_press_is_course() ) {
		$parts['tagline'] = 'SucceedLEARN Course';
	} elseif ( is_page_template( 'page-templates/page-solutions.php' ) ) {
		$parts['title']   = 'Solutions | SucceedLEARN';
		$parts['tagline'] = '';
	} elseif ( is_page_template( 'page-templates/page-about.php' ) ) {
		$parts['title']   = 'About Us | SucceedLEARN';
		$parts['tagline'] = '';
	} elseif ( is_page_template( 'page-templates/page-contact.php' ) ) {
		$parts['title']   = 'Contact Us | SucceedLEARN';
		$parts['tagline'] = '';
	} elseif ( is_page_template( 'page-templates/privacy-policy.php' ) ) {
		$parts['title']   = 'Privacy Policy | SucceedLEARN';
		$parts['tagline'] = '';
	} elseif ( is_page_template( 'page-templates/terms-and-conditions.php' ) ) {
		$parts['title']   = 'Terms and Conditions | SucceedLEARN';
		$parts['tagline'] = '';
	} elseif ( is_page_template( 'page-templates/s-phish-report.php' ) ) {
		$parts['title']   = 'S-PhishReport | SucceedLEARN';
		$parts['tagline'] = '';
	}
	return $parts;
}
add_filter( 'document_title_parts', 'akaza_document_title' );

/**
 * SEO meta + Open Graph + Twitter + JSON-LD.
 * Skips when Rank Math is active so meta/canonical/schema are not duplicated.
 */
function akaza_seo_head() {
	if ( akaza_rank_math_active() ) {
		return;
	}

	$url       = home_url( '/' );
	$site_name = 'SucceedLEARN';
	$image     = AKAZA_URI . '/assets/images/hero.jpg';
	$title     = '';
	$description = '';
	$schema    = null;

	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		$title       = 'SucceedLEARN | Global Compliance & Security Training';
		$description = 'Global compliance and security awareness training employees actually remember. Measurable behaviour change, audit-ready reporting, and one platform for workplace learning.';
		$url         = home_url( '/' );
		$schema      = akaza_schema_homepage( $url, $title, $description, $image );
	} elseif ( function_exists( 'learn_press_is_course' ) && learn_press_is_course() ) {
		$course_id   = get_the_ID();
		$title       = get_the_title( $course_id ) . ' | SucceedLEARN';
		$description = wp_strip_all_tags( get_the_excerpt( $course_id ) );
		if ( ! $description ) {
			$description = wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $course_id ) ), 40 );
		}
		$url   = get_permalink( $course_id );
		$thumb = get_the_post_thumbnail_url( $course_id, 'akaza-course-hero' );
		if ( $thumb ) {
			$image = $thumb;
		}
		$schema = akaza_schema_course( $course_id, $url, $title, $description, $image );
	} elseif ( ( function_exists( 'akaza_is_courses_archive' ) && akaza_is_courses_archive() ) || ( function_exists( 'learn_press_is_courses' ) && learn_press_is_courses() ) ) {
		$title       = 'Courses | SucceedLEARN Compliance Training';
		$description = 'Browse SucceedLEARN compliance and security awareness courses. Engaging training with measurable outcomes for modern organisations.';
		$url         = get_post_type_archive_link( akaza_course_post_type() ) ? get_post_type_archive_link( akaza_course_post_type() ) : home_url( '/courses/' );
		$schema      = akaza_schema_course_list( $url, $title, $description );
	} elseif ( is_page() ) {
		$title       = get_the_title() . ' | SucceedLEARN';
		$description = has_excerpt() ? wp_strip_all_tags( get_the_excerpt() ) : wp_trim_words( wp_strip_all_tags( get_the_content() ), 40 );
		if ( ! $description ) {
			$description = 'SucceedLEARN — global compliance and security training.';
		}
		$url = get_permalink();
	} else {
		return;
	}

	echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">' . "\n";
	echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
	echo '<link rel="sitemap" type="application/xml" title="Sitemap" href="' . esc_url( home_url( '/akaza-sitemap.xml' ) ) . '">' . "\n";

	echo '<meta property="og:locale" content="en_US">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( $site_name ) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";

	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta name="twitter:description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n";

	if ( $schema ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	}
}
add_action( 'wp_head', 'akaza_seo_head', 2 );

/**
 * Homepage schema graph.
 *
 * @param string $url URL.
 * @param string $title Title.
 * @param string $description Description.
 * @param string $image Image.
 * @return array
 */
function akaza_schema_homepage( $url, $title, $description, $image ) {
	return array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			array(
				'@type'  => 'Organization',
				'@id'    => $url . '#organization',
				'name'   => 'SucceedLEARN',
				'url'    => $url,
				'logo'   => array(
					'@type' => 'ImageObject',
					'url'   => AKAZA_URI . '/assets/images/logo-mark.svg',
				),
				'email'  => 'sales@succeedtech.com',
				'sameAs' => array(
					'https://www.linkedin.com/company/succeedlearn',
					'https://www.youtube.com/@succeedlearn',
				),
			),
			array(
				'@type'           => 'WebSite',
				'@id'             => $url . '#website',
				'url'             => $url,
				'name'            => 'SucceedLEARN',
				'description'     => $description,
				'publisher'       => array( '@id' => $url . '#organization' ),
				'inLanguage'      => 'en-US',
				'potentialAction' => array(
					'@type'       => 'SearchAction',
					'target'      => $url . '?s={search_term_string}',
					'query-input' => 'required name=search_term_string',
				),
			),
			array(
				'@type'       => 'WebPage',
				'@id'         => $url . '#webpage',
				'url'         => $url,
				'name'        => $title,
				'isPartOf'    => array( '@id' => $url . '#website' ),
				'about'       => array( '@id' => $url . '#organization' ),
				'description' => $description,
				'inLanguage'  => 'en-US',
				'primaryImageOfPage' => array(
					'@type' => 'ImageObject',
					'url'   => $image,
				),
			),
		),
	);
}

/**
 * Single course schema.
 *
 * @param int    $course_id Course ID.
 * @param string $url URL.
 * @param string $title Title.
 * @param string $description Description.
 * @param string $image Image.
 * @return array
 */
function akaza_schema_course( $course_id, $url, $title, $description, $image ) {
	$course = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Course',
		'name'        => get_the_title( $course_id ),
		'description' => $description,
		'url'         => $url,
		'image'       => $image,
		'provider'    => array(
			'@type' => 'Organization',
			'name'  => 'SucceedLEARN',
			'url'   => home_url( '/' ),
		),
	);

	if ( function_exists( 'learn_press_get_course' ) ) {
		$lp = learn_press_get_course( $course_id );
		if ( $lp ) {
			$price = method_exists( $lp, 'get_price' ) ? $lp->get_price() : '';
			if ( '' !== $price && null !== $price ) {
				$course['offers'] = array(
					'@type'         => 'Offer',
					'price'         => (float) $price,
					'priceCurrency' => 'USD',
					'availability'  => 'https://schema.org/InStock',
					'url'           => $url,
				);
			}
		}
	}

	return $course;
}

/**
 * Course archive ItemList schema.
 *
 * @param string $url URL.
 * @param string $title Title.
 * @param string $description Description.
 * @return array
 */
function akaza_schema_course_list( $url, $title, $description ) {
	$items = array();
	$query = new WP_Query(
		array(
			'post_type'      => akaza_course_post_type(),
			'posts_per_page' => 20,
			'post_status'    => 'publish',
			'no_found_rows'  => true,
		)
	);
	$pos = 1;
	while ( $query->have_posts() ) {
		$query->the_post();
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $pos,
			'url'      => get_permalink(),
			'name'     => get_the_title(),
		);
		$pos++;
	}
	wp_reset_postdata();

	return array(
		'@context'        => 'https://schema.org',
		'@type'           => 'CollectionPage',
		'name'            => $title,
		'description'     => $description,
		'url'             => $url,
		'mainEntity'      => array(
			'@type'           => 'ItemList',
			'itemListElement' => $items,
		),
	);
}

/**
 * Strip default WP bloat.
 */
function akaza_disable_bloat() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );

	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
	wp_dequeue_style( 'global-styles' );
	wp_dequeue_style( 'classic-theme-styles' );

	// Soften LearnPress front CSS when present — keep core, drop extras if registered.
	if ( ! is_admin() ) {
		wp_dequeue_style( 'lp-font-awesome-5' );
		wp_dequeue_style( 'learnpress' );
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_disable_bloat', 100 );

/**
 * Minimal LearnPress styles — theme provides layout.
 */
function akaza_learnpress_assets() {
	if ( function_exists( 'akaza_is_courses_archive' ) && akaza_is_courses_archive() ) {
		return;
	}
	if ( ! function_exists( 'learn_press_is_course' ) ) {
		return;
	}
	if ( ! learn_press_is_courses() && ! learn_press_is_course() ) {
		return;
	}
	$path = AKAZA_DIR . '/assets/css/learnpress.css';
	if ( file_exists( $path ) ) {
		wp_enqueue_style(
			'akaza-learnpress',
			AKAZA_URI . '/assets/css/learnpress.css',
			array( 'akaza-main' ),
			(string) filemtime( $path )
		);
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_learnpress_assets', 20 );

/**
 * Performance / security headers.
 */
function akaza_send_headers() {
	if ( headers_sent() ) {
		return;
	}
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'Permissions-Policy: interest-cohort=()' );
}
add_action( 'send_headers', 'akaza_send_headers' );

/**
 * Theme image URL helper.
 *
 * @param string $path Relative path under assets/images/.
 * @return string
 */
function akaza_img( $path ) {
	return AKAZA_URI . '/assets/images/' . ltrim( $path, '/' );
}

/**
 * Backward-compatible alias used in existing templates.
 *
 * @param string $path Path.
 * @return string
 */
function slf_img( $path ) {
	return akaza_img( $path );
}

/**
 * Uploads folder URL — uses local file when synced, otherwise production.
 *
 * @param string $path Path under wp-content/uploads/ (e.g. "2026/08/Security.svg").
 * @return string
 */
function akaza_upload_url( $path ) {
	$path = ltrim( $path, '/' );
	$path = preg_replace( '#^uploads/#', '', $path );
	$local = WP_CONTENT_DIR . '/uploads/' . $path;
	if ( file_exists( $local ) ) {
		return content_url( '/uploads/' . $path );
	}
	return 'https://succeedlearn.com/wp-content/uploads/' . $path;
}

/**
 * Page URL by slug.
 *
 * @param string $slug Page slug.
 * @return string
 */
function akaza_page_url( $slug ) {
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . trim( $slug, '/' ) . '/' );
}

/**
 * Create core marketing pages if missing.
 */
function akaza_bootstrap_pages() {
	$pages = array(
		array(
			'slug'     => 'solutions',
			'title'    => 'Solutions',
			'template' => 'page-templates/page-solutions.php',
		),
		array(
			'slug'     => 'about-us',
			'title'    => 'About Us',
			'template' => 'page-templates/page-about.php',
		),
		array(
			'slug'     => 'contact-us',
			'title'    => 'Contact Us',
			'template' => 'page-templates/page-contact.php',
		),
		array(
			'slug'     => 'privacy-policy',
			'title'    => 'Privacy Policy',
			'template' => 'page-templates/privacy-policy.php',
		),
		array(
			'slug'     => 'terms-and-conditions',
			'title'    => 'Terms and Conditions',
			'template' => 'page-templates/terms-and-conditions.php',
		),
		array(
			'slug'     => 's-phish-report',
			'title'    => 'S-PhishReport',
			'template' => 'page-templates/s-phish-report.php',
		),
		array(
			'slug'     => 'clients',
			'title'    => 'Clients',
			'template' => 'page-templates/page-clients.php',
		),
		array(
			'slug'     => 'defensive-driving',
			'title'    => 'Online Defensive Driving Training for Employees',
			'template' => 'page-templates/defensive-driving.php',
		),
	);

	foreach ( $pages as $page ) {
		$existing = get_page_by_path( $page['slug'] );
		if ( $existing ) {
			$current = get_post_meta( $existing->ID, '_wp_page_template', true );
			if ( $current !== $page['template'] ) {
				update_post_meta( $existing->ID, '_wp_page_template', $page['template'] );
			}
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_title'   => $page['title'],
				'post_name'    => $page['slug'],
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '',
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_wp_page_template', $page['template'] );
		}
	}

	update_option( 'akaza_pages_bootstrapped', 1, false );
}
add_action( 'after_switch_theme', 'akaza_bootstrap_pages' );
add_action( 'init', 'akaza_bootstrap_pages' );

/**
 * Register page templates.
 *
 * @param array $templates Templates.
 * @return array
 */
function akaza_page_templates( $templates ) {
	$dir = AKAZA_DIR . '/page-templates';

	if ( ! is_dir( $dir ) ) {
		return $templates;
	}

	foreach ( glob( $dir . '/*.php' ) as $file ) {
		$relative = 'page-templates/' . basename( $file );
		$data     = get_file_data(
			$file,
			array(
				'Template Name' => 'Template Name',
			)
		);

		if ( ! empty( $data['Template Name'] ) ) {
			$templates[ $relative ] = $data['Template Name'];
		}
	}

	return $templates;
}
add_filter( 'theme_page_templates', 'akaza_page_templates' );

/**
 * Course archive URL helper.
 *
 * @return string
 */
function akaza_courses_url() {
	if ( post_type_exists( 'course' ) ) {
		$archive = get_post_type_archive_link( 'course' );
		if ( $archive ) {
			return $archive;
		}
	}
	if ( function_exists( 'learn_press_get_page_link' ) ) {
		$link = learn_press_get_page_link( 'courses' );
		if ( $link ) {
			return $link;
		}
	}
	$archive = get_post_type_archive_link( 'lp_course' );
	return $archive ? $archive : home_url( '/courses/' );
}

/**
 * Handle homepage / contact form.
 */
function akaza_handle_contact() {
	if ( ! isset( $_POST['slf_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['slf_contact_nonce'] ) ), 'slf_contact' ) ) {
		wp_safe_redirect( home_url( '/?contact=invalid' ) );
		exit;
	}

	$first   = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
	$last    = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( ! $first || ! $last || ! is_email( $email ) || ! $message ) {
		wp_safe_redirect( akaza_page_url( 'contact-us' ) . '?contact=invalid' );
		exit;
	}

	$content = "Name: {$first} {$last}\nEmail: {$email}\nPhone: {$phone}\n\n{$message}";

	wp_insert_post(
		array(
			'post_type'    => 'post',
			'post_status'  => 'private',
			'post_title'   => 'Lead: ' . $first . ' ' . $last,
			'post_content' => $content,
		)
	);

	$admin = get_option( 'admin_email' );
	if ( $admin ) {
		wp_mail(
			$admin,
			'[SucceedLEARN] New enquiry from ' . $first . ' ' . $last,
			$content,
			array( 'Reply-To: ' . $email )
		);
	}

	wp_safe_redirect( akaza_page_url( 'contact-us' ) . '?contact=sent' );
	exit;
}
add_action( 'admin_post_nopriv_slf_contact', 'akaza_handle_contact' );
add_action( 'admin_post_slf_contact', 'akaza_handle_contact' );

/**
 * Basic XML sitemap for pages + courses when Rank Math is absent.
 */
function akaza_sitemap_rewrite() {
	if ( akaza_rank_math_active() ) {
		return;
	}
	add_rewrite_rule( '^akaza-sitemap\.xml$', 'index.php?akaza_sitemap=1', 'top' );
}
add_action( 'init', 'akaza_sitemap_rewrite' );

/**
 * Register sitemap query var.
 *
 * @param array $vars Vars.
 * @return array
 */
function akaza_sitemap_query_var( $vars ) {
	$vars[] = 'akaza_sitemap';
	return $vars;
}
add_filter( 'query_vars', 'akaza_sitemap_query_var' );

/**
 * Render basic sitemap (fallback only; Rank Math owns sitemap when active).
 */
function akaza_render_sitemap() {
	if ( akaza_rank_math_active() ) {
		return;
	}
	if ( ! intval( get_query_var( 'akaza_sitemap' ) ) ) {
		return;
	}

	header( 'Content-Type: application/xml; charset=UTF-8' );
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

	$urls = array( home_url( '/' ) );

	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'fields'         => 'ids',
		)
	);
	foreach ( $pages as $pid ) {
		$urls[] = get_permalink( $pid );
	}

	$courses = get_posts(
		array(
			'post_type'      => akaza_course_post_type(),
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'fields'         => 'ids',
		)
	);
	foreach ( $courses as $cid ) {
		$urls[] = get_permalink( $cid );
	}

	$archive = get_post_type_archive_link( akaza_course_post_type() );
	if ( $archive ) {
		$urls[] = $archive;
	}

	$urls = array_unique( array_filter( $urls ) );
	foreach ( $urls as $u ) {
		echo '  <url><loc>' . esc_url( $u ) . '</loc></url>' . "\n";
	}
	echo '</urlset>';
	exit;
}
add_action( 'template_redirect', 'akaza_render_sitemap' );

/**
 * Whether the current request needs Elementor frontend assets.
 *
 * @return bool
 */
function akaza_needs_elementor_assets() {
	if ( ! did_action( 'elementor/loaded' ) || ! class_exists( '\Elementor\Plugin' ) ) {
		return false;
	}

	// Keep assets in the Elementor editor / preview.
	if ( is_admin() || isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return true;
	}

	$plugin = \Elementor\Plugin::$instance;
	if ( ! empty( $plugin->preview ) && method_exists( $plugin->preview, 'is_preview_mode' ) && $plugin->preview->is_preview_mode() ) {
		return true;
	}

	// New theme homepage never uses Elementor markup.
	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		return false;
	}

	if ( ! is_singular() ) {
		return false;
	}

	$post_id = (int) get_queried_object_id();
	if ( ! $post_id ) {
		return false;
	}

	if ( isset( $plugin->db ) && method_exists( $plugin->db, 'is_built_with_elementor' ) ) {
		return (bool) $plugin->db->is_built_with_elementor( $post_id );
	}

	return 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true );
}

/**
 * Drop Elementor kit / frontend CSS+JS on theme pages so rules like
 * `.elementor-kit-8941 h2` cannot override theme typography.
 */
function akaza_dequeue_elementor_assets() {
	if ( akaza_needs_elementor_assets() ) {
		return;
	}

	$kit_id = (int) get_option( 'elementor_active_kit' );

	$style_handles = array(
		'elementor-frontend',
		'elementor-frontend-css',
		'elementor-frontend-legacy',
		'elementor-icons',
		'elementor-common',
		'elementor-wp-admin-bar',
		'font-awesome',
		'e-animations',
		'e-swiper',
		'swiper',
	);

	if ( $kit_id ) {
		$style_handles[] = 'elementor-post-' . $kit_id;
		$style_handles[] = 'elementor-global';
	}

	foreach ( $style_handles as $handle ) {
		wp_dequeue_style( $handle );
		wp_deregister_style( $handle );
	}

	// Catch remaining Elementor kit / Google Fonts CSS handles.
	global $wp_styles;
	if ( $wp_styles instanceof WP_Styles ) {
		foreach ( array_keys( $wp_styles->registered ) as $handle ) {
			if ( 0 === strpos( $handle, 'elementor-post-' )
				|| 0 === strpos( $handle, 'elementor-gf-' )
				|| 0 === strpos( $handle, 'elementor-' )
			) {
				wp_dequeue_style( $handle );
				wp_deregister_style( $handle );
			}
		}
	}

	$script_handles = array(
		'elementor-frontend',
		'elementor-frontend-modules',
		'elementor-webpack-runtime',
		'elementor-common',
		'elementor-dialog',
		'swiper',
	);

	foreach ( $script_handles as $handle ) {
		wp_dequeue_script( $handle );
		wp_deregister_script( $handle );
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_dequeue_elementor_assets', 9999 );

/**
 * Remove Elementor kit body classes on non-Elementor pages.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function akaza_strip_elementor_body_classes( $classes ) {
	if ( akaza_needs_elementor_assets() ) {
		return $classes;
	}

	return array_values(
		array_filter(
			$classes,
			static function ( $class ) {
				return 0 !== strpos( $class, 'elementor-' );
			}
		)
	);
}
add_filter( 'body_class', 'akaza_strip_elementor_body_classes', 9999 );


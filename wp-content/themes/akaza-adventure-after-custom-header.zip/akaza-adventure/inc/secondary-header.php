<?php
/**
 * Secondary global header (opt-in by page slug).
 *
 * Use for landings that keep the live Eduma footer but need a custom header
 * (logo + nav + Request Demo + email). Add/remove slugs in
 * akaza_secondary_header_slugs() or via the `akaza_secondary_header_slugs` filter.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Page slugs that use the secondary global header.
 *
 * @return string[]
 */
function akaza_secondary_header_slugs() {
	$slugs = array(
		// SAP (live + alias).
		'security-awareness',
		'security-awareness-and-phishing',
		// Add more landing slugs here as needed.
	);

	/**
	 * Filter secondary-header page slugs.
	 *
	 * @param string[] $slugs Slugs.
	 */
	return array_values( array_unique( array_map( 'strval', (array) apply_filters( 'akaza_secondary_header_slugs', $slugs ) ) ) );
}

/**
 * Current front request slug (first path segment).
 *
 * @return string
 */
function akaza_secondary_header_request_slug() {
	if ( function_exists( 'sl_landing_bridge_request_slug' ) ) {
		return (string) sl_landing_bridge_request_slug();
	}

	if ( empty( $_SERVER['REQUEST_URI'] ) ) {
		return '';
	}

	$path = (string) wp_parse_url( (string) $_SERVER['REQUEST_URI'], PHP_URL_PATH );
	$path = trim( $path, '/' );

	$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	$home_path = trim( $home_path, '/' );
	if ( '' !== $home_path && 0 === strpos( $path, $home_path . '/' ) ) {
		$path = substr( $path, strlen( $home_path ) + 1 );
	} elseif ( $path === $home_path ) {
		$path = '';
	}

	$path = trim( (string) $path, '/' );
	if ( '' === $path ) {
		return '';
	}

	$parts = explode( '/', $path );
	return (string) $parts[0];
}

/**
 * Whether the current request should render the secondary global header.
 *
 * @return bool
 */
function akaza_uses_secondary_header() {
	if ( is_admin() ) {
		return false;
	}

	$slug = akaza_secondary_header_request_slug();
	if ( '' !== $slug && in_array( $slug, akaza_secondary_header_slugs(), true ) ) {
		return true;
	}

	return false;
}

/**
 * Enqueue secondary header assets on opted-in pages.
 */
function akaza_enqueue_secondary_header_assets() {
	if ( ! akaza_uses_secondary_header() ) {
		return;
	}

	if (
		( function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint() )
		|| ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() )
		|| ( function_exists( 'succeedlearn_amp_is_serving_amp' ) && succeedlearn_amp_is_serving_amp() )
	) {
		return;
	}

	akaza_enqueue_theme_style( 'akaza-sl-secondary-header', 'sl-secondary-header.css', array() );
	akaza_enqueue_theme_script( 'akaza-sl-secondary-header', 'sl-secondary-header.js' );
}
add_action( 'wp_enqueue_scripts', 'akaza_enqueue_secondary_header_assets', 30 );

<?php
/**
 * SucceedLEARN
 * Cybersecurity Awareness Month 2026
 * Hero Section
 *
 * @package Akaza_Adventure
 */
?>

<section
	class="sl-infosec-2026-cyber-hero"
	aria-labelledby="sl-infosec-2026-cyber-hero-title"
>
	<div class="container">

		<div class="sl-infosec-2026-cyber-hero__grid">

			<!-- LEFT: Hero Content -->
			<div class="sl-infosec-2026-cyber-hero__content">

				<span class="sl-home-sub-heading">
					<?php esc_html_e( 'CYBERSECURITY AWARENESS MONTH 2026', 'akaza-adventure' ); ?>
				</span>

				<h1 id="sl-infosec-2026-cyber-hero-title">
					<?php
					echo wp_kses_post(
						__( 'Don’t Just Train Your Employees. <span>Test Their Cyber Readiness.</span>', 'akaza-adventure' )
					);
					?>
				</h1>

				<div class="sl-infosec-2026-cyber-hero__intro">

					<p>
						<?php esc_html_e(
							'Your employees are one of your organisation’s most important lines of defence.',
							'akaza-adventure'
						); ?>
					</p>

					<p>
						<?php esc_html_e(
							'But phishing attacks are becoming harder to recognise. AI-assisted emails, impersonation, social engineering and increasingly convincing fraudulent communications mean that knowing about phishing isn’t always enough.',
							'akaza-adventure'
						); ?>
					</p>

				</div>

				<div class="sl-infosec-2026-cyber-hero__question">

					<span class="sl-infosec-2026-cyber-hero__question-label">
						<?php esc_html_e( 'THE REAL QUESTION', 'akaza-adventure' ); ?>
					</span>

					<p>
						<?php
						echo wp_kses_post(
							__( 'What happens when the <strong>phishing email actually arrives?</strong>', 'akaza-adventure' )
						);
						?>
					</p>

				</div>

				<p class="sl-infosec-2026-cyber-hero__closing">
					<?php esc_html_e(
						'This Cybersecurity Awareness Month gives your employees the opportunity to put their awareness into practice through a controlled phishing simulation and gives your organisation measurable insight into how prepared your workforce really is.',
						'akaza-adventure'
					); ?>
				</p>

			</div>


			<!-- RIGHT: Hero Image -->
			<div class="sl-infosec-2026-cyber-hero__media">

				<div class="sl-infosec-2026-cyber-hero__image-wrap">

					<!-- Replace this placeholder with the final WebP image -->
					<div
						class="sl-infosec-2026-cyber-hero__image-placeholder"
						role="img"
						aria-label="<?php esc_attr_e(
							'Cybersecurity phishing simulation illustration placeholder',
							'akaza-adventure'
						); ?>"
					>
						<span>
							<?php esc_html_e(
								'Image placeholder',
								'akaza-adventure'
							); ?>
						</span>

						<small>
							<?php esc_html_e(
								'Recommended: 720 × 820 px',
								'akaza-adventure'
							); ?>
						</small>
					</div>

				</div>

			</div>

		</div>

	</div>
</section>
<?php
/**
 * SucceedLEARN — Workplace Harassment Prevention
 *
 * Section: Contact / Request a Demo
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section
	class="sl-workplace-harassment-contact"
	id="contact"
	aria-labelledby="sl-workplace-harassment-contact-title"
>

	<div class="container">

		<div class="sl-workplace-harassment-contact__grid">

			<!-- LEFT: CONTACT CONTENT -->
			<div class="sl-workplace-harassment-contact__content">

				<span class="sl-home-sub-heading">
					<?php
					esc_html_e(
						'Workplace Harassment Prevention Training',
						'akaza-adventure'
					);
					?>
				</span>

				<h2 id="sl-workplace-harassment-contact-title">
					<?php
					esc_html_e(
						'Give every employee the right answer to',
						'akaza-adventure'
					);
					?>
					<span>
						<?php
						esc_html_e(
							'“What happens next?”',
							'akaza-adventure'
						);
						?>
					</span>
				</h2>


				<!-- KEY MOMENTS -->
				<ul class="sl-workplace-harassment-contact__moments">

					<li>
						<span class="sl-workplace-harassment-contact__moment-icon" aria-hidden="true">
							✓
						</span>

						<span>
							<?php
							esc_html_e(
								'An employee experiences unwelcome conduct.',
								'akaza-adventure'
							);
							?>
						</span>
					</li>

					<li>
						<span class="sl-workplace-harassment-contact__moment-icon" aria-hidden="true">
							✓
						</span>

						<span>
							<?php
							esc_html_e(
								'A witness is uncertain whether to intervene.',
								'akaza-adventure'
							);
							?>
						</span>
					</li>

					<li>
						<span class="sl-workplace-harassment-contact__moment-icon" aria-hidden="true">
							✓
						</span>

						<span>
							<?php
							esc_html_e(
								'A supervisor receives a disclosure.',
								'akaza-adventure'
							);
							?>
						</span>
					</li>

					<li>
						<span class="sl-workplace-harassment-contact__moment-icon" aria-hidden="true">
							✓
						</span>

						<span>
							<?php
							esc_html_e(
								'An Internal Committee receives a complaint.',
								'akaza-adventure'
							);
							?>
						</span>
					</li>

				</ul>


				<p class="sl-workplace-harassment-contact__lead">
					<?php
					esc_html_e(
						'Each moment requires different knowledge, and the response can shape what happens next.',
						'akaza-adventure'
					);
					?>
				</p>

				<p>
					<?php
					esc_html_e(
						'Give your workforce training designed for their region, role and responsibilities.',
						'akaza-adventure'
					);
					?>
				</p>


				<!-- CONTACT DETAILS -->
				<div class="sl-workplace-harassment-contact__details">

					<a
						class="sl-workplace-harassment-contact__detail"
						href="mailto:sales@succeedtech.com"
					>
						<span class="sl-workplace-harassment-contact__detail-label">
							<?php esc_html_e( 'Email', 'akaza-adventure' ); ?>
						</span>

						<span class="sl-workplace-harassment-contact__detail-value">
							sales@succeedtech.com
						</span>
					</a>

					<a
						class="sl-workplace-harassment-contact__detail"
						href="tel:+916362021778"
					>
						<span class="sl-workplace-harassment-contact__detail-label">
							<?php esc_html_e( 'Phone', 'akaza-adventure' ); ?>
						</span>

						<span class="sl-workplace-harassment-contact__detail-value">
							+91 63620 21778
						</span>
					</a>

				</div>


				<!-- WHATSAPP CTA -->
				<div class="sl-workplace-harassment-contact__whatsapp">

					<a
						class="sl-workplace-harassment-contact__whatsapp-btn"
						href="https://wa.me/916362021778"
						target="_blank"
						rel="noopener noreferrer"
						aria-label="<?php esc_attr_e( 'Chat with us on WhatsApp', 'akaza-adventure' ); ?>"
					>

						<span
							class="sl-workplace-harassment-contact__whatsapp-icon"
							aria-hidden="true"
						>
							<svg
								viewBox="0 0 24 24"
								width="20"
								height="20"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M20.52 3.48A11.82 11.82 0 0 0 12.09 0C5.55 0 .23 5.32.23 11.86c0 2.09.55 4.13 1.59 5.93L.13 24l6.36-1.67a11.86 11.86 0 0 0 5.6 1.43h.01c6.54 0 11.86-5.32 11.86-11.86 0-3.17-1.23-6.15-3.44-8.42Z"
									fill="currentColor"
								/>
								<path
									d="M17.52 14.22c-.3-.15-1.77-.87-2.05-.97-.28-.1-.48-.15-.69.15-.2.3-.79.97-.97 1.17-.18.2-.36.22-.66.07-.3-.15-1.26-.46-2.4-1.47-.89-.79-1.49-1.76-1.66-2.06-.17-.3-.02-.46.13-.61.13-.13.3-.36.45-.54.15-.18.2-.3.3-.51.1-.2.05-.38-.03-.53-.08-.15-.69-1.65-.94-2.26-.25-.59-.5-.51-.69-.52h-.59c-.2 0-.53.07-.81.38-.28.3-1.06 1.03-1.06 2.52s1.09 2.92 1.24 3.12c.15.2 2.14 3.27 5.18 4.58.72.31 1.28.5 1.72.64.72.23 1.38.2 1.9.12.58-.09 1.77-.72 2.02-1.42.25-.69.25-1.28.18-1.4-.07-.13-.27-.2-.57-.35Z"
									fill="#fff"
								/>
							</svg>
						</span>

						<span>
							<?php
							esc_html_e(
								'Chat with us on WhatsApp',
								'akaza-adventure'
							);
							?>
						</span>

					</a>

				</div>

			</div>


			<!-- RIGHT: COMMON CONTACT FORM -->
			<div class="sl-workplace-harassment-contact__form-wrap">

				<div class="sl-home-form-wrapper sl-home-form-wrapper--slim">

					<?php
					$form_title     = __( 'Request a Demo', 'akaza-adventure' );
					$form_shortcode = sprintf(
						'[contact_form form_variant="course" title="%s"]',
						esc_attr( $form_title )
					);

					if ( shortcode_exists( 'contact_form' ) ) {

						echo do_shortcode( $form_shortcode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

					} elseif ( shortcode_exists( 'succeedlearn_course_form' ) ) {

						echo do_shortcode(
							sprintf(
								'[succeedlearn_course_form title="%s"]',
								esc_attr( $form_title )
							)
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

					}
					?>

				</div>

			</div>

		</div>

	</div>

</section>
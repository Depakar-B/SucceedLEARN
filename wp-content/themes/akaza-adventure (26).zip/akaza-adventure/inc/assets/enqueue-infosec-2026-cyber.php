<?php
/**
 * Infosec 2026 Cyber page assets.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue Infosec 2026 Cyber page styles (and scripts when needed).
 * Desktop only — AMP uses plugin styles in succeedlearn-amp.
 */
function akaza_enqueue_infosec_2026_cyber_assets() {
	if (
		( function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint() )
		|| ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() )
		|| ( function_exists( 'succeedlearn_amp_is_serving_amp' ) && succeedlearn_amp_is_serving_amp() )
	) {
		return;
	}

	$folder = 'infosec-2026-cyber';
	$global = akaza_enqueue_page_foundation();

	akaza_enqueue_theme_style(
		'akaza-sl-infosec-2026-cyber-hero',
		"{$folder}/sl-infosec-2026-cyber-hero.css",
		array( $global )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-infosec-2026-cyber-campaign',
		"{$folder}/sl-infosec-2026-cyber-campaign.css",
		array( $global )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-infosec-2026-cyber-testing',
		"{$folder}/sl-infosec-2026-cyber-testing.css",
		array( $global, 'akaza-global-highlight' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-infosec-2026-cyber-challenge',
		"{$folder}/sl-infosec-2026-cyber-challenge.css",
		array( $global, 'akaza-global-highlight' )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-infosec-2026-campaign-works',
		"{$folder}/sl-infosec-2026-campaign-works.css",
		array( $global )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-infosec-2026-understand',
		"{$folder}/sl-infosec-2026-understand.css",
		array( $global )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-infosec-2026-terms',
		"{$folder}/sl-infosec-2026-terms.css",
		array( $global )
	);
	akaza_enqueue_theme_style(
		'akaza-sl-infosec-2026-contact',
		"{$folder}/sl-infosec-2026-contact.css",
		array( $global )
	);
}

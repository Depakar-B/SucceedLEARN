<?php
/**
 * Akaza Adventure — performance-first SucceedLEARN theme.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AKAZA_VERSION', '1.1.0' );
define( 'AKAZA_DIR', get_template_directory() );
define( 'AKAZA_URI', get_template_directory_uri() );

/**
 * Theme setup.
 */
function akaza_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 56,
			'width'       => 180,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'akaza-adventure' ),
			'footer'  => __( 'Footer Menu', 'akaza-adventure' ),
		)
	);

	add_image_size( 'akaza-course-card', 640, 400, true );
	add_image_size( 'akaza-course-hero', 1200, 675, true );
}
add_action( 'after_setup_theme', 'akaza_setup' );

/**
 * Enqueue assets — deferred JS, versioned by filemtime.
 */
function akaza_enqueue_assets() {
	$css_path = AKAZA_DIR . '/assets/css/main.css';
	$js_path  = AKAZA_DIR . '/assets/js/main.js';

	wp_enqueue_style(
		'akaza-main',
		AKAZA_URI . '/assets/css/main.css',
		array( 'akaza-fonts' ),
		file_exists( $css_path ) ? (string) filemtime( $css_path ) : AKAZA_VERSION
	);

	$global_faq_css = AKAZA_DIR . '/assets/css/global-faq.css';
	wp_enqueue_style(
		'akaza-global-faq',
		AKAZA_URI . '/assets/css/global-faq.css',
		array( 'akaza-main' ),
		file_exists( $global_faq_css ) ? (string) filemtime( $global_faq_css ) : AKAZA_VERSION
	);

	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		$hero_css       = AKAZA_DIR . '/assets/css/home-hero.css';
		$stats_css      = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js       = AKAZA_DIR . '/assets/js/stats.js';
		$clients_css    = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js     = AKAZA_DIR . '/assets/js/clients.js';
		$challenges_css = AKAZA_DIR . '/assets/css/todays-challenges.css';
		$solution_css   = AKAZA_DIR . '/assets/css/the-solution.css';
		$solution_js    = AKAZA_DIR . '/assets/js/the-solution.js';
		$platform_css   = AKAZA_DIR . '/assets/css/platform.css';
		$feature_css    = AKAZA_DIR . '/assets/css/feature-product-section.css';
		$outcomes_css   = AKAZA_DIR . '/assets/css/outcomes.css';
		$started_css    = AKAZA_DIR . '/assets/css/Getting-Started-Section.css';
		$started_js     = AKAZA_DIR . '/assets/js/getting-started.js';
		$cta_css           = AKAZA_DIR . '/assets/css/cta-section.css';
		$contact_css       = AKAZA_DIR . '/assets/css/contact-from.css';
		$testimonials_css  = AKAZA_DIR . '/assets/css/dpdpa-testimonials.css';

		wp_enqueue_style(
			'akaza-home-hero',
			AKAZA_URI . '/assets/css/home-hero.css',
			array( 'akaza-main' ),
			file_exists( $hero_css ) ? (string) filemtime( $hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main' ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main' ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-todays-challenges',
			AKAZA_URI . '/assets/css/todays-challenges.css',
			array( 'akaza-main' ),
			file_exists( $challenges_css ) ? (string) filemtime( $challenges_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-the-solution',
			AKAZA_URI . '/assets/css/the-solution.css',
			array( 'akaza-main' ),
			file_exists( $solution_css ) ? (string) filemtime( $solution_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-the-solution',
			AKAZA_URI . '/assets/js/the-solution.js',
			array(),
			file_exists( $solution_js ) ? (string) filemtime( $solution_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-platform',
			AKAZA_URI . '/assets/css/platform.css',
			array( 'akaza-main' ),
			file_exists( $platform_css ) ? (string) filemtime( $platform_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-feature-product',
			AKAZA_URI . '/assets/css/feature-product-section.css',
			array( 'akaza-main' ),
			file_exists( $feature_css ) ? (string) filemtime( $feature_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-outcomes',
			AKAZA_URI . '/assets/css/outcomes.css',
			array( 'akaza-main' ),
			file_exists( $outcomes_css ) ? (string) filemtime( $outcomes_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-home-testimonials',
			AKAZA_URI . '/assets/css/dpdpa-testimonials.css',
			array( 'akaza-main' ),
			file_exists( $testimonials_css ) ? (string) filemtime( $testimonials_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'bootstrap-icons',
			'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
			array(),
			'1.11.3'
		);

		wp_enqueue_style(
			'akaza-getting-started',
			AKAZA_URI . '/assets/css/Getting-Started-Section.css',
			array( 'akaza-main', 'bootstrap-icons' ),
			file_exists( $started_css ) ? (string) filemtime( $started_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-getting-started',
			AKAZA_URI . '/assets/js/getting-started.js',
			array(),
			file_exists( $started_js ) ? (string) filemtime( $started_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-cta-section',
			AKAZA_URI . '/assets/css/cta-section.css',
			array( 'akaza-main' ),
			file_exists( $cta_css ) ? (string) filemtime( $cta_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main' ),
			file_exists( $contact_css ) ? (string) filemtime( $contact_css ) : AKAZA_VERSION
		);
	}

	$is_dpdpa_page = is_page_template( 'page-templates/dpdpa-compliance-training.php' );
	$is_gdpr_page  = is_page_template( 'page-templates/gdpr-employee-awareness-training.php' );

	if ( $is_dpdpa_page || $is_gdpr_page ) {
		$dpdpa_hero_css = AKAZA_DIR . '/assets/css/dpdpa-hero.css';
		$dpdpa_hero_js  = AKAZA_DIR . '/assets/js/dpdpa-hero.js';
		$stats_css      = AKAZA_DIR . '/assets/css/stats.css';
		$stats_js       = AKAZA_DIR . '/assets/js/stats.js';
		$clients_css    = AKAZA_DIR . '/assets/css/clients.css';
		$clients_js     = AKAZA_DIR . '/assets/js/clients.js';

		wp_enqueue_style(
			'akaza-dpdpa-hero',
			AKAZA_URI . '/assets/css/dpdpa-hero.css',
			array( 'akaza-main' ),
			file_exists( $dpdpa_hero_css ) ? (string) filemtime( $dpdpa_hero_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-stats',
			AKAZA_URI . '/assets/css/stats.css',
			array( 'akaza-main' ),
			file_exists( $stats_css ) ? (string) filemtime( $stats_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-stats',
			AKAZA_URI . '/assets/js/stats.js',
			array(),
			file_exists( $stats_js ) ? (string) filemtime( $stats_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-clients',
			AKAZA_URI . '/assets/css/clients.css',
			array( 'akaza-main' ),
			file_exists( $clients_css ) ? (string) filemtime( $clients_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-clients',
			AKAZA_URI . '/assets/js/clients.js',
			array(),
			file_exists( $clients_js ) ? (string) filemtime( $clients_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_script(
			'akaza-dpdpa-hero',
			AKAZA_URI . '/assets/js/dpdpa-hero.js',
			array(),
			file_exists( $dpdpa_hero_js ) ? (string) filemtime( $dpdpa_hero_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	if ( $is_dpdpa_page ) {
		$outcomes_css      = AKAZA_DIR . '/assets/css/outcomes.css';
		$course_css        = AKAZA_DIR . '/assets/css/dpdpa-course.css';
		$scorecard_css     = AKAZA_DIR . '/assets/css/dpdpa-scorecard-cta.css';
		$pricing_css       = AKAZA_DIR . '/assets/css/dpdpa-pricing.css';
		$pricing_js        = AKAZA_DIR . '/assets/js/dpdpa-pricing.js';
		$why_now_css       = AKAZA_DIR . '/assets/css/dpdpa-why-now.css';
		$spec_css          = AKAZA_DIR . '/assets/css/dpdpa-spec.css';
		$testimonials_css  = AKAZA_DIR . '/assets/css/dpdpa-testimonials.css';
		$contact_css       = AKAZA_DIR . '/assets/css/contact-from.css';
		$dpdpa_contact_css = AKAZA_DIR . '/assets/css/dpdpa-contact.css';

		wp_enqueue_style(
			'akaza-outcomes',
			AKAZA_URI . '/assets/css/outcomes.css',
			array( 'akaza-main' ),
			file_exists( $outcomes_css ) ? (string) filemtime( $outcomes_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-dpdpa-course',
			AKAZA_URI . '/assets/css/dpdpa-course.css',
			array( 'akaza-main' ),
			file_exists( $course_css ) ? (string) filemtime( $course_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-dpdpa-scorecard-cta',
			AKAZA_URI . '/assets/css/dpdpa-scorecard-cta.css',
			array( 'akaza-main' ),
			file_exists( $scorecard_css ) ? (string) filemtime( $scorecard_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-dpdpa-pricing',
			AKAZA_URI . '/assets/css/dpdpa-pricing.css',
			array( 'akaza-main' ),
			file_exists( $pricing_css ) ? (string) filemtime( $pricing_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-dpdpa-pricing',
			AKAZA_URI . '/assets/js/dpdpa-pricing.js',
			array(),
			file_exists( $pricing_js ) ? (string) filemtime( $pricing_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_enqueue_style(
			'akaza-dpdpa-why-now',
			AKAZA_URI . '/assets/css/dpdpa-why-now.css',
			array( 'akaza-main' ),
			file_exists( $why_now_css ) ? (string) filemtime( $why_now_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-dpdpa-spec',
			AKAZA_URI . '/assets/css/dpdpa-spec.css',
			array( 'akaza-main' ),
			file_exists( $spec_css ) ? (string) filemtime( $spec_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-dpdpa-testimonials',
			AKAZA_URI . '/assets/css/dpdpa-testimonials.css',
			array( 'akaza-main' ),
			file_exists( $testimonials_css ) ? (string) filemtime( $testimonials_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-contact-form',
			AKAZA_URI . '/assets/css/contact-from.css',
			array( 'akaza-main' ),
			file_exists( $contact_css ) ? (string) filemtime( $contact_css ) : AKAZA_VERSION
		);

		wp_enqueue_style(
			'akaza-dpdpa-contact',
			AKAZA_URI . '/assets/css/dpdpa-contact.css',
			array( 'akaza-contact-form' ),
			file_exists( $dpdpa_contact_css ) ? (string) filemtime( $dpdpa_contact_css ) : AKAZA_VERSION
		);
	}

	wp_enqueue_script(
		'akaza-main',
		AKAZA_URI . '/assets/js/main.js',
		array(),
		file_exists( $js_path ) ? (string) filemtime( $js_path ) : AKAZA_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);

	// Theme header CSS/JS only when Akaza Header Footer plugin is not rendering.
	if ( ! has_action( 'ahf_render_site_header' ) ) {
		$fb_css = AKAZA_DIR . '/assets/css/header-fallback.css';
		$fb_js  = AKAZA_DIR . '/assets/js/header-fallback.js';

		wp_enqueue_style(
			'akaza-header-fallback',
			AKAZA_URI . '/assets/css/header-fallback.css',
			array( 'akaza-main' ),
			file_exists( $fb_css ) ? (string) filemtime( $fb_css ) : AKAZA_VERSION
		);

		wp_enqueue_script(
			'akaza-header-fallback',
			AKAZA_URI . '/assets/js/header-fallback.js',
			array(),
			file_exists( $fb_js ) ? (string) filemtime( $fb_js ) : AKAZA_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_enqueue_assets' );

/**
 * Whether the current request is AMP (skip theme scroll-to-top).
 *
 * @return bool
 */
function akaza_is_amp() {
	if ( class_exists( 'AHF_AMP' ) && method_exists( 'AHF_AMP', 'is_amp' ) ) {
		return (bool) AHF_AMP::is_amp();
	}
	if ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() ) {
		return true;
	}
	if ( function_exists( 'amp_is_request' ) && amp_is_request() ) {
		return true;
	}
	return false;
}

/**
 * Enqueue shared scroll-to-top assets (non-AMP only).
 */
function akaza_enqueue_scroll_to_top() {
	if ( akaza_is_amp() || is_admin() ) {
		return;
	}

	$css = AKAZA_DIR . '/assets/css/scroll-to-top.css';
	$js  = AKAZA_DIR . '/assets/js/scroll-to-top.js';

	wp_enqueue_style(
		'akaza-scroll-to-top',
		AKAZA_URI . '/assets/css/scroll-to-top.css',
		array( 'akaza-main' ),
		file_exists( $css ) ? (string) filemtime( $css ) : AKAZA_VERSION
	);

	wp_enqueue_script(
		'akaza-scroll-to-top',
		AKAZA_URI . '/assets/js/scroll-to-top.js',
		array(),
		file_exists( $js ) ? (string) filemtime( $js ) : AKAZA_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);
}
add_action( 'wp_enqueue_scripts', 'akaza_enqueue_scroll_to_top', 30 );

/**
 * Print scroll-to-top markup once in the footer (non-AMP only).
 */
function akaza_render_scroll_to_top() {
	static $done = false;
	if ( $done || akaza_is_amp() || is_admin() ) {
		return;
	}
	$done = true;
	?>
	<div id="sl-scroll-top" class="sl-scroll-top-wrap">
		<button
			type="button"
			class="sl-scroll-top"
			aria-label="<?php esc_attr_e( 'Back to top', 'akaza-adventure' ); ?>"
			title="<?php esc_attr_e( 'Back to top', 'akaza-adventure' ); ?>"
		>
			<span class="sl-scroll-top__icon" aria-hidden="true"></span>
		</button>
	</div>
	<?php
}
add_action( 'wp_footer', 'akaza_render_scroll_to_top', 40 );

/**
 * Preload LCP hero + critical fonts (homepage only for hero).
 */
function akaza_resource_hints() {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";

	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		$hero = AKAZA_URI . '/assets/images/hero.jpg';
		echo '<link rel="preload" as="image" href="' . esc_url( $hero ) . '" fetchpriority="high">' . "\n";
	}
}
add_action( 'wp_head', 'akaza_resource_hints', 1 );

/**
 * Load brand fonts as a normal stylesheet (avoid print/onload FOIT failures).
 */
function akaza_enqueue_fonts() {
	wp_enqueue_style(
		'akaza-fonts',
		'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&display=swap',
		array(),
		null
	);
}
add_action( 'wp_enqueue_scripts', 'akaza_enqueue_fonts', 5 );

/**
 * Whether Rank Math owns SEO output (titles, meta, schema, sitemap).
 *
 * @return bool
 */
function akaza_rank_math_active() {
	return defined( 'RANK_MATH_VERSION' );
}

/**
 * Clean document titles (fallback only when Rank Math is not active).
 *
 * @param array $parts Title parts.
 * @return array
 */
function akaza_document_title( $parts ) {
	if ( akaza_rank_math_active() ) {
		return $parts;
	}

	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		$parts['title']   = 'SucceedLEARN | Global Compliance & Security Training';
		$parts['tagline'] = '';
	} elseif ( function_exists( 'learn_press_is_courses' ) && learn_press_is_courses() ) {
		$parts['title']   = 'Courses | SucceedLEARN Compliance Training';
		$parts['tagline'] = '';
	} elseif ( function_exists( 'learn_press_is_course' ) && learn_press_is_course() ) {
		$parts['tagline'] = 'SucceedLEARN Course';
	} elseif ( is_page_template( 'page-templates/page-solutions.php' ) ) {
		$parts['title']   = 'Solutions | SucceedLEARN';
		$parts['tagline'] = '';
	} elseif ( is_page_template( 'page-templates/page-about.php' ) ) {
		$parts['title']   = 'About Us | SucceedLEARN';
		$parts['tagline'] = '';
	} elseif ( is_page_template( 'page-templates/page-contact.php' ) ) {
		$parts['title']   = 'Contact Us | SucceedLEARN';
		$parts['tagline'] = '';
	}
	return $parts;
}
add_filter( 'document_title_parts', 'akaza_document_title' );

/**
 * SEO meta + Open Graph + Twitter + JSON-LD.
 * Skips when Rank Math is active so meta/canonical/schema are not duplicated.
 */
function akaza_seo_head() {
	if ( akaza_rank_math_active() ) {
		return;
	}

	$url       = home_url( '/' );
	$site_name = 'SucceedLEARN';
	$image     = AKAZA_URI . '/assets/images/hero.jpg';
	$title     = '';
	$description = '';
	$schema    = null;

	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		$title       = 'SucceedLEARN | Global Compliance & Security Training';
		$description = 'Global compliance and security awareness training employees actually remember. Measurable behaviour change, audit-ready reporting, and one platform for workplace learning.';
		$url         = home_url( '/' );
		$schema      = akaza_schema_homepage( $url, $title, $description, $image );
	} elseif ( function_exists( 'learn_press_is_course' ) && learn_press_is_course() ) {
		$course_id   = get_the_ID();
		$title       = get_the_title( $course_id ) . ' | SucceedLEARN';
		$description = wp_strip_all_tags( get_the_excerpt( $course_id ) );
		if ( ! $description ) {
			$description = wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $course_id ) ), 40 );
		}
		$url   = get_permalink( $course_id );
		$thumb = get_the_post_thumbnail_url( $course_id, 'akaza-course-hero' );
		if ( $thumb ) {
			$image = $thumb;
		}
		$schema = akaza_schema_course( $course_id, $url, $title, $description, $image );
	} elseif ( function_exists( 'learn_press_is_courses' ) && learn_press_is_courses() ) {
		$title       = 'Courses | SucceedLEARN Compliance Training';
		$description = 'Browse SucceedLEARN compliance and security awareness courses. Engaging training with measurable outcomes for modern organisations.';
		$url         = get_post_type_archive_link( 'lp_course' ) ? get_post_type_archive_link( 'lp_course' ) : home_url( '/courses/' );
		$schema      = akaza_schema_course_list( $url, $title, $description );
	} elseif ( is_page() ) {
		$title       = get_the_title() . ' | SucceedLEARN';
		$description = has_excerpt() ? wp_strip_all_tags( get_the_excerpt() ) : wp_trim_words( wp_strip_all_tags( get_the_content() ), 40 );
		if ( ! $description ) {
			$description = 'SucceedLEARN — global compliance and security training.';
		}
		$url = get_permalink();
	} else {
		return;
	}

	echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">' . "\n";
	echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
	echo '<link rel="sitemap" type="application/xml" title="Sitemap" href="' . esc_url( home_url( '/akaza-sitemap.xml' ) ) . '">' . "\n";

	echo '<meta property="og:locale" content="en_US">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( $site_name ) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";

	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta name="twitter:description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n";

	if ( $schema ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	}
}
add_action( 'wp_head', 'akaza_seo_head', 2 );

/**
 * Homepage schema graph.
 *
 * @param string $url URL.
 * @param string $title Title.
 * @param string $description Description.
 * @param string $image Image.
 * @return array
 */
function akaza_schema_homepage( $url, $title, $description, $image ) {
	return array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			array(
				'@type'  => 'Organization',
				'@id'    => $url . '#organization',
				'name'   => 'SucceedLEARN',
				'url'    => $url,
				'logo'   => array(
					'@type' => 'ImageObject',
					'url'   => AKAZA_URI . '/assets/images/logo-mark.svg',
				),
				'email'  => 'sales@succeedtech.com',
				'sameAs' => array(
					'https://www.linkedin.com/company/succeedlearn',
					'https://www.youtube.com/@succeedlearn',
				),
			),
			array(
				'@type'           => 'WebSite',
				'@id'             => $url . '#website',
				'url'             => $url,
				'name'            => 'SucceedLEARN',
				'description'     => $description,
				'publisher'       => array( '@id' => $url . '#organization' ),
				'inLanguage'      => 'en-US',
				'potentialAction' => array(
					'@type'       => 'SearchAction',
					'target'      => $url . '?s={search_term_string}',
					'query-input' => 'required name=search_term_string',
				),
			),
			array(
				'@type'       => 'WebPage',
				'@id'         => $url . '#webpage',
				'url'         => $url,
				'name'        => $title,
				'isPartOf'    => array( '@id' => $url . '#website' ),
				'about'       => array( '@id' => $url . '#organization' ),
				'description' => $description,
				'inLanguage'  => 'en-US',
				'primaryImageOfPage' => array(
					'@type' => 'ImageObject',
					'url'   => $image,
				),
			),
		),
	);
}

/**
 * Single course schema.
 *
 * @param int    $course_id Course ID.
 * @param string $url URL.
 * @param string $title Title.
 * @param string $description Description.
 * @param string $image Image.
 * @return array
 */
function akaza_schema_course( $course_id, $url, $title, $description, $image ) {
	$course = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Course',
		'name'        => get_the_title( $course_id ),
		'description' => $description,
		'url'         => $url,
		'image'       => $image,
		'provider'    => array(
			'@type' => 'Organization',
			'name'  => 'SucceedLEARN',
			'url'   => home_url( '/' ),
		),
	);

	if ( function_exists( 'learn_press_get_course' ) ) {
		$lp = learn_press_get_course( $course_id );
		if ( $lp ) {
			$price = method_exists( $lp, 'get_price' ) ? $lp->get_price() : '';
			if ( '' !== $price && null !== $price ) {
				$course['offers'] = array(
					'@type'         => 'Offer',
					'price'         => (float) $price,
					'priceCurrency' => 'USD',
					'availability'  => 'https://schema.org/InStock',
					'url'           => $url,
				);
			}
		}
	}

	return $course;
}

/**
 * Course archive ItemList schema.
 *
 * @param string $url URL.
 * @param string $title Title.
 * @param string $description Description.
 * @return array
 */
function akaza_schema_course_list( $url, $title, $description ) {
	$items = array();
	$query = new WP_Query(
		array(
			'post_type'      => 'lp_course',
			'posts_per_page' => 20,
			'post_status'    => 'publish',
			'no_found_rows'  => true,
		)
	);
	$pos = 1;
	while ( $query->have_posts() ) {
		$query->the_post();
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $pos,
			'url'      => get_permalink(),
			'name'     => get_the_title(),
		);
		$pos++;
	}
	wp_reset_postdata();

	return array(
		'@context'        => 'https://schema.org',
		'@type'           => 'CollectionPage',
		'name'            => $title,
		'description'     => $description,
		'url'             => $url,
		'mainEntity'      => array(
			'@type'           => 'ItemList',
			'itemListElement' => $items,
		),
	);
}

/**
 * Strip default WP bloat.
 */
function akaza_disable_bloat() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );

	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
	wp_dequeue_style( 'global-styles' );
	wp_dequeue_style( 'classic-theme-styles' );

	// Soften LearnPress front CSS when present — keep core, drop extras if registered.
	if ( ! is_admin() ) {
		wp_dequeue_style( 'lp-font-awesome-5' );
		wp_dequeue_style( 'learnpress' );
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_disable_bloat', 100 );

/**
 * Minimal LearnPress styles — theme provides layout.
 */
function akaza_learnpress_assets() {
	if ( ! function_exists( 'learn_press_is_course' ) ) {
		return;
	}
	if ( ! learn_press_is_courses() && ! learn_press_is_course() ) {
		return;
	}
	$path = AKAZA_DIR . '/assets/css/learnpress.css';
	if ( file_exists( $path ) ) {
		wp_enqueue_style(
			'akaza-learnpress',
			AKAZA_URI . '/assets/css/learnpress.css',
			array( 'akaza-main' ),
			(string) filemtime( $path )
		);
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_learnpress_assets', 20 );

/**
 * Performance / security headers.
 */
function akaza_send_headers() {
	if ( headers_sent() ) {
		return;
	}
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'Permissions-Policy: interest-cohort=()' );
}
add_action( 'send_headers', 'akaza_send_headers' );

/**
 * Theme image URL helper.
 *
 * @param string $path Relative path under assets/images/.
 * @return string
 */
function akaza_img( $path ) {
	return AKAZA_URI . '/assets/images/' . ltrim( $path, '/' );
}

/**
 * Backward-compatible alias used in existing templates.
 *
 * @param string $path Path.
 * @return string
 */
function slf_img( $path ) {
	return akaza_img( $path );
}

/**
 * Page URL by slug.
 *
 * @param string $slug Page slug.
 * @return string
 */
function akaza_page_url( $slug ) {
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . trim( $slug, '/' ) . '/' );
}

/**
 * Create core marketing pages if missing.
 */
function akaza_bootstrap_pages() {
	if ( get_option( 'akaza_pages_bootstrapped' ) ) {
		return;
	}

	$pages = array(
		array(
			'slug'     => 'solutions',
			'title'    => 'Solutions',
			'template' => 'page-templates/page-solutions.php',
		),
		array(
			'slug'     => 'about-us',
			'title'    => 'About Us',
			'template' => 'page-templates/page-about.php',
		),
		array(
			'slug'     => 'contact-us',
			'title'    => 'Contact Us',
			'template' => 'page-templates/page-contact.php',
		),
	);

	foreach ( $pages as $page ) {
		$existing = get_page_by_path( $page['slug'] );
		if ( $existing ) {
			update_post_meta( $existing->ID, '_wp_page_template', $page['template'] );
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_title'   => $page['title'],
				'post_name'    => $page['slug'],
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '',
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_wp_page_template', $page['template'] );
		}
	}

	update_option( 'akaza_pages_bootstrapped', 1, false );
}
add_action( 'after_switch_theme', 'akaza_bootstrap_pages' );
add_action( 'init', 'akaza_bootstrap_pages' );

/**
 * Register page templates.
 *
 * @param array $templates Templates.
 * @return array
 */
function akaza_page_templates( $templates ) {
	$templates['page-templates/homepage-fast.php'] = __( 'Homepage Fast (SEO + Performance)', 'akaza-adventure' );
	$templates['page-templates/page-solutions.php'] = __( 'Solutions', 'akaza-adventure' );
	$templates['page-templates/page-about.php']     = __( 'About Us', 'akaza-adventure' );
	$templates['page-templates/page-contact.php']   = __( 'Contact Us', 'akaza-adventure' );
	return $templates;
}
add_filter( 'theme_page_templates', 'akaza_page_templates' );

/**
 * Course archive URL helper.
 *
 * @return string
 */
function akaza_courses_url() {
	if ( function_exists( 'learn_press_get_page_link' ) ) {
		$link = learn_press_get_page_link( 'courses' );
		if ( $link ) {
			return $link;
		}
	}
	$archive = get_post_type_archive_link( 'lp_course' );
	return $archive ? $archive : home_url( '/courses/' );
}

/**
 * Handle homepage / contact form.
 */
function akaza_handle_contact() {
	if ( ! isset( $_POST['slf_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['slf_contact_nonce'] ) ), 'slf_contact' ) ) {
		wp_safe_redirect( home_url( '/?contact=invalid' ) );
		exit;
	}

	$first   = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
	$last    = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( ! $first || ! $last || ! is_email( $email ) || ! $message ) {
		wp_safe_redirect( akaza_page_url( 'contact-us' ) . '?contact=invalid' );
		exit;
	}

	$content = "Name: {$first} {$last}\nEmail: {$email}\nPhone: {$phone}\n\n{$message}";

	wp_insert_post(
		array(
			'post_type'    => 'post',
			'post_status'  => 'private',
			'post_title'   => 'Lead: ' . $first . ' ' . $last,
			'post_content' => $content,
		)
	);

	$admin = get_option( 'admin_email' );
	if ( $admin ) {
		wp_mail(
			$admin,
			'[SucceedLEARN] New enquiry from ' . $first . ' ' . $last,
			$content,
			array( 'Reply-To: ' . $email )
		);
	}

	wp_safe_redirect( akaza_page_url( 'contact-us' ) . '?contact=sent' );
	exit;
}
add_action( 'admin_post_nopriv_slf_contact', 'akaza_handle_contact' );
add_action( 'admin_post_slf_contact', 'akaza_handle_contact' );

/**
 * Basic XML sitemap for pages + courses when Rank Math is absent.
 */
function akaza_sitemap_rewrite() {
	if ( akaza_rank_math_active() ) {
		return;
	}
	add_rewrite_rule( '^akaza-sitemap\.xml$', 'index.php?akaza_sitemap=1', 'top' );
}
add_action( 'init', 'akaza_sitemap_rewrite' );

/**
 * Register sitemap query var.
 *
 * @param array $vars Vars.
 * @return array
 */
function akaza_sitemap_query_var( $vars ) {
	$vars[] = 'akaza_sitemap';
	return $vars;
}
add_filter( 'query_vars', 'akaza_sitemap_query_var' );

/**
 * Render basic sitemap (fallback only; Rank Math owns sitemap when active).
 */
function akaza_render_sitemap() {
	if ( akaza_rank_math_active() ) {
		return;
	}
	if ( ! intval( get_query_var( 'akaza_sitemap' ) ) ) {
		return;
	}

	header( 'Content-Type: application/xml; charset=UTF-8' );
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

	$urls = array( home_url( '/' ) );

	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'fields'         => 'ids',
		)
	);
	foreach ( $pages as $pid ) {
		$urls[] = get_permalink( $pid );
	}

	$courses = get_posts(
		array(
			'post_type'      => 'lp_course',
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'fields'         => 'ids',
		)
	);
	foreach ( $courses as $cid ) {
		$urls[] = get_permalink( $cid );
	}

	$archive = get_post_type_archive_link( 'lp_course' );
	if ( $archive ) {
		$urls[] = $archive;
	}

	$urls = array_unique( array_filter( $urls ) );
	foreach ( $urls as $u ) {
		echo '  <url><loc>' . esc_url( $u ) . '</loc></url>' . "\n";
	}
	echo '</urlset>';
	exit;
}
add_action( 'template_redirect', 'akaza_render_sitemap' );

/**
 * Whether the current request needs Elementor frontend assets.
 *
 * @return bool
 */
function akaza_needs_elementor_assets() {
	if ( ! did_action( 'elementor/loaded' ) || ! class_exists( '\Elementor\Plugin' ) ) {
		return false;
	}

	// Keep assets in the Elementor editor / preview.
	if ( is_admin() || isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return true;
	}

	$plugin = \Elementor\Plugin::$instance;
	if ( ! empty( $plugin->preview ) && method_exists( $plugin->preview, 'is_preview_mode' ) && $plugin->preview->is_preview_mode() ) {
		return true;
	}

	// New theme homepage never uses Elementor markup.
	if ( is_front_page() || is_page_template( 'page-templates/homepage-fast.php' ) ) {
		return false;
	}

	if ( ! is_singular() ) {
		return false;
	}

	$post_id = (int) get_queried_object_id();
	if ( ! $post_id ) {
		return false;
	}

	if ( isset( $plugin->db ) && method_exists( $plugin->db, 'is_built_with_elementor' ) ) {
		return (bool) $plugin->db->is_built_with_elementor( $post_id );
	}

	return 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true );
}

/**
 * Drop Elementor kit / frontend CSS+JS on theme pages so rules like
 * `.elementor-kit-8941 h2` cannot override theme typography.
 */
function akaza_dequeue_elementor_assets() {
	if ( akaza_needs_elementor_assets() ) {
		return;
	}

	$kit_id = (int) get_option( 'elementor_active_kit' );

	$style_handles = array(
		'elementor-frontend',
		'elementor-frontend-css',
		'elementor-frontend-legacy',
		'elementor-icons',
		'elementor-common',
		'elementor-wp-admin-bar',
		'font-awesome',
		'e-animations',
		'e-swiper',
		'swiper',
	);

	if ( $kit_id ) {
		$style_handles[] = 'elementor-post-' . $kit_id;
		$style_handles[] = 'elementor-global';
	}

	foreach ( $style_handles as $handle ) {
		wp_dequeue_style( $handle );
		wp_deregister_style( $handle );
	}

	// Catch remaining Elementor kit / Google Fonts CSS handles.
	global $wp_styles;
	if ( $wp_styles instanceof WP_Styles ) {
		foreach ( array_keys( $wp_styles->registered ) as $handle ) {
			if ( 0 === strpos( $handle, 'elementor-post-' )
				|| 0 === strpos( $handle, 'elementor-gf-' )
				|| 0 === strpos( $handle, 'elementor-' )
			) {
				wp_dequeue_style( $handle );
				wp_deregister_style( $handle );
			}
		}
	}

	$script_handles = array(
		'elementor-frontend',
		'elementor-frontend-modules',
		'elementor-webpack-runtime',
		'elementor-common',
		'elementor-dialog',
		'swiper',
	);

	foreach ( $script_handles as $handle ) {
		wp_dequeue_script( $handle );
		wp_deregister_script( $handle );
	}
}
add_action( 'wp_enqueue_scripts', 'akaza_dequeue_elementor_assets', 9999 );

/**
 * Remove Elementor kit body classes on non-Elementor pages.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function akaza_strip_elementor_body_classes( $classes ) {
	if ( akaza_needs_elementor_assets() ) {
		return $classes;
	}

	return array_values(
		array_filter(
			$classes,
			static function ( $class ) {
				return 0 !== strpos( $class, 'elementor-' );
			}
		)
	);
}
add_filter( 'body_class', 'akaza_strip_elementor_body_classes', 9999 );


<?php
/**
 * Template Name: About Us
 *
 * @package Akaza_Adventure
 */

get_header();
?>
<main id="main-content" class="slf-section slf-section--cream">
	<div class="slf-container slf-split">
		<div>
			<?php
			get_template_part(
				'template-parts/page-hero',
				null,
				array(
					'eyebrow' => __( 'About Us', 'akaza-adventure' ),
					'title'   => __( 'Global compliance training that turns mandatory learning into measurable outcomes', 'akaza-adventure' ),
					'lead'    => __( 'SucceedLEARN helps organisations build safer, more compliant workplaces through engaging training, continuous reinforcement, and analytics.', 'akaza-adventure' ),
				)
			);
			?>
			<ul class="slf-list slf-list--check">
				<li><?php esc_html_e( 'Trusted by 1000+ organisations worldwide', 'akaza-adventure' ); ?></li>
				<li><?php esc_html_e( '90%+ learner engagement across programmes', 'akaza-adventure' ); ?></li>
				<li><?php esc_html_e( 'Audit-ready reporting and compliance alignment', 'akaza-adventure' ); ?></li>
			</ul>
		</div>
		<figure class="slf-contact-media">
			<img src="<?php echo esc_url( akaza_img( 'form-img.jpg' ) ); ?>" alt="<?php esc_attr_e( 'SucceedLEARN team', 'akaza-adventure' ); ?>" width="720" height="640" loading="lazy" decoding="async">
		</figure>
	</div>
	<?php
	// Optional editor blocks only — skip Elementor/builder leftovers on full-custom templates.
	while ( have_posts() ) :
		the_post();
		$content = get_the_content( null, false );
		if ( $content && false === stripos( $content, 'elementor' ) ) {
			echo '<div class="slf-container slf-page-content">';
			echo apply_filters( 'the_content', $content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
		}
	endwhile;
	?>
</main>
<?php
get_footer();

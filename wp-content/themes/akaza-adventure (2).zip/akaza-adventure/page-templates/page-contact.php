<?php
/**
 * Template Name: Contact Us
 *
 * @package Akaza_Adventure
 */

get_header();
$contact_status = isset( $_GET['contact'] ) ? sanitize_key( wp_unslash( $_GET['contact'] ) ) : '';
?>
<main id="main-content" class="slf-section" id="contact">
	<div class="slf-container slf-split slf-split--contact">
		<div>
			<?php
			get_template_part(
				'template-parts/page-hero',
				null,
				array(
					'eyebrow' => __( 'Contact Us', 'akaza-adventure' ),
					'title'   => __( 'Need Help or Have a Query?', 'akaza-adventure' ),
					'lead'    => __( 'Tell us about your goals and a specialist will get back to you shortly.', 'akaza-adventure' ),
				)
			);
			?>
			<p class="slf-cta__contact">
				<?php esc_html_e( 'Sales:', 'akaza-adventure' ); ?>
				<a href="mailto:sales@succeedtech.com">sales@succeedtech.com</a>
				<span aria-hidden="true"> · </span>
				<?php esc_html_e( 'Support:', 'akaza-adventure' ); ?>
				<a href="mailto:support@succeedtech.com">support@succeedtech.com</a>
			</p>
			<?php if ( 'sent' === $contact_status ) : ?>
				<p class="slf-form__status" role="status"><?php esc_html_e( 'Thanks — your message has been sent.', 'akaza-adventure' ); ?></p>
			<?php elseif ( 'invalid' === $contact_status ) : ?>
				<p class="slf-form__status" role="status" style="color:#ea3f23;"><?php esc_html_e( 'Please check the required fields and try again.', 'akaza-adventure' ); ?></p>
			<?php endif; ?>
			<form class="slf-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate data-slf-form>
				<input type="hidden" name="action" value="slf_contact">
				<?php wp_nonce_field( 'slf_contact', 'slf_contact_nonce' ); ?>
				<div class="slf-form__row">
					<label><span><?php esc_html_e( 'First Name', 'akaza-adventure' ); ?></span><input type="text" name="first_name" autocomplete="given-name" required></label>
					<label><span><?php esc_html_e( 'Last Name', 'akaza-adventure' ); ?></span><input type="text" name="last_name" autocomplete="family-name" required></label>
				</div>
				<div class="slf-form__row">
					<label><span><?php esc_html_e( 'Work Email', 'akaza-adventure' ); ?></span><input type="email" name="email" autocomplete="email" required></label>
					<label><span><?php esc_html_e( 'Contact No.', 'akaza-adventure' ); ?></span><input type="tel" name="phone" autocomplete="tel"></label>
				</div>
				<label><span><?php esc_html_e( 'Message', 'akaza-adventure' ); ?></span><textarea name="message" rows="4" required></textarea></label>
				<button class="slf-btn slf-btn--primary" type="submit"><?php esc_html_e( 'Submit', 'akaza-adventure' ); ?></button>
			</form>
		</div>
		<figure class="slf-contact-media">
			<img src="<?php echo esc_url( akaza_img( 'form-img.jpg' ) ); ?>" alt="<?php esc_attr_e( 'SucceedLEARN team ready to help', 'akaza-adventure' ); ?>" width="720" height="640" loading="lazy" decoding="async">
		</figure>
	</div>
</main>
<?php
get_footer();

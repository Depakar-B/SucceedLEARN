<?php
/**
 * Template Name: DPDPA Compliance Training
 * Description: Page template for DPDPA Compliance Training.
 *
 * @package Akaza_Adventure
 */

get_header();
get_template_part( 'template-parts/dpdpa-compliance-training' );
get_footer();

<?php
/**
 * Course archive — Akaza Adventure override.
 *
 * @package Akaza_Adventure
 */

defined( 'ABSPATH' ) || exit;

get_header( 'course' );
?>
<main id="main-content" class="slf-section slf-section--cream slf-lp-archive">
	<div class="slf-container">
		<header class="slf-page-hero">
			<p class="slf-eyebrow"><?php esc_html_e( 'By Courses', 'akaza-adventure' ); ?></p>
			<h1><?php echo esc_html( learn_press_page_title( false ) ?: __( 'Compliance & Security Courses', 'akaza-adventure' ) ); ?></h1>
			<p class="slf-lead"><?php esc_html_e( 'Browse engaging compliance and security awareness courses designed for measurable workplace outcomes.', 'akaza-adventure' ); ?></p>
		</header>

		<?php do_action( 'learn-press/before-main-content' ); ?>

		<div class="lp-content-area akaza-lp-content">
			<div class="lp-main-content">
				<?php do_action( 'learn-press/list-courses/layout' ); ?>
			</div>
		</div>

		<?php do_action( 'learn-press/after-main-content' ); ?>
	</div>
</main>
<?php
get_footer( 'course' );

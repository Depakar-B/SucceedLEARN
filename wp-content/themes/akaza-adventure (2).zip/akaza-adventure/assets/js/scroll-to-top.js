/**
 * Scroll-to-top — show after scroll, smooth return to top.
 */
(function () {
  'use strict';

  function removeLegacyScrollTop() {
    var legacy = document.getElementById('scrollTopBtn');
    if (!legacy) {
      return;
    }
    var next = legacy.nextElementSibling;
    if (next && next.tagName === 'STYLE') {
      next.parentNode.removeChild(next);
    }
    next = legacy.nextElementSibling;
    if (next && next.tagName === 'SCRIPT' && (next.textContent || '').indexOf('scrollTopBtn') !== -1) {
      next.parentNode.removeChild(next);
    }
    legacy.parentNode.removeChild(legacy);
  }

  // After the footer snippet's DOMContentLoaded handler so it does not throw.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', removeLegacyScrollTop);
  } else {
    removeLegacyScrollTop();
  }

  var wrap = document.getElementById('sl-scroll-top');
  if (!wrap) {
    return;
  }

  var btn = wrap.querySelector('.sl-scroll-top');
  var threshold = 200;
  var ticking = false;

  function update() {
    var y = window.scrollY || document.documentElement.scrollTop || 0;
    wrap.classList.toggle('is-visible', y > threshold);
    ticking = false;
  }

  function onScroll() {
    if (!ticking) {
      window.requestAnimationFrame(update);
      ticking = true;
    }
  }

  if (btn) {
    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  update();
})();

/**
 * DPDPA pricing calculator — live ₹250 × employees.
 */
(function () {
	"use strict";

	function formatInr(n) {
		var s = String(Math.round(n));
		if (s.length <= 3) {
			return s;
		}
		var last3 = s.slice(-3);
		var rest = s.slice(0, -3);
		return rest.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + last3;
	}

	function initCalc(root) {
		var rate = parseInt(root.getAttribute("data-rate"), 10) || 250;
		var emp = root.querySelector("#dpdpa-emp-count");
		var rng = root.querySelector("#dpdpa-emp-range");
		var totalEl = root.querySelector("[data-pricing-total]");
		var perEl = root.querySelector("[data-pricing-per]");

		if (!emp || !totalEl) {
			return;
		}

		function render() {
			var n = parseInt(emp.value, 10);
			if (isNaN(n) || n < 1) {
				n = 1;
			}
			totalEl.textContent = "₹" + formatInr(n * rate);
			if (perEl) {
				perEl.textContent = "₹" + rate + " per employee per year";
			}
		}

		emp.addEventListener("input", function () {
			var n = parseInt(emp.value, 10);
			if (rng && !isNaN(n) && n >= parseInt(rng.min, 10) && n <= parseInt(rng.max, 10)) {
				rng.value = String(n);
			}
			render();
		});

		if (rng) {
			rng.addEventListener("input", function () {
				emp.value = rng.value;
				render();
			});
		}

		render();
	}

	function boot() {
		document.querySelectorAll("[data-dpdpa-pricing]").forEach(initCalc);
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", boot);
	} else {
		boot();
	}
})();

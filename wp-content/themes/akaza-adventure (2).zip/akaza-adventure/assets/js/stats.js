document.addEventListener("DOMContentLoaded", function () {

    const counters = document.querySelectorAll(".counter");

    const observer = new IntersectionObserver((entries) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                const counter = entry.target;
                const target = parseInt(counter.dataset.target);
                const duration = 2000;
                const stepTime = Math.max(10, duration / target);

                let count = 0;

                const timer = setInterval(() => {

                    count += Math.ceil(target / 100);

                    if (count >= target) {
                        counter.textContent = target;
                        clearInterval(timer);
                    } else {
                        counter.textContent = count;
                    }

                }, stepTime);

                observer.unobserve(counter);

            }

        });

    }, {
        threshold: 0.5
    });


    counters.forEach(counter => observer.observe(counter));

});

<?php
/**
 * Global reusable FAQ section.
 *
 * Usage:
 * get_template_part( 'template-parts/global/faq', null, array( ... ) );
 *
 * Args:
 * - section_class (string)
 * - eyebrow (string)
 * - title (string)
 * - items (array of question/answer)
 * - schema (bool) default true — outputs FAQPage JSON-LD
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$args          = is_array( $args ?? null ) ? $args : array();
$section_class = isset( $args['section_class'] ) ? (string) $args['section_class'] : '';
$eyebrow       = isset( $args['eyebrow'] ) ? (string) $args['eyebrow'] : '';
$title         = isset( $args['title'] ) ? (string) $args['title'] : '';
$items         = isset( $args['items'] ) && is_array( $args['items'] ) ? $args['items'] : array();
$with_schema   = ! isset( $args['schema'] ) || (bool) $args['schema'];

if ( empty( $items ) ) {
	return;
}

$valid_items = array();
foreach ( $items as $item ) {
	$question = isset( $item['question'] ) ? trim( (string) $item['question'] ) : '';
	$answer   = isset( $item['answer'] ) ? trim( (string) $item['answer'] ) : '';

	if ( '' === $question || '' === $answer ) {
		continue;
	}

	$valid_items[] = array(
		'question' => $question,
		'answer'   => $answer,
	);
}

if ( empty( $valid_items ) ) {
	return;
}

$section_classes = trim( 'sl-faq-section ' . $section_class );

if ( $with_schema ) {
	$schema_entities = array();
	foreach ( $valid_items as $item ) {
		$schema_entities[] = array(
			'@type'          => 'Question',
			'name'           => $item['question'],
			'acceptedAnswer' => array(
				'@type' => 'Answer',
				'text'  => $item['answer'],
			),
		);
	}

	$schema = array(
		'@context'   => 'https://schema.org',
		'@type'      => 'FAQPage',
		'mainEntity' => $schema_entities,
	);
	?>
	<script type="application/ld+json"><?php echo wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); ?></script>
	<?php
}
?>
<section class="<?php echo esc_attr( $section_classes ); ?>" aria-labelledby="sl-faq-heading">
	<div class="container">
		<div class="sl-home-section-heading shead">
			<?php if ( '' !== $eyebrow ) : ?>
				<span class="sl-home-sub-heading eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
			<?php endif; ?>
			<?php if ( '' !== $title ) : ?>
				<h2 id="sl-faq-heading"><?php echo esc_html( $title ); ?></h2>
			<?php endif; ?>
		</div>

		<?php foreach ( $valid_items as $item ) : ?>
			<details class="faq">
				<summary><?php echo esc_html( $item['question'] ); ?></summary>
				<p><?php echo esc_html( $item['answer'] ); ?></p>
			</details>
		<?php endforeach; ?>
	</div>
</section>

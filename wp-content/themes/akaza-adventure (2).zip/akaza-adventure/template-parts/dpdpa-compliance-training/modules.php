<?php
/**
 * DPDPA Compliance Training — Modules section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-dpdpa-modules" aria-labelledby="dpdpa-modules-heading">
	<div class="container">
		<h2 id="dpdpa-modules-heading">Training Modules</h2>
		<!-- Add modules content here -->
	</div>
</section>

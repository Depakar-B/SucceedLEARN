<?php
/**
 * DPDPA Compliance Training — Spec / details table section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$trust_url = 'https://trust.succeedtech.com/';

$rows = array(
	array(
		'label' => 'Duration',
		'value' => '25 minutes, self-paced',
	),
	array(
		'label' => 'Level',
		'value' => 'Beginner and foundational awareness, designed for all employees',
	),
	array(
		'label' => 'Learning elements',
		'value' => 'Narrated lessons, click-to-reveal tiles, sorting and decision activities, scenario-based knowledge checks',
	),
	array(
		'label' => 'Assessment',
		'value' => '5 questions from a larger question bank, minimum 4 correct to pass',
	),
	array(
		'label' => 'Certificate',
		'value' => 'Issued automatically on successful completion',
	),
	array(
		'label' => 'Language',
		'value' => 'English. Hindi is in development and coming soon.',
	),
	array(
		'label' => 'Delivery',
		'value' => 'Our SaaS LMS, SCORM package for your LMS, or LTI',
	),
	array(
		'label' => 'Platform',
		'value' => 'Branded portal, SSO, HRIS integration, Android app, completion tracking, automated reminders',
	),
	array(
		'label' => 'Customisation',
		'value' => 'Up to 10 minutes of content free for the first 25 customers',
	),
	array(
		'label'   => 'Security',
		'value'   => 'ISO 27001:2022, SOC 2, GDPR-aligned.',
		'link'    => $trust_url,
		'link_label' => 'Trust Centre',
	),
);
?>
<section class="sl-dpdpa-spec" aria-labelledby="dpdpa-spec-heading">
	<div class="container">

		<div class="sl-home-section-heading">
			<span class="sl-home-sub-heading">The details</span>
			<h2 id="dpdpa-spec-heading">The details, for your procurement form</h2>
		</div>

		<div class="sl-dpdpa-spec__table-wrap">
			<table class="sl-dpdpa-spec__table">
				<tbody>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<th scope="row"><?php echo esc_html( $row['label'] ); ?></th>
							<td>
								<?php echo esc_html( $row['value'] ); ?>
								<?php if ( ! empty( $row['link'] ) && ! empty( $row['link_label'] ) ) : ?>
									<a href="<?php echo esc_url( $row['link'] ); ?>" target="_blank" rel="noopener noreferrer">
										<?php echo esc_html( $row['link_label'] ); ?>
									</a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

	</div>
</section>

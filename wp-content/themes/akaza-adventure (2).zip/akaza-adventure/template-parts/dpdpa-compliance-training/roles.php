<?php
/**
 * DPDPA Compliance Training — Decision makers / roles section (outcomes UI).
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-home-outcomes-section sl-home-outcomes-section--white" aria-labelledby="dpdpa-roles-heading">

	<div class="container">

		<div class="sl-home-section-heading">

			<span class="sl-home-sub-heading">
				If you are the one who has to answer for this
			</span>

			<h2 id="dpdpa-roles-heading">
				Who signs off, and what they are really asking
			</h2>

		</div>

		<div class="row g-4">

			<div class="col-lg-4">
				<div class="sl-home-outcome-card">
					<h3>Data Protection Officer</h3>
					<p class="sl-home-outcome-quote">
						&quot;If the Board or a regulator asks what training we have actually done, what do I show them?&quot;
					</p>
					<p>
						A completion record, an assessment score and a certificate for every employee, timestamped and exportable. Not a slide deck saying training &quot;took place.&quot;
					</p>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="sl-home-outcome-card">
					<h3>CISO / CIO</h3>
					<p class="sl-home-outcome-quote">
						&quot;We already run DLP, email security and access controls. Why did this still happen?&quot;
					</p>
					<p>
						Because most incidents in this category start with a person, not a system. This is the layer your tooling cannot reach, and it does not add another dashboard to your stack to babysit.
					</p>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="sl-home-outcome-card">
					<h3>Head of HR</h3>
					<p class="sl-home-outcome-quote">
						&quot;I am the one who has to actually roll this out to thousands of people who have never heard of the DPDPA.&quot;
					</p>
					<p>
						25 minutes, SSO and HRIS integration, automated reminders, and a dashboard that tells you exactly who has and has not finished. Live in weeks, not a quarter.
					</p>
				</div>
			</div>

		</div>

	</div>

</section>

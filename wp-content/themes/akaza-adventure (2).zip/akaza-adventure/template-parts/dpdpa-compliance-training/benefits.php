<?php
/**
 * DPDPA Compliance Training — Benefits section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-dpdpa-benefits" aria-labelledby="dpdpa-benefits-heading">
	<div class="container">
		<h2 id="dpdpa-benefits-heading">Key Benefits</h2>
		<!-- Add benefits content here -->
	</div>
</section>

<?php
/**
 * DPDPA Compliance Training — Overview section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-dpdpa-overview" aria-labelledby="dpdpa-overview-heading">
	<div class="container">
		<h2 id="dpdpa-overview-heading">Overview</h2>
		<!-- Add overview content here -->
	</div>
</section>

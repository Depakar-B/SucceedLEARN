<?php
/**
 * DPDPA Compliance Training — Why now section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$timeline = array(
	array(
		'label'   => 'NOW',
		'text'    => 'Roughly nine months of runway. Enough to roll out properly rather than scramble.',
		'current' => true,
	),
	array(
		'label'   => '3 TO 6 MONTHS',
		'text'    => 'Typical time for procurement, integration and full workforce completion.',
		'current' => false,
	),
	array(
		'label'   => '13 MAY 2027',
		'text'    => 'Full compliance obligations take effect: consent, notice, Data Principal rights.',
		'current' => false,
	),
);
?>
<section class="sl-dpdpa-why-now" aria-labelledby="dpdpa-why-now-heading">
	<div class="container">
		<div class="sl-dpdpa-why-now__panel">
			<span class="sl-home-sub-heading">Why this quarter, not next year</span>
			<h2 id="dpdpa-why-now-heading">The deadline is May 2027. The decision is now</h2>
			<p>
				Rolling out training across a workforce is not a one-week task. Procurement, LMS integration, completion across every employee and the evidence trail behind it typically run three to six months. Working backwards from May 2027, that puts the decision in this quarter or the next. Not because a vendor says so, but because the calendar does.
			</p>

			<div class="sl-dpdpa-why-now__timeline" role="list">
				<?php foreach ( $timeline as $item ) : ?>
					<div class="sl-dpdpa-why-now__item<?php echo ! empty( $item['current'] ) ? ' is-now' : ''; ?>" role="listitem">
						<span class="sl-dpdpa-why-now__label"><?php echo esc_html( $item['label'] ); ?></span>
						<p><?php echo esc_html( $item['text'] ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>

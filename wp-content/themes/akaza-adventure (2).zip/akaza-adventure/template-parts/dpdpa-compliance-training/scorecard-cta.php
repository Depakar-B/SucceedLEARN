<?php
/**
 * DPDPA Compliance Training — Readiness Scorecard CTA.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-dpdpa-scorecard-cta" aria-labelledby="dpdpa-scorecard-heading">
	<div class="container">
		<div class="sl-dpdpa-scorecard-cta__card">

			<div class="sl-dpdpa-scorecard-cta__content">
				<span class="sl-home-sub-heading">Not ready to book a call yet?</span>
				<h2 id="dpdpa-scorecard-heading">Find your gaps in four minutes</h2>
				<p>
					Four minutes, fifteen questions, a scored result you can forward to whoever else needs to sign off.
				</p>
				<a href="#contact" class="sl-dpdpa-scorecard-cta__btn">
					Take the Readiness Scorecard
				</a>
			</div>

			<div class="sl-dpdpa-scorecard-cta__media">
				<img
					src="<?php echo esc_url( home_url( '/wp-content/uploads/2026/07/Get-Your-Personalized.webp' ) ); ?>"
					alt=""
					width="480"
					height="360"
					loading="lazy"
					decoding="async"
				>
			</div>

		</div>
	</div>
</section>

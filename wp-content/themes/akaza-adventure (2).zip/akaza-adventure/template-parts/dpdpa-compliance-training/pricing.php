<?php
/**
 * DPDPA Compliance Training — Pricing calculator section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$rate           = 250;
$default_emps   = 50;
$default_total  = $rate * $default_emps;
?>
<section id="pricing" class="sl-dpdpa-pricing" aria-labelledby="dpdpa-pricing-heading">
	<div class="container">
		<div class="sl-dpdpa-pricing__calc" data-dpdpa-pricing data-rate="<?php echo esc_attr( (string) $rate ); ?>">

			<div class="sl-dpdpa-pricing__copy">
				<span class="sl-home-sub-heading">Pricing</span>
				<h2 id="dpdpa-pricing-heading">Know the price before you call</h2>
				<p>
					Most compliance vendors make you book a call to find out the price. We would rather you know now. Compliance consultancies typically quote lakhs for an engagement. This is employee training, priced per head, per year.
				</p>
				<p class="sl-dpdpa-pricing__highlight">
					<strong>Free customisation of up to 10 minutes of content for our first 25 customers.</strong>
				</p>
			</div>

			<div class="sl-dpdpa-pricing__panel">
				<label class="sl-dpdpa-pricing__label" for="dpdpa-emp-count">How many employees?</label>

				<input
					type="number"
					id="dpdpa-emp-count"
					class="sl-dpdpa-pricing__number"
					value="<?php echo esc_attr( (string) $default_emps ); ?>"
					min="1"
					max="100000"
					step="50"
					inputmode="numeric"
					aria-describedby="dpdpa-pricing-out"
				>

				<input
					type="range"
					id="dpdpa-emp-range"
					class="sl-dpdpa-pricing__range"
					value="<?php echo esc_attr( (string) $default_emps ); ?>"
					min="50"
					max="10000"
					step="50"
					aria-label="<?php esc_attr_e( 'Adjust employee count', 'akaza-adventure' ); ?>"
				>

				<div class="sl-dpdpa-pricing__out" id="dpdpa-pricing-out" aria-live="polite">
					<span class="sl-dpdpa-pricing__total" data-pricing-total>₹<?php echo esc_html( number_format_i18n( $default_total ) ); ?></span>
					<span class="sl-dpdpa-pricing__lbl">per year, for your whole workforce</span>
					<span class="sl-dpdpa-pricing__per" data-pricing-per>₹<?php echo esc_html( (string) $rate ); ?> per employee per year</span>
				</div>

				<p class="sl-dpdpa-pricing__foot">
					Indicative list pricing. Volume rates apply above 1,000 employees. Bundle pricing available with our POSH programmes.
				</p>

				<a href="#contact" class="sl-dpdpa-pricing__btn">Get an exact quote</a>
			</div>

		</div>
	</div>
</section>

<?php
/**
 * DPDPA Compliance Training — CTA section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-dpdpa-cta" aria-labelledby="dpdpa-cta-heading">
	<div class="container">
		<h2 id="dpdpa-cta-heading">Get Started</h2>
		<!-- Add call-to-action content here -->
	</div>
</section>

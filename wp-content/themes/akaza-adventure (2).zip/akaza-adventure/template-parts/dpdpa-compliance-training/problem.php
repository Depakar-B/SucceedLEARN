<?php
/**
 * DPDPA Compliance Training — Problem section (outcomes UI).
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="sl-home-outcomes-section" aria-labelledby="dpdpa-problem-heading">

	<div class="container">

		<div class="sl-home-section-heading">

			<span class="sl-home-sub-heading">
				The problem
			</span>

			<h2 id="dpdpa-problem-heading">
				Your systems are secure. Your Tuesday afternoon is not
			</h2>

			<p class="sl-home-outcomes-intro">
				Most personal data incidents do not begin with an attacker. They begin with someone doing ordinary work: a wrongly addressed email, an exposed file link, an export kept &quot;just in case&quot;, a printout left on a desk, access given to the wrong person.
			</p>

		</div>

		<div class="row g-4">

			<div class="col-lg-4">
				<div class="sl-home-outcome-card">
					<h3>Regulatory</h3>
					<p>
						Scrutiny and directions from the Data Protection Board of India, with financial penalties of up to ₹250 crore for certain violations such as failing to take reasonable security safeguards.
					</p>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="sl-home-outcome-card">
					<h3>Commercial</h3>
					<p>
						Customer complaints, contractual issues and business disruption, plus reputational damage and loss of stakeholder confidence.
					</p>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="sl-home-outcome-card">
					<h3>Internal</h3>
					<p>
						Disciplinary action for employees, up to termination, where personal data is handled carelessly or outside approved processes.
					</p>
				</div>
			</div>

		</div>

		<div class="sl-home-outcome-footer">
			<h4>
				Technical controls cannot stop a manager forwarding a salary sheet to the wrong Rahul.
			</h4>
			<p>
				That is a training problem, and it is the one this course solves.
			</p>
		</div>

	</div>

</section>

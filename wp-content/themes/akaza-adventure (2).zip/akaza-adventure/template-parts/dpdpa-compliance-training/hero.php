<?php
/**
 * DPDPA Compliance Training — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="dpdpa-hero">

    <div class="dpdpa-container">

        <div class="dpdpa-hero__wrapper">

            <!-- ==========================================
                 LEFT CONTENT
            =========================================== -->

            <div class="dpdpa-hero__content">

                <!-- Eyebrow -->

                <div class="dpdpa-hero__eyebrow">

                    <span class="dpdpa-hero__eyebrow-line"></span>

                    <span class="dpdpa-hero__eyebrow-text">

					DPDPA compliance training for employees

                    </span>

                </div>

                <!-- Heading -->

                <h1 class="dpdpa-hero__title">

				DPDPA Employee Training: stop
                    

                    breaches before they start

                </h1>

                <!-- Description -->

                <p class="dpdpa-hero__description">

				25-minute training built to stop the everyday employee mistakes that trigger reportable breaches.

                </p>

                <!-- Feature Chips -->

                <div class="dpdpa-hero__features">

                    <div class="dpdpa-feature">

                        <span class="dpdpa-feature__icon">✓</span>

                        <span class="dpdpa-feature__text">

						25 minutes

                        </span>

                    </div>

                    <div class="dpdpa-feature">

                        <span class="dpdpa-feature__icon">✓</span>

                        <span class="dpdpa-feature__text">

						Assessed and certified

                        </span>

                    </div>

                    <div class="dpdpa-feature">

                        <span class="dpdpa-feature__icon">✓</span>

                        <span class="dpdpa-feature__text">

						English now, Hindi coming soon

                        </span>

                    </div>

                    <div class="dpdpa-feature">

                        <span class="dpdpa-feature__icon">✓</span>

                        <span class="dpdpa-feature__text">

						SCORM, LTI or our LMS

                        </span>

                    </div>

                   
                </div>

                <!-- CTA -->

                <div class="dpdpa-hero__actions">

                    <a href="#contact"
                       class="dpdpa-btn dpdpa-btn--primary">

                        Book Free Demo

                    </a>

                    <a href="#pricing"
                       class="dpdpa-btn dpdpa-btn--secondary">

                        Take the Readliness Scorecard

                    </a>

                </div>

               
				<div class="dpdpa-hero__trust">
					<p>
						No obligation. Most demos take 20 minutes.
						Or <a href="#check-pricing" onclick="event.preventDefault();document.getElementById('check-pricing').scrollIntoView({ behavior: 'smooth' });" style="cursor:pointer; text-decoration:underline; color:#F35A2B; font-weight:700;">see what it costs first</a>.
					</p>

</div>

            </div>

            <!-- ==========================================
                 RIGHT SIDE
            =========================================== -->

            <div class="dpdpa-hero__visual">

                <div class="dpdpa-illustration">

                    <!--
                        Dashboard Illustration

                        (Next Part)

                        We'll build

                        Browser Window

                        Email Client

                        Warning Banner

                        Attachment

                        Statistics

                        Modern Dashboard

                    -->

                    <div class="dpdpa-dashboard">
                        <div class="dpdpa-dashboard__header">
                            <div class="dpdpa-dashboard__dots">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                            <div class="dpdpa-dashboard__title">
                                Incident Preview
                            </div>
                        </div>

                        <div class="dpdpa-dashboard__body">
                            <div class="dpdpa-email-card">
                                <div class="dpdpa-email-card__header">
                                    <small>To</small>
                                    <div class="dpdpa-email-users">
                                        <span>Finance Team</span>
                                        <span>Operations</span>
                                        <span class="danger">+214 Recipients</span>
                                    </div>
                                </div>

                                <div class="dpdpa-email-subject">
                                    <strong>Updated customer list, July</strong>
                                </div>

                                <p class="dpdpa-email-message">
                                    Sharing the latest customer file for review before distribution. Please validate and acknowledge.
                                </p>

                                <div class="dpdpa-attachment">
                                    <div class="dpdpa-attachment__icon">XLS</div>
                                    <div class="dpdpa-attachment__content">
                                        <strong>customer_master_july.xlsx</strong>
                                        <span>1,204 personal data records</span>
                                    </div>
                                </div>

                                <div class="dpdpa-email-footer">
                                    <button type="button">Send</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <p class="dpdpa-hero__caption">
                        Not a hacker. One click, one wrong recipient, and 1,204 people's data is exposed. It's one of many everyday moments the course trains employees to catch, alongside consent, safe data handling and breach reporting.
                    </p>

                </div>

            </div>

        </div>

    </div>

</section>

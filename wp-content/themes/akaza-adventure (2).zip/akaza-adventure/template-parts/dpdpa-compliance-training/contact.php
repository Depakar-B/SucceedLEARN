<?php
/**
 * DPDPA Compliance Training — Demo / contact section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$scorecard_url = '#contact'; // Temporary: later redirect to readiness scorecard.
?>
<section id="contact" class="sl-home-contact-section sl-dpdpa-contact-section" aria-labelledby="contact-heading">

	<div class="container">

		<div class="row align-items-start gy-5">

			<div class="col-lg-6">

				<div class="sl-home-contact-content sl-dpdpa-contact-content">

					<span class="sl-home-sub-heading">
						Book a free demo
					</span>

					<h2 id="contact-heading">
						See it before you decide
					</h2>

					<p>
						Twenty minutes, no obligation. We will walk you through the actual course, show you the admin dashboard and completion reporting, and give you an exact quote for your headcount.
					</p>

					<div class="sl-dpdpa-contact-note">
						<strong>Already run POSH training with us?</strong>
						Mention it and we will show you bundle pricing on the same call.
					</div>

					<p class="sl-dpdpa-contact-scorecard">
						Prefer a quick self-check first?
						<a href="<?php echo esc_url( $scorecard_url ); ?>">Take the four-minute Readiness Scorecard</a>
						instead.
					</p>

					<p class="sl-dpdpa-contact-alt">
						Prefer to email?
						<a href="mailto:sales@succeedtech.com">sales@succeedtech.com</a><br>
						Or call <a href="tel:+916362021778">+91 63620 21778</a>
					</p>

				</div>

			</div>

			<div class="col-lg-6">

				<div class="sl-home-form-wrapper">
					<?php
					/**
					 * Temporary: reuse existing contact form shortcode.
					 * Replace with DPDPA-specific form later if needed.
					 */
					echo do_shortcode( '[contact_form]' );
					?>
				</div>

			</div>

		</div>

	</div>

</section>

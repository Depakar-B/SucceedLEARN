<?php
/**
 * DPDPA Compliance Training — Inside the course section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$themes = array(
	array(
		'title' => 'Recognise personal data',
		'text'  => 'Spot what counts as personal data, directly or indirectly, before it gets mishandled.',
	),
	array(
		'title' => 'Get consent right',
		'text'  => 'What makes consent valid, and the situations where it is not even required.',
	),
	array(
		'title' => 'Handle data end to end',
		'text'  => 'Collect, store, share, retain and delete personal data the way the DPDPA expects.',
	),
	array(
		'title' => 'Route a rights request',
		'text'  => 'Recognise a Data Principal request and send it to the right process, not answer it informally.',
	),
	array(
		'title' => 'Report a breach immediately',
		'text'  => 'Know what counts as a breach and act in the first minutes, not after checking with five people.',
	),
	array(
		'title' => 'Pass a real assessment',
		'text'  => '5 questions, 4 correct required, certificate issued automatically on completion.',
	),
);

$modules = array(
	array( 'n' => '01', 'title' => 'Introduction and Objectives', 'text' => 'Why DPDPA training matters in everyday work.' ),
	array( 'n' => '02', 'title' => 'Why Data Protection Matters', 'text' => 'The real-world impact of poor data handling.' ),
	array( 'n' => '03', 'title' => 'What is the DPDPA?', 'text' => 'Overview of the law and consequences of non-compliance.' ),
	array( 'n' => '04', 'title' => 'Key DPDPA Terms', 'text' => 'Personal Data, Data Principal, Data Fiduciary, Data Processor.' ),
	array( 'n' => '05', 'title' => 'Scope of the DPDPA', 'text' => 'What data and which organisations are covered.' ),
	array( 'n' => '06', 'title' => 'Lawful Grounds for Processing', 'text' => 'Valid consent and the legitimate uses that do not require it.' ),
	array( 'n' => '07', 'title' => 'Privacy by Design', 'text' => 'Building privacy into everyday decisions and processes.' ),
	array( 'n' => '08', 'title' => 'Handling Data Across Its Lifecycle', 'text' => 'Collection, classification, storage, sharing, retention, deletion.' ),
	array( 'n' => '09', 'title' => 'Data Principal Rights and Requests', 'text' => 'Consent withdrawal, access, correction, erasure, grievance redressal.' ),
	array( 'n' => '10', 'title' => 'Grievances and Escalation', 'text' => 'Recognising and routing privacy concerns correctly.' ),
	array( 'n' => '11', 'title' => 'Breach Awareness and Reporting', 'text' => 'What counts as a breach and how to report it without delay.' ),
	array( 'n' => '12', 'title' => 'Your Responsibilities', 'text' => 'Practical dos and don\'ts for everyday data handling.' ),
	array( 'n' => '13', 'title' => 'Final Assessment and Certificate', 'text' => '5 randomised questions, minimum 4 correct to pass.' ),
);

$stages = array(
	array( 'n' => '01', 'title' => 'Collect', 'text' => 'Only what is necessary, through approved forms.' ),
	array( 'n' => '02', 'title' => 'Classify', 'text' => 'Recognise personal data and apply the right care.' ),
	array( 'n' => '03', 'title' => 'Store', 'text' => 'Approved systems, not local or personal copies.' ),
	array( 'n' => '04', 'title' => 'Share', 'text' => 'Need-to-know, right purpose, approved channel.' ),
	array( 'n' => '05', 'title' => 'Retain', 'text' => 'Only as long as needed, never "just in case".' ),
	array( 'n' => '06', 'title' => 'Delete', 'text' => 'Through approved disposal methods.' ),
);
?>
<section class="sl-dpdpa-course" aria-labelledby="dpdpa-course-heading">
	<div class="container">

		<div class="sl-home-section-heading">
			<span class="sl-home-sub-heading">Inside the course</span>
			<h2 id="dpdpa-course-heading">What your people will do differently</h2>
			<p class="sl-dpdpa-course__intro">
				Narrated lessons, click-to-reveal terms, sorting activities and scenario-based knowledge checks. Beginner level, built for people with no legal background.
			</p>
		</div>

		<div class="sl-dpdpa-course__themes">
			<?php foreach ( $themes as $theme ) : ?>
				<article class="sl-dpdpa-course__theme-card">
					<span class="sl-dpdpa-course__check" aria-hidden="true">✓</span>
					<div>
						<h3><?php echo esc_html( $theme['title'] ); ?></h3>
						<p><?php echo esc_html( $theme['text'] ); ?></p>
					</div>
				</article>
			<?php endforeach; ?>
		</div>

		<details class="sl-dpdpa-course__curriculum">
			<summary>
				<span class="sl-dpdpa-course__curriculum-title">Full course curriculum</span>
				<span class="sl-dpdpa-course__curriculum-toggle">
					<span class="is-closed">View all 13 modules</span>
					<span class="is-open">Hide module list</span>
				</span>
			</summary>

			<div class="sl-dpdpa-course__modules">
				<?php foreach ( $modules as $module ) : ?>
					<div class="sl-dpdpa-course__module">
						<span class="sl-dpdpa-course__module-n"><?php echo esc_html( $module['n'] ); ?></span>
						<div>
							<h4><?php echo esc_html( $module['title'] ); ?></h4>
							<p><?php echo esc_html( $module['text'] ); ?></p>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</details>

		<div class="sl-dpdpa-course__stages-wrap">
			<h3 class="sl-dpdpa-course__stages-heading">The six stages we train on</h3>
			<ol class="sl-dpdpa-course__stages">
				<?php foreach ( $stages as $stage ) : ?>
					<li class="sl-dpdpa-course__stage">
						<div class="sl-dpdpa-course__stage-marker">
							<span class="sl-dpdpa-course__stage-n"><?php echo esc_html( $stage['n'] ); ?></span>
						</div>
						<strong class="sl-dpdpa-course__stage-title"><?php echo esc_html( $stage['title'] ); ?></strong>
						<p><?php echo esc_html( $stage['text'] ); ?></p>
					</li>
				<?php endforeach; ?>
			</ol>
		</div>

	</div>
</section>

<?php
/**
 * Homepage — Testimonials section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$quotes = array(
	array(
		'quote' => 'The learning portal in Minda branding and integrated with our HRIS portal has made learner access seamless. I have recommended eLearnPOSH to my professional contacts.',
		'name'  => 'Mr. Sachchidanand Pande',
		'role'  => 'Group PR Head, UNO Minda Group',
	),
	array(
		'quote' => 'Succeed helped us make sure all of our workforce were trained and awareness was spread so effectively within a very short time. Your response to every email sent out by our employees was super quick and solution-oriented.',
		'name'  => 'Mr. Girisha Krishnappa',
		'role'  => 'People and Culture, AirAsia',
	),
	array(
		'quote' => 'An easy to use interface. The clarity and simplicity helps to navigate easily. The technical team is equally very good, their responses on queries are very prompt and they provide timely solutions.',
		'name'  => 'Ms. Gayatri Mishra',
		'role'  => 'L&D Specialist, Tata Smartfoodz Ltd',
	),
);
?>
<section class="sl-dpdpa-testimonials sl-home-testimonials" aria-labelledby="home-testimonials-heading">
	<div class="container">

		<div class="sl-home-section-heading">
			<span class="sl-home-sub-heading">What clients say</span>
			<h2 id="home-testimonials-heading">From teams who rolled it out</h2>
			<p class="sl-dpdpa-testimonials__intro">
				Organisations use SucceedLEARN to roll out compliance training that people complete — and remember.
			</p>
		</div>

		<div class="sl-dpdpa-testimonials__grid">
			<?php foreach ( $quotes as $item ) : ?>
				<figure class="sl-dpdpa-testimonials__card">
					<blockquote>
						<p>&ldquo;<?php echo esc_html( $item['quote'] ); ?>&rdquo;</p>
					</blockquote>
					<figcaption>
						<strong><?php echo esc_html( $item['name'] ); ?></strong>
						<span><?php echo esc_html( $item['role'] ); ?></span>
					</figcaption>
				</figure>
			<?php endforeach; ?>
		</div>

	</div>
</section>

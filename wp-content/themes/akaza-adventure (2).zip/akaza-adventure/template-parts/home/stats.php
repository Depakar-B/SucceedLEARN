<section class="stats-section">
    <div class="container">

        <div class="row">

            <div class="col-6 col-lg-3 stat-item">
                <h2 class="counter" data-target="1000">0</h2><span>+</span>
                <p>Organisations Trained</p>
            </div>

            <div class="col-6 col-lg-3 stat-item">
                <h2 class="counter" data-target="90">0</h2><span>%+</span>
                <p>Learner Engagement</p>
            </div>

            <div class="col-6 col-lg-3 stat-item">
                <h2 class="counter" data-target="70">0</h2><span>%</span>
                <p>Reduction in Phishing Risk</p>
            </div>

            <div class="col-6 col-lg-3 stat-item">
                <h2 class="counter" data-target="90">0</h2><span>%</span>
                <p>Compliance Reduced</p>
            </div>

        </div>

    </div>
</section>
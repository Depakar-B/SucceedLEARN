<?php
/**
 * Homepage — Platform / How SucceedLEARN Helps section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cards = array(
	array(
		'icon'  => content_url( '/uploads/2026/08/Security.svg' ),
		'title' => 'Security Awareness Training',
		'text'  => 'Reduce human cyber risk through phishing simulations, microlearning, gamified learning and analytics.',
	),
	array(
		'icon'  => content_url( '/uploads/2026/08/HR-Complaince.svg' ),
		'title' => 'HR Compliance Training',
		'text'  => 'Create respectful workplaces through workplace conduct, anti-harassment, ethics and compliance learning.',
	),
	array(
		'icon'  => content_url( '/uploads/2026/08/Financial.svg' ),
		'title' => 'Financial Crime Prevention',
		'text'  => 'Support AML, anti-bribery, anti-corruption and fraud awareness initiatives.',
	),
	array(
		'icon'  => content_url( '/uploads/2026/08/Workplace.svg' ),
		'title' => 'Workplace Health & Safety',
		'text'  => 'Help employees identify risks and contribute to safer workplaces.',
	),
	array(
		'icon'  => content_url( '/uploads/2026/08/SucceedLEARN-Code-of-conduct.svg' ),
		'title' => 'Code of Conduct Training',
		'text'  => 'Turn policies into practical workplace decisions through scenario-based learning.',
	),
	array(
		'icon'  => content_url( '/uploads/2026/08/Private-Equity.svg' ),
		'title' => 'Private Equity & VC Compliance',
		'text'  => 'Help organisations remain investor-ready through targeted compliance programmes.',
	),
	array(
		'icon'  => content_url( '/uploads/2026/08/Compliance-LMS.svg' ),
		'title' => 'Compliance LMS',
		'text'  => 'A compliance-focused LMS with automation, reporting, branding and enterprise integrations.',
	),
);
?>
<section id="solutions" class="sl-home-platform-section" aria-labelledby="platform-heading">

    <div class="container">

        <div class="sl-home-platform-heading">

            <span class="sl-home-sub-heading">
                How SucceedLEARN Helps
            </span>

            <h2 id="platform-heading">
                One platform for security,
                compliance &amp; workplace learning
            </h2>

            <p>
                Bring training and compliance together through one intelligent,
                scalable eLearning platform.
            </p>

        </div>

        <div class="row g-4">

            <?php foreach ( $cards as $card ) : ?>
                <div class="col-md-6 col-lg-3">
                    <div class="sl-home-platform-card">
                        <img src="<?php echo esc_url( $card['icon'] ); ?>" alt="" width="32" height="32" loading="lazy" decoding="async">
                        <h3><?php echo esc_html( $card['title'] ); ?></h3>
                        <p><?php echo esc_html( $card['text'] ); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="col-md-6 col-lg-3">
                <div class="sl-home-platform-card sl-home-cta-card">
                    <h3>See the full solution set</h3>
                    <a href="<?php echo esc_url( akaza_page_url( 'solutions' ) ); ?>" class="btn sl-home-btn">
                        Explore All Solutions →
                    </a>
                </div>
            </div>

        </div>

    </div>

</section>

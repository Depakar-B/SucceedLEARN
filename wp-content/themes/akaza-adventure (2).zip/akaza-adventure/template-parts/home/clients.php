<?php
/**
 * Homepage — Clients / trusted-by logo carousel.
 *
 * Left intro stays static; right side scrolls as a dual-row marquee (both rows right → left).
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$uploads = '/wp-content/uploads/2026/03/';

$row_one = array(
	'Autoliv.webp'              => 'Autoliv',
	'Shipbob.webp'              => 'Shipbob',
	'Sharechat.webp'            => 'Sharechat',
	'Saint-Gobin.webp'          => 'Saint Gobain',
	'Royal-Enfield.webp'        => 'Royal Enfield',
	'Redchilies.webp'           => 'Redchilies',
	'RazorPay.webp'             => 'RazorPay',
	'PowerGrid.webp'            => 'PowerGrid',
	'Phillips-Machine-Tool.webp' => 'Phillips Machine Tool',
	'Ocrolus.webp'              => 'Ocrolus',
	'NXP.webp'                  => 'NXP',
	'Nippon-Express-1.webp'     => 'Nippon Express',
	'MSC-1.webp'                => 'MSC',
	'Lupin-1.webp'              => 'Lupin',
	'Lenova-1.webp'             => 'Lenovo',
	'TATA.webp'                 => 'TATA',
);

$row_two = array(
	'LatentView-1.webp'            => 'LatentView',
	'Landmark-Group-1.webp'        => 'Landmark Group',
	'Inspira-1.webp'               => 'Inspira',
	'GE-Appliances-1.webp'         => 'GE Appliances',
	'Experion-Technologies-1.webp' => 'Experion Technologies',
	'DHL-1.webp'                   => 'DHL',
	'Cred.webp'                    => 'Cred',
	'Chargebee.webp'               => 'Chargebee',
	'Aggreko.webp'                 => 'Aggreko',
	'Abakkus-1.webp'               => 'Abakkus',
	'Broll.webp'                   => 'Broll',
	'Berkidea.webp'                => 'Berkidea',
	'Arcil.webp'                   => 'Arcil',
	'AirIndia.webp'                => 'Air India',
	'AirAsia.webp'                 => 'AirAsia',
	'Tresvista.webp'               => 'Tresvista',
	'Titan.webp'                   => 'Titan',
	'The-Economist.webp'           => 'The Economist',
	'TCS.webp'                     => 'TCS',
);

/**
 * Render one logo list (JS duplicates the set for a seamless loop).
 *
 * @param array  $clients Filename => label map.
 * @param string $row_id  Accessible label id suffix.
 * @param string $uploads Uploads path prefix.
 */
$render_row = static function ( $clients, $row_id, $uploads ) {
	?>
	<ul class="slf-clients__logos" data-clients-set="<?php echo esc_attr( $row_id ); ?>">
		<?php foreach ( $clients as $file => $name ) : ?>
			<li class="slf-clients__logo">
				<img
					src="<?php echo esc_url( home_url( $uploads . $file ) ); ?>"
					alt="<?php echo esc_attr( $name ); ?>"
					width="220"
					height="96"
					loading="eager"
					decoding="async"
				>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php
};
?>
<section class="slf-clients" aria-labelledby="clients-heading" data-clients-carousel>
	<div class="slf-clients__layout">
		<div class="slf-clients__intro">
			<h2 id="clients-heading" class="slf-clients__title">
				Trusted by Leading <span>60+</span> Organisations
			</h2>
			<p class="slf-clients__sub">Building safer, compliant, and resilient workplaces worldwide.</p>
		</div>

		<div class="slf-clients__carousel" role="region" aria-label="<?php esc_attr_e( 'Client logos', 'akaza-adventure' ); ?>">
			<div class="slf-clients__row" data-clients-row data-direction="left">
				<div class="slf-clients__track" data-clients-track>
					<?php $render_row( $row_one, 'one', $uploads ); ?>
				</div>
			</div>
			<div class="slf-clients__row" data-clients-row data-direction="left">
				<div class="slf-clients__track" data-clients-track>
					<?php $render_row( $row_two, 'two', $uploads ); ?>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
/**
 * GDPR Employee Awareness Training — Hero section.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="dpdpa-hero">

	<div class="dpdpa-container">

		<div class="dpdpa-hero__wrapper">

			<div class="dpdpa-hero__content">

				<div class="dpdpa-hero__eyebrow">
					<span class="dpdpa-hero__eyebrow-line"></span>
					<span class="dpdpa-hero__eyebrow-text">
						GDPR Employee Awareness Training
					</span>
				</div>

				<h1 class="dpdpa-hero__title">
					GDPR Employee Training: stop breaches before they start
				</h1>

				<p class="dpdpa-hero__description">
					25-minute training built to stop the everyday employee mistakes that trigger reportable personal data breaches under the GDPR.
				</p>

				<div class="dpdpa-hero__features">
					<div class="dpdpa-feature">
						<span class="dpdpa-feature__icon">✓</span>
						<span class="dpdpa-feature__text">25 minutes</span>
					</div>
					<div class="dpdpa-feature">
						<span class="dpdpa-feature__icon">✓</span>
						<span class="dpdpa-feature__text">Assessed and certified</span>
					</div>
					<div class="dpdpa-feature">
						<span class="dpdpa-feature__icon">✓</span>
						<span class="dpdpa-feature__text">English available</span>
					</div>
					<div class="dpdpa-feature">
						<span class="dpdpa-feature__icon">✓</span>
						<span class="dpdpa-feature__text">SCORM, LTI or our LMS</span>
					</div>
				</div>

				<div class="dpdpa-hero__actions">
					<a href="#contact" class="dpdpa-btn dpdpa-btn--primary">
						Book Free Demo
					</a>
					<a href="#pricing" class="dpdpa-btn dpdpa-btn--secondary">
						View Pricing
					</a>
				</div>

				<div class="dpdpa-hero__trust">
					<p>
						No obligation. Most demos take 20 minutes.
						Or <a href="#pricing">see what it costs first</a>.
					</p>
				</div>

			</div>

			<div class="dpdpa-hero__visual">
				<div class="dpdpa-illustration">

					<div class="dpdpa-dashboard">
						<div class="dpdpa-dashboard__header">
							<div class="dpdpa-dashboard__dots">
								<span></span>
								<span></span>
								<span></span>
							</div>
							<div class="dpdpa-dashboard__title">
								Incident Preview
							</div>
						</div>

						<div class="dpdpa-dashboard__body">
							<div class="dpdpa-email-card">
								<div class="dpdpa-email-card__header">
									<small>To</small>
									<div class="dpdpa-email-users">
										<span>Finance Team</span>
										<span>Operations</span>
										<span class="danger">+214 Recipients</span>
									</div>
								</div>

								<div class="dpdpa-email-subject">
									<strong>Updated customer list, July</strong>
								</div>

								<p class="dpdpa-email-message">
									Sharing the latest customer file for review before distribution. Please validate and acknowledge.
								</p>

								<div class="dpdpa-attachment">
									<div class="dpdpa-attachment__icon">XLS</div>
									<div class="dpdpa-attachment__content">
										<strong>customer_master_july.xlsx</strong>
										<span>1,204 personal data records</span>
									</div>
								</div>

								<div class="dpdpa-email-footer">
									<button type="button">Send</button>
								</div>
							</div>
						</div>
					</div>

					<p class="dpdpa-hero__caption">
						Not a hacker. One click, one wrong recipient, and 1,204 people's data is exposed. It's one of many everyday moments the course trains employees to catch, alongside consent, lawful processing and breach reporting.
					</p>

				</div>
			</div>

		</div>

	</div>

</section>

<?php
/**
 * DPDPA Compliance Training page content wrapper.
 *
 * @package Akaza_Adventure
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dpdpa_faq_items = array(
	array(
		'question' => 'What is the DPDPA?',
		'answer'   => 'The Digital Personal Data Protection Act, 2023 is India\'s data protection law for digital personal data. It governs how organisations collect, use, store, share, protect, retain and delete personal data, gives individuals rights over their data, and places accountability on organisations that decide the purpose and means of processing.',
	),
	array(
		'question' => 'Why is DPDPA awareness training important for an organisation?',
		'answer'   => 'It helps employees handle personal data lawfully and securely, reducing the risk of human error, unsafe sharing, unclear consent practices, weak escalation and breaches. It also helps organisations demonstrate that privacy is part of their compliance culture.',
	),
	array(
		'question' => 'Does the DPDPA apply to employee data?',
		'answer'   => 'Yes. Employee names, contact details, attendance records, salary information, bank details, identity documents, performance records, health-related documents and disciplinary records can all be personal data. Such data should be handled responsibly and accessed only by authorised persons.',
	),
	array(
		'question' => 'Does the DPDPA apply to small businesses and startups?',
		'answer'   => 'Yes. The DPDPA can apply to any organisation processing digital personal data, regardless of size, where the data relates to individuals and is processed in connection with offering goods or services.',
	),
	array(
		'question' => 'Does the DPDPA apply to offline data and handwritten forms?',
		'answer'   => 'The DPDPA applies to digital personal data. It can also apply when personal data is collected offline and later digitised. A handwritten form on its own may not be digital personal data, but once the details are scanned, typed into software or stored electronically, the digitised information can fall within scope.',
	),
	array(
		'question' => 'What should employees do if they suspect a data breach?',
		'answer'   => 'Report it immediately to the privacy, security, IT, legal or designated internal team. They should not delete evidence, delay reporting, contact affected individuals on their own, or try to fix the issue outside the incident-response process.',
	),
	array(
		'question' => 'We already ran a privacy session. Why do we need this?',
		'answer'   => 'A session reaches whoever attended and produces no ongoing evidence. This is assigned to every employee, tracked to completion, assessed and certified, so you have a record if a regulator, auditor, customer or board member asks what training has taken place.',
	),
	array(
		'question' => 'What language is the training available in?',
		'answer'   => 'The course is currently available in English. A Hindi version is in development and coming soon.',
	),
	array(
		'question' => 'What does it cost?',
		'answer'   => 'Pricing starts from ₹250 per employee per year, with volume rates above 1,000 employees and bundle pricing alongside our POSH programmes. Use the calculator above for an indicative figure, or book a demo for an exact quote.',
	),
	array(
		'question' => 'What are the penalties for non-compliance?',
		'answer'   => 'The DPDPA provides for significant financial penalties. Depending on the violation, penalties may go up to ₹250 crore for certain failures, such as failure to take reasonable security safeguards to prevent a personal data breach.',
	),
	array(
		'question' => 'Can we host it on our own LMS?',
		'answer'   => 'Yes. Take a SCORM package for your own LMS, use LTI, or run it on our SaaS platform with a branded portal, SSO and HRIS integration, completion tracking and automated reminders.',
	),
);
?>
<main id="main-content" class="sl-dpdpa-page">
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/hero' ); ?>
	<?php get_template_part( 'template-parts/home/stats' ); ?>
	<?php get_template_part( 'template-parts/home/clients' ); ?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/problem' ); ?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/roles' ); ?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/course' ); ?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/scorecard-cta' ); ?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/pricing' ); ?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/why-now' ); ?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/spec' ); ?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/testimonials' ); ?>
	<?php
	get_template_part(
		'template-parts/global/faq',
		null,
		array(
			'section_class' => 'sl-faq-section--alt',
			'eyebrow'       => 'Questions',
			'title'         => 'The questions buyers actually ask',
			'items'         => $dpdpa_faq_items,
		)
	);
	?>
	<?php get_template_part( 'template-parts/dpdpa-compliance-training/contact' ); ?>
</main>

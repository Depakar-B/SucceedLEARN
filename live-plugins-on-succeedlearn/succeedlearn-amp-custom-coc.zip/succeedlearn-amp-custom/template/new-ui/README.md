# New-UI AMP (Cyber US/UK + Infosec + SAP + Code of Conduct)

Canonical linked-pages checklist (desktop + AMP):  
`wp-content/plugins/succeedlearn-landing-bridge/LINKED-PAGES.md`

## Live slug → AMP wrapper

| Live slug | AMP template | New-UI page |
|---|---|---|
| `us-cyber-aware-october` | `template/us-cyber-aware-october.php` | `new-ui/pages/cybersecurity-awareness.php` |
| `uk-cyber-aware-october` | `template/uk-cyber-aware-october.php` | `new-ui/pages/cybersecurity-awareness.php` |
| `cybersecurity-awareness` (+ Infosec aliases) | `template/cybersecurity-awareness.php` | `new-ui/pages/infosec-2026-cyber.php` |
| `security-awareness` (+ `security-awareness-and-phishing`) | `template/security-awareness.php` | `new-ui/pages/security-awareness.php` |
| `code-of-conduct` (+ `code-of-conduct-elearning-training`, page ID 51624) | `template/code-of-conduct.php` | `new-ui/pages/code-of-conduct.php` |

Infosec aliases mapped to the Infosec AMP template:

- `infosec-cybersecurity-awareness-month-2026`
- `infosec-cybersecurity-awareness`
- `infosec-2026-cyber`
- `infosec-2026`

## Isolation from legacy AMP

- Legacy pages keep using `template/style.php`.
- New-UI CSS lives under `template/new-ui/styles/` and is included **only** by the wrappers above.
- Other AMP pages never load this folder.

## Deploy / test

1. Upload/replace `succeedlearn-amp-custom` (v1.9.5+) and merge desktop CoC theme patch if needed.
2. Keep AMPforWP active.
3. Smoke test:
   - `/us-cyber-aware-october/?amp=1`
   - `/uk-cyber-aware-october/?amp=1`
   - `/cybersecurity-awareness/?amp=1`
   - `/security-awareness/?amp=1`
   - `/code-of-conduct/?amp=1`
   - Desktop of the same URLs

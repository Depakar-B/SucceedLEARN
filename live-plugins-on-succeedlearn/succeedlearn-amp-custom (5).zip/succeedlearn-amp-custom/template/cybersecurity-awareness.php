<?php
/**
 * AMP template: Infosec campaign (new UI).
 * Live slug: cybersecurity-awareness
 *
 * Self-contained new-UI stack. Does not include legacy template/style.php.
 *
 * @package SucceedLearn_AMP_Custom
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once SUCCEEDLEARN_AMP_PATH . 'template/new-ui/includes/bootstrap.php';
require_once SUCCEEDLEARN_AMP_PATH . 'template/new-ui/pages/infosec-2026-cyber.php';

<?php
/**
 * Infosec 2026 Cyber — AMP data helpers.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include an Infosec 2026 Cyber section partial.
 *
 * @param string $name Partial basename without .php.
 */
function succeedlearn_amp_infosec_partial( $name ) {
	$path = SUCCEEDLEARN_AMP_TEMPLATES_DIR . 'partials/infosec-2026-cyber/' . sanitize_file_name( (string) $name ) . '.php';
	if ( is_readable( $path ) ) {
		include $path;
	}
}

/**
 * @return string
 */
function succeedlearn_amp_get_infosec_canonical_url() {
	$canonical = home_url( '/cybersecurity-awareness/' );
	$page      = get_page_by_path( 'cybersecurity-awareness' );
	if ( ! ( $page instanceof WP_Post ) || 'publish' !== $page->post_status ) {
		$page = get_page_by_path( 'infosec-cybersecurity-awareness-month-2026' );
	}
	if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
		$link = get_permalink( $page );
		if ( $link ) {
			return $link;
		}
	}
	return $canonical;
}

/**
 * @return string
 */
function succeedlearn_amp_get_infosec_page_title() {
	return __( 'Infosec Cybersecurity Awareness Month 2026', 'succeedlearn-amp' );
}

/**
 * @return string
 */
function succeedlearn_amp_get_infosec_meta_description() {
	return '';
}

/**
 * @return string
 */
function succeedlearn_amp_get_infosec_hero_image() {
	return '';
}


/**
 * Return the questions measured by the phishing simulation.
 *
 * @return array
 */
function succeedlearn_amp_infosec_testing_questions() {
	return array(
		__(
			'Will employees recognise the warning signs?',
			'succeedlearn-amp'
		),
		__(
			'Will they resist the click?',
			'succeedlearn-amp'
		),
		__(
			'Will they know what to do next?',
			'succeedlearn-amp'
		),
		__(
			'And most importantly: Where can you help them become stronger?',
			'succeedlearn-amp'
		),
	);
}


/**
 * Return the Cyber Readiness Challenge qualification criteria.
 *
 * @return array
 */
function succeedlearn_amp_infosec_challenge_criteria() {
	return array(
		array(
			'number' => '01',
			'title'  => __( 'ZERO (0) Employees', 'succeedlearn-amp' ),
			'text'   => __( 'successfully phished', 'succeedlearn-amp' ),
		),
		array(
			'number' => '02',
			'title'  => __( '80+ Overall', 'succeedlearn-amp' ),
			'text'   => __( 'Resiliency Score', 'succeedlearn-amp' ),
		),
	);
}

/**
 * Return the Cyber Readiness Challenge result paths.
 *
 * @return array
 */
function succeedlearn_amp_infosec_challenge_paths() {
	return array(
		array(
			'modifier'   => 'achieved',
			'label'      => __( 'Challenge Achieved', 'succeedlearn-amp' ),
			'title'      => __( 'Your organization demonstrates strong resilience.', 'succeedlearn-amp' ),
			'intro'      => array(),
			'subheading' => __( 'You Unlock', 'succeedlearn-amp' ),
			'benefits'   => array(
				array(
					'icon'        => 'repeat',
					'title'       => __( 'Another Phishing Simulation', 'succeedlearn-amp' ),
					'label'       => __( 'Complimentary', 'succeedlearn-amp' ),
					'description' => __( 'Run another round within the following six months to measure how employee behaviour evolves.', 'succeedlearn-amp' ),
				),
				array(
					'icon'        => 'training',
					'title'       => __( '6 Months of Standard Information Security Awareness Training', 'succeedlearn-amp' ),
					'label'       => __( 'Complimentary', 'succeedlearn-amp' ),
					'description' => __( 'Includes 3 Microlearning modules, with the option to choose from a pool of 50 microlearning modules.', 'succeedlearn-amp' ),
				),
			),
			'message'    => array(
				array(
					'text' => __( "You've demonstrated strong resilience. Now keep building on it.", 'succeedlearn-amp' ),
					'lead' => true,
				),
				array(
					'text' => __( 'Use the next six months to reinforce good behaviours, keep cybersecurity top of mind and test your workforce again to understand whether resilience continues.', 'succeedlearn-amp' ),
					'lead' => false,
				),
			),
		),
		array(
			'modifier'   => 'awareness',
			'label'      => __( 'Awareness Path', 'succeedlearn-amp' ),
			'title'      => __( 'Didn’t meet the Challenge criteria?', 'succeedlearn-amp' ),
			'intro'      => array(
				wp_kses_post(
					__(
						"That's not a failure. <strong>That's insight.</strong>",
						'succeedlearn-amp'
					)
				),
				__(
					'Your simulation has done exactly what it was designed to do: identify where additional awareness and reinforcement can make a difference.',
					'succeedlearn-amp'
				),
			),
			'subheading' => __( 'You Receive 3 Months Of', 'succeedlearn-amp' ),
			'benefits'   => array(
				array(
					'icon'        => 'training',
					'title'       => __( 'Information Security Awareness Training', 'succeedlearn-amp' ),
					'label'       => __( 'Complimentary', 'succeedlearn-amp' ),
					'description' => '',
				),
				array(
					'icon'        => 'modules',
					'title'       => __( '3 Microlearning Modules', 'succeedlearn-amp' ),
					'label'       => __( 'Complimentary', 'succeedlearn-amp' ),
					'description' => __( 'Choose from a pool of 50 microlearning modules.', 'succeedlearn-amp' ),
				),
			),
			'message'    => array(
				array(
					'text' => __( 'Use the results from your phishing simulation to focus employee learning on the behaviours and risks that matter.', 'succeedlearn-amp' ),
					'lead' => false,
				),
				array(
					'text' => __( 'Identify the gap. Build awareness. Come back stronger.', 'succeedlearn-amp' ),
					'lead' => true,
				),
			),
		),
	);
}

/**
 * Return the Cyber Readiness campaign steps.
 *
 * @return array
 */
function succeedlearn_amp_infosec_campaign_steps() {
	return array(
		array(
			'number'     => '01',
			'title'      => __( 'Enrol Your Workforce', 'succeedlearn-amp' ),
			'paragraphs' => array(
				__(
					'Choose the employees you want to include in your Cybersecurity Awareness Month campaign.',
					'succeedlearn-amp'
				),
			),
			'note'       => __(
				'Campaign pricing starts at $2/user/month',
				'succeedlearn-amp'
			),
			'list_intro' => '',
			'items'      => array(),
			'closing'    => '',
			'outcomes'   => array(),
			'continue'   => '',
			'cta'        => '',
			'final'      => false,
		),
		array(
			'number'     => '02',
			'title'      => __( 'Launch the Simulation', 'succeedlearn-amp' ),
			'paragraphs' => array(
				__(
					'A controlled phishing simulation is delivered to participating employees.',
					'succeedlearn-amp'
				),
				__(
					'The campaign recreates realistic phishing scenarios in a safe environment without exposing your organization to an actual malicious threat.',
					'succeedlearn-amp'
				),
			),
			'note'       => '',
			'list_intro' => '',
			'items'      => array(),
			'closing'    => '',
			'outcomes'   => array(),
			'continue'   => '',
			'cta'        => '',
			'final'      => false,
		),
		array(
			'number'     => '03',
			'title'      => __( 'Measure Your Cyber Resilience', 'succeedlearn-amp' ),
			'paragraphs' => array(
				__(
					"See how employees respond to the simulated attack and understand your organization's phishing resilience through campaign metrics and insights.",
					'succeedlearn-amp'
				),
			),
			'note'       => '',
			'list_intro' => '',
			'items'      => array(),
			'closing'    => '',
			'outcomes'   => array(),
			'continue'   => '',
			'cta'        => '',
			'final'      => false,
		),
		array(
			'number'     => '04',
			'title'      => __( 'Identify Awareness Gaps', 'succeedlearn-amp' ),
			'paragraphs' => array(),
			'note'       => '',
			'list_intro' => __( 'Your results help identify:', 'succeedlearn-amp' ),
			'items'      => array(
				__( 'Employee susceptibility', 'succeedlearn-amp' ),
				__( 'Phishing resilience', 'succeedlearn-amp' ),
				__( 'Behavioural risk', 'succeedlearn-amp' ),
				__( 'Awareness gaps', 'succeedlearn-amp' ),
				__( 'Areas for reinforcement', 'succeedlearn-amp' ),
			),
			'closing'    => __(
				'Instead of assuming where your vulnerabilities lie, you have measurable insight to work from.',
				'succeedlearn-amp'
			),
			'outcomes'   => array(),
			'continue'   => '',
			'cta'        => '',
			'final'      => false,
		),
		array(
			'number'     => '05',
			'title'      => __( 'Unlock Your Next Step', 'succeedlearn-amp' ),
			'paragraphs' => array(),
			'note'       => '',
			'list_intro' => '',
			'items'      => array(),
			'closing'    => '',
			'outcomes'   => array(
				array(
					'title' => __( 'Challenge Achieved?', 'succeedlearn-amp' ),
					'text'  => __(
						"Unlock 6 months of complimentary standard Information Security Awareness Training + 3 Microlearning modules (option to choose from a pool of 50 microlearning's), plus another complimentary phishing simulation within six months.",
						'succeedlearn-amp'
					),
				),
				array(
					'title' => __( 'Awareness Path?', 'succeedlearn-amp' ),
					'text'  => __(
						'Receive 3 months of complimentary Information Security Awareness Training + 3 Microlearning modules (option to choose from a pool of 50 microlearning’s) to help address the awareness gaps identified.',
						'succeedlearn-amp'
					),
				),
			),
			'continue'   => __(
				'Whatever the result, learning continues.',
				'succeedlearn-amp'
			),
			'cta'        => __(
				'Take the Cyber Readiness Challenge',
				'succeedlearn-amp'
			),
			'final'      => true,
		),
	);
}

/**
 * Return the insights provided by the phishing simulation.
 *
 * @return array
 */
function succeedlearn_amp_infosec_simulation_insights() {
	return array(
		array(
			'number' => '01',
			'title'  => __( 'Employee Susceptibility', 'succeedlearn-amp' ),
			'text'   => __(
				'Understand how employees respond when confronted with a realistic simulated phishing attempt.',
				'succeedlearn-amp'
			),
		),
		array(
			'number' => '02',
			'title'  => __( 'Phishing Resilience', 'succeedlearn-amp' ),
			'text'   => __(
				"Measure your workforce's ability to recognize and withstand simulated phishing threats.",
				'succeedlearn-amp'
			),
		),
		array(
			'number' => '03',
			'title'  => __( 'Behavioural Risk', 'succeedlearn-amp' ),
			'text'   => __(
				'Identify employee actions that could create exposure during a real-world attack.',
				'succeedlearn-amp'
			),
		),
		array(
			'number' => '04',
			'title'  => __( 'Awareness Gaps', 'succeedlearn-amp' ),
			'text'   => __(
				'Discover areas where employees may require further education or reinforcement.',
				'succeedlearn-amp'
			),
		),
		array(
			'number' => '05',
			'title'  => __( 'Campaign Metrics', 'succeedlearn-amp' ),
			'text'   => __(
				'Use measurable campaign insights to guide future cybersecurity awareness initiatives.',
				'succeedlearn-amp'
			),
		),
	);
}
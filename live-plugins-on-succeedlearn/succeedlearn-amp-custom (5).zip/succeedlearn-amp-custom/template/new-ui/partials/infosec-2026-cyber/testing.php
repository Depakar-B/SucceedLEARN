<?php
/**
 * Infosec Cybersecurity Awareness Month 2026 AMP - Testing section.
 *
 * @package SucceedLEARN\AMP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$testing_questions = succeedlearn_amp_infosec_testing_questions();
?>

<section
	class="sl-section sl-infosec-2026-cyber-testing"
	aria-labelledby="sl-infosec-2026-cyber-testing-title"
>
	<div class="sl-wrap">
		<div class="sl-infosec-2026-cyber-testing__grid">
			<div class="sl-infosec-2026-cyber-testing__content">
				<span class="sl-home-sub-heading">
					<?php
					esc_html_e(
						'FROM AWARENESS TO ACTION',
						'succeedlearn-amp'
					);
					?>
				</span>

				<h2
					id="sl-infosec-2026-cyber-testing-title"
					class="sl-h2"
				>
					<?php
					echo wp_kses_post(
						__(
							'One Click Can Be <span>Expensive.</span> Testing Doesn’t Have to Be.',
							'succeedlearn-amp'
						)
					);
					?>
				</h2>

				<p>
					<?php
					esc_html_e(
						'Cybersecurity awareness shouldn’t end when an employee completes a course.',
						'succeedlearn-amp'
					);
					?>
				</p>

				<p>
					<?php
					esc_html_e(
						'A phishing simulation allows you to see how awareness translates into real-world decisions.',
						'succeedlearn-amp'
					);
					?>
				</p>

				<ul class="sl-list sl-infosec-2026-cyber-testing__questions">
					<?php foreach ( $testing_questions as $question ) : ?>
						<li class="sl-list-item">
							<span
								class="sl-infosec-2026-cyber-testing__question-mark"
								aria-hidden="true"
							></span>

							<span class="sl-list-item__text">
								<?php echo esc_html( $question ); ?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>

				<p>
					<?php
					esc_html_e(
						'This campaign isn’t about catching employees out or highlighting failure.',
						'succeedlearn-amp'
					);
					?>
				</p>

				<p class="sl-infosec-2026-cyber-testing__emphasis">
					<?php
					esc_html_e(
						"It's about turning employee behaviour into an opportunity to learn.",
						'succeedlearn-amp'
					);
					?>
				</p>
			</div>

			<div class="sl-infosec-2026-cyber-testing__visual">
				<div
					class="sl-infosec-2026-cyber-testing__image-placeholder"
					role="img"
					aria-label="<?php esc_attr_e( 'Cybersecurity testing image placeholder, recommended size 600 by 600 pixels', 'succeedlearn-amp' ); ?>"
				>
					<span>
						<?php esc_html_e( 'Image placeholder', 'succeedlearn-amp' ); ?>
					</span>

					<small>
						<?php esc_html_e( 'Recommended: 600 × 600 px', 'succeedlearn-amp' ); ?>
					</small>
				</div>
			</div>
		</div>
	</div>
</section>
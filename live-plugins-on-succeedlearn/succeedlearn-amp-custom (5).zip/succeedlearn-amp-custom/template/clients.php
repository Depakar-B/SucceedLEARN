<?php
/**
 * AMP template: Clients (all logos)
 */
?>
<!doctype html>
<html amp lang="en">
<head>
	<meta charset="utf-8">
	<title>Clients | SucceedLEARN</title>
	<link rel="canonical" href="<?php echo esc_url( home_url( '/clients/' ) ); ?>">
	<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
	<link rel="preconnect" href="https://cdn.ampproject.org" crossorigin>
	<link rel="dns-prefetch" href="//cdn.ampproject.org">
	<script async src="https://cdn.ampproject.org/v0.js"></script>
	<script async custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js"></script>
	<script async custom-element="amp-consent" src="https://cdn.ampproject.org/v0/amp-consent-0.1.js"></script>

	<style amp-boilerplate>
		body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;
		-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;
		-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;
		animation:-amp-start 8s steps(1,end) 0s 1 normal both}
		@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}
		@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}
		@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}
		@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}
		@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}
	</style>
	<noscript>
		<style amp-boilerplate>
			body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}
		</style>
	</noscript>

	<style amp-custom>
		<?php include( 'style.php' ); ?>
	</style>
</head>
<body>
	<?php include( plugin_dir_path( __FILE__ ) . 'amp-cookie-consent.php' ); ?>
	<?php include( plugin_dir_path( __FILE__ ) . 'menu.php' ); ?>

	<main id="main-content">
		<?php
		include_once plugin_dir_path( __FILE__ ) . 'clients-marquee.php';
		render_succeedlearn_clients_marquee(
			array(
				'title_tag'      => 'h1',
				'title_html'     => '<span class="black">Our </span><span class="blue">Clients</span>',
				'max_logos'      => 0,
				'show_view_all'  => false,
			)
		);
		?>

		<?php include( plugin_dir_path( __FILE__ ) . 'footer.php' ); ?>
	</main>
</body>
</html>


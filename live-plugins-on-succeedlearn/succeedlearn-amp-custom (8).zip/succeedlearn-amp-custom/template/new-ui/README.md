# New-UI AMP (Cyber + Infosec only)

These templates are used only when the page slug matches:

| Live slug | AMP template | Source page |
|---|---|---|
| `us-cyber-aware-october` | `template/us-cyber-aware-october.php` | Cyber October campaign |
| `cybersecurity-awareness` | `template/cybersecurity-awareness.php` | Infosec campaign |

## Isolation from legacy AMP

- Legacy pages keep using `template/style.php`.
- New-UI CSS lives under `template/new-ui/styles/` and is included **only** by the two wrappers above.
- Other AMP pages never load this folder.

## Deploy

1. Upload/replace the updated `succeedlearn-amp-custom` plugin on live.
2. Create/publish the two WP pages with those slugs.
3. Keep AMPforWP + this plugin active.
4. Test:
   - `/us-cyber-aware-october/?amp=1` (canonical AMP)
   - `/us-cyber-aware-october/?amp` (should redirect to `?amp=1`)
   - Mobile/tablet open of `/us-cyber-aware-october/` and `/cybersecurity-awareness/` should redirect to `?amp=1`
   - Desktop open of those URLs stays desktop (use `?noamp=1` to force desktop on mobile)
   - One existing AMP page (must still look the same)

Note: AMPforWP only treats `amp=1` as AMP. v1.8.1+ redirects bare `?amp` to `?amp=1`. v1.8.2 forces AMP on mobile/tablet for Cyber + Infosec only.

## Grow later

Add another new-UI page by:

1. Copy page/partials/styles into `template/new-ui/`
2. Add a thin wrapper under `template/`
3. Map the slug in `succeedlearn_amp_main_template_file()`

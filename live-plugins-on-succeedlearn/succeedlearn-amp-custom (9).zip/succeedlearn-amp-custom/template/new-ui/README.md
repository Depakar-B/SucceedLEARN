# New-UI AMP (Cyber US/UK + Infosec)

These templates are used only when the page slug matches:

| Live slug | AMP template | Source page |
|---|---|---|
| `us-cyber-aware-october` | `template/us-cyber-aware-october.php` | Cyber October campaign (US) |
| `uk-cyber-aware-october` | `template/uk-cyber-aware-october.php` | Cyber October campaign (UK) |
| `cybersecurity-awareness` | `template/cybersecurity-awareness.php` | Infosec campaign |

## Isolation from legacy AMP

- Legacy pages keep using `template/style.php`.
- New-UI CSS lives under `template/new-ui/styles/` and is included **only** by the wrappers above.
- Other AMP pages never load this folder.

## Deploy

1. Upload/replace the updated `succeedlearn-amp-custom` plugin on live.
2. Create/publish WP pages with those slugs and assign the matching Landing Bridge templates.
3. Keep AMPforWP + this plugin active.
4. Test:
   - `/us-cyber-aware-october/?amp=1`
   - `/uk-cyber-aware-october/?amp=1` (UK pricing £ + UK Stripe links)
   - `/cybersecurity-awareness/?amp=1`
   - Mobile/tablet open of those URLs should redirect to `?amp=1`
   - One existing AMP page (must still look the same)

Note: AMPforWP only treats `amp=1` as AMP. Bare `?amp` redirects to `?amp=1`. Mobile/tablet force-AMP covers US Cyber, UK Cyber, and Infosec.
